ATOLL RISING SERVER
===================

Run your own Atoll Rising multiplayer server. Players find it in the game's Multiplayer screen.

1. Unpack this folder anywhere (keep the "game" folder next to the program).
2. Start atollrising-server (Windows: double-click atollrising-server.exe; Linux: ./atollrising-server).
   Windows may say "Windows protected your PC" because the program is not signed yet:
   click "More info", then "Run anyway". When the Windows firewall asks, allow it.
3. On your router, forward TCP port 25564 to this computer.

On the first start the server:
- makes atollrising-server.json with its settings (title, name, port), and
- gets its own address, for example https://reef-4821.atollrising.eu:25564/, with a certificate
  from Let's Encrypt (takes a minute or two).
It then shows up in the game's server list while it runs. The console window says if the port
cannot be reached from the internet.

Settings (atollrising-server.json, restart after a change):
  title     the name shown in the server list (up to 40 characters)
  name      your address NAME.atollrising.eu; 3-20 letters, digits or hyphens.
            Only used on the very first start (empty: one is picked for you).
  port      the TCP port players connect to (forward it on your router)
  maxGames  at most this many games at the same time (1-20)

Keep server-identity.json and the "certificate" folder private: they prove this server owns its address.
Whoever runs a server runs the games, so the server can see everything in them.
