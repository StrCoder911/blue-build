(function(){let e=document.createElement(`link`).relList;if(e&&e.supports&&e.supports(`modulepreload`))return;for(let e of document.querySelectorAll(`link[rel="modulepreload"]`))n(e);new MutationObserver(e=>{for(let t of e)if(t.type===`childList`)for(let e of t.addedNodes)e.tagName===`LINK`&&e.rel===`modulepreload`&&n(e)}).observe(document,{childList:!0,subtree:!0});function t(e){let t={};return e.integrity&&(t.integrity=e.integrity),e.referrerPolicy&&(t.referrerPolicy=e.referrerPolicy),t.credentials=e.crossOrigin===`use-credentials`?`include`:e.crossOrigin===`anonymous`?`omit`:`same-origin`,t}function n(e){if(e.ep)return;e.ep=!0;let n=t(e);fetch(e.href,n)}})();var e=1e3,t=1001,n=1002,r=1003,i=1004,a=1005,o=1006,s=1007,c=1008,l=1009,u=1010,d=1011,f=1012,p=1013,m=1014,h=1015,g=1016,_=1017,v=1018,y=1020,b=35902,x=35899,S=1021,C=1022,w=1023,T=1026,E=1027,D=1028,O=1029,k=1030,A=1031,ee=1033,j=33776,te=33777,M=33778,ne=33779,N=35840,re=35841,ie=35842,ae=35843,oe=36196,se=37492,ce=37496,le=37488,ue=37489,de=37490,fe=37491,pe=37808,me=37809,he=37810,ge=37811,_e=37812,ve=37813,ye=37814,be=37815,xe=37816,Se=37817,Ce=37818,we=37819,Te=37820,Ee=37821,De=36492,Oe=36494,ke=36495,Ae=36283,je=36284,Me=36285,Ne=36286,Pe=2300,Fe=2301,P=2302,Ie=2303,Le=2400,Re=2401,F=2402,ze=3200,Be=`srgb`,Ve=`srgb-linear`,He=`linear`,Ue=`srgb`,We=7680,Ge=35044,Ke=35048,qe=2e3;function Je(e){for(let t=e.length-1;t>=0;--t)if(e[t]>=65535)return!0;return!1}function Ye(e){return ArrayBuffer.isView(e)&&!(e instanceof DataView)}function Xe(e){return document.createElementNS(`http://www.w3.org/1999/xhtml`,e)}function Ze(){let e=Xe(`canvas`);return e.style.display=`block`,e}var Qe={};function $e(...e){let t=`THREE.`+e.shift();console.log(t,...e)}function et(e){let t=e[0];if(typeof t==`string`&&t.startsWith(`TSL:`)){let t=e[1];t&&t.isStackTrace?e[0]+=` `+t.getLocation():e[1]=`Stack trace not available. Enable "THREE.Node.captureStackTrace" to capture stack traces.`}return e}function tt(...e){e=et(e);let t=`THREE.`+e.shift();{let n=e[0];n&&n.isStackTrace?console.warn(n.getError(t)):console.warn(t,...e)}}function nt(...e){e=et(e);let t=`THREE.`+e.shift();{let n=e[0];n&&n.isStackTrace?console.error(n.getError(t)):console.error(t,...e)}}function rt(...e){let t=e.join(` `);t in Qe||(Qe[t]=!0,tt(...e))}function it(e,t,n){return new Promise(function(r,i){function a(){switch(e.clientWaitSync(t,e.SYNC_FLUSH_COMMANDS_BIT,0)){case e.WAIT_FAILED:i();break;case e.TIMEOUT_EXPIRED:setTimeout(a,n);break;default:r()}}setTimeout(a,n)})}var at={0:0,2:6,4:4,3:5,1:1,6:2,7:7,5:3},ot=class{addEventListener(e,t){this._listeners===void 0&&(this._listeners={});let n=this._listeners;n[e]===void 0&&(n[e]=[]),n[e].indexOf(t)===-1&&n[e].push(t)}hasEventListener(e,t){let n=this._listeners;return n!==void 0&&n[e]!==void 0&&n[e].indexOf(t)!==-1}removeEventListener(e,t){let n=this._listeners;if(n===void 0)return;let r=n[e];if(r!==void 0){let e=r.indexOf(t);e!==-1&&r.splice(e,1)}}dispatchEvent(e){let t=this._listeners;if(t===void 0)return;let n=t[e.type];if(n!==void 0){e.target=this;let t=n.slice(0);for(let n=0,r=t.length;n<r;n++)t[n].call(this,e);e.target=null}}},st=`00.01.02.03.04.05.06.07.08.09.0a.0b.0c.0d.0e.0f.10.11.12.13.14.15.16.17.18.19.1a.1b.1c.1d.1e.1f.20.21.22.23.24.25.26.27.28.29.2a.2b.2c.2d.2e.2f.30.31.32.33.34.35.36.37.38.39.3a.3b.3c.3d.3e.3f.40.41.42.43.44.45.46.47.48.49.4a.4b.4c.4d.4e.4f.50.51.52.53.54.55.56.57.58.59.5a.5b.5c.5d.5e.5f.60.61.62.63.64.65.66.67.68.69.6a.6b.6c.6d.6e.6f.70.71.72.73.74.75.76.77.78.79.7a.7b.7c.7d.7e.7f.80.81.82.83.84.85.86.87.88.89.8a.8b.8c.8d.8e.8f.90.91.92.93.94.95.96.97.98.99.9a.9b.9c.9d.9e.9f.a0.a1.a2.a3.a4.a5.a6.a7.a8.a9.aa.ab.ac.ad.ae.af.b0.b1.b2.b3.b4.b5.b6.b7.b8.b9.ba.bb.bc.bd.be.bf.c0.c1.c2.c3.c4.c5.c6.c7.c8.c9.ca.cb.cc.cd.ce.cf.d0.d1.d2.d3.d4.d5.d6.d7.d8.d9.da.db.dc.dd.de.df.e0.e1.e2.e3.e4.e5.e6.e7.e8.e9.ea.eb.ec.ed.ee.ef.f0.f1.f2.f3.f4.f5.f6.f7.f8.f9.fa.fb.fc.fd.fe.ff`.split(`.`),ct=1234567,lt=Math.PI/180,ut=180/Math.PI;function dt(){let e=Math.random()*4294967295|0,t=Math.random()*4294967295|0,n=Math.random()*4294967295|0,r=Math.random()*4294967295|0;return(st[e&255]+st[e>>8&255]+st[e>>16&255]+st[e>>24&255]+`-`+st[t&255]+st[t>>8&255]+`-`+st[t>>16&15|64]+st[t>>24&255]+`-`+st[n&63|128]+st[n>>8&255]+`-`+st[n>>16&255]+st[n>>24&255]+st[r&255]+st[r>>8&255]+st[r>>16&255]+st[r>>24&255]).toLowerCase()}function ft(e,t,n){return Math.max(t,Math.min(n,e))}function pt(e,t){return(e%t+t)%t}function mt(e,t,n,r,i){return r+(e-t)*(i-r)/(n-t)}function ht(e,t,n){return e===t?0:(n-e)/(t-e)}function gt(e,t,n){return(1-n)*e+n*t}function _t(e,t,n,r){return gt(e,t,1-Math.exp(-n*r))}function vt(e,t=1){return t-Math.abs(pt(e,t*2)-t)}function yt(e,t,n){return e<=t?0:e>=n?1:(e=(e-t)/(n-t),e*e*(3-2*e))}function bt(e,t,n){return e<=t?0:e>=n?1:(e=(e-t)/(n-t),e*e*e*(e*(e*6-15)+10))}function xt(e,t){return e+Math.floor(Math.random()*(t-e+1))}function St(e,t){return e+Math.random()*(t-e)}function Ct(e){return e*(.5-Math.random())}function wt(e){e!==void 0&&(ct=e);let t=ct+=1831565813;return t=Math.imul(t^t>>>15,t|1),t^=t+Math.imul(t^t>>>7,t|61),((t^t>>>14)>>>0)/4294967296}function Tt(e){return e*lt}function Et(e){return e*ut}function Dt(e){return e>0&&Number.isInteger(e)&&2**Math.round(Math.log2(e))===e}function Ot(e){return 2**Math.ceil(Math.log(e)/Math.LN2)}function kt(e){return 2**Math.floor(Math.log(e)/Math.LN2)}function At(e,t,n,r,i){let a=Math.cos,o=Math.sin,s=a(n/2),c=o(n/2),l=a((t+r)/2),u=o((t+r)/2),d=a((t-r)/2),f=o((t-r)/2),p=a((r-t)/2),m=o((r-t)/2);switch(i){case`XYX`:e.set(s*u,c*d,c*f,s*l);break;case`YZY`:e.set(c*f,s*u,c*d,s*l);break;case`ZXZ`:e.set(c*d,c*f,s*u,s*l);break;case`XZX`:e.set(s*u,c*m,c*p,s*l);break;case`YXY`:e.set(c*p,s*u,c*m,s*l);break;case`ZYZ`:e.set(c*m,c*p,s*u,s*l);break;default:tt(`MathUtils: .setQuaternionFromProperEuler() encountered an unknown order: `+i)}}function jt(e){switch(e.constructor){case Uint32Array:return 4294967295;case Uint16Array:return 65535;case Uint8Array:case Uint8ClampedArray:return 255;case Int32Array:return 2147483647;case Int16Array:return 32767;case Int8Array:return 127;default:return}}function Mt(e,t){if(t.constructor===Float32Array)return e;let n=jt(t);if(n===void 0)throw Error(`THREE.MathUtils: Invalid component type.`);return Math.max(e/n,-1)}function Nt(e,t){if(t.constructor===Float32Array)return e;let n=jt(t);if(n===void 0)throw Error(`THREE.MathUtils: Invalid component type.`);return Math.round(e*n)}var Pt={DEG2RAD:lt,RAD2DEG:ut,generateUUID:dt,clamp:ft,euclideanModulo:pt,mapLinear:mt,inverseLerp:ht,lerp:gt,damp:_t,pingpong:vt,smoothstep:yt,smootherstep:bt,randInt:xt,randFloat:St,randFloatSpread:Ct,seededRandom:wt,degToRad:Tt,radToDeg:Et,isPowerOfTwo:Dt,ceilPowerOfTwo:Ot,floorPowerOfTwo:kt,setQuaternionFromProperEuler:At,normalize:Nt,denormalize:Mt},I=class{static{this.prototype.isVector2=!0}constructor(e=0,t=0){this.x=e,this.y=t}get width(){return this.x}set width(e){this.x=e}get height(){return this.y}set height(e){this.y=e}set(e,t){return this.x=e,this.y=t,this}setScalar(e){return this.x=e,this.y=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setComponent(e,t){switch(e){case 0:this.x=t;break;case 1:this.y=t;break;default:throw Error(`THREE.Vector2: index is out of range: `+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;default:throw Error(`THREE.Vector2: index is out of range: `+e)}}clone(){return new this.constructor(this.x,this.y)}copy(e){return this.x=e.x,this.y=e.y,this}add(e){return this.x+=e.x,this.y+=e.y,this}addScalar(e){return this.x+=e,this.y+=e,this}addVectors(e,t){return this.x=e.x+t.x,this.y=e.y+t.y,this}addScaledVector(e,t){return this.x+=e.x*t,this.y+=e.y*t,this}sub(e){return this.x-=e.x,this.y-=e.y,this}subScalar(e){return this.x-=e,this.y-=e,this}subVectors(e,t){return this.x=e.x-t.x,this.y=e.y-t.y,this}multiply(e){return this.x*=e.x,this.y*=e.y,this}multiplyScalar(e){return this.x*=e,this.y*=e,this}divide(e){return this.x/=e.x,this.y/=e.y,this}divideScalar(e){return this.multiplyScalar(1/e)}applyMatrix3(e){let t=this.x,n=this.y,r=e.elements;return this.x=r[0]*t+r[3]*n+r[6],this.y=r[1]*t+r[4]*n+r[7],this}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this}clamp(e,t){return this.x=ft(this.x,e.x,t.x),this.y=ft(this.y,e.y,t.y),this}clampScalar(e,t){return this.x=ft(this.x,e,t),this.y=ft(this.y,e,t),this}clampLength(e,t){let n=this.length();return this.divideScalar(n||1).multiplyScalar(ft(n,e,t))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this}negate(){return this.x=-this.x,this.y=-this.y,this}dot(e){return this.x*e.x+this.y*e.y}cross(e){return this.x*e.y-this.y*e.x}lengthSq(){return this.x*this.x+this.y*this.y}length(){return Math.sqrt(this.x*this.x+this.y*this.y)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)}normalize(){return this.divideScalar(this.length()||1)}angle(){return Math.atan2(-this.y,-this.x)+Math.PI}angleTo(e){let t=Math.sqrt(this.lengthSq()*e.lengthSq());if(t===0)return Math.PI/2;let n=this.dot(e)/t;return Math.acos(ft(n,-1,1))}distanceTo(e){return Math.sqrt(this.distanceToSquared(e))}distanceToSquared(e){let t=this.x-e.x,n=this.y-e.y;return t*t+n*n}manhattanDistanceTo(e){return Math.abs(this.x-e.x)+Math.abs(this.y-e.y)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,t){return this.x+=(e.x-this.x)*t,this.y+=(e.y-this.y)*t,this}lerpVectors(e,t,n){return this.x=e.x+(t.x-e.x)*n,this.y=e.y+(t.y-e.y)*n,this}equals(e){return e.x===this.x&&e.y===this.y}fromArray(e,t=0){return this.x=e[t],this.y=e[t+1],this}toArray(e=[],t=0){return e[t]=this.x,e[t+1]=this.y,e}fromBufferAttribute(e,t){return this.x=e.getX(t),this.y=e.getY(t),this}rotateAround(e,t){let n=Math.cos(t),r=Math.sin(t),i=this.x-e.x,a=this.y-e.y;return this.x=i*n-a*r+e.x,this.y=i*r+a*n+e.y,this}random(){return this.x=Math.random(),this.y=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y}},Ft=class{constructor(e=0,t=0,n=0,r=1){this.isQuaternion=!0,this._x=e,this._y=t,this._z=n,this._w=r}static slerpFlat(e,t,n,r,i,a,o){let s=n[r+0],c=n[r+1],l=n[r+2],u=n[r+3],d=i[a+0],f=i[a+1],p=i[a+2],m=i[a+3];if(u!==m||s!==d||c!==f||l!==p){let e=s*d+c*f+l*p+u*m;e<0&&(d=-d,f=-f,p=-p,m=-m,e=-e);let t=1-o;if(e<.9995){let n=Math.acos(e),r=Math.sin(n);t=Math.sin(t*n)/r,o=Math.sin(o*n)/r,s=s*t+d*o,c=c*t+f*o,l=l*t+p*o,u=u*t+m*o}else{s=s*t+d*o,c=c*t+f*o,l=l*t+p*o,u=u*t+m*o;let e=1/Math.sqrt(s*s+c*c+l*l+u*u);s*=e,c*=e,l*=e,u*=e}}e[t]=s,e[t+1]=c,e[t+2]=l,e[t+3]=u}static multiplyQuaternionsFlat(e,t,n,r,i,a){let o=n[r],s=n[r+1],c=n[r+2],l=n[r+3],u=i[a],d=i[a+1],f=i[a+2],p=i[a+3];return e[t]=o*p+l*u+s*f-c*d,e[t+1]=s*p+l*d+c*u-o*f,e[t+2]=c*p+l*f+o*d-s*u,e[t+3]=l*p-o*u-s*d-c*f,e}get x(){return this._x}set x(e){this._x=e,this._onChangeCallback()}get y(){return this._y}set y(e){this._y=e,this._onChangeCallback()}get z(){return this._z}set z(e){this._z=e,this._onChangeCallback()}get w(){return this._w}set w(e){this._w=e,this._onChangeCallback()}set(e,t,n,r){return this._x=e,this._y=t,this._z=n,this._w=r,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._w)}copy(e){return this._x=e.x,this._y=e.y,this._z=e.z,this._w=e.w,this._onChangeCallback(),this}setFromEuler(e,t=!0){let n=e._x,r=e._y,i=e._z,a=e._order,o=Math.cos,s=Math.sin,c=o(n/2),l=o(r/2),u=o(i/2),d=s(n/2),f=s(r/2),p=s(i/2);switch(a){case`XYZ`:this._x=d*l*u+c*f*p,this._y=c*f*u-d*l*p,this._z=c*l*p+d*f*u,this._w=c*l*u-d*f*p;break;case`YXZ`:this._x=d*l*u+c*f*p,this._y=c*f*u-d*l*p,this._z=c*l*p-d*f*u,this._w=c*l*u+d*f*p;break;case`ZXY`:this._x=d*l*u-c*f*p,this._y=c*f*u+d*l*p,this._z=c*l*p+d*f*u,this._w=c*l*u-d*f*p;break;case`ZYX`:this._x=d*l*u-c*f*p,this._y=c*f*u+d*l*p,this._z=c*l*p-d*f*u,this._w=c*l*u+d*f*p;break;case`YZX`:this._x=d*l*u+c*f*p,this._y=c*f*u+d*l*p,this._z=c*l*p-d*f*u,this._w=c*l*u-d*f*p;break;case`XZY`:this._x=d*l*u-c*f*p,this._y=c*f*u-d*l*p,this._z=c*l*p+d*f*u,this._w=c*l*u+d*f*p;break;default:tt(`Quaternion: .setFromEuler() encountered an unknown order: `+a)}return t===!0&&this._onChangeCallback(),this}setFromAxisAngle(e,t){let n=t/2,r=Math.sin(n);return this._x=e.x*r,this._y=e.y*r,this._z=e.z*r,this._w=Math.cos(n),this._onChangeCallback(),this}setFromRotationMatrix(e){let t=e.elements,n=t[0],r=t[4],i=t[8],a=t[1],o=t[5],s=t[9],c=t[2],l=t[6],u=t[10],d=n+o+u;if(d>0){let e=.5/Math.sqrt(d+1);this._w=.25/e,this._x=(l-s)*e,this._y=(i-c)*e,this._z=(a-r)*e}else if(n>o&&n>u){let e=2*Math.sqrt(1+n-o-u);this._w=(l-s)/e,this._x=.25*e,this._y=(r+a)/e,this._z=(i+c)/e}else if(o>u){let e=2*Math.sqrt(1+o-n-u);this._w=(i-c)/e,this._x=(r+a)/e,this._y=.25*e,this._z=(s+l)/e}else{let e=2*Math.sqrt(1+u-n-o);this._w=(a-r)/e,this._x=(i+c)/e,this._y=(s+l)/e,this._z=.25*e}return this._onChangeCallback(),this}setFromUnitVectors(e,t){let n=e.dot(t)+1;return n<1e-8?(n=0,Math.abs(e.x)>Math.abs(e.z)?(this._x=-e.y,this._y=e.x,this._z=0,this._w=n):(this._x=0,this._y=-e.z,this._z=e.y,this._w=n)):(this._x=e.y*t.z-e.z*t.y,this._y=e.z*t.x-e.x*t.z,this._z=e.x*t.y-e.y*t.x,this._w=n),this.normalize()}angleTo(e){return 2*Math.acos(Math.abs(ft(this.dot(e),-1,1)))}rotateTowards(e,t){let n=this.angleTo(e);if(n===0)return this;let r=Math.min(1,t/n);return this.slerp(e,r),this}identity(){return this.set(0,0,0,1)}invert(){return this.conjugate()}conjugate(){return this._x*=-1,this._y*=-1,this._z*=-1,this._onChangeCallback(),this}dot(e){return this._x*e._x+this._y*e._y+this._z*e._z+this._w*e._w}lengthSq(){return this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w}length(){return Math.sqrt(this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w)}normalize(){let e=this.length();return e===0?(this._x=0,this._y=0,this._z=0,this._w=1):(e=1/e,this._x*=e,this._y*=e,this._z*=e,this._w*=e),this._onChangeCallback(),this}multiply(e){return this.multiplyQuaternions(this,e)}premultiply(e){return this.multiplyQuaternions(e,this)}multiplyQuaternions(e,t){let n=e._x,r=e._y,i=e._z,a=e._w,o=t._x,s=t._y,c=t._z,l=t._w;return this._x=n*l+a*o+r*c-i*s,this._y=r*l+a*s+i*o-n*c,this._z=i*l+a*c+n*s-r*o,this._w=a*l-n*o-r*s-i*c,this._onChangeCallback(),this}slerp(e,t){let n=e._x,r=e._y,i=e._z,a=e._w,o=this.dot(e);o<0&&(n=-n,r=-r,i=-i,a=-a,o=-o);let s=1-t;if(o<.9995){let e=Math.acos(o),c=Math.sin(e);s=Math.sin(s*e)/c,t=Math.sin(t*e)/c,this._x=this._x*s+n*t,this._y=this._y*s+r*t,this._z=this._z*s+i*t,this._w=this._w*s+a*t,this._onChangeCallback()}else this._x=this._x*s+n*t,this._y=this._y*s+r*t,this._z=this._z*s+i*t,this._w=this._w*s+a*t,this.normalize();return this}slerpQuaternions(e,t,n){return this.copy(e).slerp(t,n)}random(){let e=2*Math.PI*Math.random(),t=2*Math.PI*Math.random(),n=Math.random(),r=Math.sqrt(1-n),i=Math.sqrt(n);return this.set(r*Math.sin(e),r*Math.cos(e),i*Math.sin(t),i*Math.cos(t))}equals(e){return e._x===this._x&&e._y===this._y&&e._z===this._z&&e._w===this._w}fromArray(e,t=0){return this._x=e[t],this._y=e[t+1],this._z=e[t+2],this._w=e[t+3],this._onChangeCallback(),this}toArray(e=[],t=0){return e[t]=this._x,e[t+1]=this._y,e[t+2]=this._z,e[t+3]=this._w,e}fromBufferAttribute(e,t){return this._x=e.getX(t),this._y=e.getY(t),this._z=e.getZ(t),this._w=e.getW(t),this._onChangeCallback(),this}toJSON(){return this.toArray()}_onChange(e){return this._onChangeCallback=e,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._w}},L=class{static{this.prototype.isVector3=!0}constructor(e=0,t=0,n=0){this.x=e,this.y=t,this.z=n}set(e,t,n){return n===void 0&&(n=this.z),this.x=e,this.y=t,this.z=n,this}setScalar(e){return this.x=e,this.y=e,this.z=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setZ(e){return this.z=e,this}setComponent(e,t){switch(e){case 0:this.x=t;break;case 1:this.y=t;break;case 2:this.z=t;break;default:throw Error(`THREE.Vector3: index is out of range: `+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;case 2:return this.z;default:throw Error(`THREE.Vector3: index is out of range: `+e)}}clone(){return new this.constructor(this.x,this.y,this.z)}copy(e){return this.x=e.x,this.y=e.y,this.z=e.z,this}add(e){return this.x+=e.x,this.y+=e.y,this.z+=e.z,this}addScalar(e){return this.x+=e,this.y+=e,this.z+=e,this}addVectors(e,t){return this.x=e.x+t.x,this.y=e.y+t.y,this.z=e.z+t.z,this}addScaledVector(e,t){return this.x+=e.x*t,this.y+=e.y*t,this.z+=e.z*t,this}sub(e){return this.x-=e.x,this.y-=e.y,this.z-=e.z,this}subScalar(e){return this.x-=e,this.y-=e,this.z-=e,this}subVectors(e,t){return this.x=e.x-t.x,this.y=e.y-t.y,this.z=e.z-t.z,this}multiply(e){return this.x*=e.x,this.y*=e.y,this.z*=e.z,this}multiplyScalar(e){return this.x*=e,this.y*=e,this.z*=e,this}multiplyVectors(e,t){return this.x=e.x*t.x,this.y=e.y*t.y,this.z=e.z*t.z,this}applyEuler(e){return this.applyQuaternion(Lt.setFromEuler(e))}applyAxisAngle(e,t){return this.applyQuaternion(Lt.setFromAxisAngle(e,t))}applyMatrix3(e){let t=this.x,n=this.y,r=this.z,i=e.elements;return this.x=i[0]*t+i[3]*n+i[6]*r,this.y=i[1]*t+i[4]*n+i[7]*r,this.z=i[2]*t+i[5]*n+i[8]*r,this}applyNormalMatrix(e){return this.applyMatrix3(e).normalize()}applyMatrix4(e){let t=this.x,n=this.y,r=this.z,i=e.elements,a=1/(i[3]*t+i[7]*n+i[11]*r+i[15]);return this.x=(i[0]*t+i[4]*n+i[8]*r+i[12])*a,this.y=(i[1]*t+i[5]*n+i[9]*r+i[13])*a,this.z=(i[2]*t+i[6]*n+i[10]*r+i[14])*a,this}applyQuaternion(e){let t=this.x,n=this.y,r=this.z,i=e.x,a=e.y,o=e.z,s=e.w,c=2*(a*r-o*n),l=2*(o*t-i*r),u=2*(i*n-a*t);return this.x=t+s*c+a*u-o*l,this.y=n+s*l+o*c-i*u,this.z=r+s*u+i*l-a*c,this}project(e){return this.applyMatrix4(e.matrixWorldInverse).applyMatrix4(e.projectionMatrix)}unproject(e){return this.applyMatrix4(e.projectionMatrixInverse).applyMatrix4(e.matrixWorld)}transformDirection(e){let t=this.x,n=this.y,r=this.z,i=e.elements;return this.x=i[0]*t+i[4]*n+i[8]*r,this.y=i[1]*t+i[5]*n+i[9]*r,this.z=i[2]*t+i[6]*n+i[10]*r,this.normalize()}divide(e){return this.x/=e.x,this.y/=e.y,this.z/=e.z,this}divideScalar(e){return this.multiplyScalar(1/e)}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this.z=Math.min(this.z,e.z),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this.z=Math.max(this.z,e.z),this}clamp(e,t){return this.x=ft(this.x,e.x,t.x),this.y=ft(this.y,e.y,t.y),this.z=ft(this.z,e.z,t.z),this}clampScalar(e,t){return this.x=ft(this.x,e,t),this.y=ft(this.y,e,t),this.z=ft(this.z,e,t),this}clampLength(e,t){let n=this.length();return this.divideScalar(n||1).multiplyScalar(ft(n,e,t))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this}dot(e){return this.x*e.x+this.y*e.y+this.z*e.z}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)}normalize(){return this.divideScalar(this.length()||1)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,t){return this.x+=(e.x-this.x)*t,this.y+=(e.y-this.y)*t,this.z+=(e.z-this.z)*t,this}lerpVectors(e,t,n){return this.x=e.x+(t.x-e.x)*n,this.y=e.y+(t.y-e.y)*n,this.z=e.z+(t.z-e.z)*n,this}cross(e){return this.crossVectors(this,e)}crossVectors(e,t){let n=e.x,r=e.y,i=e.z,a=t.x,o=t.y,s=t.z;return this.x=r*s-i*o,this.y=i*a-n*s,this.z=n*o-r*a,this}projectOnVector(e){let t=e.lengthSq();if(t===0)return this.set(0,0,0);let n=e.dot(this)/t;return this.copy(e).multiplyScalar(n)}projectOnPlane(e){return It.copy(this).projectOnVector(e),this.sub(It)}reflect(e){return this.sub(It.copy(e).multiplyScalar(2*this.dot(e)))}angleTo(e){let t=Math.sqrt(this.lengthSq()*e.lengthSq());if(t===0)return Math.PI/2;let n=this.dot(e)/t;return Math.acos(ft(n,-1,1))}distanceTo(e){return Math.sqrt(this.distanceToSquared(e))}distanceToSquared(e){let t=this.x-e.x,n=this.y-e.y,r=this.z-e.z;return t*t+n*n+r*r}manhattanDistanceTo(e){return Math.abs(this.x-e.x)+Math.abs(this.y-e.y)+Math.abs(this.z-e.z)}setFromSpherical(e){return this.setFromSphericalCoords(e.radius,e.phi,e.theta)}setFromSphericalCoords(e,t,n){let r=Math.sin(t)*e;return this.x=r*Math.sin(n),this.y=Math.cos(t)*e,this.z=r*Math.cos(n),this}setFromCylindrical(e){return this.setFromCylindricalCoords(e.radius,e.theta,e.y)}setFromCylindricalCoords(e,t,n){return this.x=e*Math.sin(t),this.y=n,this.z=e*Math.cos(t),this}setFromMatrixPosition(e){let t=e.elements;return this.x=t[12],this.y=t[13],this.z=t[14],this}setFromMatrixScale(e){let t=this.setFromMatrixColumn(e,0).length(),n=this.setFromMatrixColumn(e,1).length(),r=this.setFromMatrixColumn(e,2).length();return this.x=t,this.y=n,this.z=r,this}setFromMatrixColumn(e,t){return this.fromArray(e.elements,t*4)}setFromMatrix3Column(e,t){return this.fromArray(e.elements,t*3)}setFromEuler(e){return this.x=e._x,this.y=e._y,this.z=e._z,this}setFromColor(e){return this.x=e.r,this.y=e.g,this.z=e.b,this}equals(e){return e.x===this.x&&e.y===this.y&&e.z===this.z}fromArray(e,t=0){return this.x=e[t],this.y=e[t+1],this.z=e[t+2],this}toArray(e=[],t=0){return e[t]=this.x,e[t+1]=this.y,e[t+2]=this.z,e}fromBufferAttribute(e,t){return this.x=e.getX(t),this.y=e.getY(t),this.z=e.getZ(t),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this}randomDirection(){let e=Math.random()*Math.PI*2,t=Math.random()*2-1,n=Math.sqrt(1-t*t);return this.x=n*Math.cos(e),this.y=t,this.z=n*Math.sin(e),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z}},It=new L,Lt=new Ft,Rt=class{static{this.prototype.isMatrix3=!0}constructor(e,t,n,r,i,a,o,s,c){this.elements=[1,0,0,0,1,0,0,0,1],e!==void 0&&this.set(e,t,n,r,i,a,o,s,c)}set(e,t,n,r,i,a,o,s,c){let l=this.elements;return l[0]=e,l[1]=r,l[2]=o,l[3]=t,l[4]=i,l[5]=s,l[6]=n,l[7]=a,l[8]=c,this}identity(){return this.set(1,0,0,0,1,0,0,0,1),this}copy(e){let t=this.elements,n=e.elements;return t[0]=n[0],t[1]=n[1],t[2]=n[2],t[3]=n[3],t[4]=n[4],t[5]=n[5],t[6]=n[6],t[7]=n[7],t[8]=n[8],this}extractBasis(e,t,n){return e.setFromMatrix3Column(this,0),t.setFromMatrix3Column(this,1),n.setFromMatrix3Column(this,2),this}setFromMatrix4(e){let t=e.elements;return this.set(t[0],t[4],t[8],t[1],t[5],t[9],t[2],t[6],t[10]),this}multiply(e){return this.multiplyMatrices(this,e)}premultiply(e){return this.multiplyMatrices(e,this)}multiplyMatrices(e,t){let n=e.elements,r=t.elements,i=this.elements,a=n[0],o=n[3],s=n[6],c=n[1],l=n[4],u=n[7],d=n[2],f=n[5],p=n[8],m=r[0],h=r[3],g=r[6],_=r[1],v=r[4],y=r[7],b=r[2],x=r[5],S=r[8];return i[0]=a*m+o*_+s*b,i[3]=a*h+o*v+s*x,i[6]=a*g+o*y+s*S,i[1]=c*m+l*_+u*b,i[4]=c*h+l*v+u*x,i[7]=c*g+l*y+u*S,i[2]=d*m+f*_+p*b,i[5]=d*h+f*v+p*x,i[8]=d*g+f*y+p*S,this}multiplyScalar(e){let t=this.elements;return t[0]*=e,t[3]*=e,t[6]*=e,t[1]*=e,t[4]*=e,t[7]*=e,t[2]*=e,t[5]*=e,t[8]*=e,this}determinant(){let e=this.elements,t=e[0],n=e[1],r=e[2],i=e[3],a=e[4],o=e[5],s=e[6],c=e[7],l=e[8];return t*a*l-t*o*c-n*i*l+n*o*s+r*i*c-r*a*s}invert(){let e=this.elements,t=e[0],n=e[1],r=e[2],i=e[3],a=e[4],o=e[5],s=e[6],c=e[7],l=e[8],u=l*a-o*c,d=o*s-l*i,f=c*i-a*s,p=t*u+n*d+r*f;if(p===0)return this.set(0,0,0,0,0,0,0,0,0);let m=1/p;return e[0]=u*m,e[1]=(r*c-l*n)*m,e[2]=(o*n-r*a)*m,e[3]=d*m,e[4]=(l*t-r*s)*m,e[5]=(r*i-o*t)*m,e[6]=f*m,e[7]=(n*s-c*t)*m,e[8]=(a*t-n*i)*m,this}transpose(){let e,t=this.elements;return e=t[1],t[1]=t[3],t[3]=e,e=t[2],t[2]=t[6],t[6]=e,e=t[5],t[5]=t[7],t[7]=e,this}getNormalMatrix(e){return this.setFromMatrix4(e).invert().transpose()}transposeIntoArray(e){let t=this.elements;return e[0]=t[0],e[1]=t[3],e[2]=t[6],e[3]=t[1],e[4]=t[4],e[5]=t[7],e[6]=t[2],e[7]=t[5],e[8]=t[8],this}setUvTransform(e,t,n,r,i,a,o){let s=Math.cos(i),c=Math.sin(i);return this.set(n*s,n*c,-n*(s*a+c*o)+a+e,-r*c,r*s,-r*(-c*a+s*o)+o+t,0,0,1),this}scale(e,t){return rt(`Matrix3: .scale() is deprecated. Use .makeScale() instead.`),this.premultiply(zt.makeScale(e,t)),this}rotate(e){return rt(`Matrix3: .rotate() is deprecated. Use .makeRotation() instead.`),this.premultiply(zt.makeRotation(-e)),this}translate(e,t){return rt(`Matrix3: .translate() is deprecated. Use .makeTranslation() instead.`),this.premultiply(zt.makeTranslation(e,t)),this}makeTranslation(e,t){return e.isVector2?this.set(1,0,e.x,0,1,e.y,0,0,1):this.set(1,0,e,0,1,t,0,0,1),this}makeRotation(e){let t=Math.cos(e),n=Math.sin(e);return this.set(t,-n,0,n,t,0,0,0,1),this}makeScale(e,t){return this.set(e,0,0,0,t,0,0,0,1),this}equals(e){let t=this.elements,n=e.elements;for(let e=0;e<9;e++)if(t[e]!==n[e])return!1;return!0}fromArray(e,t=0){for(let n=0;n<9;n++)this.elements[n]=e[n+t];return this}toArray(e=[],t=0){let n=this.elements;return e[t]=n[0],e[t+1]=n[1],e[t+2]=n[2],e[t+3]=n[3],e[t+4]=n[4],e[t+5]=n[5],e[t+6]=n[6],e[t+7]=n[7],e[t+8]=n[8],e}clone(){return new this.constructor().fromArray(this.elements)}},zt=new Rt,Bt=new Rt().set(.4123908,.3575843,.1804808,.212639,.7151687,.0721923,.0193308,.1191948,.9505322),Vt=new Rt().set(3.2409699,-1.5373832,-.4986108,-.9692436,1.8759675,.0415551,.0556301,-.203977,1.0569715);function Ht(){let e={enabled:!0,workingColorSpace:Ve,spaces:{},convert:function(e,t,n){return this.enabled===!1||t===n||!t||!n||(this.spaces[t].transfer===`srgb`&&(e.r=Wt(e.r),e.g=Wt(e.g),e.b=Wt(e.b)),this.spaces[t].primaries!==this.spaces[n].primaries&&(e.applyMatrix3(this.spaces[t].toXYZ),e.applyMatrix3(this.spaces[n].fromXYZ)),this.spaces[n].transfer===`srgb`&&(e.r=Gt(e.r),e.g=Gt(e.g),e.b=Gt(e.b))),e},workingToColorSpace:function(e,t){return this.convert(e,this.workingColorSpace,t)},colorSpaceToWorking:function(e,t){return this.convert(e,t,this.workingColorSpace)},getPrimaries:function(e){return this.spaces[e].primaries},getTransfer:function(e){return e===``?He:this.spaces[e].transfer},getToneMappingMode:function(e){return this.spaces[e].outputColorSpaceConfig.toneMappingMode||`standard`},getLuminanceCoefficients:function(e,t=this.workingColorSpace){return e.fromArray(this.spaces[t].luminanceCoefficients)},define:function(e){Object.assign(this.spaces,e)},_getMatrix:function(e,t,n){return e.copy(this.spaces[n].fromXYZ).multiply(this.spaces[t].toXYZ)},_getDrawingBufferColorSpace:function(e){return this.spaces[e].outputColorSpaceConfig.drawingBufferColorSpace},_getUnpackColorSpace:function(e=this.workingColorSpace){return this.spaces[e].workingColorSpaceConfig.unpackColorSpace}},t=[.64,.33,.3,.6,.15,.06],n=[.2126,.7152,.0722],r=[.3127,.329];return e.define({[Ve]:{primaries:t,whitePoint:r,transfer:He,toXYZ:Bt,fromXYZ:Vt,luminanceCoefficients:n,workingColorSpaceConfig:{unpackColorSpace:Be},outputColorSpaceConfig:{drawingBufferColorSpace:Be}},[Be]:{primaries:t,whitePoint:r,transfer:Ue,toXYZ:Bt,fromXYZ:Vt,luminanceCoefficients:n,outputColorSpaceConfig:{drawingBufferColorSpace:Be}}}),e}var Ut=Ht();function Wt(e){return e<.04045?e*.0773993808:(e*.9478672986+.0521327014)**2.4}function Gt(e){return e<.0031308?e*12.92:1.055*e**.41666-.055}var Kt,qt=class{static getDataURL(e,t=`image/png`){if(/^data:/i.test(e.src)||typeof HTMLCanvasElement>`u`)return e.src;let n;if(e instanceof HTMLCanvasElement)n=e;else{Kt===void 0&&(Kt=Xe(`canvas`)),Kt.width=e.width,Kt.height=e.height;let t=Kt.getContext(`2d`);e instanceof ImageData?t.putImageData(e,0,0):t.drawImage(e,0,0,e.width,e.height),n=Kt}return n.toDataURL(t)}static sRGBToLinear(e){if(typeof HTMLImageElement<`u`&&e instanceof HTMLImageElement||typeof HTMLCanvasElement<`u`&&e instanceof HTMLCanvasElement||typeof ImageBitmap<`u`&&e instanceof ImageBitmap){let t=Xe(`canvas`);t.width=e.width,t.height=e.height;let n=t.getContext(`2d`);n.drawImage(e,0,0,e.width,e.height);let r=n.getImageData(0,0,e.width,e.height),i=r.data;for(let e=0;e<i.length;e++)i[e]=Wt(i[e]/255)*255;return n.putImageData(r,0,0),t}if(e.data){let t=e.data.slice(0);for(let e=0;e<t.length;e++)t instanceof Uint8Array||t instanceof Uint8ClampedArray?t[e]=Math.floor(Wt(t[e]/255)*255):t[e]=Wt(t[e]);return{data:t,width:e.width,height:e.height}}return tt(`ImageUtils.sRGBToLinear(): Unsupported image type. No color space conversion applied.`),e}},Jt=0,Yt=class{constructor(e=null){this.isTextureSource=!0,Object.defineProperty(this,"id",{value:Jt++}),this.uuid=dt(),this.data=e,this.dataReady=!0,this.version=0}getSize(e){let t=this.data;return typeof HTMLVideoElement<`u`&&t instanceof HTMLVideoElement?e.set(t.videoWidth,t.videoHeight,0):typeof VideoFrame<`u`&&t instanceof VideoFrame?e.set(t.displayWidth,t.displayHeight,0):t===null?e.set(0,0,0):e.set(t.width||0,t.height||0,t.depth||0),e}set needsUpdate(e){e===!0&&this.version++}toJSON(e){let t=e===void 0||typeof e==`string`;if(!t&&e.images[this.uuid]!==void 0)return e.images[this.uuid];let n={uuid:this.uuid,url:``},r=this.data;if(r!==null){let e;if(Array.isArray(r)){e=[];for(let t=0,n=r.length;t<n;t++)r[t].isDataTexture?e.push(Xt(r[t].image)):e.push(Xt(r[t]))}else e=Xt(r);n.url=e}return t||(e.images[this.uuid]=n),n}};function Xt(e){return typeof HTMLImageElement<`u`&&e instanceof HTMLImageElement||typeof HTMLCanvasElement<`u`&&e instanceof HTMLCanvasElement||typeof ImageBitmap<`u`&&e instanceof ImageBitmap?qt.getDataURL(e):e.data?{data:Array.from(e.data),width:e.width,height:e.height,type:e.data.constructor.name}:(tt(`Texture: Unable to serialize Texture.`),{})}var Zt=0,Qt=new L,$t=class r extends ot{constructor(e=r.DEFAULT_IMAGE,n=r.DEFAULT_MAPPING,i=t,a=t,s=o,u=c,d=w,f=l,p=r.DEFAULT_ANISOTROPY,m=``){super(),this.isTexture=!0,Object.defineProperty(this,"id",{value:Zt++}),this.uuid=dt(),this.name=``,this.source=new Yt(e),this.mipmaps=[],this.mapping=n,this.channel=0,this.wrapS=i,this.wrapT=a,this.magFilter=s,this.minFilter=u,this.anisotropy=p,this.format=d,this.internalFormat=null,this.type=f,this.offset=new I(0,0),this.repeat=new I(1,1),this.center=new I(0,0),this.rotation=0,this.matrixAutoUpdate=!0,this.matrix=new Rt,this.generateMipmaps=!0,this.mipmapsAutoUpdate=!0,this.premultiplyAlpha=!1,this.flipY=!0,this.unpackAlignment=4,this.colorSpace=m,this.userData={},this.updateRanges=[],this.version=0,this.onUpdate=null,this.renderTarget=null,this.isRenderTargetTexture=!1,this.isArrayTexture=!!(e&&e.depth&&e.depth>1),this.pmremVersion=0,this.isPMREMTexture=!1,this.normalized=!1}get width(){return this.source.getSize(Qt).x}get height(){return this.source.getSize(Qt).y}get depth(){return this.source.getSize(Qt).z}get image(){return this.source.data}set image(e){this.source.data=e}updateMatrix(){this.matrix.setUvTransform(this.offset.x,this.offset.y,this.repeat.x,this.repeat.y,this.rotation,this.center.x,this.center.y)}addUpdateRange(e,t){this.updateRanges.push({start:e,count:t})}clearUpdateRanges(){this.updateRanges.length=0}clone(){return new this.constructor().copy(this)}copy(e){return this.name=e.name,this.source=e.source,this.mipmaps=e.mipmaps.slice(0),this.mapping=e.mapping,this.channel=e.channel,this.wrapS=e.wrapS,this.wrapT=e.wrapT,this.magFilter=e.magFilter,this.minFilter=e.minFilter,this.anisotropy=e.anisotropy,this.format=e.format,this.internalFormat=e.internalFormat,this.type=e.type,this.normalized=e.normalized,this.offset.copy(e.offset),this.repeat.copy(e.repeat),this.center.copy(e.center),this.rotation=e.rotation,this.matrixAutoUpdate=e.matrixAutoUpdate,this.matrix.copy(e.matrix),this.generateMipmaps=e.generateMipmaps,this.mipmapsAutoUpdate=e.mipmapsAutoUpdate,this.premultiplyAlpha=e.premultiplyAlpha,this.flipY=e.flipY,this.unpackAlignment=e.unpackAlignment,this.colorSpace=e.colorSpace,this.renderTarget=e.renderTarget,this.isRenderTargetTexture=e.isRenderTargetTexture,this.isPMREMTexture=e.isPMREMTexture,this.isArrayTexture=e.isArrayTexture,this.userData=JSON.parse(JSON.stringify(e.userData)),this.needsUpdate=!0,this}setValues(e){for(let t in e){let n=e[t];if(n===void 0){tt(`Texture.setValues(): parameter '${t}' has value of undefined.`);continue}let r=this[t];r===void 0?tt(`Texture.setValues(): property '${t}' does not exist.`):r&&n&&r.isVector2&&n.isVector2||r&&n&&r.isVector3&&n.isVector3||r&&n&&r.isMatrix3&&n.isMatrix3?r.copy(n):this[t]=n}}toJSON(e){let t=e===void 0||typeof e==`string`;if(!t&&e.textures[this.uuid]!==void 0)return e.textures[this.uuid];let n={metadata:{version:4.7,type:`Texture`,generator:`Texture.toJSON`},uuid:this.uuid,name:this.name,image:this.source.toJSON(e).uuid,mapping:this.mapping,channel:this.channel,repeat:[this.repeat.x,this.repeat.y],offset:[this.offset.x,this.offset.y],center:[this.center.x,this.center.y],rotation:this.rotation,wrap:[this.wrapS,this.wrapT],format:this.format,internalFormat:this.internalFormat,type:this.type,normalized:this.normalized,colorSpace:this.colorSpace,minFilter:this.minFilter,magFilter:this.magFilter,anisotropy:this.anisotropy,flipY:this.flipY,generateMipmaps:this.generateMipmaps,mipmapsAutoUpdate:this.mipmapsAutoUpdate,premultiplyAlpha:this.premultiplyAlpha,unpackAlignment:this.unpackAlignment};return Object.keys(this.userData).length>0&&(n.userData=this.userData),t||(e.textures[this.uuid]=n),n}dispose(){this.dispatchEvent({type:`dispose`})}transformUv(r){if(this.mapping!==300)return r;if(r.applyMatrix3(this.matrix),r.x<0||r.x>1)switch(this.wrapS){case e:r.x-=Math.floor(r.x);break;case t:r.x=r.x<0?0:1;break;case n:Math.abs(Math.floor(r.x)%2)===1?r.x=Math.ceil(r.x)-r.x:r.x-=Math.floor(r.x)}if(r.y<0||r.y>1)switch(this.wrapT){case e:r.y-=Math.floor(r.y);break;case t:r.y=r.y<0?0:1;break;case n:Math.abs(Math.floor(r.y)%2)===1?r.y=Math.ceil(r.y)-r.y:r.y-=Math.floor(r.y)}return this.flipY&&(r.y=1-r.y),r}set needsUpdate(e){e===!0&&(this.version++,this.source.needsUpdate=!0)}set needsPMREMUpdate(e){e===!0&&this.pmremVersion++}};$t.DEFAULT_IMAGE=null,$t.DEFAULT_MAPPING=300,$t.DEFAULT_ANISOTROPY=1;var en=class{static{this.prototype.isVector4=!0}constructor(e=0,t=0,n=0,r=1){this.x=e,this.y=t,this.z=n,this.w=r}get width(){return this.z}set width(e){this.z=e}get height(){return this.w}set height(e){this.w=e}set(e,t,n,r){return this.x=e,this.y=t,this.z=n,this.w=r,this}setScalar(e){return this.x=e,this.y=e,this.z=e,this.w=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setZ(e){return this.z=e,this}setW(e){return this.w=e,this}setComponent(e,t){switch(e){case 0:this.x=t;break;case 1:this.y=t;break;case 2:this.z=t;break;case 3:this.w=t;break;default:throw Error(`THREE.Vector4: index is out of range: `+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;case 2:return this.z;case 3:return this.w;default:throw Error(`THREE.Vector4: index is out of range: `+e)}}clone(){return new this.constructor(this.x,this.y,this.z,this.w)}copy(e){return this.x=e.x,this.y=e.y,this.z=e.z,this.w=e.w===void 0?1:e.w,this}add(e){return this.x+=e.x,this.y+=e.y,this.z+=e.z,this.w+=e.w,this}addScalar(e){return this.x+=e,this.y+=e,this.z+=e,this.w+=e,this}addVectors(e,t){return this.x=e.x+t.x,this.y=e.y+t.y,this.z=e.z+t.z,this.w=e.w+t.w,this}addScaledVector(e,t){return this.x+=e.x*t,this.y+=e.y*t,this.z+=e.z*t,this.w+=e.w*t,this}sub(e){return this.x-=e.x,this.y-=e.y,this.z-=e.z,this.w-=e.w,this}subScalar(e){return this.x-=e,this.y-=e,this.z-=e,this.w-=e,this}subVectors(e,t){return this.x=e.x-t.x,this.y=e.y-t.y,this.z=e.z-t.z,this.w=e.w-t.w,this}multiply(e){return this.x*=e.x,this.y*=e.y,this.z*=e.z,this.w*=e.w,this}multiplyScalar(e){return this.x*=e,this.y*=e,this.z*=e,this.w*=e,this}applyMatrix4(e){let t=this.x,n=this.y,r=this.z,i=this.w,a=e.elements;return this.x=a[0]*t+a[4]*n+a[8]*r+a[12]*i,this.y=a[1]*t+a[5]*n+a[9]*r+a[13]*i,this.z=a[2]*t+a[6]*n+a[10]*r+a[14]*i,this.w=a[3]*t+a[7]*n+a[11]*r+a[15]*i,this}divide(e){return this.x/=e.x,this.y/=e.y,this.z/=e.z,this.w/=e.w,this}divideScalar(e){return this.multiplyScalar(1/e)}setAxisAngleFromQuaternion(e){this.w=2*Math.acos(e.w);let t=Math.sqrt(1-e.w*e.w);return t<1e-4?(this.x=1,this.y=0,this.z=0):(this.x=e.x/t,this.y=e.y/t,this.z=e.z/t),this}setAxisAngleFromRotationMatrix(e){let t,n,r,i,a=.01,o=.1,s=e.elements,c=s[0],l=s[4],u=s[8],d=s[1],f=s[5],p=s[9],m=s[2],h=s[6],g=s[10];if(Math.abs(l-d)<a&&Math.abs(u-m)<a&&Math.abs(p-h)<a){if(Math.abs(l+d)<o&&Math.abs(u+m)<o&&Math.abs(p+h)<o&&Math.abs(c+f+g-3)<o)return this.set(1,0,0,0),this;t=Math.PI;let e=(c+1)/2,s=(f+1)/2,_=(g+1)/2,v=(l+d)/4,y=(u+m)/4,b=(p+h)/4;return e>s&&e>_?e<a?(n=0,r=.707106781,i=.707106781):(n=Math.sqrt(e),r=v/n,i=y/n):s>_?s<a?(n=.707106781,r=0,i=.707106781):(r=Math.sqrt(s),n=v/r,i=b/r):_<a?(n=.707106781,r=.707106781,i=0):(i=Math.sqrt(_),n=y/i,r=b/i),this.set(n,r,i,t),this}let _=Math.sqrt((h-p)*(h-p)+(u-m)*(u-m)+(d-l)*(d-l));return Math.abs(_)<.001&&(_=1),this.x=(h-p)/_,this.y=(u-m)/_,this.z=(d-l)/_,this.w=Math.acos((c+f+g-1)/2),this}setFromMatrixPosition(e){let t=e.elements;return this.x=t[12],this.y=t[13],this.z=t[14],this.w=t[15],this}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this.z=Math.min(this.z,e.z),this.w=Math.min(this.w,e.w),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this.z=Math.max(this.z,e.z),this.w=Math.max(this.w,e.w),this}clamp(e,t){return this.x=ft(this.x,e.x,t.x),this.y=ft(this.y,e.y,t.y),this.z=ft(this.z,e.z,t.z),this.w=ft(this.w,e.w,t.w),this}clampScalar(e,t){return this.x=ft(this.x,e,t),this.y=ft(this.y,e,t),this.z=ft(this.z,e,t),this.w=ft(this.w,e,t),this}clampLength(e,t){let n=this.length();return this.divideScalar(n||1).multiplyScalar(ft(n,e,t))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this.w=Math.floor(this.w),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this.w=Math.ceil(this.w),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this.w=Math.round(this.w),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this.w=Math.trunc(this.w),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this.w=-this.w,this}dot(e){return this.x*e.x+this.y*e.y+this.z*e.z+this.w*e.w}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)+Math.abs(this.w)}normalize(){return this.divideScalar(this.length()||1)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,t){return this.x+=(e.x-this.x)*t,this.y+=(e.y-this.y)*t,this.z+=(e.z-this.z)*t,this.w+=(e.w-this.w)*t,this}lerpVectors(e,t,n){return this.x=e.x+(t.x-e.x)*n,this.y=e.y+(t.y-e.y)*n,this.z=e.z+(t.z-e.z)*n,this.w=e.w+(t.w-e.w)*n,this}equals(e){return e.x===this.x&&e.y===this.y&&e.z===this.z&&e.w===this.w}fromArray(e,t=0){return this.x=e[t],this.y=e[t+1],this.z=e[t+2],this.w=e[t+3],this}toArray(e=[],t=0){return e[t]=this.x,e[t+1]=this.y,e[t+2]=this.z,e[t+3]=this.w,e}fromBufferAttribute(e,t){return this.x=e.getX(t),this.y=e.getY(t),this.z=e.getZ(t),this.w=e.getW(t),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this.w=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z,yield this.w}},tn=class extends ot{constructor(e=1,t=1,n={}){super(),n=Object.assign({generateMipmaps:!1,internalFormat:null,minFilter:o,depthBuffer:!0,stencilBuffer:!1,resolveColorBuffer:!0,resolveDepthBuffer:!0,resolveStencilBuffer:!0,storeMultisampledColorBuffer:!0,storeMultisampledDepthBuffer:!0,storeMultisampledStencilBuffer:!0,depthTexture:null,samples:0,count:1,depth:1,multiview:!1,useArrayDepthTexture:!1},n),this.isRenderTarget=!0,this.width=e,this.height=t,this.depth=n.depth,this.scissor=new en(0,0,e,t),this.scissorTest=!1,this.viewport=new en(0,0,e,t),this.textures=[];let r=n.count;for(let i=0;i<r;i++)this.textures[i]=new $t({width:e,height:t,depth:n.depth}),this.textures[i].isRenderTargetTexture=!0,this.textures[i].renderTarget=this;this._setTextureOptions(n),this.depthBuffer=n.depthBuffer,this.stencilBuffer=n.stencilBuffer,this.resolveColorBuffer=n.resolveColorBuffer,this.resolveDepthBuffer=n.resolveDepthBuffer,this.resolveStencilBuffer=n.resolveStencilBuffer,this.storeMultisampledColorBuffer=n.storeMultisampledColorBuffer,this.storeMultisampledDepthBuffer=n.storeMultisampledDepthBuffer,this.storeMultisampledStencilBuffer=n.storeMultisampledStencilBuffer,this._depthTexture=null,this.depthTexture=n.depthTexture,this.samples=n.samples,this.multiview=n.multiview,this.useArrayDepthTexture=n.useArrayDepthTexture}_setTextureOptions(e={}){let t={minFilter:o,generateMipmaps:!1,flipY:!1,internalFormat:null};e.mapping!==void 0&&(t.mapping=e.mapping),e.wrapS!==void 0&&(t.wrapS=e.wrapS),e.wrapT!==void 0&&(t.wrapT=e.wrapT),e.wrapR!==void 0&&(t.wrapR=e.wrapR),e.magFilter!==void 0&&(t.magFilter=e.magFilter),e.minFilter!==void 0&&(t.minFilter=e.minFilter),e.format!==void 0&&(t.format=e.format),e.type!==void 0&&(t.type=e.type),e.anisotropy!==void 0&&(t.anisotropy=e.anisotropy),e.colorSpace!==void 0&&(t.colorSpace=e.colorSpace),e.flipY!==void 0&&(t.flipY=e.flipY),e.generateMipmaps!==void 0&&(t.generateMipmaps=e.generateMipmaps),e.mipmapsAutoUpdate!==void 0&&(t.mipmapsAutoUpdate=e.mipmapsAutoUpdate),e.internalFormat!==void 0&&(t.internalFormat=e.internalFormat);for(let e=0;e<this.textures.length;e++)this.textures[e].setValues(t)}get texture(){return this.textures[0]}set texture(e){this.textures[0]=e}set depthTexture(e){this._depthTexture!==null&&this._depthTexture.renderTarget===this&&(this._depthTexture.renderTarget=null),e!==null&&e.renderTarget===null&&(e.renderTarget=this),this._depthTexture=e}get depthTexture(){return this._depthTexture}setSize(e,t,n=1){if(this.width!==e||this.height!==t||this.depth!==n){this.width=e,this.height=t,this.depth=n;for(let r=0,i=this.textures.length;r<i;r++)this.textures[r].image.width=e,this.textures[r].image.height=t,this.textures[r].image.depth=n,this.textures[r].isData3DTexture!==!0&&(this.textures[r].isArrayTexture=this.textures[r].image.depth>1);this.dispose()}this.viewport.set(0,0,e,t),this.scissor.set(0,0,e,t)}clone(){return new this.constructor().copy(this)}copy(e){this.width=e.width,this.height=e.height,this.depth=e.depth,this.scissor.copy(e.scissor),this.scissorTest=e.scissorTest,this.viewport.copy(e.viewport),this.textures.length=0;for(let t=0,n=e.textures.length;t<n;t++){this.textures[t]=e.textures[t].clone(),this.textures[t].isRenderTargetTexture=!0,this.textures[t].renderTarget=this;let n=Object.assign({},e.textures[t].image);this.textures[t].source=new Yt(n)}if(this.depthBuffer=e.depthBuffer,this.stencilBuffer=e.stencilBuffer,this.resolveColorBuffer=e.resolveColorBuffer,this.resolveDepthBuffer=e.resolveDepthBuffer,this.resolveStencilBuffer=e.resolveStencilBuffer,this.storeMultisampledColorBuffer=e.storeMultisampledColorBuffer,this.storeMultisampledDepthBuffer=e.storeMultisampledDepthBuffer,this.storeMultisampledStencilBuffer=e.storeMultisampledStencilBuffer,e.depthTexture!==null){if(e.depthTexture.renderTarget===e){let t=e.depthTexture.clone();t.renderTarget=null,this.depthTexture=t}else this.depthTexture=e.depthTexture}else this.depthTexture=null;return this.samples=e.samples,this.multiview=e.multiview,this.useArrayDepthTexture=e.useArrayDepthTexture,this}dispose(){this.dispatchEvent({type:`dispose`})}},nn=class extends tn{constructor(e=1,t=1,n={}){super(e,t,n),this.isWebGLRenderTarget=!0}},rn=class extends $t{constructor(e=null,n=1,i=1,a=1){super(null),this.isDataArrayTexture=!0,this.image={data:e,width:n,height:i,depth:a},this.magFilter=r,this.minFilter=r,this.wrapR=t,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1,this.layerUpdates=new Set}copy(e){return super.copy(e),this.wrapR=e.wrapR,this}addLayerUpdate(e){this.layerUpdates.add(e)}clearLayerUpdates(){this.layerUpdates.clear()}},an=class extends $t{constructor(e=null,n=1,i=1,a=1){super(null),this.isData3DTexture=!0,this.image={data:e,width:n,height:i,depth:a},this.magFilter=r,this.minFilter=r,this.wrapR=t,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}copy(e){return super.copy(e),this.wrapR=e.wrapR,this}},on=class e{static{this.prototype.isMatrix4=!0}constructor(e,t,n,r,i,a,o,s,c,l,u,d,f,p,m,h){this.elements=[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1],e!==void 0&&this.set(e,t,n,r,i,a,o,s,c,l,u,d,f,p,m,h)}set(e,t,n,r,i,a,o,s,c,l,u,d,f,p,m,h){let g=this.elements;return g[0]=e,g[4]=t,g[8]=n,g[12]=r,g[1]=i,g[5]=a,g[9]=o,g[13]=s,g[2]=c,g[6]=l,g[10]=u,g[14]=d,g[3]=f,g[7]=p,g[11]=m,g[15]=h,this}identity(){return this.set(1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1),this}clone(){return new e().fromArray(this.elements)}copy(e){let t=this.elements,n=e.elements;return t[0]=n[0],t[1]=n[1],t[2]=n[2],t[3]=n[3],t[4]=n[4],t[5]=n[5],t[6]=n[6],t[7]=n[7],t[8]=n[8],t[9]=n[9],t[10]=n[10],t[11]=n[11],t[12]=n[12],t[13]=n[13],t[14]=n[14],t[15]=n[15],this}copyPosition(e){let t=this.elements,n=e.elements;return t[12]=n[12],t[13]=n[13],t[14]=n[14],this}setFromMatrix3(e){let t=e.elements;return this.set(t[0],t[3],t[6],0,t[1],t[4],t[7],0,t[2],t[5],t[8],0,0,0,0,1),this}extractBasis(e,t,n){return this.determinantAffine()===0?(e.set(1,0,0),t.set(0,1,0),n.set(0,0,1),this):(e.setFromMatrixColumn(this,0),t.setFromMatrixColumn(this,1),n.setFromMatrixColumn(this,2),this)}makeBasis(e,t,n){return this.set(e.x,t.x,n.x,0,e.y,t.y,n.y,0,e.z,t.z,n.z,0,0,0,0,1),this}extractRotation(e){if(e.determinantAffine()===0)return this.identity();let t=this.elements,n=e.elements,r=1/sn.setFromMatrixColumn(e,0).length(),i=1/sn.setFromMatrixColumn(e,1).length(),a=1/sn.setFromMatrixColumn(e,2).length();return t[0]=n[0]*r,t[1]=n[1]*r,t[2]=n[2]*r,t[3]=0,t[4]=n[4]*i,t[5]=n[5]*i,t[6]=n[6]*i,t[7]=0,t[8]=n[8]*a,t[9]=n[9]*a,t[10]=n[10]*a,t[11]=0,t[12]=0,t[13]=0,t[14]=0,t[15]=1,this}makeRotationFromEuler(e){let t=this.elements,n=e.x,r=e.y,i=e.z,a=Math.cos(n),o=Math.sin(n),s=Math.cos(r),c=Math.sin(r),l=Math.cos(i),u=Math.sin(i);if(e.order===`XYZ`){let e=a*l,n=a*u,r=o*l,i=o*u;t[0]=s*l,t[4]=-s*u,t[8]=c,t[1]=n+r*c,t[5]=e-i*c,t[9]=-o*s,t[2]=i-e*c,t[6]=r+n*c,t[10]=a*s}else if(e.order===`YXZ`){let e=s*l,n=s*u,r=c*l,i=c*u;t[0]=e+i*o,t[4]=r*o-n,t[8]=a*c,t[1]=a*u,t[5]=a*l,t[9]=-o,t[2]=n*o-r,t[6]=i+e*o,t[10]=a*s}else if(e.order===`ZXY`){let e=s*l,n=s*u,r=c*l,i=c*u;t[0]=e-i*o,t[4]=-a*u,t[8]=r+n*o,t[1]=n+r*o,t[5]=a*l,t[9]=i-e*o,t[2]=-a*c,t[6]=o,t[10]=a*s}else if(e.order===`ZYX`){let e=a*l,n=a*u,r=o*l,i=o*u;t[0]=s*l,t[4]=r*c-n,t[8]=e*c+i,t[1]=s*u,t[5]=i*c+e,t[9]=n*c-r,t[2]=-c,t[6]=o*s,t[10]=a*s}else if(e.order===`YZX`){let e=a*s,n=a*c,r=o*s,i=o*c;t[0]=s*l,t[4]=i-e*u,t[8]=r*u+n,t[1]=u,t[5]=a*l,t[9]=-o*l,t[2]=-c*l,t[6]=n*u+r,t[10]=e-i*u}else if(e.order===`XZY`){let e=a*s,n=a*c,r=o*s,i=o*c;t[0]=s*l,t[4]=-u,t[8]=c*l,t[1]=e*u+i,t[5]=a*l,t[9]=n*u-r,t[2]=r*u-n,t[6]=o*l,t[10]=i*u+e}return t[3]=0,t[7]=0,t[11]=0,t[12]=0,t[13]=0,t[14]=0,t[15]=1,this}makeRotationFromQuaternion(e){return this.compose(ln,e,un)}lookAt(e,t,n){let r=this.elements;return pn.subVectors(e,t),pn.lengthSq()===0&&(pn.z=1),pn.normalize(),dn.crossVectors(n,pn),dn.lengthSq()===0&&(Math.abs(n.z)===1?pn.x+=1e-4:pn.z+=1e-4,pn.normalize(),dn.crossVectors(n,pn)),dn.normalize(),fn.crossVectors(pn,dn),r[0]=dn.x,r[4]=fn.x,r[8]=pn.x,r[1]=dn.y,r[5]=fn.y,r[9]=pn.y,r[2]=dn.z,r[6]=fn.z,r[10]=pn.z,this}multiply(e){return this.multiplyMatrices(this,e)}premultiply(e){return this.multiplyMatrices(e,this)}multiplyMatrices(e,t){let n=e.elements,r=t.elements,i=this.elements,a=n[0],o=n[4],s=n[8],c=n[12],l=n[1],u=n[5],d=n[9],f=n[13],p=n[2],m=n[6],h=n[10],g=n[14],_=n[3],v=n[7],y=n[11],b=n[15],x=r[0],S=r[4],C=r[8],w=r[12],T=r[1],E=r[5],D=r[9],O=r[13],k=r[2],A=r[6],ee=r[10],j=r[14],te=r[3],M=r[7],ne=r[11],N=r[15];return i[0]=a*x+o*T+s*k+c*te,i[4]=a*S+o*E+s*A+c*M,i[8]=a*C+o*D+s*ee+c*ne,i[12]=a*w+o*O+s*j+c*N,i[1]=l*x+u*T+d*k+f*te,i[5]=l*S+u*E+d*A+f*M,i[9]=l*C+u*D+d*ee+f*ne,i[13]=l*w+u*O+d*j+f*N,i[2]=p*x+m*T+h*k+g*te,i[6]=p*S+m*E+h*A+g*M,i[10]=p*C+m*D+h*ee+g*ne,i[14]=p*w+m*O+h*j+g*N,i[3]=_*x+v*T+y*k+b*te,i[7]=_*S+v*E+y*A+b*M,i[11]=_*C+v*D+y*ee+b*ne,i[15]=_*w+v*O+y*j+b*N,this}multiplyScalar(e){let t=this.elements;return t[0]*=e,t[4]*=e,t[8]*=e,t[12]*=e,t[1]*=e,t[5]*=e,t[9]*=e,t[13]*=e,t[2]*=e,t[6]*=e,t[10]*=e,t[14]*=e,t[3]*=e,t[7]*=e,t[11]*=e,t[15]*=e,this}determinant(){let e=this.elements,t=e[0],n=e[4],r=e[8],i=e[12],a=e[1],o=e[5],s=e[9],c=e[13],l=e[2],u=e[6],d=e[10],f=e[14],p=e[3],m=e[7],h=e[11],g=e[15],_=s*f-c*d,v=o*f-c*u,y=o*d-s*u,b=a*f-c*l,x=a*d-s*l,S=a*u-o*l;return t*(m*_-h*v+g*y)-n*(p*_-h*b+g*x)+r*(p*v-m*b+g*S)-i*(p*y-m*x+h*S)}determinantAffine(){let e=this.elements,t=e[0],n=e[4],r=e[8],i=e[1],a=e[5],o=e[9],s=e[2],c=e[6],l=e[10];return t*(a*l-o*c)-n*(i*l-o*s)+r*(i*c-a*s)}transpose(){let e=this.elements,t;return t=e[1],e[1]=e[4],e[4]=t,t=e[2],e[2]=e[8],e[8]=t,t=e[6],e[6]=e[9],e[9]=t,t=e[3],e[3]=e[12],e[12]=t,t=e[7],e[7]=e[13],e[13]=t,t=e[11],e[11]=e[14],e[14]=t,this}setPosition(e,t,n){let r=this.elements;return e.isVector3?(r[12]=e.x,r[13]=e.y,r[14]=e.z):(r[12]=e,r[13]=t,r[14]=n),this}invert(){let e=this.elements,t=e[0],n=e[1],r=e[2],i=e[3],a=e[4],o=e[5],s=e[6],c=e[7],l=e[8],u=e[9],d=e[10],f=e[11],p=e[12],m=e[13],h=e[14],g=e[15],_=t*o-n*a,v=t*s-r*a,y=t*c-i*a,b=n*s-r*o,x=n*c-i*o,S=r*c-i*s,C=l*m-u*p,w=l*h-d*p,T=l*g-f*p,E=u*h-d*m,D=u*g-f*m,O=d*g-f*h,k=_*O-v*D+y*E+b*T-x*w+S*C;if(k===0)return this.set(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);let A=1/k;return e[0]=(o*O-s*D+c*E)*A,e[1]=(r*D-n*O-i*E)*A,e[2]=(m*S-h*x+g*b)*A,e[3]=(d*x-u*S-f*b)*A,e[4]=(s*T-a*O-c*w)*A,e[5]=(t*O-r*T+i*w)*A,e[6]=(h*y-p*S-g*v)*A,e[7]=(l*S-d*y+f*v)*A,e[8]=(a*D-o*T+c*C)*A,e[9]=(n*T-t*D-i*C)*A,e[10]=(p*x-m*y+g*_)*A,e[11]=(u*y-l*x-f*_)*A,e[12]=(o*w-a*E-s*C)*A,e[13]=(t*E-n*w+r*C)*A,e[14]=(m*v-p*b-h*_)*A,e[15]=(l*b-u*v+d*_)*A,this}scale(e){let t=this.elements,n=e.x,r=e.y,i=e.z;return t[0]*=n,t[4]*=r,t[8]*=i,t[1]*=n,t[5]*=r,t[9]*=i,t[2]*=n,t[6]*=r,t[10]*=i,t[3]*=n,t[7]*=r,t[11]*=i,this}getMaxScaleOnAxis(){let e=this.elements,t=e[0]*e[0]+e[1]*e[1]+e[2]*e[2],n=e[4]*e[4]+e[5]*e[5]+e[6]*e[6],r=e[8]*e[8]+e[9]*e[9]+e[10]*e[10];return Math.sqrt(Math.max(t,n,r))}makeTranslation(e,t,n){return e.isVector3?this.set(1,0,0,e.x,0,1,0,e.y,0,0,1,e.z,0,0,0,1):this.set(1,0,0,e,0,1,0,t,0,0,1,n,0,0,0,1),this}makeRotationX(e){let t=Math.cos(e),n=Math.sin(e);return this.set(1,0,0,0,0,t,-n,0,0,n,t,0,0,0,0,1),this}makeRotationY(e){let t=Math.cos(e),n=Math.sin(e);return this.set(t,0,n,0,0,1,0,0,-n,0,t,0,0,0,0,1),this}makeRotationZ(e){let t=Math.cos(e),n=Math.sin(e);return this.set(t,-n,0,0,n,t,0,0,0,0,1,0,0,0,0,1),this}makeRotationAxis(e,t){let n=Math.cos(t),r=Math.sin(t),i=1-n,a=e.x,o=e.y,s=e.z,c=i*a,l=i*o;return this.set(c*a+n,c*o-r*s,c*s+r*o,0,c*o+r*s,l*o+n,l*s-r*a,0,c*s-r*o,l*s+r*a,i*s*s+n,0,0,0,0,1),this}makeScale(e,t,n){return this.set(e,0,0,0,0,t,0,0,0,0,n,0,0,0,0,1),this}makeShear(e,t,n,r,i,a){return this.set(1,n,i,0,e,1,a,0,t,r,1,0,0,0,0,1),this}compose(e,t,n){let r=this.elements,i=t._x,a=t._y,o=t._z,s=t._w,c=i+i,l=a+a,u=o+o,d=i*c,f=i*l,p=i*u,m=a*l,h=a*u,g=o*u,_=s*c,v=s*l,y=s*u,b=n.x,x=n.y,S=n.z;return r[0]=(1-(m+g))*b,r[1]=(f+y)*b,r[2]=(p-v)*b,r[3]=0,r[4]=(f-y)*x,r[5]=(1-(d+g))*x,r[6]=(h+_)*x,r[7]=0,r[8]=(p+v)*S,r[9]=(h-_)*S,r[10]=(1-(d+m))*S,r[11]=0,r[12]=e.x,r[13]=e.y,r[14]=e.z,r[15]=1,this}decompose(e,t,n){let r=this.elements;e.x=r[12],e.y=r[13],e.z=r[14];let i=this.determinantAffine();if(i===0)return n.set(1,1,1),t.identity(),this;let a=sn.set(r[0],r[1],r[2]).length(),o=sn.set(r[4],r[5],r[6]).length(),s=sn.set(r[8],r[9],r[10]).length();i<0&&(a=-a),cn.copy(this);let c=1/a,l=1/o,u=1/s;return cn.elements[0]*=c,cn.elements[1]*=c,cn.elements[2]*=c,cn.elements[4]*=l,cn.elements[5]*=l,cn.elements[6]*=l,cn.elements[8]*=u,cn.elements[9]*=u,cn.elements[10]*=u,t.setFromRotationMatrix(cn),n.x=a,n.y=o,n.z=s,this}makePerspective(e,t,n,r,i,a,o=qe,s=!1){let c=this.elements,l=2*i/(t-e),u=2*i/(n-r),d=(t+e)/(t-e),f=(n+r)/(n-r),p,m;if(s)p=i/(a-i),m=a*i/(a-i);else if(o===2e3)p=-(a+i)/(a-i),m=-2*a*i/(a-i);else if(o===2001)p=-a/(a-i),m=-a*i/(a-i);else throw Error(`THREE.Matrix4.makePerspective(): Invalid coordinate system: `+o);return c[0]=l,c[4]=0,c[8]=d,c[12]=0,c[1]=0,c[5]=u,c[9]=f,c[13]=0,c[2]=0,c[6]=0,c[10]=p,c[14]=m,c[3]=0,c[7]=0,c[11]=-1,c[15]=0,this}makeOrthographic(e,t,n,r,i,a,o=qe,s=!1){let c=this.elements,l=2/(t-e),u=2/(n-r),d=-(t+e)/(t-e),f=-(n+r)/(n-r),p,m;if(s)p=1/(a-i),m=a/(a-i);else if(o===2e3)p=-2/(a-i),m=-(a+i)/(a-i);else if(o===2001)p=-1/(a-i),m=-i/(a-i);else throw Error(`THREE.Matrix4.makeOrthographic(): Invalid coordinate system: `+o);return c[0]=l,c[4]=0,c[8]=0,c[12]=d,c[1]=0,c[5]=u,c[9]=0,c[13]=f,c[2]=0,c[6]=0,c[10]=p,c[14]=m,c[3]=0,c[7]=0,c[11]=0,c[15]=1,this}equals(e){let t=this.elements,n=e.elements;for(let e=0;e<16;e++)if(t[e]!==n[e])return!1;return!0}fromArray(e,t=0){for(let n=0;n<16;n++)this.elements[n]=e[n+t];return this}toArray(e=[],t=0){let n=this.elements;return e[t]=n[0],e[t+1]=n[1],e[t+2]=n[2],e[t+3]=n[3],e[t+4]=n[4],e[t+5]=n[5],e[t+6]=n[6],e[t+7]=n[7],e[t+8]=n[8],e[t+9]=n[9],e[t+10]=n[10],e[t+11]=n[11],e[t+12]=n[12],e[t+13]=n[13],e[t+14]=n[14],e[t+15]=n[15],e}},sn=new L,cn=new on,ln=new L(0,0,0),un=new L(1,1,1),dn=new L,fn=new L,pn=new L,mn=new on,hn=new Ft,gn=class e{constructor(t=0,n=0,r=0,i=e.DEFAULT_ORDER){this.isEuler=!0,this._x=t,this._y=n,this._z=r,this._order=i}get x(){return this._x}set x(e){this._x=e,this._onChangeCallback()}get y(){return this._y}set y(e){this._y=e,this._onChangeCallback()}get z(){return this._z}set z(e){this._z=e,this._onChangeCallback()}get order(){return this._order}set order(e){this._order=e,this._onChangeCallback()}set(e,t,n,r=this._order){return this._x=e,this._y=t,this._z=n,this._order=r,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._order)}copy(e){return this._x=e._x,this._y=e._y,this._z=e._z,this._order=e._order,this._onChangeCallback(),this}setFromRotationMatrix(e,t=this._order,n=!0){let r=e.elements,i=r[0],a=r[4],o=r[8],s=r[1],c=r[5],l=r[9],u=r[2],d=r[6],f=r[10];switch(t){case`XYZ`:this._y=Math.asin(ft(o,-1,1)),Math.abs(o)<.9999999?(this._x=Math.atan2(-l,f),this._z=Math.atan2(-a,i)):(this._x=Math.atan2(d,c),this._z=0);break;case`YXZ`:this._x=Math.asin(-ft(l,-1,1)),Math.abs(l)<.9999999?(this._y=Math.atan2(o,f),this._z=Math.atan2(s,c)):(this._y=Math.atan2(-u,i),this._z=0);break;case`ZXY`:this._x=Math.asin(ft(d,-1,1)),Math.abs(d)<.9999999?(this._y=Math.atan2(-u,f),this._z=Math.atan2(-a,c)):(this._y=0,this._z=Math.atan2(s,i));break;case`ZYX`:this._y=Math.asin(-ft(u,-1,1)),Math.abs(u)<.9999999?(this._x=Math.atan2(d,f),this._z=Math.atan2(s,i)):(this._x=0,this._z=Math.atan2(-a,c));break;case`YZX`:this._z=Math.asin(ft(s,-1,1)),Math.abs(s)<.9999999?(this._x=Math.atan2(-l,c),this._y=Math.atan2(-u,i)):(this._x=0,this._y=Math.atan2(o,f));break;case`XZY`:this._z=Math.asin(-ft(a,-1,1)),Math.abs(a)<.9999999?(this._x=Math.atan2(d,c),this._y=Math.atan2(o,i)):(this._x=Math.atan2(-l,f),this._y=0);break;default:tt(`Euler: .setFromRotationMatrix() encountered an unknown order: `+t)}return this._order=t,n===!0&&this._onChangeCallback(),this}setFromQuaternion(e,t,n){return mn.makeRotationFromQuaternion(e),this.setFromRotationMatrix(mn,t,n)}setFromVector3(e,t=this._order){return this.set(e.x,e.y,e.z,t)}reorder(e){return hn.setFromEuler(this),this.setFromQuaternion(hn,e)}equals(e){return e._x===this._x&&e._y===this._y&&e._z===this._z&&e._order===this._order}fromArray(e){return this._x=e[0],this._y=e[1],this._z=e[2],e[3]!==void 0&&(this._order=e[3]),this._onChangeCallback(),this}toArray(e=[],t=0){return e[t]=this._x,e[t+1]=this._y,e[t+2]=this._z,e[t+3]=this._order,e}_onChange(e){return this._onChangeCallback=e,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._order}};gn.DEFAULT_ORDER=`XYZ`;var _n=class{constructor(){this.mask=1}set(e){this.mask=1<<e>>>0}enable(e){this.mask|=1<<e}enableAll(){this.mask=-1}toggle(e){this.mask^=1<<e}disable(e){this.mask&=~(1<<e)}disableAll(){this.mask=0}test(e){return(this.mask&e.mask)!==0}isEnabled(e){return!!(this.mask&1<<e)}},vn=0,yn=new L,bn=new Ft,xn=new on,Sn=new L,Cn=new L,wn=new L,Tn=new Ft,En=new L(1,0,0),Dn=new L(0,1,0),On=new L(0,0,1),kn={type:`added`},An={type:`removed`},jn={type:`childadded`,child:null},Mn={type:`childremoved`,child:null},Nn=class e extends ot{constructor(){super(),this.isObject3D=!0,Object.defineProperty(this,"id",{value:vn++}),this.uuid=dt(),this.name=``,this.type=`Object3D`,this.parent=null,this.children=[],this.up=e.DEFAULT_UP.clone();let t=new L,n=new gn,r=new Ft,i=new L(1,1,1);function a(){r.setFromEuler(n,!1)}function o(){n.setFromQuaternion(r,void 0,!1)}n._onChange(a),r._onChange(o),Object.defineProperties(this,{position:{configurable:!0,enumerable:!0,value:t},rotation:{configurable:!0,enumerable:!0,value:n},quaternion:{configurable:!0,enumerable:!0,value:r},scale:{configurable:!0,enumerable:!0,value:i},modelViewMatrix:{value:new on},normalMatrix:{value:new Rt}}),this.matrix=new on,this.matrixWorld=new on,this.matrixAutoUpdate=e.DEFAULT_MATRIX_AUTO_UPDATE,this.matrixWorldAutoUpdate=e.DEFAULT_MATRIX_WORLD_AUTO_UPDATE,this.matrixWorldNeedsUpdate=!1,this.layers=new _n,this.visible=!0,this.castShadow=!1,this.receiveShadow=!1,this.frustumCulled=!0,this.renderOrder=0,this.animations=[],this.customDepthMaterial=void 0,this.customDistanceMaterial=void 0,this.static=!1,this.userData={},this.pivot=null}onBeforeShadow(){}onAfterShadow(){}onBeforeRender(){}onAfterRender(){}applyMatrix4(e){this.matrixAutoUpdate&&this.updateMatrix(),this.matrix.premultiply(e),this.matrix.decompose(this.position,this.quaternion,this.scale),this.pivot!==null&&this.position.copy(this.pivot).applyMatrix4(this.matrix).sub(this.pivot)}applyQuaternion(e){return this.quaternion.premultiply(e),this}setRotationFromAxisAngle(e,t){this.quaternion.setFromAxisAngle(e,t)}setRotationFromEuler(e){this.quaternion.setFromEuler(e,!0)}setRotationFromMatrix(e){this.quaternion.setFromRotationMatrix(e)}setRotationFromQuaternion(e){this.quaternion.copy(e)}rotateOnAxis(e,t){return bn.setFromAxisAngle(e,t),this.quaternion.multiply(bn),this}rotateOnWorldAxis(e,t){return bn.setFromAxisAngle(e,t),this.quaternion.premultiply(bn),this}rotateX(e){return this.rotateOnAxis(En,e)}rotateY(e){return this.rotateOnAxis(Dn,e)}rotateZ(e){return this.rotateOnAxis(On,e)}translateOnAxis(e,t){return yn.copy(e).applyQuaternion(this.quaternion),this.position.add(yn.multiplyScalar(t)),this}translateX(e){return this.translateOnAxis(En,e)}translateY(e){return this.translateOnAxis(Dn,e)}translateZ(e){return this.translateOnAxis(On,e)}localToWorld(e){return this.updateWorldMatrix(!0,!1),e.applyMatrix4(this.matrixWorld)}worldToLocal(e){return this.updateWorldMatrix(!0,!1),e.applyMatrix4(xn.copy(this.matrixWorld).invert())}lookAt(e,t,n){e.isVector3?Sn.copy(e):Sn.set(e,t,n);let r=this.parent;this.updateWorldMatrix(!0,!1),Cn.setFromMatrixPosition(this.matrixWorld),this.isCamera||this.isLight?xn.lookAt(Cn,Sn,this.up):xn.lookAt(Sn,Cn,this.up),this.quaternion.setFromRotationMatrix(xn),r&&(xn.extractRotation(r.matrixWorld),bn.setFromRotationMatrix(xn),this.quaternion.premultiply(bn.invert()))}add(e){if(arguments.length>1){for(let e=0;e<arguments.length;e++)this.add(arguments[e]);return this}return e===this?(nt(`Object3D.add: object can't be added as a child of itself.`,e),this):(e&&e.isObject3D?(e.removeFromParent(),e.parent=this,this.children.push(e),e.dispatchEvent(kn),jn.child=e,this.dispatchEvent(jn),jn.child=null):nt(`Object3D.add: object not an instance of THREE.Object3D.`,e),this)}remove(e){if(arguments.length>1){for(let e=0;e<arguments.length;e++)this.remove(arguments[e]);return this}let t=this.children.indexOf(e);return t!==-1&&(e.parent=null,this.children.splice(t,1),e.dispatchEvent(An),Mn.child=e,this.dispatchEvent(Mn),Mn.child=null),this}removeFromParent(){let e=this.parent;return e!==null&&e.remove(this),this}clear(){return this.remove(...this.children)}attach(e){return this.updateWorldMatrix(!0,!1),xn.copy(this.matrixWorld).invert(),e.parent!==null&&(e.parent.updateWorldMatrix(!0,!1),xn.multiply(e.parent.matrixWorld)),e.applyMatrix4(xn),e.removeFromParent(),e.parent=this,this.children.push(e),e.updateWorldMatrix(!1,!0),e.dispatchEvent(kn),jn.child=e,this.dispatchEvent(jn),jn.child=null,this}getObjectById(e){return this.getObjectByProperty(`id`,e)}getObjectByName(e){return this.getObjectByProperty(`name`,e)}getObjectByProperty(e,t){if(this[e]===t)return this;for(let n=0,r=this.children.length;n<r;n++){let r=this.children[n].getObjectByProperty(e,t);if(r!==void 0)return r}}getObjectsByProperty(e,t,n=[]){this[e]===t&&n.push(this);let r=this.children;for(let i=0,a=r.length;i<a;i++)r[i].getObjectsByProperty(e,t,n);return n}getWorldPosition(e){return this.updateWorldMatrix(!0,!1),e.setFromMatrixPosition(this.matrixWorld)}getWorldQuaternion(e){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(Cn,e,wn),e}getWorldScale(e){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(Cn,Tn,e),e}getWorldDirection(e){this.updateWorldMatrix(!0,!1);let t=this.matrixWorld.elements;return e.set(t[8],t[9],t[10]).normalize()}raycast(){}intersectsFrustum(){return!0}traverse(e){e(this);let t=this.children;for(let n=0,r=t.length;n<r;n++)t[n].traverse(e)}traverseVisible(e){if(this.visible===!1)return;e(this);let t=this.children;for(let n=0,r=t.length;n<r;n++)t[n].traverseVisible(e)}traverseAncestors(e){let t=this.parent;t!==null&&(e(t),t.traverseAncestors(e))}updateMatrix(){this.matrix.compose(this.position,this.quaternion,this.scale);let e=this.pivot;if(e!==null){let t=e.x,n=e.y,r=e.z,i=this.matrix.elements;i[12]+=t-i[0]*t-i[4]*n-i[8]*r,i[13]+=n-i[1]*t-i[5]*n-i[9]*r,i[14]+=r-i[2]*t-i[6]*n-i[10]*r}this.matrixWorldNeedsUpdate=!0}updateMatrixWorld(e){this.matrixAutoUpdate&&this.updateMatrix(),(this.matrixWorldNeedsUpdate||e)&&(this.matrixWorldAutoUpdate===!0&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix)),this.matrixWorldNeedsUpdate=!1,e=!0);let t=this.children;for(let n=0,r=t.length;n<r;n++)t[n].updateMatrixWorld(e)}updateWorldMatrix(e,t,n=!1){let r=this.parent;if(e===!0&&r!==null&&r.updateWorldMatrix(!0,!1),this.matrixAutoUpdate&&this.updateMatrix(),(this.matrixWorldNeedsUpdate||n)&&(this.matrixWorldAutoUpdate===!0&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix)),this.matrixWorldNeedsUpdate=!1,n=!0),t===!0){let e=this.children;for(let t=0,r=e.length;t<r;t++)e[t].updateWorldMatrix(!1,!0,n)}}toJSON(e){let t=e===void 0||typeof e==`string`,n={};t&&(e={geometries:{},materials:{},textures:{},images:{},shapes:{},skeletons:{},animations:{},nodes:{}},n.metadata={version:4.7,type:`Object`,generator:`Object3D.toJSON`});let r={};r.uuid=this.uuid,r.type=this.type,r.name=this.name,r.castShadow=this.castShadow,r.receiveShadow=this.receiveShadow,r.visible=this.visible,r.frustumCulled=this.frustumCulled,r.renderOrder=this.renderOrder,r.static=this.static,r.matrixAutoUpdate=this.matrixAutoUpdate,Object.keys(this.userData).length>0&&(r.userData=this.userData),r.layers=this.layers.mask,r.matrix=this.matrix.toArray(),r.up=this.up.toArray(),this.pivot!==null&&(r.pivot=this.pivot.toArray()),this.morphTargetDictionary!==void 0&&(r.morphTargetDictionary=Object.assign({},this.morphTargetDictionary)),this.morphTargetInfluences!==void 0&&(r.morphTargetInfluences=this.morphTargetInfluences.slice()),this.isInstancedMesh&&(r.type=`InstancedMesh`,r.count=this.count,r.instanceMatrix=this.instanceMatrix.toJSON(),this.instanceColor!==null&&(r.instanceColor=this.instanceColor.toJSON())),this.isBatchedMesh&&(r.type=`BatchedMesh`,r.perObjectFrustumCulled=this.perObjectFrustumCulled,r.sortObjects=this.sortObjects,r.drawRanges=this._drawRanges,r.reservedRanges=this._reservedRanges,r.geometryInfo=this._geometryInfo.map(e=>({...e,boundingBox:e.boundingBox?e.boundingBox.toJSON():void 0,boundingSphere:e.boundingSphere?e.boundingSphere.toJSON():void 0})),r.instanceInfo=this._instanceInfo.map(e=>({...e})),r.availableInstanceIds=this._availableInstanceIds.slice(),r.availableGeometryIds=this._availableGeometryIds.slice(),r.nextIndexStart=this._nextIndexStart,r.nextVertexStart=this._nextVertexStart,r.geometryCount=this._geometryCount,r.maxInstanceCount=this._maxInstanceCount,r.maxVertexCount=this._maxVertexCount,r.maxIndexCount=this._maxIndexCount,r.geometryInitialized=this._geometryInitialized,r.matricesTexture=this._matricesTexture.toJSON(e),r.indirectTexture=this._indirectTexture.toJSON(e),this._colorsTexture!==null&&(r.colorsTexture=this._colorsTexture.toJSON(e)),this.boundingSphere!==null&&(r.boundingSphere=this.boundingSphere.toJSON()),this.boundingBox!==null&&(r.boundingBox=this.boundingBox.toJSON()));function i(t,n){return t[n.uuid]===void 0&&(t[n.uuid]=n.toJSON(e)),n.uuid}if(this.isScene)this.background&&(this.background.isColor?r.background=this.background.toJSON():this.background.isTexture&&(r.background=this.background.toJSON(e).uuid)),this.environment&&this.environment.isTexture&&this.environment.isRenderTargetTexture!==!0&&(r.environment=this.environment.toJSON(e).uuid);else if(this.isMesh||this.isLine||this.isPoints){r.geometry=i(e.geometries,this.geometry);let t=this.geometry.parameters;if(t!==void 0&&t.shapes!==void 0){let n=t.shapes;if(Array.isArray(n))for(let t=0,r=n.length;t<r;t++){let r=n[t];i(e.shapes,r)}else i(e.shapes,n)}}if(this.isSkinnedMesh&&(r.bindMode=this.bindMode,r.bindMatrix=this.bindMatrix.toArray(),this.skeleton!==void 0&&(i(e.skeletons,this.skeleton),r.skeleton=this.skeleton.uuid)),this.material!==void 0){if(Array.isArray(this.material)){let t=[];for(let n=0,r=this.material.length;n<r;n++)t.push(i(e.materials,this.material[n]));r.material=t}else r.material=i(e.materials,this.material)}if(this.children.length>0){r.children=[];for(let t=0;t<this.children.length;t++)r.children.push(this.children[t].toJSON(e).object)}if(this.animations.length>0){r.animations=[];for(let t=0;t<this.animations.length;t++){let n=this.animations[t];r.animations.push(i(e.animations,n))}}if(t){let t=a(e.geometries),r=a(e.materials),i=a(e.textures),o=a(e.images),s=a(e.shapes),c=a(e.skeletons),l=a(e.animations),u=a(e.nodes);t.length>0&&(n.geometries=t),r.length>0&&(n.materials=r),i.length>0&&(n.textures=i),o.length>0&&(n.images=o),s.length>0&&(n.shapes=s),c.length>0&&(n.skeletons=c),l.length>0&&(n.animations=l),u.length>0&&(n.nodes=u)}return n.object=r,n;function a(e){let t=[];for(let n in e){let r=e[n];delete r.metadata,t.push(r)}return t}}clone(e){return new this.constructor().copy(this,e)}copy(e,t=!0){if(this.name=e.name,this.up.copy(e.up),this.position.copy(e.position),this.rotation.order=e.rotation.order,this.quaternion.copy(e.quaternion),this.scale.copy(e.scale),this.pivot=e.pivot===null?null:e.pivot.clone(),this.matrix.copy(e.matrix),this.matrixWorld.copy(e.matrixWorld),this.matrixAutoUpdate=e.matrixAutoUpdate,this.matrixWorldAutoUpdate=e.matrixWorldAutoUpdate,this.matrixWorldNeedsUpdate=e.matrixWorldNeedsUpdate,this.layers.mask=e.layers.mask,this.visible=e.visible,this.castShadow=e.castShadow,this.receiveShadow=e.receiveShadow,this.frustumCulled=e.frustumCulled,this.renderOrder=e.renderOrder,this.static=e.static,this.animations=e.animations.slice(),this.userData=JSON.parse(JSON.stringify(e.userData)),t===!0)for(let t=0;t<e.children.length;t++){let n=e.children[t];this.add(n.clone())}return this}dispose(){this.dispatchEvent({type:`dispose`})}};Nn.DEFAULT_UP=new L(0,1,0),Nn.DEFAULT_MATRIX_AUTO_UPDATE=!0,Nn.DEFAULT_MATRIX_WORLD_AUTO_UPDATE=!0;var Pn=class extends Nn{constructor(){super(),this.isGroup=!0,this.type=`Group`}},Fn={type:`move`},In=class{constructor(){this._targetRay=null,this._grip=null,this._hand=null}getHandSpace(){return this._hand===null&&(this._hand=new Pn,this._hand.matrixAutoUpdate=!1,this._hand.visible=!1,this._hand.joints={},this._hand.inputState={pinching:!1}),this._hand}getTargetRaySpace(){return this._targetRay===null&&(this._targetRay=new Pn,this._targetRay.matrixAutoUpdate=!1,this._targetRay.visible=!1,this._targetRay.hasLinearVelocity=!1,this._targetRay.linearVelocity=new L,this._targetRay.hasAngularVelocity=!1,this._targetRay.angularVelocity=new L),this._targetRay}getGripSpace(){return this._grip===null&&(this._grip=new Pn,this._grip.matrixAutoUpdate=!1,this._grip.visible=!1,this._grip.hasLinearVelocity=!1,this._grip.linearVelocity=new L,this._grip.hasAngularVelocity=!1,this._grip.angularVelocity=new L,this._grip.eventsEnabled=!1),this._grip}dispatchEvent(e){return this._targetRay!==null&&this._targetRay.dispatchEvent(e),this._grip!==null&&this._grip.dispatchEvent(e),this._hand!==null&&this._hand.dispatchEvent(e),this}connect(e){if(e&&e.hand){let t=this._hand;if(t)for(let n of e.hand.values())this._getHandJoint(t,n)}return this.dispatchEvent({type:`connected`,data:e}),this}disconnect(e){return this.dispatchEvent({type:`disconnected`,data:e}),this._targetRay!==null&&(this._targetRay.visible=!1),this._grip!==null&&(this._grip.visible=!1),this._hand!==null&&(this._hand.visible=!1),this}update(e,t,n){let r=null,i=null,a=null,o=this._targetRay,s=this._grip,c=this._hand;if(e&&t.session.visibilityState!==`visible-blurred`){if(c&&e.hand){a=!0;for(let r of e.hand.values()){let e=t.getJointPose(r,n),i=this._getHandJoint(c,r);e!==null&&(i.matrix.fromArray(e.transform.matrix),i.matrix.decompose(i.position,i.quaternion,i.scale),i.matrixWorldNeedsUpdate=!0,i.jointRadius=e.radius),i.visible=e!==null}let r=c.joints[`index-finger-tip`],i=c.joints[`thumb-tip`],o=r.position.distanceTo(i.position);c.inputState.pinching&&o>.025?(c.inputState.pinching=!1,this.dispatchEvent({type:`pinchend`,handedness:e.handedness,target:this})):!c.inputState.pinching&&o<=.015&&(c.inputState.pinching=!0,this.dispatchEvent({type:`pinchstart`,handedness:e.handedness,target:this}))}else s!==null&&e.gripSpace&&(i=t.getPose(e.gripSpace,n),i!==null&&(s.matrix.fromArray(i.transform.matrix),s.matrix.decompose(s.position,s.quaternion,s.scale),s.matrixWorldNeedsUpdate=!0,i.linearVelocity?(s.hasLinearVelocity=!0,s.linearVelocity.copy(i.linearVelocity)):s.hasLinearVelocity=!1,i.angularVelocity?(s.hasAngularVelocity=!0,s.angularVelocity.copy(i.angularVelocity)):s.hasAngularVelocity=!1,s.eventsEnabled&&s.dispatchEvent({type:`gripUpdated`,data:e,target:this})));o!==null&&(r=t.getPose(e.targetRaySpace,n),r===null&&i!==null&&(r=i),r!==null&&(o.matrix.fromArray(r.transform.matrix),o.matrix.decompose(o.position,o.quaternion,o.scale),o.matrixWorldNeedsUpdate=!0,r.linearVelocity?(o.hasLinearVelocity=!0,o.linearVelocity.copy(r.linearVelocity)):o.hasLinearVelocity=!1,r.angularVelocity?(o.hasAngularVelocity=!0,o.angularVelocity.copy(r.angularVelocity)):o.hasAngularVelocity=!1,this.dispatchEvent(Fn)))}return o!==null&&(o.visible=r!==null),s!==null&&(s.visible=i!==null),c!==null&&(c.visible=a!==null),this}_getHandJoint(e,t){if(e.joints[t.jointName]===void 0){let n=new Pn;n.matrixAutoUpdate=!1,n.visible=!1,e.joints[t.jointName]=n,e.add(n)}return e.joints[t.jointName]}},Ln={aliceblue:15792383,antiquewhite:16444375,aqua:65535,aquamarine:8388564,azure:15794175,beige:16119260,bisque:16770244,black:0,blanchedalmond:16772045,blue:255,blueviolet:9055202,brown:10824234,burlywood:14596231,cadetblue:6266528,chartreuse:8388352,chocolate:13789470,coral:16744272,cornflowerblue:6591981,cornsilk:16775388,crimson:14423100,cyan:65535,darkblue:139,darkcyan:35723,darkgoldenrod:12092939,darkgray:11119017,darkgreen:25600,darkgrey:11119017,darkkhaki:12433259,darkmagenta:9109643,darkolivegreen:5597999,darkorange:16747520,darkorchid:10040012,darkred:9109504,darksalmon:15308410,darkseagreen:9419919,darkslateblue:4734347,darkslategray:3100495,darkslategrey:3100495,darkturquoise:52945,darkviolet:9699539,deeppink:16716947,deepskyblue:49151,dimgray:6908265,dimgrey:6908265,dodgerblue:2003199,firebrick:11674146,floralwhite:16775920,forestgreen:2263842,fuchsia:16711935,gainsboro:14474460,ghostwhite:16316671,gold:16766720,goldenrod:14329120,gray:8421504,green:32768,greenyellow:11403055,grey:8421504,honeydew:15794160,hotpink:16738740,indianred:13458524,indigo:4915330,ivory:16777200,khaki:15787660,lavender:15132410,lavenderblush:16773365,lawngreen:8190976,lemonchiffon:16775885,lightblue:11393254,lightcoral:15761536,lightcyan:14745599,lightgoldenrodyellow:16448210,lightgray:13882323,lightgreen:9498256,lightgrey:13882323,lightpink:16758465,lightsalmon:16752762,lightseagreen:2142890,lightskyblue:8900346,lightslategray:7833753,lightslategrey:7833753,lightsteelblue:11584734,lightyellow:16777184,lime:65280,limegreen:3329330,linen:16445670,magenta:16711935,maroon:8388608,mediumaquamarine:6737322,mediumblue:205,mediumorchid:12211667,mediumpurple:9662683,mediumseagreen:3978097,mediumslateblue:8087790,mediumspringgreen:64154,mediumturquoise:4772300,mediumvioletred:13047173,midnightblue:1644912,mintcream:16121850,mistyrose:16770273,moccasin:16770229,navajowhite:16768685,navy:128,oldlace:16643558,olive:8421376,olivedrab:7048739,orange:16753920,orangered:16729344,orchid:14315734,palegoldenrod:15657130,palegreen:10025880,paleturquoise:11529966,palevioletred:14381203,papayawhip:16773077,peachpuff:16767673,peru:13468991,pink:16761035,plum:14524637,powderblue:11591910,purple:8388736,rebeccapurple:6697881,red:16711680,rosybrown:12357519,royalblue:4286945,saddlebrown:9127187,salmon:16416882,sandybrown:16032864,seagreen:3050327,seashell:16774638,sienna:10506797,silver:12632256,skyblue:8900331,slateblue:6970061,slategray:7372944,slategrey:7372944,snow:16775930,springgreen:65407,steelblue:4620980,tan:13808780,teal:32896,thistle:14204888,tomato:16737095,turquoise:4251856,violet:15631086,wheat:16113331,white:16777215,whitesmoke:16119285,yellow:16776960,yellowgreen:10145074},Rn={h:0,s:0,l:0},zn={h:0,s:0,l:0};function Bn(e,t,n){return n<0&&(n+=1),n>1&&--n,n<1/6?e+(t-e)*6*n:n<1/2?t:n<2/3?e+(t-e)*6*(2/3-n):e}var R=class{constructor(e,t,n){return this.isColor=!0,this.r=1,this.g=1,this.b=1,this.set(e,t,n)}set(e,t,n){if(t===void 0&&n===void 0){let t=e;t&&t.isColor?this.copy(t):typeof t==`number`?this.setHex(t):typeof t==`string`&&this.setStyle(t)}else this.setRGB(e,t,n);return this}setScalar(e){return this.r=e,this.g=e,this.b=e,this}setHex(e,t=Be){return e=Math.floor(e),this.r=(e>>16&255)/255,this.g=(e>>8&255)/255,this.b=(e&255)/255,Ut.colorSpaceToWorking(this,t),this}setRGB(e,t,n,r=Ut.workingColorSpace){return this.r=e,this.g=t,this.b=n,Ut.colorSpaceToWorking(this,r),this}setHSL(e,t,n,r=Ut.workingColorSpace){if(e=pt(e,1),t=ft(t,0,1),n=ft(n,0,1),t===0)this.r=this.g=this.b=n;else{let r=n<=.5?n*(1+t):n+t-n*t,i=2*n-r;this.r=Bn(i,r,e+1/3),this.g=Bn(i,r,e),this.b=Bn(i,r,e-1/3)}return Ut.colorSpaceToWorking(this,r),this}setStyle(e,t=Be){function n(t){t!==void 0&&parseFloat(t)<1&&tt(`Color: Alpha component of `+e+` will be ignored.`)}let r;if(r=/^(\w+)\(([^\)]*)\)/.exec(e)){let i,a=r[1],o=r[2];switch(a){case`rgb`:case`rgba`:if(i=/^\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*(?:,\s*(\d+(?:\.\d+)?|\.\d+)\s*)?$/.exec(o))return n(i[4]),this.setRGB(Math.min(255,parseInt(i[1],10))/255,Math.min(255,parseInt(i[2],10))/255,Math.min(255,parseInt(i[3],10))/255,t);if(i=/^\s*(\d+(?:\.\d+)?|\.\d+)\%\s*,\s*(\d+(?:\.\d+)?|\.\d+)\%\s*,\s*(\d+(?:\.\d+)?|\.\d+)\%\s*(?:,\s*(\d+(?:\.\d+)?|\.\d+)\s*)?$/.exec(o))return n(i[4]),this.setRGB(Math.min(100,parseFloat(i[1]))/100,Math.min(100,parseFloat(i[2]))/100,Math.min(100,parseFloat(i[3]))/100,t);break;case`hsl`:case`hsla`:if(i=/^\s*([+-]?(?:\d+(?:\.\d+)?|\.\d+))\s*,\s*(\d+(?:\.\d+)?|\.\d+)\%\s*,\s*(\d+(?:\.\d+)?|\.\d+)\%\s*(?:,\s*(\d+(?:\.\d+)?|\.\d+)\s*)?$/.exec(o))return n(i[4]),this.setHSL(parseFloat(i[1])/360,parseFloat(i[2])/100,parseFloat(i[3])/100,t);break;default:tt(`Color: Unknown color model `+e)}}else if(r=/^\#([A-Fa-f\d]+)$/.exec(e)){let n=r[1],i=n.length;if(i===3)return this.setRGB(parseInt(n.charAt(0),16)/15,parseInt(n.charAt(1),16)/15,parseInt(n.charAt(2),16)/15,t);if(i===6)return this.setHex(parseInt(n,16),t);tt(`Color: Invalid hex color `+e)}else if(e&&e.length>0)return this.setColorName(e,t);return this}setColorName(e,t=Be){let n=Ln[e.toLowerCase()];return n===void 0?tt(`Color: Unknown color `+e):this.setHex(n,t),this}clone(){return new this.constructor(this.r,this.g,this.b)}copy(e){return this.r=e.r,this.g=e.g,this.b=e.b,this}copySRGBToLinear(e){return this.r=Wt(e.r),this.g=Wt(e.g),this.b=Wt(e.b),this}copyLinearToSRGB(e){return this.r=Gt(e.r),this.g=Gt(e.g),this.b=Gt(e.b),this}convertSRGBToLinear(){return this.copySRGBToLinear(this),this}convertLinearToSRGB(){return this.copyLinearToSRGB(this),this}getHex(e=Be){return Ut.workingToColorSpace(Vn.copy(this),e),Math.round(ft(Vn.r*255,0,255))*65536+Math.round(ft(Vn.g*255,0,255))*256+Math.round(ft(Vn.b*255,0,255))}getHexString(e=Be){return(`000000`+this.getHex(e).toString(16)).slice(-6)}getHSL(e,t=Ut.workingColorSpace){Ut.workingToColorSpace(Vn.copy(this),t);let n=Vn.r,r=Vn.g,i=Vn.b,a=Math.max(n,r,i),o=Math.min(n,r,i),s,c,l=(o+a)/2;if(o===a)s=0,c=0;else{let e=a-o;switch(c=l<=.5?e/(a+o):e/(2-a-o),a){case n:s=(r-i)/e+(r<i?6:0);break;case r:s=(i-n)/e+2;break;case i:s=(n-r)/e+4}s/=6}return e.h=s,e.s=c,e.l=l,e}getRGB(e,t=Ut.workingColorSpace){return Ut.workingToColorSpace(Vn.copy(this),t),e.r=Vn.r,e.g=Vn.g,e.b=Vn.b,e}getStyle(e=Be){Ut.workingToColorSpace(Vn.copy(this),e);let t=Vn.r,n=Vn.g,r=Vn.b;return e===`srgb`?`rgb(${Math.round(t*255)},${Math.round(n*255)},${Math.round(r*255)})`:`color(${e} ${t.toFixed(3)} ${n.toFixed(3)} ${r.toFixed(3)})`}offsetHSL(e,t,n){return this.getHSL(Rn),this.setHSL(Rn.h+e,Rn.s+t,Rn.l+n)}add(e){return this.r+=e.r,this.g+=e.g,this.b+=e.b,this}addColors(e,t){return this.r=e.r+t.r,this.g=e.g+t.g,this.b=e.b+t.b,this}addScalar(e){return this.r+=e,this.g+=e,this.b+=e,this}sub(e){return this.r=Math.max(0,this.r-e.r),this.g=Math.max(0,this.g-e.g),this.b=Math.max(0,this.b-e.b),this}multiply(e){return this.r*=e.r,this.g*=e.g,this.b*=e.b,this}multiplyScalar(e){return this.r*=e,this.g*=e,this.b*=e,this}lerp(e,t){return this.r+=(e.r-this.r)*t,this.g+=(e.g-this.g)*t,this.b+=(e.b-this.b)*t,this}lerpColors(e,t,n){return this.r=e.r+(t.r-e.r)*n,this.g=e.g+(t.g-e.g)*n,this.b=e.b+(t.b-e.b)*n,this}lerpHSL(e,t){this.getHSL(Rn),e.getHSL(zn);let n=gt(Rn.h,zn.h,t),r=gt(Rn.s,zn.s,t),i=gt(Rn.l,zn.l,t);return this.setHSL(n,r,i),this}setFromVector3(e){return this.r=e.x,this.g=e.y,this.b=e.z,this}applyMatrix3(e){let t=this.r,n=this.g,r=this.b,i=e.elements;return this.r=i[0]*t+i[3]*n+i[6]*r,this.g=i[1]*t+i[4]*n+i[7]*r,this.b=i[2]*t+i[5]*n+i[8]*r,this}equals(e){return e.r===this.r&&e.g===this.g&&e.b===this.b}fromArray(e,t=0){return this.r=e[t],this.g=e[t+1],this.b=e[t+2],this}toArray(e=[],t=0){return e[t]=this.r,e[t+1]=this.g,e[t+2]=this.b,e}fromBufferAttribute(e,t){return this.r=e.getX(t),this.g=e.getY(t),this.b=e.getZ(t),this}toJSON(){return this.getHex()}*[Symbol.iterator](){yield this.r,yield this.g,yield this.b}},Vn=new R;R.NAMES=Ln;var Hn=class extends Nn{constructor(){super(),this.isScene=!0,this.type=`Scene`,this.background=null,this.environment=null,this.fog=null,this.backgroundBlurriness=0,this.backgroundIntensity=1,this.backgroundRotation=new gn,this.environmentIntensity=1,this.environmentRotation=new gn,this.overrideMaterial=null,typeof __THREE_DEVTOOLS__<`u`&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent(`observe`,{detail:this}))}copy(e,t){return super.copy(e,t),this.background=e.background===null?null:e.background.clone(),this.environment=e.environment===null?null:e.environment.clone(),this.fog=e.fog===null?null:e.fog.clone(),this.backgroundBlurriness=e.backgroundBlurriness,this.backgroundIntensity=e.backgroundIntensity,this.backgroundRotation.copy(e.backgroundRotation),this.environmentIntensity=e.environmentIntensity,this.environmentRotation.copy(e.environmentRotation),this.overrideMaterial=e.overrideMaterial===null?null:e.overrideMaterial.clone(),this.matrixAutoUpdate=e.matrixAutoUpdate,this}toJSON(e){let t=super.toJSON(e);return this.fog!==null&&(t.object.fog=this.fog.toJSON()),t.object.backgroundBlurriness=this.backgroundBlurriness,t.object.backgroundIntensity=this.backgroundIntensity,t.object.backgroundRotation=this.backgroundRotation.toArray(),t.object.environmentIntensity=this.environmentIntensity,t.object.environmentRotation=this.environmentRotation.toArray(),t}},Un=new L,Wn=new L,Gn=new L,Kn=new L,qn=new L,Jn=new L,Yn=new L,Xn=new L,Zn=new L,Qn=new L,$n=new en,er=new en,tr=new en,nr=class e{constructor(e=new L,t=new L,n=new L){this.a=e,this.b=t,this.c=n}static getNormal(e,t,n,r){r.subVectors(n,t),Un.subVectors(e,t),r.cross(Un);let i=r.lengthSq();return i>0?r.multiplyScalar(1/Math.sqrt(i)):r.set(0,0,0)}static getBarycoord(e,t,n,r,i){Un.subVectors(r,t),Wn.subVectors(n,t),Gn.subVectors(e,t);let a=Un.dot(Un),o=Un.dot(Wn),s=Un.dot(Gn),c=Wn.dot(Wn),l=Wn.dot(Gn),u=a*c-o*o;if(u===0)return i.set(0,0,0),null;let d=1/u,f=(c*s-o*l)*d,p=(a*l-o*s)*d;return i.set(1-f-p,p,f)}static containsPoint(e,t,n,r){return this.getBarycoord(e,t,n,r,Kn)!==null&&Kn.x>=0&&Kn.y>=0&&Kn.x+Kn.y<=1}static getInterpolation(e,t,n,r,i,a,o,s){return this.getBarycoord(e,t,n,r,Kn)===null?(s.x=0,s.y=0,`z`in s&&(s.z=0),`w`in s&&(s.w=0),null):(s.setScalar(0),s.addScaledVector(i,Kn.x),s.addScaledVector(a,Kn.y),s.addScaledVector(o,Kn.z),s)}static getInterpolatedAttribute(e,t,n,r,i,a){return $n.setScalar(0),er.setScalar(0),tr.setScalar(0),$n.fromBufferAttribute(e,t),er.fromBufferAttribute(e,n),tr.fromBufferAttribute(e,r),a.setScalar(0),a.addScaledVector($n,i.x),a.addScaledVector(er,i.y),a.addScaledVector(tr,i.z),a}static isFrontFacing(e,t,n,r){return Un.subVectors(n,t),Wn.subVectors(e,t),Un.cross(Wn).dot(r)<0}set(e,t,n){return this.a.copy(e),this.b.copy(t),this.c.copy(n),this}setFromPointsAndIndices(e,t,n,r){return this.a.copy(e[t]),this.b.copy(e[n]),this.c.copy(e[r]),this}setFromAttributeAndIndices(e,t,n,r){return this.a.fromBufferAttribute(e,t),this.b.fromBufferAttribute(e,n),this.c.fromBufferAttribute(e,r),this}clone(){return new this.constructor().copy(this)}copy(e){return this.a.copy(e.a),this.b.copy(e.b),this.c.copy(e.c),this}getArea(){return Un.subVectors(this.c,this.b),Wn.subVectors(this.a,this.b),Un.cross(Wn).length()*.5}getMidpoint(e){return e.addVectors(this.a,this.b).add(this.c).multiplyScalar(1/3)}getNormal(t){return e.getNormal(this.a,this.b,this.c,t)}getPlane(e){return e.setFromCoplanarPoints(this.a,this.b,this.c)}getBarycoord(t,n){return e.getBarycoord(t,this.a,this.b,this.c,n)}getInterpolation(t,n,r,i,a){return e.getInterpolation(t,this.a,this.b,this.c,n,r,i,a)}containsPoint(t){return e.containsPoint(t,this.a,this.b,this.c)}isFrontFacing(t){return e.isFrontFacing(this.a,this.b,this.c,t)}intersectsBox(e){return e.intersectsTriangle(this)}closestPointToPoint(e,t){let n=this.a,r=this.b,i=this.c,a,o;qn.subVectors(r,n),Jn.subVectors(i,n),Xn.subVectors(e,n);let s=qn.dot(Xn),c=Jn.dot(Xn);if(s<=0&&c<=0)return t.copy(n);Zn.subVectors(e,r);let l=qn.dot(Zn),u=Jn.dot(Zn);if(l>=0&&u<=l)return t.copy(r);let d=s*u-l*c;if(d<=0&&s>=0&&l<=0&&s-l>0)return a=s/(s-l),t.copy(n).addScaledVector(qn,a);Qn.subVectors(e,i);let f=qn.dot(Qn),p=Jn.dot(Qn);if(p>=0&&f<=p)return t.copy(i);let m=f*c-s*p;if(m<=0&&c>=0&&p<=0)return o=c/(c-p),t.copy(n).addScaledVector(Jn,o);let h=l*p-f*u;if(h<=0&&u-l>=0&&f-p>=0)return Yn.subVectors(i,r),o=(u-l)/(u-l+(f-p)),t.copy(r).addScaledVector(Yn,o);let g=1/(h+m+d);return a=m*g,o=d*g,t.copy(n).addScaledVector(qn,a).addScaledVector(Jn,o)}equals(e){return e.a.equals(this.a)&&e.b.equals(this.b)&&e.c.equals(this.c)}},rr=class{constructor(e=new L(1/0,1/0,1/0),t=new L(-1/0,-1/0,-1/0)){this.isBox3=!0,this.min=e,this.max=t}set(e,t){return this.min.copy(e),this.max.copy(t),this}setFromArray(e){this.makeEmpty();for(let t=0,n=e.length;t<n;t+=3)this.expandByPoint(ar.fromArray(e,t));return this}setFromBufferAttribute(e){this.makeEmpty();for(let t=0,n=e.count;t<n;t++)this.expandByPoint(ar.fromBufferAttribute(e,t));return this}setFromPoints(e){this.makeEmpty();for(let t=0,n=e.length;t<n;t++)this.expandByPoint(e[t]);return this}setFromCenterAndSize(e,t){let n=ar.copy(t).multiplyScalar(.5);return this.min.copy(e).sub(n),this.max.copy(e).add(n),this}setFromObject(e,t=!1){return this.makeEmpty(),this.expandByObject(e,t)}clone(){return new this.constructor().copy(this)}copy(e){return this.min.copy(e.min),this.max.copy(e.max),this}makeEmpty(){return this.min.x=this.min.y=this.min.z=1/0,this.max.x=this.max.y=this.max.z=-1/0,this}isEmpty(){return this.max.x<this.min.x||this.max.y<this.min.y||this.max.z<this.min.z}getCenter(e){return this.isEmpty()?e.set(0,0,0):e.addVectors(this.min,this.max).multiplyScalar(.5)}getSize(e){return this.isEmpty()?e.set(0,0,0):e.subVectors(this.max,this.min)}expandByPoint(e){return this.min.min(e),this.max.max(e),this}expandByVector(e){return this.min.sub(e),this.max.add(e),this}expandByScalar(e){return this.min.addScalar(-e),this.max.addScalar(e),this}expandByObject(e,t=!1){e.updateWorldMatrix(!1,!1);let n=e.geometry;if(n!==void 0){let r=n.getAttribute(`position`);if(t===!0&&r!==void 0&&e.isInstancedMesh!==!0&&e.isBatchedMesh!==!0)for(let t=0,n=r.count;t<n;t++)e.isMesh===!0?e.getVertexPosition(t,ar):ar.fromBufferAttribute(r,t),ar.applyMatrix4(e.matrixWorld),this.expandByPoint(ar);else e.boundingBox===void 0?(n.boundingBox===null&&n.computeBoundingBox(),or.copy(n.boundingBox)):(e.boundingBox===null&&e.computeBoundingBox(),or.copy(e.boundingBox)),or.applyMatrix4(e.matrixWorld),this.union(or)}let r=e.children;for(let e=0,n=r.length;e<n;e++)this.expandByObject(r[e],t);return this}containsPoint(e){return e.x>=this.min.x&&e.x<=this.max.x&&e.y>=this.min.y&&e.y<=this.max.y&&e.z>=this.min.z&&e.z<=this.max.z}containsBox(e){return this.min.x<=e.min.x&&e.max.x<=this.max.x&&this.min.y<=e.min.y&&e.max.y<=this.max.y&&this.min.z<=e.min.z&&e.max.z<=this.max.z}getParameter(e,t){return t.set((e.x-this.min.x)/(this.max.x-this.min.x),(e.y-this.min.y)/(this.max.y-this.min.y),(e.z-this.min.z)/(this.max.z-this.min.z))}intersectsBox(e){return e.max.x>=this.min.x&&e.min.x<=this.max.x&&e.max.y>=this.min.y&&e.min.y<=this.max.y&&e.max.z>=this.min.z&&e.min.z<=this.max.z}intersectsSphere(e){return this.clampPoint(e.center,ar),ar.distanceToSquared(e.center)<=e.radius*e.radius}intersectsPlane(e){let t,n;return e.normal.x>0?(t=e.normal.x*this.min.x,n=e.normal.x*this.max.x):(t=e.normal.x*this.max.x,n=e.normal.x*this.min.x),e.normal.y>0?(t+=e.normal.y*this.min.y,n+=e.normal.y*this.max.y):(t+=e.normal.y*this.max.y,n+=e.normal.y*this.min.y),e.normal.z>0?(t+=e.normal.z*this.min.z,n+=e.normal.z*this.max.z):(t+=e.normal.z*this.max.z,n+=e.normal.z*this.min.z),t<=-e.constant&&n>=-e.constant}intersectsTriangle(e){if(this.isEmpty())return!1;this.getCenter(pr),mr.subVectors(this.max,pr),sr.subVectors(e.a,pr),cr.subVectors(e.b,pr),lr.subVectors(e.c,pr),ur.subVectors(cr,sr),dr.subVectors(lr,cr),fr.subVectors(sr,lr);let t=[0,-ur.z,ur.y,0,-dr.z,dr.y,0,-fr.z,fr.y,ur.z,0,-ur.x,dr.z,0,-dr.x,fr.z,0,-fr.x,-ur.y,ur.x,0,-dr.y,dr.x,0,-fr.y,fr.x,0];return!_r(t,sr,cr,lr,mr)||(t=[1,0,0,0,1,0,0,0,1],!_r(t,sr,cr,lr,mr))?!1:(hr.crossVectors(ur,dr),t=[hr.x,hr.y,hr.z],_r(t,sr,cr,lr,mr))}clampPoint(e,t){return t.copy(e).clamp(this.min,this.max)}distanceToPoint(e){return this.clampPoint(e,ar).distanceTo(e)}getBoundingSphere(e){return this.isEmpty()?e.makeEmpty():(this.getCenter(e.center),e.radius=this.getSize(ar).length()*.5),e}intersect(e){return this.min.max(e.min),this.max.min(e.max),this.isEmpty()&&this.makeEmpty(),this}union(e){return this.min.min(e.min),this.max.max(e.max),this}applyMatrix4(e){return this.isEmpty()||(ir[0].set(this.min.x,this.min.y,this.min.z).applyMatrix4(e),ir[1].set(this.min.x,this.min.y,this.max.z).applyMatrix4(e),ir[2].set(this.min.x,this.max.y,this.min.z).applyMatrix4(e),ir[3].set(this.min.x,this.max.y,this.max.z).applyMatrix4(e),ir[4].set(this.max.x,this.min.y,this.min.z).applyMatrix4(e),ir[5].set(this.max.x,this.min.y,this.max.z).applyMatrix4(e),ir[6].set(this.max.x,this.max.y,this.min.z).applyMatrix4(e),ir[7].set(this.max.x,this.max.y,this.max.z).applyMatrix4(e),this.setFromPoints(ir)),this}translate(e){return this.min.add(e),this.max.add(e),this}equals(e){return e.min.equals(this.min)&&e.max.equals(this.max)}toJSON(){return{min:this.min.toArray(),max:this.max.toArray()}}fromJSON(e){return this.min.fromArray(e.min),this.max.fromArray(e.max),this}},ir=[new L,new L,new L,new L,new L,new L,new L,new L],ar=new L,or=new rr,sr=new L,cr=new L,lr=new L,ur=new L,dr=new L,fr=new L,pr=new L,mr=new L,hr=new L,gr=new L;function _r(e,t,n,r,i){for(let a=0,o=e.length-3;a<=o;a+=3){gr.fromArray(e,a);let o=i.x*Math.abs(gr.x)+i.y*Math.abs(gr.y)+i.z*Math.abs(gr.z),s=t.dot(gr),c=n.dot(gr),l=r.dot(gr);if(Math.max(-Math.max(s,c,l),Math.min(s,c,l))>o)return!1}return!0}var vr=new L,yr=new I,br=0,xr=class extends ot{constructor(e,t,n=!1){if(super(),Array.isArray(e))throw TypeError(`THREE.BufferAttribute: array should be a Typed Array.`);this.isBufferAttribute=!0,Object.defineProperty(this,"id",{value:br++}),this.name=``,this.array=e,this.itemSize=t,this.count=e===void 0?0:e.length/t,this.normalized=n,this.usage=Ge,this.updateRanges=[],this.gpuType=h,this.version=0,this._normalizationScale=e===void 0?void 0:jt(e)}onUploadCallback(){}set needsUpdate(e){e===!0&&this.version++}setUsage(e){return this.usage=e,this}addUpdateRange(e,t){this.updateRanges.push({start:e,count:t})}clearUpdateRanges(){this.updateRanges.length=0}copy(e){return this.name=e.name,this.array=new e.array.constructor(e.array),this.itemSize=e.itemSize,this.count=e.count,this.normalized=e.normalized,this.usage=e.usage,this.gpuType=e.gpuType,this._normalizationScale=e._normalizationScale,this}copyAt(e,t,n){e*=this.itemSize,n*=t.itemSize;for(let r=0,i=this.itemSize;r<i;r++)this.array[e+r]=t.array[n+r];return this}copyArray(e){return this.array.set(e),this}applyMatrix3(e){if(this.itemSize===2)for(let t=0,n=this.count;t<n;t++)yr.fromBufferAttribute(this,t),yr.applyMatrix3(e),this.setXY(t,yr.x,yr.y);else if(this.itemSize===3)for(let t=0,n=this.count;t<n;t++)vr.fromBufferAttribute(this,t),vr.applyMatrix3(e),this.setXYZ(t,vr.x,vr.y,vr.z);return this}applyMatrix4(e){for(let t=0,n=this.count;t<n;t++)vr.fromBufferAttribute(this,t),vr.applyMatrix4(e),this.setXYZ(t,vr.x,vr.y,vr.z);return this}applyNormalMatrix(e){for(let t=0,n=this.count;t<n;t++)vr.fromBufferAttribute(this,t),vr.applyNormalMatrix(e),this.setXYZ(t,vr.x,vr.y,vr.z);return this}transformDirection(e){for(let t=0,n=this.count;t<n;t++)vr.fromBufferAttribute(this,t),vr.transformDirection(e),this.setXYZ(t,vr.x,vr.y,vr.z);return this}set(e,t=0){return this.array.set(e,t),this}getComponent(e,t){let n=this.array[e*this.itemSize+t];return this.normalized&&(n=this._denormalize(n)),n}setComponent(e,t,n){return this.normalized&&(n=this._normalize(n)),this.array[e*this.itemSize+t]=n,this}getX(e){let t=this.array[e*this.itemSize];return this.normalized&&(t=this._denormalize(t)),t}setX(e,t){return this.normalized&&(t=this._normalize(t)),this.array[e*this.itemSize]=t,this}getY(e){let t=this.array[e*this.itemSize+1];return this.normalized&&(t=this._denormalize(t)),t}setY(e,t){return this.normalized&&(t=this._normalize(t)),this.array[e*this.itemSize+1]=t,this}getZ(e){let t=this.array[e*this.itemSize+2];return this.normalized&&(t=this._denormalize(t)),t}setZ(e,t){return this.normalized&&(t=this._normalize(t)),this.array[e*this.itemSize+2]=t,this}getW(e){let t=this.array[e*this.itemSize+3];return this.normalized&&(t=this._denormalize(t)),t}setW(e,t){return this.normalized&&(t=this._normalize(t)),this.array[e*this.itemSize+3]=t,this}setXY(e,t,n){return e*=this.itemSize,this.normalized&&(t=this._normalize(t),n=this._normalize(n)),this.array[e+0]=t,this.array[e+1]=n,this}setXYZ(e,t,n,r){return e*=this.itemSize,this.normalized&&(t=this._normalize(t),n=this._normalize(n),r=this._normalize(r)),this.array[e+0]=t,this.array[e+1]=n,this.array[e+2]=r,this}setXYZW(e,t,n,r,i){return e*=this.itemSize,this.normalized&&(t=this._normalize(t),n=this._normalize(n),r=this._normalize(r),i=this._normalize(i)),this.array[e+0]=t,this.array[e+1]=n,this.array[e+2]=r,this.array[e+3]=i,this}onUpload(e){return this.onUploadCallback=e,this}clone(){return new this.constructor(this.array,this.itemSize).copy(this)}toJSON(){let e={itemSize:this.itemSize,type:this.array.constructor.name,array:Array.from(this.array),normalized:this.normalized};return e.name=this.name,e.usage=this.usage,e.gpuType=this.gpuType,e}dispose(){this.dispatchEvent({type:`dispose`})}_denormalize(e){let t=this._normalizationScale;return t===void 0?Mt(e,this.array):Math.max(e/t,-1)}_normalize(e){let t=this._normalizationScale;return t===void 0?Nt(e,this.array):Math.round(e*t)}},Sr=class extends xr{constructor(e,t,n){super(new Uint16Array(e),t,n)}},Cr=class extends xr{constructor(e,t,n){super(new Uint32Array(e),t,n)}},wr=class extends xr{constructor(e,t,n){super(new Float32Array(e),t,n)}},Tr=new rr,Er=new L,Dr=new L,Or=class{constructor(e=new L,t=-1){this.isSphere=!0,this.center=e,this.radius=t}set(e,t){return this.center.copy(e),this.radius=t,this}setFromPoints(e,t){let n=this.center;t===void 0?Tr.setFromPoints(e).getCenter(n):n.copy(t);let r=0;for(let t=0,i=e.length;t<i;t++)r=Math.max(r,n.distanceToSquared(e[t]));return this.radius=Math.sqrt(r),this}copy(e){return this.center.copy(e.center),this.radius=e.radius,this}isEmpty(){return this.radius<0}makeEmpty(){return this.center.set(0,0,0),this.radius=-1,this}containsPoint(e){return e.distanceToSquared(this.center)<=this.radius*this.radius}distanceToPoint(e){return e.distanceTo(this.center)-this.radius}intersectsSphere(e){let t=this.radius+e.radius;return e.center.distanceToSquared(this.center)<=t*t}intersectsBox(e){return e.intersectsSphere(this)}intersectsPlane(e){return Math.abs(e.distanceToPoint(this.center))<=this.radius}clampPoint(e,t){let n=this.center.distanceToSquared(e);return t.copy(e),n>this.radius*this.radius&&(t.sub(this.center).normalize(),t.multiplyScalar(this.radius).add(this.center)),t}getBoundingBox(e){return this.isEmpty()?(e.makeEmpty(),e):(e.set(this.center,this.center),e.expandByScalar(this.radius),e)}applyMatrix4(e){return this.center.applyMatrix4(e),this.radius*=e.getMaxScaleOnAxis(),this}translate(e){return this.center.add(e),this}expandByPoint(e){if(this.isEmpty())return this.center.copy(e),this.radius=0,this;Er.subVectors(e,this.center);let t=Er.lengthSq();if(t>this.radius*this.radius){let e=Math.sqrt(t),n=(e-this.radius)*.5;this.center.addScaledVector(Er,n/e),this.radius+=n}return this}union(e){return e.isEmpty()?this:this.isEmpty()?(this.copy(e),this):(this.center.equals(e.center)===!0?this.radius=Math.max(this.radius,e.radius):(Dr.subVectors(e.center,this.center).setLength(e.radius),this.expandByPoint(Er.copy(e.center).add(Dr)),this.expandByPoint(Er.copy(e.center).sub(Dr))),this)}equals(e){return e.center.equals(this.center)&&e.radius===this.radius}clone(){return new this.constructor().copy(this)}toJSON(){return{radius:this.radius,center:this.center.toArray()}}fromJSON(e){return this.radius=e.radius,this.center.fromArray(e.center),this}},kr=0,Ar=new on,jr=new Nn,Mr=new L,Nr=new rr,Pr=new rr,Fr=new L,Ir=class e extends ot{constructor(){super(),this.isBufferGeometry=!0,Object.defineProperty(this,"id",{value:kr++}),this.uuid=dt(),this.name=``,this.type=`BufferGeometry`,this.index=null,this.indirect=null,this.indirectOffset=0,this.attributes={},this.morphAttributes={},this.morphTargetsRelative=!1,this.groups=[],this.boundingBox=null,this.boundingSphere=null,this.drawRange={start:0,count:1/0},this.userData={},this._transformed=!1}getIndex(){return this.index}setIndex(e){return this.index=Array.isArray(e)?new(Je(e)?Cr:Sr)(e,1):e,this}setIndirect(e,t=0){return this.indirect=e,this.indirectOffset=t,this}getIndirect(){return this.indirect}getAttribute(e){return this.attributes[e]}setAttribute(e,t){return this.attributes[e]=t,this}deleteAttribute(e){return delete this.attributes[e],this}hasAttribute(e){return this.attributes[e]!==void 0}addGroup(e,t,n=0){this.groups.push({start:e,count:t,materialIndex:n})}clearGroups(){this.groups=[]}setDrawRange(e,t){this.drawRange.start=e,this.drawRange.count=t}applyMatrix4(e){let t=this.attributes.position;t!==void 0&&(t.applyMatrix4(e),t.needsUpdate=!0);let n=this.attributes.normal;if(n!==void 0){let t=new Rt().getNormalMatrix(e);n.applyNormalMatrix(t),n.needsUpdate=!0}let r=this.attributes.tangent;return r!==void 0&&(r.transformDirection(e),r.needsUpdate=!0),this.boundingBox!==null&&this.computeBoundingBox(),this.boundingSphere!==null&&this.computeBoundingSphere(),this._transformed=!0,this}applyQuaternion(e){return Ar.makeRotationFromQuaternion(e),this.applyMatrix4(Ar),this}rotateX(e){return Ar.makeRotationX(e),this.applyMatrix4(Ar),this}rotateY(e){return Ar.makeRotationY(e),this.applyMatrix4(Ar),this}rotateZ(e){return Ar.makeRotationZ(e),this.applyMatrix4(Ar),this}translate(e,t,n){return Ar.makeTranslation(e,t,n),this.applyMatrix4(Ar),this}scale(e,t,n){return Ar.makeScale(e,t,n),this.applyMatrix4(Ar),this}lookAt(e){return jr.lookAt(e),jr.updateMatrix(),this.applyMatrix4(jr.matrix),this}center(){return this.computeBoundingBox(),this.boundingBox.getCenter(Mr).negate(),this.translate(Mr.x,Mr.y,Mr.z),this}setFromPoints(e){let t=this.getAttribute(`position`);if(t===void 0){let t=[];for(let n=0,r=e.length;n<r;n++){let r=e[n];t.push(r.x,r.y,r.z||0)}this.setAttribute(`position`,new wr(t,3))}else{let n=Math.min(e.length,t.count);for(let r=0;r<n;r++){let n=e[r];t.setXYZ(r,n.x,n.y,n.z||0)}e.length>t.count&&tt(`BufferGeometry: Buffer size too small for points data. Use .dispose() and create a new geometry.`),t.needsUpdate=!0}return this}computeBoundingBox(){this.boundingBox===null&&(this.boundingBox=new rr);let e=this.attributes.position,t=this.morphAttributes.position;if(e&&e.isGLBufferAttribute)nt(`BufferGeometry.computeBoundingBox(): GLBufferAttribute requires a manual bounding box.`,this),this.boundingBox.set(new L(-1/0,-1/0,-1/0),new L(1/0,1/0,1/0));else{if(e!==void 0){if(this.boundingBox.setFromBufferAttribute(e),t)for(let e=0,n=t.length;e<n;e++){let n=t[e];Nr.setFromBufferAttribute(n),this.morphTargetsRelative?(Fr.addVectors(this.boundingBox.min,Nr.min),this.boundingBox.expandByPoint(Fr),Fr.addVectors(this.boundingBox.max,Nr.max),this.boundingBox.expandByPoint(Fr)):(this.boundingBox.expandByPoint(Nr.min),this.boundingBox.expandByPoint(Nr.max))}}else this.boundingBox.makeEmpty();(isNaN(this.boundingBox.min.x)||isNaN(this.boundingBox.min.y)||isNaN(this.boundingBox.min.z))&&nt(`BufferGeometry.computeBoundingBox(): Computed min/max have NaN values. The "position" attribute is likely to have NaN values.`,this)}}computeBoundingSphere(){this.boundingSphere===null&&(this.boundingSphere=new Or);let e=this.attributes.position,t=this.morphAttributes.position;if(e&&e.isGLBufferAttribute)nt(`BufferGeometry.computeBoundingSphere(): GLBufferAttribute requires a manual bounding sphere.`,this),this.boundingSphere.set(new L,1/0);else if(e){let n=this.boundingSphere.center;if(Nr.setFromBufferAttribute(e),t)for(let e=0,n=t.length;e<n;e++){let n=t[e];Pr.setFromBufferAttribute(n),this.morphTargetsRelative?(Fr.addVectors(Nr.min,Pr.min),Nr.expandByPoint(Fr),Fr.addVectors(Nr.max,Pr.max),Nr.expandByPoint(Fr)):(Nr.expandByPoint(Pr.min),Nr.expandByPoint(Pr.max))}Nr.getCenter(n);let r=0;for(let t=0,i=e.count;t<i;t++)Fr.fromBufferAttribute(e,t),r=Math.max(r,n.distanceToSquared(Fr));if(t)for(let i=0,a=t.length;i<a;i++){let a=t[i],o=this.morphTargetsRelative;for(let t=0,i=a.count;t<i;t++)Fr.fromBufferAttribute(a,t),o&&(Mr.fromBufferAttribute(e,t),Fr.add(Mr)),r=Math.max(r,n.distanceToSquared(Fr))}this.boundingSphere.radius=Math.sqrt(r),isNaN(this.boundingSphere.radius)&&nt(`BufferGeometry.computeBoundingSphere(): Computed radius is NaN. The "position" attribute is likely to have NaN values.`,this)}}computeTangents(){let e=this.index,t=this.attributes;if(e===null||t.position===void 0||t.normal===void 0||t.uv===void 0){nt(`BufferGeometry: .computeTangents() failed. Missing required attributes (index, position, normal or uv)`);return}let n=t.position,r=t.normal,i=t.uv,a=this.getAttribute(`tangent`);(a===void 0||a.count!==n.count)&&(a=new xr(new Float32Array(4*n.count),4),this.setAttribute(`tangent`,a));let o=[],s=[],c=new Uint8Array(n.count);for(let e=0;e<n.count;e++)o[e]=new L,s[e]=new L;let l=new L,u=new L,d=new L,f=new I,p=new I,m=new I,h=new L,g=new L;function _(e,t,r){c[e]=c[t]=c[r]=1,l.fromBufferAttribute(n,e),u.fromBufferAttribute(n,t),d.fromBufferAttribute(n,r),f.fromBufferAttribute(i,e),p.fromBufferAttribute(i,t),m.fromBufferAttribute(i,r),u.sub(l),d.sub(l),p.sub(f),m.sub(f);let a=1/(p.x*m.y-m.x*p.y);isFinite(a)&&(h.copy(u).multiplyScalar(m.y).addScaledVector(d,-p.y).multiplyScalar(a),g.copy(d).multiplyScalar(p.x).addScaledVector(u,-m.x).multiplyScalar(a),o[e].add(h),o[t].add(h),o[r].add(h),s[e].add(g),s[t].add(g),s[r].add(g))}let v=this.groups;v.length===0&&(v=[{start:0,count:e.count}]);for(let t=0,n=v.length;t<n;++t){let n=v[t],r=n.start,i=n.count;for(let t=r,n=r+i;t<n;t+=3)_(e.getX(t+0),e.getX(t+1),e.getX(t+2))}let y=new L,b=new L,x=new L,S=new L;function C(e){x.fromBufferAttribute(r,e),S.copy(x);let t=o[e];y.copy(t),y.sub(x.multiplyScalar(x.dot(t))).normalize(),b.crossVectors(S,t);let n=b.dot(s[e])<0?-1:1;a.setXYZW(e,y.x,y.y,y.z,n)}for(let e=0,t=n.count;e<t;++e)c[e]&&C(e);this._transformed=!0}computeVertexNormals(){let e=this.index,t=this.getAttribute(`position`);if(t!==void 0){let n=this.getAttribute(`normal`);if(n===void 0||n.count!==t.count)n=new xr(new Float32Array(t.count*3),3),this.setAttribute(`normal`,n);else for(let e=0,t=n.count;e<t;e++)n.setXYZ(e,0,0,0);let r=new L,i=new L,a=new L,o=new L,s=new L,c=new L,l=new L,u=new L;if(e)for(let d=0,f=e.count;d<f;d+=3){let f=e.getX(d+0),p=e.getX(d+1),m=e.getX(d+2);r.fromBufferAttribute(t,f),i.fromBufferAttribute(t,p),a.fromBufferAttribute(t,m),l.subVectors(a,i),u.subVectors(r,i),l.cross(u),o.fromBufferAttribute(n,f),s.fromBufferAttribute(n,p),c.fromBufferAttribute(n,m),o.add(l),s.add(l),c.add(l),n.setXYZ(f,o.x,o.y,o.z),n.setXYZ(p,s.x,s.y,s.z),n.setXYZ(m,c.x,c.y,c.z)}else for(let e=0,o=t.count;e<o;e+=3)r.fromBufferAttribute(t,e+0),i.fromBufferAttribute(t,e+1),a.fromBufferAttribute(t,e+2),l.subVectors(a,i),u.subVectors(r,i),l.cross(u),n.setXYZ(e+0,l.x,l.y,l.z),n.setXYZ(e+1,l.x,l.y,l.z),n.setXYZ(e+2,l.x,l.y,l.z);this.normalizeNormals(),n.needsUpdate=!0}}normalizeNormals(){let e=this.attributes.normal;for(let t=0,n=e.count;t<n;t++)Fr.fromBufferAttribute(e,t),Fr.normalize(),e.setXYZ(t,Fr.x,Fr.y,Fr.z)}toNonIndexed(){function t(e,t){let n=e.array,r=e.itemSize,i=e.normalized,a=new n.constructor(t.length*r),o=0,s=0;for(let i=0,c=t.length;i<c;i++){o=e.isInterleavedBufferAttribute?t[i]*e.data.stride+e.offset:t[i]*r;for(let e=0;e<r;e++)a[s++]=n[o++]}return new xr(a,r,i)}if(this.index===null)return tt(`BufferGeometry.toNonIndexed(): BufferGeometry is already non-indexed.`),this;let n=new e,r=this.index.array,i=this.attributes;for(let e in i){let a=i[e],o=t(a,r);n.setAttribute(e,o)}let a=this.morphAttributes;for(let e in a){let i=[],o=a[e];for(let e=0,n=o.length;e<n;e++){let n=o[e],a=t(n,r);i.push(a)}n.morphAttributes[e]=i}n.morphTargetsRelative=this.morphTargetsRelative;let o=this.groups;for(let e=0,t=o.length;e<t;e++){let t=o[e];n.addGroup(t.start,t.count,t.materialIndex)}return n}toJSON(){let e={metadata:{version:4.7,type:`BufferGeometry`,generator:`BufferGeometry.toJSON`}};if(e.uuid=this.uuid,e.type=this.parameters!==void 0&&this._transformed===!0?`BufferGeometry`:this.type,e.name=this.name,Object.keys(this.userData).length>0&&(e.userData=this.userData),this.parameters!==void 0&&this._transformed!==!0){let t=this.parameters;for(let n in t)t[n]!==void 0&&(e[n]=t[n]);return e}e.data={attributes:{}};let t=this.index;t!==null&&(e.data.index={type:t.array.constructor.name,array:Array.prototype.slice.call(t.array)});let n=this.attributes;for(let t in n){let r=n[t];e.data.attributes[t]=r.toJSON(e.data)}let r={},i=!1;for(let t in this.morphAttributes){let n=this.morphAttributes[t],a=[];for(let t=0,r=n.length;t<r;t++){let r=n[t];a.push(r.toJSON(e.data))}a.length>0&&(r[t]=a,i=!0)}i&&(e.data.morphAttributes=r,e.data.morphTargetsRelative=this.morphTargetsRelative);let a=this.groups;a.length>0&&(e.data.groups=JSON.parse(JSON.stringify(a)));let o=this.boundingSphere;return o!==null&&(e.data.boundingSphere=o.toJSON()),e}clone(){return new this.constructor().copy(this)}copy(e){this.index=null,this.attributes={},this.morphAttributes={},this.groups=[],this.boundingBox=null,this.boundingSphere=null;let t={};this.name=e.name;let n=e.index;n!==null&&this.setIndex(n.clone());let r=e.attributes;for(let e in r){let n=r[e];this.setAttribute(e,n.clone(t))}let i=e.morphAttributes;for(let e in i){let n=[],r=i[e];for(let e=0,i=r.length;e<i;e++)n.push(r[e].clone(t));this.morphAttributes[e]=n}this.morphTargetsRelative=e.morphTargetsRelative;let a=e.groups;for(let e=0,t=a.length;e<t;e++){let t=a[e];this.addGroup(t.start,t.count,t.materialIndex)}let o=e.boundingBox;o!==null&&(this.boundingBox=o.clone());let s=e.boundingSphere;return s!==null&&(this.boundingSphere=s.clone()),this.drawRange.start=e.drawRange.start,this.drawRange.count=e.drawRange.count,this.userData=e.userData,this._transformed=e._transformed,this}dispose(){this.dispatchEvent({type:`dispose`})}},Lr=new L,Rr=new L,zr=new Rt,Br=class{constructor(e=new L(1,0,0),t=0){this.isPlane=!0,this.normal=e,this.constant=t}set(e,t){return this.normal.copy(e),this.constant=t,this}setComponents(e,t,n,r){return this.normal.set(e,t,n),this.constant=r,this}setFromNormalAndCoplanarPoint(e,t){return this.normal.copy(e),this.constant=-t.dot(this.normal),this}setFromCoplanarPoints(e,t,n){let r=Lr.subVectors(n,t).cross(Rr.subVectors(e,t)).normalize();return this.setFromNormalAndCoplanarPoint(r,e),this}copy(e){return this.normal.copy(e.normal),this.constant=e.constant,this}normalize(){let e=1/this.normal.length();return this.normal.multiplyScalar(e),this.constant*=e,this}negate(){return this.constant*=-1,this.normal.negate(),this}distanceToPoint(e){return this.normal.dot(e)+this.constant}distanceToSphere(e){return this.distanceToPoint(e.center)-e.radius}projectPoint(e,t){return t.copy(e).addScaledVector(this.normal,-this.distanceToPoint(e))}intersectLine(e,t,n=!0){let r=e.delta(Lr),i=this.normal.dot(r);if(i===0)return this.distanceToPoint(e.start)===0?t.copy(e.start):null;let a=-(e.start.dot(this.normal)+this.constant)/i;return n===!0&&(a<0||a>1)?null:t.copy(e.start).addScaledVector(r,a)}intersectsLine(e){let t=this.distanceToPoint(e.start),n=this.distanceToPoint(e.end);return t<0&&n>0||n<0&&t>0}intersectsBox(e){return e.intersectsPlane(this)}intersectsSphere(e){return e.intersectsPlane(this)}coplanarPoint(e){return e.copy(this.normal).multiplyScalar(-this.constant)}applyMatrix4(e,t){let n=t||zr.getNormalMatrix(e),r=this.coplanarPoint(Lr).applyMatrix4(e),i=this.normal.applyMatrix3(n).normalize();return this.constant=-r.dot(i),this}translate(e){return this.constant-=e.dot(this.normal),this}equals(e){return e.normal.equals(this.normal)&&e.constant===this.constant}clone(){return new this.constructor().copy(this)}toJSON(){return{normal:this.normal.toArray(),constant:this.constant}}fromJSON(e){return this.normal.fromArray(e.normal),this.constant=e.constant,this}},Vr=0,Hr=class extends ot{constructor(){super(),this.isMaterial=!0,Object.defineProperty(this,"id",{value:Vr++}),this.uuid=dt(),this.name=``,this.type=`Material`,this.blending=1,this.side=0,this.vertexColors=!1,this.opacity=1,this.transparent=!1,this.alphaHash=!1,this.blendSrc=204,this.blendDst=205,this.blendEquation=100,this.blendSrcAlpha=null,this.blendDstAlpha=null,this.blendEquationAlpha=null,this.blendColor=new R(0,0,0),this.blendAlpha=0,this.depthFunc=3,this.depthTest=!0,this.depthWrite=!0,this.stencilWriteMask=255,this.stencilFunc=519,this.stencilRef=0,this.stencilFuncMask=255,this.stencilFail=We,this.stencilZFail=We,this.stencilZPass=We,this.stencilWrite=!1,this.clippingPlanes=null,this.clipIntersection=!1,this.clipShadows=!1,this.shadowSide=null,this.colorWrite=!0,this.precision=null,this.polygonOffset=!1,this.polygonOffsetFactor=0,this.polygonOffsetUnits=0,this.dithering=!1,this.alphaToCoverage=!1,this.premultipliedAlpha=!1,this.forceSinglePass=!1,this.allowOverride=!0,this.visible=!0,this.toneMapped=!0,this.userData={},this.version=0,this._alphaTest=0}get alphaTest(){return this._alphaTest}set alphaTest(e){this._alphaTest>0!=e>0&&this.version++,this._alphaTest=e}onBeforeRender(){}onBeforeCompile(){}customProgramCacheKey(){return this.onBeforeCompile.toString()}setValues(e){if(e!==void 0)for(let t in e){let n=e[t];if(n===void 0){tt(`Material: parameter '${t}' has value of undefined.`);continue}let r=this[t];r===void 0?tt(`Material: '${t}' is not a property of THREE.${this.type}.`):r&&r.isColor?r.set(n):r&&r.isVector2&&n&&n.isVector2||r&&r.isEuler&&n&&n.isEuler||r&&r.isVector3&&n&&n.isVector3?r.copy(n):this[t]=n}}toJSON(e){let t=e===void 0||typeof e==`string`;t&&(e={textures:{},images:{}});let n={metadata:{version:4.7,type:`Material`,generator:`Material.toJSON`}};n.uuid=this.uuid,n.type=this.type,n.blending=this.blending,n.side=this.side,n.shadowSide=this.shadowSide,n.vertexColors=this.vertexColors,n.opacity=this.opacity,n.transparent=this.transparent,n.blendSrc=this.blendSrc,n.blendDst=this.blendDst,n.blendEquation=this.blendEquation,n.blendSrcAlpha=this.blendSrcAlpha,n.blendDstAlpha=this.blendDstAlpha,n.blendEquationAlpha=this.blendEquationAlpha,n.blendColor=this.blendColor.getHex(),n.blendAlpha=this.blendAlpha,n.depthFunc=this.depthFunc,n.depthTest=this.depthTest,n.depthWrite=this.depthWrite,n.colorWrite=this.colorWrite,n.clipIntersection=this.clipIntersection,n.clipShadows=this.clipShadows,n.stencilWriteMask=this.stencilWriteMask,n.stencilFunc=this.stencilFunc,n.stencilRef=this.stencilRef,n.stencilFuncMask=this.stencilFuncMask,n.stencilFail=this.stencilFail,n.stencilZFail=this.stencilZFail,n.stencilZPass=this.stencilZPass,n.stencilWrite=this.stencilWrite,n.polygonOffset=this.polygonOffset,n.polygonOffsetFactor=this.polygonOffsetFactor,n.polygonOffsetUnits=this.polygonOffsetUnits,n.dithering=this.dithering,n.alphaTest=this.alphaTest,n.alphaHash=this.alphaHash,n.alphaToCoverage=this.alphaToCoverage,n.premultipliedAlpha=this.premultipliedAlpha,n.forceSinglePass=this.forceSinglePass,n.allowOverride=this.allowOverride,n.visible=this.visible,n.toneMapped=this.toneMapped,n.name=this.name,this.color&&this.color.isColor&&(n.color=this.color.getHex()),this.roughness!==void 0&&(n.roughness=this.roughness),this.metalness!==void 0&&(n.metalness=this.metalness),this.sheen!==void 0&&(n.sheen=this.sheen),this.sheenColor&&this.sheenColor.isColor&&(n.sheenColor=this.sheenColor.getHex()),this.sheenRoughness!==void 0&&(n.sheenRoughness=this.sheenRoughness),this.emissive&&this.emissive.isColor&&(n.emissive=this.emissive.getHex()),this.emissiveIntensity!==void 0&&(n.emissiveIntensity=this.emissiveIntensity),this.specular&&this.specular.isColor&&(n.specular=this.specular.getHex()),this.specularIntensity!==void 0&&(n.specularIntensity=this.specularIntensity),this.specularColor&&this.specularColor.isColor&&(n.specularColor=this.specularColor.getHex()),this.shininess!==void 0&&(n.shininess=this.shininess),this.clearcoat!==void 0&&(n.clearcoat=this.clearcoat),this.clearcoatRoughness!==void 0&&(n.clearcoatRoughness=this.clearcoatRoughness),this.diffuseRoughness!==void 0&&(n.diffuseRoughness=this.diffuseRoughness),this.diffuseRoughnessMap&&this.diffuseRoughnessMap.isTexture&&(n.diffuseRoughnessMap=this.diffuseRoughnessMap.toJSON(e).uuid),this.clearcoatMap&&this.clearcoatMap.isTexture&&(n.clearcoatMap=this.clearcoatMap.toJSON(e).uuid),this.clearcoatRoughnessMap&&this.clearcoatRoughnessMap.isTexture&&(n.clearcoatRoughnessMap=this.clearcoatRoughnessMap.toJSON(e).uuid),this.clearcoatNormalMap&&this.clearcoatNormalMap.isTexture&&(n.clearcoatNormalMap=this.clearcoatNormalMap.toJSON(e).uuid,n.clearcoatNormalScale=this.clearcoatNormalScale.toArray()),this.sheenColorMap&&this.sheenColorMap.isTexture&&(n.sheenColorMap=this.sheenColorMap.toJSON(e).uuid),this.sheenRoughnessMap&&this.sheenRoughnessMap.isTexture&&(n.sheenRoughnessMap=this.sheenRoughnessMap.toJSON(e).uuid),this.dispersion!==void 0&&(n.dispersion=this.dispersion),this.retroreflectivity!==void 0&&(n.retroreflectivity=this.retroreflectivity),this.iridescence!==void 0&&(n.iridescence=this.iridescence),this.iridescenceIOR!==void 0&&(n.iridescenceIOR=this.iridescenceIOR),this.iridescenceThicknessMinimum!==void 0&&(n.iridescenceThicknessMinimum=this.iridescenceThicknessMinimum),this.iridescenceThicknessMaximum!==void 0&&(n.iridescenceThicknessMaximum=this.iridescenceThicknessMaximum),this.iridescenceMap&&this.iridescenceMap.isTexture&&(n.iridescenceMap=this.iridescenceMap.toJSON(e).uuid),this.iridescenceThicknessMap&&this.iridescenceThicknessMap.isTexture&&(n.iridescenceThicknessMap=this.iridescenceThicknessMap.toJSON(e).uuid),this.anisotropy!==void 0&&(n.anisotropy=this.anisotropy),this.anisotropyRotation!==void 0&&(n.anisotropyRotation=this.anisotropyRotation),this.anisotropyMap&&this.anisotropyMap.isTexture&&(n.anisotropyMap=this.anisotropyMap.toJSON(e).uuid),this.map&&this.map.isTexture&&(n.map=this.map.toJSON(e).uuid),this.matcap&&this.matcap.isTexture&&(n.matcap=this.matcap.toJSON(e).uuid),this.alphaMap&&this.alphaMap.isTexture&&(n.alphaMap=this.alphaMap.toJSON(e).uuid),this.lightMap&&this.lightMap.isTexture&&(n.lightMap=this.lightMap.toJSON(e).uuid,n.lightMapIntensity=this.lightMapIntensity),this.aoMap&&this.aoMap.isTexture&&(n.aoMap=this.aoMap.toJSON(e).uuid,n.aoMapIntensity=this.aoMapIntensity),this.bumpMap&&this.bumpMap.isTexture&&(n.bumpMap=this.bumpMap.toJSON(e).uuid,n.bumpScale=this.bumpScale),this.normalMap&&this.normalMap.isTexture&&(n.normalMap=this.normalMap.toJSON(e).uuid,n.normalMapType=this.normalMapType,n.normalScale=this.normalScale.toArray()),this.displacementMap&&this.displacementMap.isTexture&&(n.displacementMap=this.displacementMap.toJSON(e).uuid,n.displacementScale=this.displacementScale,n.displacementBias=this.displacementBias),this.roughnessMap&&this.roughnessMap.isTexture&&(n.roughnessMap=this.roughnessMap.toJSON(e).uuid),this.metalnessMap&&this.metalnessMap.isTexture&&(n.metalnessMap=this.metalnessMap.toJSON(e).uuid),this.emissiveMap&&this.emissiveMap.isTexture&&(n.emissiveMap=this.emissiveMap.toJSON(e).uuid),this.specularMap&&this.specularMap.isTexture&&(n.specularMap=this.specularMap.toJSON(e).uuid),this.specularIntensityMap&&this.specularIntensityMap.isTexture&&(n.specularIntensityMap=this.specularIntensityMap.toJSON(e).uuid),this.specularColorMap&&this.specularColorMap.isTexture&&(n.specularColorMap=this.specularColorMap.toJSON(e).uuid),this.envMap&&this.envMap.isTexture&&(n.envMap=this.envMap.toJSON(e).uuid,this.combine!==void 0&&(n.combine=this.combine)),this.envMapRotation!==void 0&&(n.envMapRotation=this.envMapRotation.toArray()),this.envMapIntensity!==void 0&&(n.envMapIntensity=this.envMapIntensity),this.reflectivity!==void 0&&(n.reflectivity=this.reflectivity),this.refractionRatio!==void 0&&(n.refractionRatio=this.refractionRatio),this.gradientMap&&this.gradientMap.isTexture&&(n.gradientMap=this.gradientMap.toJSON(e).uuid),this.transmission!==void 0&&(n.transmission=this.transmission),this.transmissionMap&&this.transmissionMap.isTexture&&(n.transmissionMap=this.transmissionMap.toJSON(e).uuid),this.thickness!==void 0&&(n.thickness=this.thickness),this.thicknessMap&&this.thicknessMap.isTexture&&(n.thicknessMap=this.thicknessMap.toJSON(e).uuid),this.attenuationDistance!==void 0&&(n.attenuationDistance=this.attenuationDistance),this.attenuationColor!==void 0&&(n.attenuationColor=this.attenuationColor.getHex()),this.size!==void 0&&(n.size=this.size),this.sizeAttenuation!==void 0&&(n.sizeAttenuation=this.sizeAttenuation),Array.isArray(this.clippingPlanes)&&this.clippingPlanes.length>0&&(n.clippingPlanes=this.clippingPlanes.map(e=>e.toJSON())),this.rotation!==void 0&&(n.rotation=this.rotation),this.depthPacking!==void 0&&(n.depthPacking=this.depthPacking),this.linewidth!==void 0&&(n.linewidth=this.linewidth),this.linecap!==void 0&&(n.linecap=this.linecap),this.linejoin!==void 0&&(n.linejoin=this.linejoin),this.dashSize!==void 0&&(n.dashSize=this.dashSize),this.gapSize!==void 0&&(n.gapSize=this.gapSize),this.scale!==void 0&&(n.scale=this.scale),this.wireframe!==void 0&&(n.wireframe=this.wireframe),this.wireframeLinewidth!==void 0&&(n.wireframeLinewidth=this.wireframeLinewidth),this.wireframeLinecap!==void 0&&(n.wireframeLinecap=this.wireframeLinecap),this.wireframeLinejoin!==void 0&&(n.wireframeLinejoin=this.wireframeLinejoin),this.flatShading!==void 0&&(n.flatShading=this.flatShading),this.fog!==void 0&&(n.fog=this.fog),Object.keys(this.userData).length>0&&(n.userData=this.userData);function r(e){let t=[];for(let n in e){let r=e[n];delete r.metadata,t.push(r)}return t}if(t){let t=r(e.textures),i=r(e.images);t.length>0&&(n.textures=t),i.length>0&&(n.images=i)}return n}fromJSON(e,t){if(e.uuid!==void 0&&(this.uuid=e.uuid),e.name!==void 0&&(this.name=e.name),e.color!==void 0&&this.color!==void 0&&this.color.setHex(e.color),e.roughness!==void 0&&(this.roughness=e.roughness),e.metalness!==void 0&&(this.metalness=e.metalness),e.sheen!==void 0&&(this.sheen=e.sheen),e.sheenColor!==void 0&&(this.sheenColor=new R().setHex(e.sheenColor)),e.sheenRoughness!==void 0&&(this.sheenRoughness=e.sheenRoughness),e.emissive!==void 0&&this.emissive!==void 0&&this.emissive.setHex(e.emissive),e.specular!==void 0&&this.specular!==void 0&&this.specular.setHex(e.specular),e.specularIntensity!==void 0&&(this.specularIntensity=e.specularIntensity),e.specularColor!==void 0&&this.specularColor!==void 0&&this.specularColor.setHex(e.specularColor),e.shininess!==void 0&&(this.shininess=e.shininess),e.clearcoat!==void 0&&(this.clearcoat=e.clearcoat),e.clearcoatRoughness!==void 0&&(this.clearcoatRoughness=e.clearcoatRoughness),e.diffuseRoughness!==void 0&&(this.diffuseRoughness=e.diffuseRoughness),e.dispersion!==void 0&&(this.dispersion=e.dispersion),e.retroreflectivity!==void 0&&(this.retroreflectivity=e.retroreflectivity),e.iridescence!==void 0&&(this.iridescence=e.iridescence),e.iridescenceIOR!==void 0&&(this.iridescenceIOR=e.iridescenceIOR),e.iridescenceThicknessMinimum!==void 0&&(this.iridescenceThicknessMinimum=e.iridescenceThicknessMinimum),e.iridescenceThicknessMaximum!==void 0&&(this.iridescenceThicknessMaximum=e.iridescenceThicknessMaximum),e.iridescenceThicknessRange!==void 0&&(this.iridescenceThicknessMinimum=e.iridescenceThicknessRange[0],this.iridescenceThicknessMaximum=e.iridescenceThicknessRange[1]),e.transmission!==void 0&&(this.transmission=e.transmission),e.thickness!==void 0&&(this.thickness=e.thickness),e.attenuationDistance!==void 0&&(this.attenuationDistance=e.attenuationDistance),e.attenuationColor!==void 0&&this.attenuationColor!==void 0&&this.attenuationColor.setHex(e.attenuationColor),e.anisotropy!==void 0&&(this.anisotropy=e.anisotropy),e.anisotropyRotation!==void 0&&(this.anisotropyRotation=e.anisotropyRotation),e.fog!==void 0&&(this.fog=e.fog),e.flatShading!==void 0&&(this.flatShading=e.flatShading),e.blending!==void 0&&(this.blending=e.blending),e.combine!==void 0&&(this.combine=e.combine),e.side!==void 0&&(this.side=e.side),e.shadowSide!==void 0&&(this.shadowSide=e.shadowSide),e.opacity!==void 0&&(this.opacity=e.opacity),e.transparent!==void 0&&(this.transparent=e.transparent),e.alphaTest!==void 0&&(this.alphaTest=e.alphaTest),e.alphaHash!==void 0&&(this.alphaHash=e.alphaHash),e.depthFunc!==void 0&&(this.depthFunc=e.depthFunc),e.depthTest!==void 0&&(this.depthTest=e.depthTest),e.depthWrite!==void 0&&(this.depthWrite=e.depthWrite),e.colorWrite!==void 0&&(this.colorWrite=e.colorWrite),e.clippingPlanes!==void 0&&(this.clippingPlanes=e.clippingPlanes.map(e=>new Br().fromJSON(e))),e.clipIntersection!==void 0&&(this.clipIntersection=e.clipIntersection),e.clipShadows!==void 0&&(this.clipShadows=e.clipShadows),e.depthPacking!==void 0&&(this.depthPacking=e.depthPacking),e.blendSrc!==void 0&&(this.blendSrc=e.blendSrc),e.blendDst!==void 0&&(this.blendDst=e.blendDst),e.blendEquation!==void 0&&(this.blendEquation=e.blendEquation),e.blendSrcAlpha!==void 0&&(this.blendSrcAlpha=e.blendSrcAlpha),e.blendDstAlpha!==void 0&&(this.blendDstAlpha=e.blendDstAlpha),e.blendEquationAlpha!==void 0&&(this.blendEquationAlpha=e.blendEquationAlpha),e.blendColor!==void 0&&this.blendColor!==void 0&&this.blendColor.setHex(e.blendColor),e.blendAlpha!==void 0&&(this.blendAlpha=e.blendAlpha),e.stencilWriteMask!==void 0&&(this.stencilWriteMask=e.stencilWriteMask),e.stencilFunc!==void 0&&(this.stencilFunc=e.stencilFunc),e.stencilRef!==void 0&&(this.stencilRef=e.stencilRef),e.stencilFuncMask!==void 0&&(this.stencilFuncMask=e.stencilFuncMask),e.stencilFail!==void 0&&(this.stencilFail=e.stencilFail),e.stencilZFail!==void 0&&(this.stencilZFail=e.stencilZFail),e.stencilZPass!==void 0&&(this.stencilZPass=e.stencilZPass),e.stencilWrite!==void 0&&(this.stencilWrite=e.stencilWrite),e.wireframe!==void 0&&(this.wireframe=e.wireframe),e.wireframeLinewidth!==void 0&&(this.wireframeLinewidth=e.wireframeLinewidth),e.wireframeLinecap!==void 0&&(this.wireframeLinecap=e.wireframeLinecap),e.wireframeLinejoin!==void 0&&(this.wireframeLinejoin=e.wireframeLinejoin),e.rotation!==void 0&&(this.rotation=e.rotation),e.linewidth!==void 0&&(this.linewidth=e.linewidth),e.linecap!==void 0&&(this.linecap=e.linecap),e.linejoin!==void 0&&(this.linejoin=e.linejoin),e.dashSize!==void 0&&(this.dashSize=e.dashSize),e.gapSize!==void 0&&(this.gapSize=e.gapSize),e.scale!==void 0&&(this.scale=e.scale),e.polygonOffset!==void 0&&(this.polygonOffset=e.polygonOffset),e.polygonOffsetFactor!==void 0&&(this.polygonOffsetFactor=e.polygonOffsetFactor),e.polygonOffsetUnits!==void 0&&(this.polygonOffsetUnits=e.polygonOffsetUnits),e.dithering!==void 0&&(this.dithering=e.dithering),e.alphaToCoverage!==void 0&&(this.alphaToCoverage=e.alphaToCoverage),e.premultipliedAlpha!==void 0&&(this.premultipliedAlpha=e.premultipliedAlpha),e.forceSinglePass!==void 0&&(this.forceSinglePass=e.forceSinglePass),e.allowOverride!==void 0&&(this.allowOverride=e.allowOverride),e.visible!==void 0&&(this.visible=e.visible),e.toneMapped!==void 0&&(this.toneMapped=e.toneMapped),e.userData!==void 0&&(this.userData=e.userData),e.vertexColors!==void 0&&(this.vertexColors=typeof e.vertexColors==`number`?e.vertexColors>0:e.vertexColors),e.size!==void 0&&(this.size=e.size),e.sizeAttenuation!==void 0&&(this.sizeAttenuation=e.sizeAttenuation),e.map!==void 0&&(this.map=t[e.map]||null),e.matcap!==void 0&&(this.matcap=t[e.matcap]||null),e.alphaMap!==void 0&&(this.alphaMap=t[e.alphaMap]||null),e.bumpMap!==void 0&&(this.bumpMap=t[e.bumpMap]||null),e.bumpScale!==void 0&&(this.bumpScale=e.bumpScale),e.normalMap!==void 0&&(this.normalMap=t[e.normalMap]||null),e.normalMapType!==void 0&&(this.normalMapType=e.normalMapType),e.normalScale!==void 0){let t=e.normalScale;Array.isArray(t)===!1&&(t=[t,t]),this.normalScale=new I().fromArray(t)}return e.displacementMap!==void 0&&(this.displacementMap=t[e.displacementMap]||null),e.displacementScale!==void 0&&(this.displacementScale=e.displacementScale),e.displacementBias!==void 0&&(this.displacementBias=e.displacementBias),e.roughnessMap!==void 0&&(this.roughnessMap=t[e.roughnessMap]||null),e.metalnessMap!==void 0&&(this.metalnessMap=t[e.metalnessMap]||null),e.emissiveMap!==void 0&&(this.emissiveMap=t[e.emissiveMap]||null),e.emissiveIntensity!==void 0&&(this.emissiveIntensity=e.emissiveIntensity),e.specularMap!==void 0&&(this.specularMap=t[e.specularMap]||null),e.specularIntensityMap!==void 0&&(this.specularIntensityMap=t[e.specularIntensityMap]||null),e.specularColorMap!==void 0&&(this.specularColorMap=t[e.specularColorMap]||null),e.envMap!==void 0&&(this.envMap=t[e.envMap]||null),e.envMapRotation!==void 0&&this.envMapRotation.fromArray(e.envMapRotation),e.envMapIntensity!==void 0&&(this.envMapIntensity=e.envMapIntensity),e.reflectivity!==void 0&&(this.reflectivity=e.reflectivity),e.refractionRatio!==void 0&&(this.refractionRatio=e.refractionRatio),e.lightMap!==void 0&&(this.lightMap=t[e.lightMap]||null),e.lightMapIntensity!==void 0&&(this.lightMapIntensity=e.lightMapIntensity),e.aoMap!==void 0&&(this.aoMap=t[e.aoMap]||null),e.aoMapIntensity!==void 0&&(this.aoMapIntensity=e.aoMapIntensity),e.gradientMap!==void 0&&(this.gradientMap=t[e.gradientMap]||null),e.clearcoatMap!==void 0&&(this.clearcoatMap=t[e.clearcoatMap]||null),e.clearcoatRoughnessMap!==void 0&&(this.clearcoatRoughnessMap=t[e.clearcoatRoughnessMap]||null),e.clearcoatNormalMap!==void 0&&(this.clearcoatNormalMap=t[e.clearcoatNormalMap]||null),e.clearcoatNormalScale!==void 0&&(this.clearcoatNormalScale=new I().fromArray(e.clearcoatNormalScale)),e.diffuseRoughnessMap!==void 0&&(this.diffuseRoughnessMap=t[e.diffuseRoughnessMap]||null),e.iridescenceMap!==void 0&&(this.iridescenceMap=t[e.iridescenceMap]||null),e.iridescenceThicknessMap!==void 0&&(this.iridescenceThicknessMap=t[e.iridescenceThicknessMap]||null),e.transmissionMap!==void 0&&(this.transmissionMap=t[e.transmissionMap]||null),e.thicknessMap!==void 0&&(this.thicknessMap=t[e.thicknessMap]||null),e.anisotropyMap!==void 0&&(this.anisotropyMap=t[e.anisotropyMap]||null),e.sheenColorMap!==void 0&&(this.sheenColorMap=t[e.sheenColorMap]||null),e.sheenRoughnessMap!==void 0&&(this.sheenRoughnessMap=t[e.sheenRoughnessMap]||null),this}clone(){return new this.constructor().copy(this)}copy(e){this.name=e.name,this.blending=e.blending,this.side=e.side,this.vertexColors=e.vertexColors,this.opacity=e.opacity,this.transparent=e.transparent,this.blendSrc=e.blendSrc,this.blendDst=e.blendDst,this.blendEquation=e.blendEquation,this.blendSrcAlpha=e.blendSrcAlpha,this.blendDstAlpha=e.blendDstAlpha,this.blendEquationAlpha=e.blendEquationAlpha,this.blendColor.copy(e.blendColor),this.blendAlpha=e.blendAlpha,this.depthFunc=e.depthFunc,this.depthTest=e.depthTest,this.depthWrite=e.depthWrite,this.stencilWriteMask=e.stencilWriteMask,this.stencilFunc=e.stencilFunc,this.stencilRef=e.stencilRef,this.stencilFuncMask=e.stencilFuncMask,this.stencilFail=e.stencilFail,this.stencilZFail=e.stencilZFail,this.stencilZPass=e.stencilZPass,this.stencilWrite=e.stencilWrite;let t=e.clippingPlanes,n=null;if(t!==null){let e=t.length;n=Array(e);for(let r=0;r!==e;++r)n[r]=t[r].clone()}return this.clippingPlanes=n,this.clipIntersection=e.clipIntersection,this.clipShadows=e.clipShadows,this.shadowSide=e.shadowSide,this.colorWrite=e.colorWrite,this.precision=e.precision,this.polygonOffset=e.polygonOffset,this.polygonOffsetFactor=e.polygonOffsetFactor,this.polygonOffsetUnits=e.polygonOffsetUnits,this.dithering=e.dithering,this.alphaTest=e.alphaTest,this.alphaHash=e.alphaHash,this.alphaToCoverage=e.alphaToCoverage,this.premultipliedAlpha=e.premultipliedAlpha,this.forceSinglePass=e.forceSinglePass,this.allowOverride=e.allowOverride,this.visible=e.visible,this.toneMapped=e.toneMapped,this.userData=JSON.parse(JSON.stringify(e.userData)),this}dispose(){this.dispatchEvent({type:`dispose`})}set needsUpdate(e){e===!0&&this.version++}},Ur=new L,Wr=new L,Gr=new L,Kr=new L,qr=class{constructor(e=new L,t=new L(0,0,-1)){this.origin=e,this.direction=t}set(e,t){return this.origin.copy(e),this.direction.copy(t),this}copy(e){return this.origin.copy(e.origin),this.direction.copy(e.direction),this}at(e,t){return t.copy(this.origin).addScaledVector(this.direction,e)}lookAt(e){return this.direction.copy(e).sub(this.origin).normalize(),this}recast(e){return this.origin.copy(this.at(e,Ur)),this}closestPointToPoint(e,t){t.subVectors(e,this.origin);let n=t.dot(this.direction);return n<0?t.copy(this.origin):t.copy(this.origin).addScaledVector(this.direction,n)}distanceToPoint(e){return Math.sqrt(this.distanceSqToPoint(e))}distanceSqToPoint(e){let t=Ur.subVectors(e,this.origin).dot(this.direction);return t<0?this.origin.distanceToSquared(e):(Ur.copy(this.origin).addScaledVector(this.direction,t),Ur.distanceToSquared(e))}distanceSqToSegment(e,t,n,r){Wr.copy(e).add(t).multiplyScalar(.5),Gr.copy(t).sub(e).normalize(),Kr.copy(this.origin).sub(Wr);let i=e.distanceTo(t)*.5,a=-this.direction.dot(Gr),o=Kr.dot(this.direction),s=-Kr.dot(Gr),c=Kr.lengthSq(),l=Math.abs(1-a*a),u,d,f,p;if(l>0){if(u=a*s-o,d=a*o-s,p=i*l,u>=0){if(d>=-p){if(d<=p){let e=1/l;u*=e,d*=e,f=u*(u+a*d+2*o)+d*(a*u+d+2*s)+c}else d=i,u=Math.max(0,-(a*d+o)),f=-u*u+d*(d+2*s)+c}else d=-i,u=Math.max(0,-(a*d+o)),f=-u*u+d*(d+2*s)+c}else d<=-p?(u=Math.max(0,-(-a*i+o)),d=u>0?-i:Math.min(Math.max(-i,-s),i),f=-u*u+d*(d+2*s)+c):d<=p?(u=0,d=Math.min(Math.max(-i,-s),i),f=d*(d+2*s)+c):(u=Math.max(0,-(a*i+o)),d=u>0?i:Math.min(Math.max(-i,-s),i),f=-u*u+d*(d+2*s)+c)}else d=a>0?-i:i,u=Math.max(0,-(a*d+o)),f=-u*u+d*(d+2*s)+c;return n&&n.copy(this.origin).addScaledVector(this.direction,u),r&&r.copy(Wr).addScaledVector(Gr,d),f}intersectSphere(e,t){if(e.radius<0)return null;Ur.subVectors(e.center,this.origin);let n=Ur.dot(this.direction),r=Ur.dot(Ur)-n*n,i=e.radius*e.radius;if(r>i)return null;let a=Math.sqrt(i-r),o=n-a,s=n+a;return s<0?null:o<0?this.at(s,t):this.at(o,t)}intersectsSphere(e){return e.radius<0?!1:this.distanceSqToPoint(e.center)<=e.radius*e.radius}distanceToPlane(e){let t=e.normal.dot(this.direction);if(t===0)return e.distanceToPoint(this.origin)===0?0:null;let n=-(this.origin.dot(e.normal)+e.constant)/t;return n>=0?n:null}intersectPlane(e,t){let n=this.distanceToPlane(e);return n===null?null:this.at(n,t)}intersectsPlane(e){let t=e.distanceToPoint(this.origin);return t===0||e.normal.dot(this.direction)*t<0}intersectBox(e,t){let n,r,i,a,o,s,c=1/this.direction.x,l=1/this.direction.y,u=1/this.direction.z,d=this.origin;return c>=0?(n=(e.min.x-d.x)*c,r=(e.max.x-d.x)*c):(n=(e.max.x-d.x)*c,r=(e.min.x-d.x)*c),l>=0?(i=(e.min.y-d.y)*l,a=(e.max.y-d.y)*l):(i=(e.max.y-d.y)*l,a=(e.min.y-d.y)*l),n>a||i>r||((i>n||isNaN(n))&&(n=i),(a<r||isNaN(r))&&(r=a),u>=0?(o=(e.min.z-d.z)*u,s=(e.max.z-d.z)*u):(o=(e.max.z-d.z)*u,s=(e.min.z-d.z)*u),n>s||o>r)||((o>n||n!==n)&&(n=o),(s<r||r!==r)&&(r=s),r<0)?null:this.at(n>=0?n:r,t)}intersectsBox(e){return this.intersectBox(e,Ur)!==null}intersectTriangle(e,t,n,r,i){let a=this.origin,o=this.direction,s=o.x,c=o.y,l=o.z,u=e.x-a.x,d=e.y-a.y,f=e.z-a.z,p=t.x-a.x,m=t.y-a.y,h=t.z-a.z,g=n.x-a.x,_=n.y-a.y,v=n.z-a.z,y=Math.abs(s),b=Math.abs(c),x=Math.abs(l),S,C,w,T,E,D,O,k,A,ee,j,te;if(y>=b&&y>=x?(w=s,D=u,A=p,te=g,s>=0?(S=c,C=l,T=d,E=f,O=m,k=h,ee=_,j=v):(S=l,C=c,T=f,E=d,O=h,k=m,ee=v,j=_)):b>=x?(w=c,D=d,A=m,te=_,c>=0?(S=l,C=s,T=f,E=u,O=h,k=p,ee=v,j=g):(S=s,C=l,T=u,E=f,O=p,k=h,ee=g,j=v)):(w=l,D=f,A=h,te=v,l>=0?(S=s,C=c,T=u,E=d,O=p,k=m,ee=g,j=_):(S=c,C=s,T=d,E=u,O=m,k=p,ee=_,j=g)),w===0)return null;let M=S/w,ne=C/w,N=1/w,re=T-M*D,ie=E-ne*D,ae=O-M*A,oe=k-ne*A,se=ee-M*te,ce=j-ne*te,le=se*oe-ce*ae,ue=re*ce-ie*se,de=ae*ie-oe*re;if(r){if(le<0||ue<0||de<0)return null}else if((le<0||ue<0||de<0)&&(le>0||ue>0||de>0))return null;let fe=le+ue+de;if(fe===0)return null;let pe=N*(le*D+ue*A+de*te);return(fe>0?pe<0:pe>0)?null:this.at(pe/fe,i)}applyMatrix4(e){return this.origin.applyMatrix4(e),this.direction.transformDirection(e),this}equals(e){return e.origin.equals(this.origin)&&e.direction.equals(this.direction)}clone(){return new this.constructor().copy(this)}},Jr=class extends Hr{constructor(e){super(),this.isMeshBasicMaterial=!0,this.type=`MeshBasicMaterial`,this.color=new R(16777215),this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.specularMap=null,this.alphaMap=null,this.envMap=null,this.envMapRotation=new gn,this.combine=0,this.reflectivity=1,this.refractionRatio=.98,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap=`round`,this.wireframeLinejoin=`round`,this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.lightMap=e.lightMap,this.lightMapIntensity=e.lightMapIntensity,this.aoMap=e.aoMap,this.aoMapIntensity=e.aoMapIntensity,this.specularMap=e.specularMap,this.alphaMap=e.alphaMap,this.envMap=e.envMap,this.envMapRotation.copy(e.envMapRotation),this.combine=e.combine,this.reflectivity=e.reflectivity,this.refractionRatio=e.refractionRatio,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.wireframeLinecap=e.wireframeLinecap,this.wireframeLinejoin=e.wireframeLinejoin,this.fog=e.fog,this}},Yr=new on,Xr=new qr,Zr=new Or,Qr=new L,$r=new L,ei=new L,ti=new L,ni=new L,ri=new L,ii=new L,ai=new L,oi=class extends Nn{constructor(e=new Ir,t=new Jr){super(),this.isMesh=!0,this.type=`Mesh`,this.geometry=e,this.material=t,this.morphTargetDictionary=void 0,this.morphTargetInfluences=void 0,this.count=1,this.updateMorphTargets()}copy(e,t){return super.copy(e,t),this.morphTargetInfluences=e.morphTargetInfluences===void 0?void 0:e.morphTargetInfluences.slice(),this.morphTargetDictionary=e.morphTargetDictionary===void 0?void 0:Object.assign({},e.morphTargetDictionary),this.material=Array.isArray(e.material)?e.material.slice():e.material,this.geometry=e.geometry,this}updateMorphTargets(){let e=this.geometry.morphAttributes,t=Object.keys(e);if(t.length>0){let n=e[t[0]];if(n!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let e=0,t=n.length;e<t;e++){let t=n[e].name||String(e);this.morphTargetInfluences.push(0),this.morphTargetDictionary[t]=e}}}}getVertexPosition(e,t){let n=this.geometry,r=n.attributes.position,i=n.morphAttributes.position,a=n.morphTargetsRelative;t.fromBufferAttribute(r,e);let o=this.morphTargetInfluences;if(i&&o){ri.set(0,0,0);for(let n=0,r=i.length;n<r;n++){let r=o[n],s=i[n];r!==0&&(ni.fromBufferAttribute(s,e),a?ri.addScaledVector(ni,r):ri.addScaledVector(ni.sub(t),r))}t.add(ri)}return t}intersectsFrustum(e){return e.intersectsObject(this)}raycast(e,t){let n=this.geometry,r=this.material,i=this.matrixWorld;r!==void 0&&(n.boundingSphere===null&&n.computeBoundingSphere(),Zr.copy(n.boundingSphere),Zr.applyMatrix4(i),Xr.copy(e.ray).recast(e.near),Zr.containsPoint(Xr.origin)===!1&&(Xr.intersectSphere(Zr,Qr)===null||Xr.origin.distanceToSquared(Qr)>(e.far-e.near)**2)||(Yr.copy(i).invert(),Xr.copy(e.ray).applyMatrix4(Yr),(n.boundingBox===null||Xr.intersectsBox(n.boundingBox)!==!1)&&this._computeIntersections(e,t,Xr)))}_computeIntersections(e,t,n){let r,i=this.geometry,a=this.material,o=i.index,s=i.attributes.position,c=i.attributes.uv,l=i.attributes.uv1,u=i.attributes.normal,d=i.groups,f=i.drawRange;if(o!==null){if(Array.isArray(a))for(let i=0,s=d.length;i<s;i++){let s=d[i],p=a[s.materialIndex],m=Math.max(s.start,f.start),h=Math.min(o.count,Math.min(s.start+s.count,f.start+f.count));for(let i=m,a=h;i<a;i+=3){let a=o.getX(i),d=o.getX(i+1),f=o.getX(i+2);r=ci(this,p,e,n,c,l,u,a,d,f),r&&(r.faceIndex=Math.floor(i/3),r.face.materialIndex=s.materialIndex,t.push(r))}}else{let i=Math.max(0,f.start),s=Math.min(o.count,f.start+f.count);for(let d=i,f=s;d<f;d+=3){let i=o.getX(d),s=o.getX(d+1),f=o.getX(d+2);r=ci(this,a,e,n,c,l,u,i,s,f),r&&(r.faceIndex=Math.floor(d/3),t.push(r))}}}else if(s!==void 0){if(Array.isArray(a))for(let i=0,o=d.length;i<o;i++){let o=d[i],p=a[o.materialIndex],m=Math.max(o.start,f.start),h=Math.min(s.count,Math.min(o.start+o.count,f.start+f.count));for(let i=m,a=h;i<a;i+=3){let a=i,s=i+1,d=i+2;r=ci(this,p,e,n,c,l,u,a,s,d),r&&(r.faceIndex=Math.floor(i/3),r.face.materialIndex=o.materialIndex,t.push(r))}}else{let i=Math.max(0,f.start),o=Math.min(s.count,f.start+f.count);for(let s=i,d=o;s<d;s+=3){let i=s,o=s+1,d=s+2;r=ci(this,a,e,n,c,l,u,i,o,d),r&&(r.faceIndex=Math.floor(s/3),t.push(r))}}}}};function si(e,t,n,r,i,a,o,s){let c;if(c=t.side===1?r.intersectTriangle(o,a,i,!0,s):r.intersectTriangle(i,a,o,t.side===0,s),c===null)return null;ai.copy(s),ai.applyMatrix4(e.matrixWorld);let l=n.ray.origin.distanceTo(ai);return l<n.near||l>n.far?null:{distance:l,point:ai.clone(),object:e}}function ci(e,t,n,r,i,a,o,s,c,l){e.getVertexPosition(s,$r),e.getVertexPosition(c,ei),e.getVertexPosition(l,ti);let u=si(e,t,n,r,$r,ei,ti,ii);if(u){let e=new L;nr.getBarycoord(ii,$r,ei,ti,e),i&&(u.uv=nr.getInterpolatedAttribute(i,s,c,l,e,new I)),a&&(u.uv1=nr.getInterpolatedAttribute(a,s,c,l,e,new I)),o&&(u.normal=nr.getInterpolatedAttribute(o,s,c,l,e,new L),u.normal.dot(r.direction)>0&&u.normal.multiplyScalar(-1));let t={a:s,b:c,c:l,normal:new L,materialIndex:0};nr.getNormal($r,ei,ti,t.normal),u.face=t,u.barycoord=e}return u}var li=class extends $t{constructor(e=null,t=1,n=1,i,a,o,s,c,l=r,u=r,d,f){super(null,o,s,c,l,u,i,a,d,f),this.isDataTexture=!0,this.image={data:e,width:t,height:n},this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}},ui=class extends xr{constructor(e,t,n,r=1){super(e,t,n),this.isInstancedBufferAttribute=!0,this.meshPerAttribute=r}copy(e){return super.copy(e),this.meshPerAttribute=e.meshPerAttribute,this}toJSON(){let e=super.toJSON();return e.meshPerAttribute=this.meshPerAttribute,e.isInstancedBufferAttribute=!0,e}},di=new on,fi=new on,pi=[],mi=new rr,hi=new on,gi=new oi,_i=new Or,vi=class extends oi{constructor(e,t,n){super(e,t),this.isInstancedMesh=!0,this.instanceMatrix=new ui(new Float32Array(n*16),16),this.instanceColor=null,this.morphTexture=null,this.count=n,this.boundingBox=null,this.boundingSphere=null;for(let e=0;e<n;e++)this.setMatrixAt(e,hi)}computeBoundingBox(){let e=this.geometry,t=this.count;this.boundingBox===null&&(this.boundingBox=new rr),e.boundingBox===null&&e.computeBoundingBox(),this.boundingBox.makeEmpty();for(let n=0;n<t;n++)this.getMatrixAt(n,di),mi.copy(e.boundingBox).applyMatrix4(di),this.boundingBox.union(mi)}computeBoundingSphere(){let e=this.geometry,t=this.count;this.boundingSphere===null&&(this.boundingSphere=new Or),e.boundingSphere===null&&e.computeBoundingSphere(),this.boundingSphere.makeEmpty();for(let n=0;n<t;n++)this.getMatrixAt(n,di),_i.copy(e.boundingSphere).applyMatrix4(di),this.boundingSphere.union(_i)}copy(e,t){return super.copy(e,t),this.instanceMatrix.copy(e.instanceMatrix),this.morphTexture=e.morphTexture===null?null:e.morphTexture.clone(),this.instanceColor=e.instanceColor===null?null:e.instanceColor.clone(),this.count=e.count,this.boundingBox=e.boundingBox===null?null:e.boundingBox.clone(),this.boundingSphere=e.boundingSphere===null?null:e.boundingSphere.clone(),this}getColorAt(e,t){return this.instanceColor===null?t.setRGB(1,1,1):t.fromArray(this.instanceColor.array,e*3)}getMatrixAt(e,t){return t.fromArray(this.instanceMatrix.array,e*16)}getMorphAt(e,t){let n=t.morphTargetInfluences,r=this.morphTexture.source.data.data,i=e*(n.length+1)+1;for(let e=0;e<n.length;e++)n[e]=r[i+e]}raycast(e,t){let n=this.matrixWorld,r=this.count;if(gi.geometry=this.geometry,gi.material=this.material,gi.material!==void 0&&(this.boundingSphere===null&&this.computeBoundingSphere(),_i.copy(this.boundingSphere),_i.applyMatrix4(n),e.ray.intersectsSphere(_i)!==!1))for(let i=0;i<r;i++){this.getMatrixAt(i,di),fi.multiplyMatrices(n,di),gi.matrixWorld=fi,gi.raycast(e,pi);for(let e=0,n=pi.length;e<n;e++){let n=pi[e];n.instanceId=i,n.object=this,t.push(n)}pi.length=0}}setColorAt(e,t){return this.instanceColor===null&&(this.instanceColor=new ui(new Float32Array(this.instanceMatrix.count*3).fill(1),3)),t.toArray(this.instanceColor.array,e*3),this}setMatrixAt(e,t){return t.toArray(this.instanceMatrix.array,e*16),this}setMorphAt(e,t){let n=t.morphTargetInfluences,r=n.length+1;this.morphTexture===null&&(this.morphTexture=new li(new Float32Array(r*this.count),r,this.count,D,h));let i=this.morphTexture.source.data.data,a=0;for(let e=0;e<n.length;e++)a+=n[e];let o=this.geometry.morphTargetsRelative?1:1-a,s=r*e;return i[s]=o,i.set(n,s+1),this}updateMorphTargets(){}dispose(){super.dispose(),this.instanceMatrix.dispose(),this.instanceColor!==null&&this.instanceColor.dispose(),this.morphTexture!==null&&(this.morphTexture.dispose(),this.morphTexture=null)}},yi=new Or,bi=new I(.5,.5),xi=new L,Si=class{constructor(e=new Br,t=new Br,n=new Br,r=new Br,i=new Br,a=new Br){this.planes=[e,t,n,r,i,a]}set(e,t,n,r,i,a){let o=this.planes;return o[0].copy(e),o[1].copy(t),o[2].copy(n),o[3].copy(r),o[4].copy(i),o[5].copy(a),this}copy(e){let t=this.planes;for(let n=0;n<6;n++)t[n].copy(e.planes[n]);return this}setFromProjectionMatrix(e,t=qe,n=!1){let r=this.planes,i=e.elements,a=i[0],o=i[1],s=i[2],c=i[3],l=i[4],u=i[5],d=i[6],f=i[7],p=i[8],m=i[9],h=i[10],g=i[11],_=i[12],v=i[13],y=i[14],b=i[15];if(r[0].setComponents(c-a,f-l,g-p,b-_).normalize(),r[1].setComponents(c+a,f+l,g+p,b+_).normalize(),r[2].setComponents(c+o,f+u,g+m,b+v).normalize(),r[3].setComponents(c-o,f-u,g-m,b-v).normalize(),n)r[4].setComponents(s,d,h,y).normalize(),r[5].setComponents(c-s,f-d,g-h,b-y).normalize();else if(r[4].setComponents(c-s,f-d,g-h,b-y).normalize(),t===2e3)r[5].setComponents(c+s,f+d,g+h,b+y).normalize();else if(t===2001)r[5].setComponents(s,d,h,y).normalize();else throw Error(`THREE.Frustum.setFromProjectionMatrix(): Invalid coordinate system: `+t);return this}intersectsObject(e){if(e.boundingSphere!==void 0)e.boundingSphere===null&&e.computeBoundingSphere(),yi.copy(e.boundingSphere).applyMatrix4(e.matrixWorld);else{let t=e.geometry;t.boundingSphere===null&&t.computeBoundingSphere(),yi.copy(t.boundingSphere).applyMatrix4(e.matrixWorld)}return this.intersectsSphere(yi)}intersectsSprite(e){return yi.center.set(0,0,0),yi.radius=.7071067811865476+bi.distanceTo(e.center),yi.applyMatrix4(e.matrixWorld),this.intersectsSphere(yi)}intersectsSphere(e){let t=this.planes,n=e.center,r=-e.radius;for(let e=0;e<6;e++)if(t[e].distanceToPoint(n)<r)return!1;return!0}intersectsBox(e){let t=this.planes;for(let n=0;n<6;n++){let r=t[n];if(xi.x=r.normal.x>0?e.max.x:e.min.x,xi.y=r.normal.y>0?e.max.y:e.min.y,xi.z=r.normal.z>0?e.max.z:e.min.z,r.distanceToPoint(xi)<0)return!1}return!0}containsPoint(e){let t=this.planes;for(let n=0;n<6;n++)if(t[n].distanceToPoint(e)<0)return!1;return!0}clone(){return new this.constructor().copy(this)}},Ci=new on,wi=class e{constructor(){this.coordinateSystem=qe,this._frustums=[],this._count=0}setFromArrayCamera(e){let t=e.cameras,n=this._frustums;for(let e=0;e<t.length;e++){let r=t[e];Ci.multiplyMatrices(r.projectionMatrix,r.matrixWorldInverse),n[e]===void 0&&(n[e]=new Si),n[e].setFromProjectionMatrix(Ci,r.coordinateSystem,r.reversedDepth)}return this._count=t.length,this}getFrustum(e){return this._frustums[e]}intersectsObject(e){let t=this._frustums;for(let n=0;n<this._count;n++)if(t[n].intersectsObject(e))return!0;return!1}intersectsSprite(e){let t=this._frustums;for(let n=0;n<this._count;n++)if(t[n].intersectsSprite(e))return!0;return!1}intersectsSphere(e){let t=this._frustums;for(let n=0;n<this._count;n++)if(t[n].intersectsSphere(e))return!0;return!1}intersectsBox(e){let t=this._frustums;for(let n=0;n<this._count;n++)if(t[n].intersectsBox(e))return!0;return!1}containsPoint(e){let t=this._frustums;for(let n=0;n<this._count;n++)if(t[n].containsPoint(e))return!0;return!1}copy(e){this.coordinateSystem=e.coordinateSystem;let t=this._frustums,n=e._frustums;for(let r=0;r<e._count;r++)t[r]===void 0&&(t[r]=new Si),t[r].copy(n[r]);return this._count=e._count,this}clone(){return new e().copy(this)}},Ti=class extends Hr{constructor(e){super(),this.isLineBasicMaterial=!0,this.type=`LineBasicMaterial`,this.color=new R(16777215),this.map=null,this.linewidth=1,this.linecap=`round`,this.linejoin=`round`,this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.linewidth=e.linewidth,this.linecap=e.linecap,this.linejoin=e.linejoin,this.fog=e.fog,this}},Ei=new L,Di=new L,Oi=new on,ki=new qr,Ai=new Or,ji=new L,Mi=new L,Ni=class extends Nn{constructor(e=new Ir,t=new Ti){super(),this.isLine=!0,this.type=`Line`,this.geometry=e,this.material=t,this.morphTargetDictionary=void 0,this.morphTargetInfluences=void 0,this.updateMorphTargets()}copy(e,t){return super.copy(e,t),this.morphTargetInfluences=e.morphTargetInfluences===void 0?void 0:e.morphTargetInfluences.slice(),this.morphTargetDictionary=e.morphTargetDictionary===void 0?void 0:Object.assign({},e.morphTargetDictionary),this.material=Array.isArray(e.material)?e.material.slice():e.material,this.geometry=e.geometry,this}computeLineDistances(){let e=this.geometry;if(e.index===null){let t=e.attributes.position,n=[0];for(let e=1,r=t.count;e<r;e++)Ei.fromBufferAttribute(t,e-1),Di.fromBufferAttribute(t,e),n[e]=n[e-1],n[e]+=Ei.distanceTo(Di);e.setAttribute(`lineDistance`,new wr(n,1))}else tt(`Line.computeLineDistances(): Computation only possible with non-indexed BufferGeometry.`);return this}intersectsFrustum(e){return e.intersectsObject(this)}raycast(e,t){let n=this.geometry,r=this.matrixWorld,i=e.params.Line.threshold,a=n.drawRange;if(n.boundingSphere===null&&n.computeBoundingSphere(),Ai.copy(n.boundingSphere),Ai.applyMatrix4(r),Ai.radius+=i,e.ray.intersectsSphere(Ai)===!1)return;Oi.copy(r).invert(),ki.copy(e.ray).applyMatrix4(Oi);let o=i/((this.scale.x+this.scale.y+this.scale.z)/3),s=o*o,c=this.isLineSegments?2:1,l=n.index,u=n.attributes.position;if(l!==null){let n=Math.max(0,a.start),r=Math.min(l.count,a.start+a.count);for(let i=n,a=r-1;i<a;i+=c){let n=l.getX(i),r=l.getX(i+1),a=Pi(this,e,ki,s,n,r,i);a&&t.push(a)}if(this.isLineLoop){let i=l.getX(r-1),a=l.getX(n),o=Pi(this,e,ki,s,i,a,r-1);o&&t.push(o)}}else{let n=Math.max(0,a.start),r=Math.min(u.count,a.start+a.count);for(let i=n,a=r-1;i<a;i+=c){let n=Pi(this,e,ki,s,i,i+1,i);n&&t.push(n)}if(this.isLineLoop){let i=Pi(this,e,ki,s,r-1,n,r-1);i&&t.push(i)}}}updateMorphTargets(){let e=this.geometry.morphAttributes,t=Object.keys(e);if(t.length>0){let n=e[t[0]];if(n!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let e=0,t=n.length;e<t;e++){let t=n[e].name||String(e);this.morphTargetInfluences.push(0),this.morphTargetDictionary[t]=e}}}}};function Pi(e,t,n,r,i,a,o){let s=e.geometry.attributes.position;if(Ei.fromBufferAttribute(s,i),Di.fromBufferAttribute(s,a),n.distanceSqToSegment(Ei,Di,ji,Mi)>r)return;ji.applyMatrix4(e.matrixWorld);let c=t.ray.origin.distanceTo(ji);if(!(c<t.near||c>t.far))return{distance:c,point:Mi.clone().applyMatrix4(e.matrixWorld),index:o,face:null,faceIndex:null,barycoord:null,object:e}}var Fi=new L,Ii=new L,Li=class extends Ni{constructor(e,t){super(e,t),this.isLineSegments=!0,this.type=`LineSegments`}computeLineDistances(){let e=this.geometry;if(e.index===null){let t=e.attributes.position,n=[];for(let e=0,r=t.count;e<r;e+=2)Fi.fromBufferAttribute(t,e),Ii.fromBufferAttribute(t,e+1),n[e]=e===0?0:n[e-1],n[e+1]=n[e]+Fi.distanceTo(Ii);e.setAttribute(`lineDistance`,new wr(n,1))}else tt(`LineSegments.computeLineDistances(): Computation only possible with non-indexed BufferGeometry.`);return this}},Ri=class extends Ni{constructor(e,t){super(e,t),this.isLineLoop=!0,this.type=`LineLoop`}},zi=class extends Hr{constructor(e){super(),this.isPointsMaterial=!0,this.type=`PointsMaterial`,this.color=new R(16777215),this.map=null,this.alphaMap=null,this.size=1,this.sizeAttenuation=!0,this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.alphaMap=e.alphaMap,this.size=e.size,this.sizeAttenuation=e.sizeAttenuation,this.fog=e.fog,this}},Bi=new on,Vi=new qr,Hi=new Or,Ui=new L,Wi=class extends Nn{constructor(e=new Ir,t=new zi){super(),this.isPoints=!0,this.type=`Points`,this.geometry=e,this.material=t,this.morphTargetDictionary=void 0,this.morphTargetInfluences=void 0,this.updateMorphTargets()}copy(e,t){return super.copy(e,t),this.morphTargetInfluences=e.morphTargetInfluences===void 0?void 0:e.morphTargetInfluences.slice(),this.morphTargetDictionary=e.morphTargetDictionary===void 0?void 0:Object.assign({},e.morphTargetDictionary),this.material=Array.isArray(e.material)?e.material.slice():e.material,this.geometry=e.geometry,this}intersectsFrustum(e){return e.intersectsObject(this)}raycast(e,t){let n=this.geometry,r=this.matrixWorld,i=e.params.Points.threshold,a=n.drawRange;if(n.boundingSphere===null&&n.computeBoundingSphere(),Hi.copy(n.boundingSphere),Hi.applyMatrix4(r),Hi.radius+=i,e.ray.intersectsSphere(Hi)===!1)return;Bi.copy(r).invert(),Vi.copy(e.ray).applyMatrix4(Bi);let o=i/((this.scale.x+this.scale.y+this.scale.z)/3),s=o*o,c=n.index,l=n.attributes.position;if(c!==null){let n=Math.max(0,a.start),i=Math.min(c.count,a.start+a.count);for(let a=n,o=i;a<o;a++){let n=c.getX(a);Ui.fromBufferAttribute(l,n),Gi(Ui,n,s,r,e,t,this)}}else{let n=Math.max(0,a.start),i=Math.min(l.count,a.start+a.count);for(let a=n,o=i;a<o;a++)Ui.fromBufferAttribute(l,a),Gi(Ui,a,s,r,e,t,this)}}updateMorphTargets(){let e=this.geometry.morphAttributes,t=Object.keys(e);if(t.length>0){let n=e[t[0]];if(n!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let e=0,t=n.length;e<t;e++){let t=n[e].name||String(e);this.morphTargetInfluences.push(0),this.morphTargetDictionary[t]=e}}}}};function Gi(e,t,n,r,i,a,o){let s=Vi.distanceSqToPoint(e);if(s<n){let n=new L;Vi.closestPointToPoint(e,n),n.applyMatrix4(r);let c=i.ray.origin.distanceTo(n);if(c<i.near||c>i.far)return;a.push({distance:c,distanceToRay:Math.sqrt(s),point:n,index:t,face:null,faceIndex:null,barycoord:null,object:o})}}var Ki=class extends $t{constructor(e=[],t=301,n,r,i,a,o,s,c,l){super(e,t,n,r,i,a,o,s,c,l),this.isCubeTexture=!0,this.flipY=!1}get images(){return this.image}set images(e){this.image=e}},qi=class extends $t{constructor(e,t,n=m,i,a,o,s=r,c=r,l,u=T,d=1){if(u!==1026&&u!==1027)throw Error(`THREE.DepthTexture: format must be either THREE.DepthFormat or THREE.DepthStencilFormat`);super({width:e,height:t,depth:d},i,a,o,s,c,u,n,l),this.isDepthTexture=!0,this.flipY=!1,this.generateMipmaps=!1,this.compareFunction=null}copy(e){return super.copy(e),this.source=new Yt(Object.assign({},e.image)),this.compareFunction=e.compareFunction,this}toJSON(e){let t=super.toJSON(e);return t.compareFunction=this.compareFunction,t}},Ji=class extends qi{constructor(e,t=m,n=301,i,a,o=r,s=r,c,l=T){let u={width:e,height:e,depth:1},d=[u,u,u,u,u,u];super(e,e,t,n,i,a,o,s,c,l),this.image=d,this.isCubeDepthTexture=!0,this.isCubeTexture=!0}get images(){return this.image}set images(e){this.image=e}},Yi=class extends $t{constructor(e=null){super(),this.sourceTexture=e,this.isExternalTexture=!0}copy(e){return super.copy(e),this.sourceTexture=e.sourceTexture,this}},Xi=class e extends Ir{constructor(e=1,t=1,n=1,r=1,i=1,a=1){super(),this.type=`BoxGeometry`,this.parameters={width:e,height:t,depth:n,widthSegments:r,heightSegments:i,depthSegments:a};let o=this;r=Math.floor(r),i=Math.floor(i),a=Math.floor(a);let s=[],c=[],l=[],u=[],d=0,f=0;p(`z`,`y`,`x`,-1,-1,n,t,e,a,i,0),p(`z`,`y`,`x`,1,-1,n,t,-e,a,i,1),p(`x`,`z`,`y`,1,1,e,n,t,r,a,2),p(`x`,`z`,`y`,1,-1,e,n,-t,r,a,3),p(`x`,`y`,`z`,1,-1,e,t,n,r,i,4),p(`x`,`y`,`z`,-1,-1,e,t,-n,r,i,5),this.setIndex(s),this.setAttribute(`position`,new wr(c,3)),this.setAttribute(`normal`,new wr(l,3)),this.setAttribute(`uv`,new wr(u,2));function p(e,t,n,r,i,a,p,m,h,g,_){let v=a/h,y=p/g,b=a/2,x=p/2,S=m/2,C=h+1,w=g+1,T=0,E=0,D=new L;for(let a=0;a<w;a++){let o=a*y-x;for(let s=0;s<C;s++)D[e]=(s*v-b)*r,D[t]=o*i,D[n]=S,c.push(D.x,D.y,D.z),D[e]=0,D[t]=0,D[n]=m>0?1:-1,l.push(D.x,D.y,D.z),u.push(s/h),u.push(1-a/g),T+=1}for(let e=0;e<g;e++)for(let t=0;t<h;t++){let n=d+t+C*e,r=d+t+C*(e+1),i=d+(t+1)+C*(e+1),a=d+(t+1)+C*e;s.push(n,r,a),s.push(r,i,a),E+=6}o.addGroup(f,E,_),f+=E,d+=T}}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(t){return new e(t.width,t.height,t.depth,t.widthSegments,t.heightSegments,t.depthSegments)}},Zi=class e extends Ir{constructor(e=1,t=1,n=4,r=8,i=1){super(),this.type=`CapsuleGeometry`,this.parameters={radius:e,height:t,capSegments:n,radialSegments:r,heightSegments:i},t=Math.max(0,t),n=Math.max(1,Math.floor(n)),r=Math.max(3,Math.floor(r)),i=Math.max(1,Math.floor(i));let a=[],o=[],s=[],c=[],l=t/2,u=Math.PI/2*e,d=t,f=2*u+d,p=n*2+i,m=r+1,h=new L,g=new L;for(let _=0;_<=p;_++){let v=0,y=0,b=0,x=0;if(_<=n){let t=_/n,r=t*Math.PI/2;y=-l-e*Math.cos(r),b=e*Math.sin(r),x=-e*Math.cos(r),v=t*u}else if(_<=n+i){let r=(_-n)/i;y=-l+r*t,b=e,x=0,v=u+r*d}else{let t=(_-n-i)/n,r=t*Math.PI/2;y=l+e*Math.sin(r),b=e*Math.cos(r),x=e*Math.sin(r),v=u+d+t*u}let S=Math.max(0,Math.min(1,v/f)),C=0;_===0?C=.5/r:_===p&&(C=-.5/r);for(let e=0;e<=r;e++){let t=e/r,n=t*Math.PI*2,i=Math.sin(n),a=Math.cos(n);g.x=-b*a,g.y=y,g.z=b*i,o.push(g.x,g.y,g.z),h.set(-b*a,x,b*i),h.normalize(),s.push(h.x,h.y,h.z),c.push(t+C,S)}if(_>0){let e=(_-1)*m;for(let t=0;t<r;t++){let n=e+t,r=e+t+1,i=_*m+t,o=_*m+t+1;a.push(n,r,i),a.push(r,o,i)}}}this.setIndex(a),this.setAttribute(`position`,new wr(o,3)),this.setAttribute(`normal`,new wr(s,3)),this.setAttribute(`uv`,new wr(c,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(t){return new e(t.radius,t.height,t.capSegments,t.radialSegments,t.heightSegments)}},Qi=class e extends Ir{constructor(e=1,t=32,n=0,r=Math.PI*2){super(),this.type=`CircleGeometry`,this.parameters={radius:e,segments:t,thetaStart:n,thetaLength:r},t=Math.max(3,t);let i=[],a=[],o=[],s=[],c=new L,l=new I;a.push(0,0,0),o.push(0,0,1),s.push(.5,.5);for(let i=0,u=3;i<=t;i++,u+=3){let d=n+i/t*r;c.x=e*Math.cos(d),c.y=e*Math.sin(d),a.push(c.x,c.y,c.z),o.push(0,0,1),l.x=(a[u]/e+1)/2,l.y=(a[u+1]/e+1)/2,s.push(l.x,l.y)}for(let e=1;e<=t;e++)i.push(e,e+1,0);this.setIndex(i),this.setAttribute(`position`,new wr(a,3)),this.setAttribute(`normal`,new wr(o,3)),this.setAttribute(`uv`,new wr(s,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(t){return new e(t.radius,t.segments,t.thetaStart,t.thetaLength)}},$i=class e extends Ir{constructor(e=1,t=1,n=1,r=32,i=1,a=!1,o=0,s=Math.PI*2){super(),this.type=`CylinderGeometry`,this.parameters={radiusTop:e,radiusBottom:t,height:n,radialSegments:r,heightSegments:i,openEnded:a,thetaStart:o,thetaLength:s};let c=this;r=Math.floor(r),i=Math.floor(i);let l=[],u=[],d=[],f=[],p=0,m=[],h=n/2,g=0;_(),a===!1&&(e>0&&v(!0),t>0&&v(!1)),this.setIndex(l),this.setAttribute(`position`,new wr(u,3)),this.setAttribute(`normal`,new wr(d,3)),this.setAttribute(`uv`,new wr(f,2));function _(){let a=new L,_=new L,v=0,y=(t-e)/n;for(let c=0;c<=i;c++){let l=[],g=c/i,v=g*(t-e)+e;for(let e=0;e<=r;e++){let t=e/r,i=t*s+o,c=Math.sin(i),m=Math.cos(i);_.x=v*c,_.y=-g*n+h,_.z=v*m,u.push(_.x,_.y,_.z),a.set(c,y,m).normalize(),d.push(a.x,a.y,a.z),f.push(t,1-g),l.push(p++)}m.push(l)}for(let n=0;n<r;n++)for(let r=0;r<i;r++){let a=m[r][n],o=m[r+1][n],s=m[r+1][n+1],c=m[r][n+1];(e>0||r!==0)&&(l.push(a,o,c),v+=3),(t>0||r!==i-1)&&(l.push(o,s,c),v+=3)}c.addGroup(g,v,0),g+=v}function v(n){let i=p,a=new I,m=new L,_=0,v=n===!0?e:t,y=n===!0?1:-1;for(let e=1;e<=r;e++)u.push(0,h*y,0),d.push(0,y,0),f.push(.5,.5),p++;let b=p;for(let e=0;e<=r;e++){let t=e/r*s+o,n=Math.cos(t),i=Math.sin(t);m.x=v*i,m.y=h*y,m.z=v*n,u.push(m.x,m.y,m.z),d.push(0,y,0),a.x=n*.5+.5,a.y=i*.5*y+.5,f.push(a.x,a.y),p++}for(let e=0;e<r;e++){let t=i+e,r=b+e;n===!0?l.push(r,r+1,t):l.push(r+1,r,t),_+=3}c.addGroup(g,_,n===!0?1:2),g+=_}}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(t){return new e(t.radiusTop,t.radiusBottom,t.height,t.radialSegments,t.heightSegments,t.openEnded,t.thetaStart,t.thetaLength)}},ea=class e extends $i{constructor(e=1,t=1,n=32,r=1,i=!1,a=0,o=Math.PI*2){super(0,e,t,n,r,i,a,o),this.type=`ConeGeometry`,this.parameters={radius:e,height:t,radialSegments:n,heightSegments:r,openEnded:i,thetaStart:a,thetaLength:o}}static fromJSON(t){return new e(t.radius,t.height,t.radialSegments,t.heightSegments,t.openEnded,t.thetaStart,t.thetaLength)}},ta=class e extends Ir{constructor(e=[],t=[],n=1,r=0){super(),this.type=`PolyhedronGeometry`,this.parameters={vertices:e,indices:t,radius:n,detail:r};let i=[],a=[];o(r),c(n),l(),this.setAttribute(`position`,new wr(i,3)),this.setAttribute(`normal`,new wr(i.slice(),3)),this.setAttribute(`uv`,new wr(a,2)),r===0?this.computeVertexNormals():this.normalizeNormals();function o(e){let n=new L,r=new L,i=new L;for(let a=0;a<t.length;a+=3)f(t[a+0],n),f(t[a+1],r),f(t[a+2],i),s(n,r,i,e)}function s(e,t,n,r){let i=r+1,a=[];for(let r=0;r<=i;r++){a[r]=[];let o=e.clone().lerp(n,r/i),s=t.clone().lerp(n,r/i),c=i-r;for(let e=0;e<=c;e++)e===0&&r===i?a[r][e]=o:a[r][e]=o.clone().lerp(s,e/c)}for(let e=0;e<i;e++)for(let t=0;t<2*(i-e)-1;t++){let n=Math.floor(t/2);t%2==0?(d(a[e][n+1]),d(a[e+1][n]),d(a[e][n])):(d(a[e][n+1]),d(a[e+1][n+1]),d(a[e+1][n]))}}function c(e){let t=new L;for(let n=0;n<i.length;n+=3)t.x=i[n+0],t.y=i[n+1],t.z=i[n+2],t.normalize().multiplyScalar(e),i[n+0]=t.x,i[n+1]=t.y,i[n+2]=t.z}function l(){let e=new L;for(let t=0;t<i.length;t+=3){e.x=i[t+0],e.y=i[t+1],e.z=i[t+2];let n=h(e)/2/Math.PI+.5,r=g(e)/Math.PI+.5;a.push(n,1-r)}p(),u()}function u(){for(let e=0;e<a.length;e+=6){let t=a[e+0],n=a[e+2],r=a[e+4];Math.max(t,n,r)>.9&&Math.min(t,n,r)<.1&&(t<.2&&(a[e+0]+=1),n<.2&&(a[e+2]+=1),r<.2&&(a[e+4]+=1))}}function d(e){i.push(e.x,e.y,e.z)}function f(t,n){let r=t*3;n.x=e[r+0],n.y=e[r+1],n.z=e[r+2]}function p(){let e=new L,t=new L,n=new L,r=new L,o=new I,s=new I,c=new I;for(let l=0,u=0;l<i.length;l+=9,u+=6){e.set(i[l+0],i[l+1],i[l+2]),t.set(i[l+3],i[l+4],i[l+5]),n.set(i[l+6],i[l+7],i[l+8]),o.set(a[u+0],a[u+1]),s.set(a[u+2],a[u+3]),c.set(a[u+4],a[u+5]),r.copy(e).add(t).add(n).divideScalar(3);let d=h(r);m(o,u+0,e,d),m(s,u+2,t,d),m(c,u+4,n,d)}}function m(e,t,n,r){r<0&&e.x===1&&(a[t]=e.x-1),n.x===0&&n.z===0&&(a[t]=r/2/Math.PI+.5)}function h(e){return Math.atan2(e.z,-e.x)}function g(e){return Math.atan2(-e.y,Math.sqrt(e.x*e.x+e.z*e.z))}}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(t){return new e(t.vertices,t.indices,t.radius,t.detail)}},na=class{constructor(){this.type=`Curve`,this.arcLengthDivisions=200,this.needsUpdate=!1,this.cacheArcLengths=null}getPoint(){tt(`Curve: .getPoint() not implemented.`)}getPointAt(e,t){let n=this.getUtoTmapping(e);return this.getPoint(n,t)}getPoints(e=5){let t=[];for(let n=0;n<=e;n++)t.push(this.getPoint(n/e));return t}getSpacedPoints(e=5){let t=[];for(let n=0;n<=e;n++)t.push(this.getPointAt(n/e));return t}getLength(){let e=this.getLengths();return e[e.length-1]}getLengths(e=this.arcLengthDivisions){if(this.cacheArcLengths&&this.cacheArcLengths.length===e+1&&!this.needsUpdate)return this.cacheArcLengths;this.needsUpdate=!1;let t=[],n,r=this.getPoint(0),i=0;t.push(0);for(let a=1;a<=e;a++)n=this.getPoint(a/e),i+=n.distanceTo(r),t.push(i),r=n;return this.cacheArcLengths=t,t}updateArcLengths(){this.needsUpdate=!0,this.getLengths()}getUtoTmapping(e,t=null){let n=this.getLengths(),r=0,i=n.length,a;a=t||e*n[i-1];let o=0,s=i-1,c;for(;o<=s;)if(r=Math.floor(o+(s-o)/2),c=n[r]-a,c<0)o=r+1;else if(c>0)s=r-1;else{s=r;break}if(r=s,n[r]===a)return r/(i-1);let l=n[r],u=n[r+1]-l,d=(a-l)/u;return(r+d)/(i-1)}getTangent(e,t){let n=1e-4,r=e-n,i=e+n;r<0&&(r=0),i>1&&(i=1);let a=this.getPoint(r),o=this.getPoint(i),s=t||(a.isVector2?new I:new L);return s.copy(o).sub(a).normalize(),s}getTangentAt(e,t){let n=this.getUtoTmapping(e);return this.getTangent(n,t)}computeFrenetFrames(e,t=!1){let n=new L,r=[],i=[],a=[],o=new L,s=new on;for(let t=0;t<=e;t++){let n=t/e;r[t]=this.getTangentAt(n,new L)}i[0]=new L,a[0]=new L;let c=Number.MAX_VALUE,l=Math.abs(r[0].x),u=Math.abs(r[0].y),d=Math.abs(r[0].z);l<=c&&(c=l,n.set(1,0,0)),u<=c&&(c=u,n.set(0,1,0)),d<=c&&n.set(0,0,1),o.crossVectors(r[0],n).normalize(),i[0].crossVectors(r[0],o),a[0].crossVectors(r[0],i[0]);for(let t=1;t<=e;t++){if(i[t]=i[t-1].clone(),a[t]=a[t-1].clone(),o.crossVectors(r[t-1],r[t]),o.length()>2**-52){o.normalize();let e=Math.acos(ft(r[t-1].dot(r[t]),-1,1));i[t].applyMatrix4(s.makeRotationAxis(o,e))}a[t].crossVectors(r[t],i[t])}if(t===!0){let t=Math.acos(ft(i[0].dot(i[e]),-1,1));t/=e,r[0].dot(o.crossVectors(i[0],i[e]))>0&&(t=-t);for(let n=1;n<=e;n++)i[n].applyMatrix4(s.makeRotationAxis(r[n],t*n)),a[n].crossVectors(r[n],i[n])}return{tangents:r,normals:i,binormals:a}}clone(){return new this.constructor().copy(this)}copy(e){return this.arcLengthDivisions=e.arcLengthDivisions,this.cacheArcLengths=null,this}toJSON(){let e={metadata:{version:4.7,type:`Curve`,generator:`Curve.toJSON`}};return e.arcLengthDivisions=this.arcLengthDivisions,e.type=this.type,e}fromJSON(e){return this.arcLengthDivisions=e.arcLengthDivisions,this.cacheArcLengths=null,this}},ra=class extends na{constructor(e=0,t=0,n=1,r=1,i=0,a=Math.PI*2,o=!1,s=0){super(),this.isEllipseCurve=!0,this.type=`EllipseCurve`,this.aX=e,this.aY=t,this.xRadius=n,this.yRadius=r,this.aStartAngle=i,this.aEndAngle=a,this.aClockwise=o,this.aRotation=s}getPoint(e,t=new I){let n=t,r=Math.PI*2,i=this.aEndAngle-this.aStartAngle,a=Math.abs(i)<2**-52;for(;i<0;)i+=r;for(;i>r;)i-=r;i<2**-52&&(i=a?0:r),this.aClockwise===!0&&!a&&(i===r?i=-r:i-=r);let o=this.aStartAngle+e*i,s=this.aX+this.xRadius*Math.cos(o),c=this.aY+this.yRadius*Math.sin(o);if(this.aRotation!==0){let e=Math.cos(this.aRotation),t=Math.sin(this.aRotation),n=s-this.aX,r=c-this.aY;s=n*e-r*t+this.aX,c=n*t+r*e+this.aY}return n.set(s,c)}copy(e){return super.copy(e),this.aX=e.aX,this.aY=e.aY,this.xRadius=e.xRadius,this.yRadius=e.yRadius,this.aStartAngle=e.aStartAngle,this.aEndAngle=e.aEndAngle,this.aClockwise=e.aClockwise,this.aRotation=e.aRotation,this}toJSON(){let e=super.toJSON();return e.aX=this.aX,e.aY=this.aY,e.xRadius=this.xRadius,e.yRadius=this.yRadius,e.aStartAngle=this.aStartAngle,e.aEndAngle=this.aEndAngle,e.aClockwise=this.aClockwise,e.aRotation=this.aRotation,e}fromJSON(e){return super.fromJSON(e),this.aX=e.aX,this.aY=e.aY,this.xRadius=e.xRadius,this.yRadius=e.yRadius,this.aStartAngle=e.aStartAngle,this.aEndAngle=e.aEndAngle,this.aClockwise=e.aClockwise,this.aRotation=e.aRotation,this}},ia=class extends ra{constructor(e,t,n,r,i,a){super(e,t,n,n,r,i,a),this.isArcCurve=!0,this.type=`ArcCurve`}};function aa(){let e=0,t=0,n=0,r=0;function i(i,a,o,s){e=i,t=o,n=-3*i+3*a-2*o-s,r=2*i-2*a+o+s}return{initCatmullRom:function(e,t,n,r,a){i(t,n,a*(n-e),a*(r-t))},initNonuniformCatmullRom:function(e,t,n,r,a,o,s){let c=(t-e)/a-(n-e)/(a+o)+(n-t)/o,l=(n-t)/o-(r-t)/(o+s)+(r-n)/s;c*=o,l*=o,i(t,n,c,l)},calc:function(i){let a=i*i,o=a*i;return e+t*i+n*a+r*o}}}var oa=new L,sa=new L,ca=new aa,la=new aa,ua=new aa,da=class extends na{constructor(e=[],t=!1,n=`centripetal`,r=.5){super(),this.isCatmullRomCurve3=!0,this.type=`CatmullRomCurve3`,this.points=e,this.closed=t,this.curveType=n,this.tension=r}getPoint(e,t=new L){let n=t,r=this.points,i=r.length,a=(i-+!this.closed)*e,o=Math.floor(a),s=a-o;this.closed?o+=o>0?0:(Math.floor(Math.abs(o)/i)+1)*i:s===0&&o===i-1&&(o=i-2,s=1);let c,l;this.closed||o>0?c=r[(o-1)%i]:(sa.subVectors(r[0],r[1]).add(r[0]),c=sa);let u=r[o%i],d=r[(o+1)%i];if(this.closed||o+2<i?l=r[(o+2)%i]:(oa.subVectors(r[i-1],r[i-2]).add(r[i-1]),l=oa),this.curveType===`centripetal`||this.curveType===`chordal`){let e=this.curveType===`chordal`?.5:.25,t=c.distanceToSquared(u)**+e,n=u.distanceToSquared(d)**+e,r=d.distanceToSquared(l)**+e;n<1e-4&&(n=1),t<1e-4&&(t=n),r<1e-4&&(r=n),ca.initNonuniformCatmullRom(c.x,u.x,d.x,l.x,t,n,r),la.initNonuniformCatmullRom(c.y,u.y,d.y,l.y,t,n,r),ua.initNonuniformCatmullRom(c.z,u.z,d.z,l.z,t,n,r)}else this.curveType===`catmullrom`&&(ca.initCatmullRom(c.x,u.x,d.x,l.x,this.tension),la.initCatmullRom(c.y,u.y,d.y,l.y,this.tension),ua.initCatmullRom(c.z,u.z,d.z,l.z,this.tension));return n.set(ca.calc(s),la.calc(s),ua.calc(s)),n}copy(e){super.copy(e),this.points=[];for(let t=0,n=e.points.length;t<n;t++){let n=e.points[t];this.points.push(n.clone())}return this.closed=e.closed,this.curveType=e.curveType,this.tension=e.tension,this}toJSON(){let e=super.toJSON();e.points=[];for(let t=0,n=this.points.length;t<n;t++){let n=this.points[t];e.points.push(n.toArray())}return e.closed=this.closed,e.curveType=this.curveType,e.tension=this.tension,e}fromJSON(e){super.fromJSON(e),this.points=[];for(let t=0,n=e.points.length;t<n;t++){let n=e.points[t];this.points.push(new L().fromArray(n))}return this.closed=e.closed,this.curveType=e.curveType,this.tension=e.tension,this}};function fa(e,t,n,r,i){let a=(r-t)*.5,o=(i-n)*.5,s=e*e,c=e*s;return(2*n-2*r+a+o)*c+(-3*n+3*r-2*a-o)*s+a*e+n}function pa(e,t){let n=1-e;return n*n*t}function ma(e,t){return 2*(1-e)*e*t}function ha(e,t){return e*e*t}function ga(e,t,n,r){return pa(e,t)+ma(e,n)+ha(e,r)}function _a(e,t){let n=1-e;return n*n*n*t}function va(e,t){let n=1-e;return 3*n*n*e*t}function ya(e,t){return 3*(1-e)*e*e*t}function ba(e,t){return e*e*e*t}function xa(e,t,n,r,i){return _a(e,t)+va(e,n)+ya(e,r)+ba(e,i)}var Sa=class extends na{constructor(e=new I,t=new I,n=new I,r=new I){super(),this.isCubicBezierCurve=!0,this.type=`CubicBezierCurve`,this.v0=e,this.v1=t,this.v2=n,this.v3=r}getPoint(e,t=new I){let n=t,r=this.v0,i=this.v1,a=this.v2,o=this.v3;return n.set(xa(e,r.x,i.x,a.x,o.x),xa(e,r.y,i.y,a.y,o.y)),n}copy(e){return super.copy(e),this.v0.copy(e.v0),this.v1.copy(e.v1),this.v2.copy(e.v2),this.v3.copy(e.v3),this}toJSON(){let e=super.toJSON();return e.v0=this.v0.toArray(),e.v1=this.v1.toArray(),e.v2=this.v2.toArray(),e.v3=this.v3.toArray(),e}fromJSON(e){return super.fromJSON(e),this.v0.fromArray(e.v0),this.v1.fromArray(e.v1),this.v2.fromArray(e.v2),this.v3.fromArray(e.v3),this}},Ca=class extends na{constructor(e=new L,t=new L,n=new L,r=new L){super(),this.isCubicBezierCurve3=!0,this.type=`CubicBezierCurve3`,this.v0=e,this.v1=t,this.v2=n,this.v3=r}getPoint(e,t=new L){let n=t,r=this.v0,i=this.v1,a=this.v2,o=this.v3;return n.set(xa(e,r.x,i.x,a.x,o.x),xa(e,r.y,i.y,a.y,o.y),xa(e,r.z,i.z,a.z,o.z)),n}copy(e){return super.copy(e),this.v0.copy(e.v0),this.v1.copy(e.v1),this.v2.copy(e.v2),this.v3.copy(e.v3),this}toJSON(){let e=super.toJSON();return e.v0=this.v0.toArray(),e.v1=this.v1.toArray(),e.v2=this.v2.toArray(),e.v3=this.v3.toArray(),e}fromJSON(e){return super.fromJSON(e),this.v0.fromArray(e.v0),this.v1.fromArray(e.v1),this.v2.fromArray(e.v2),this.v3.fromArray(e.v3),this}},wa=class extends na{constructor(e=new I,t=new I){super(),this.isLineCurve=!0,this.type=`LineCurve`,this.v1=e,this.v2=t}getPoint(e,t=new I){let n=t;return e===1?n.copy(this.v2):(n.copy(this.v2).sub(this.v1),n.multiplyScalar(e).add(this.v1)),n}getPointAt(e,t){return this.getPoint(e,t)}getTangent(e,t=new I){return t.subVectors(this.v2,this.v1).normalize()}getTangentAt(e,t){return this.getTangent(e,t)}copy(e){return super.copy(e),this.v1.copy(e.v1),this.v2.copy(e.v2),this}toJSON(){let e=super.toJSON();return e.v1=this.v1.toArray(),e.v2=this.v2.toArray(),e}fromJSON(e){return super.fromJSON(e),this.v1.fromArray(e.v1),this.v2.fromArray(e.v2),this}},Ta=class extends na{constructor(e=new L,t=new L){super(),this.isLineCurve3=!0,this.type=`LineCurve3`,this.v1=e,this.v2=t}getPoint(e,t=new L){let n=t;return e===1?n.copy(this.v2):(n.copy(this.v2).sub(this.v1),n.multiplyScalar(e).add(this.v1)),n}getPointAt(e,t){return this.getPoint(e,t)}getTangent(e,t=new L){return t.subVectors(this.v2,this.v1).normalize()}getTangentAt(e,t){return this.getTangent(e,t)}copy(e){return super.copy(e),this.v1.copy(e.v1),this.v2.copy(e.v2),this}toJSON(){let e=super.toJSON();return e.v1=this.v1.toArray(),e.v2=this.v2.toArray(),e}fromJSON(e){return super.fromJSON(e),this.v1.fromArray(e.v1),this.v2.fromArray(e.v2),this}},Ea=class extends na{constructor(e=new I,t=new I,n=new I){super(),this.isQuadraticBezierCurve=!0,this.type=`QuadraticBezierCurve`,this.v0=e,this.v1=t,this.v2=n}getPoint(e,t=new I){let n=t,r=this.v0,i=this.v1,a=this.v2;return n.set(ga(e,r.x,i.x,a.x),ga(e,r.y,i.y,a.y)),n}copy(e){return super.copy(e),this.v0.copy(e.v0),this.v1.copy(e.v1),this.v2.copy(e.v2),this}toJSON(){let e=super.toJSON();return e.v0=this.v0.toArray(),e.v1=this.v1.toArray(),e.v2=this.v2.toArray(),e}fromJSON(e){return super.fromJSON(e),this.v0.fromArray(e.v0),this.v1.fromArray(e.v1),this.v2.fromArray(e.v2),this}},Da=class extends na{constructor(e=new L,t=new L,n=new L){super(),this.isQuadraticBezierCurve3=!0,this.type=`QuadraticBezierCurve3`,this.v0=e,this.v1=t,this.v2=n}getPoint(e,t=new L){let n=t,r=this.v0,i=this.v1,a=this.v2;return n.set(ga(e,r.x,i.x,a.x),ga(e,r.y,i.y,a.y),ga(e,r.z,i.z,a.z)),n}copy(e){return super.copy(e),this.v0.copy(e.v0),this.v1.copy(e.v1),this.v2.copy(e.v2),this}toJSON(){let e=super.toJSON();return e.v0=this.v0.toArray(),e.v1=this.v1.toArray(),e.v2=this.v2.toArray(),e}fromJSON(e){return super.fromJSON(e),this.v0.fromArray(e.v0),this.v1.fromArray(e.v1),this.v2.fromArray(e.v2),this}},Oa=class extends na{constructor(e=[]){super(),this.isSplineCurve=!0,this.type=`SplineCurve`,this.points=e}getPoint(e,t=new I){let n=t,r=this.points,i=(r.length-1)*e,a=Math.floor(i),o=i-a,s=r[a===0?a:a-1],c=r[a],l=r[a>r.length-2?r.length-1:a+1],u=r[a>r.length-3?r.length-1:a+2];return n.set(fa(o,s.x,c.x,l.x,u.x),fa(o,s.y,c.y,l.y,u.y)),n}copy(e){super.copy(e),this.points=[];for(let t=0,n=e.points.length;t<n;t++){let n=e.points[t];this.points.push(n.clone())}return this}toJSON(){let e=super.toJSON();e.points=[];for(let t=0,n=this.points.length;t<n;t++){let n=this.points[t];e.points.push(n.toArray())}return e}fromJSON(e){super.fromJSON(e),this.points=[];for(let t=0,n=e.points.length;t<n;t++){let n=e.points[t];this.points.push(new I().fromArray(n))}return this}},ka=Object.freeze({__proto__:null,ArcCurve:ia,CatmullRomCurve3:da,CubicBezierCurve:Sa,CubicBezierCurve3:Ca,EllipseCurve:ra,LineCurve:wa,LineCurve3:Ta,QuadraticBezierCurve:Ea,QuadraticBezierCurve3:Da,SplineCurve:Oa}),Aa=class extends na{constructor(){super(),this.type=`CurvePath`,this.curves=[],this.autoClose=!1,this.cacheLengths=null}add(e){this.curves.push(e)}closePath(){let e=this.curves[0].getPoint(0),t=this.curves[this.curves.length-1].getPoint(1);if(!e.equals(t)){let n=e.isVector2===!0?`LineCurve`:`LineCurve3`;this.curves.push(new ka[n](t,e))}return this}getPoint(e,t){let n=e*this.getLength(),r=this.getCurveLengths(),i=0;for(;i<r.length;){if(r[i]>=n){let e=r[i]-n,a=this.curves[i],o=a.getLength(),s=o===0?0:1-e/o;return a.getPointAt(s,t)}i++}return null}getLength(){let e=this.getCurveLengths();return e[e.length-1]}updateArcLengths(){this.needsUpdate=!0,this.cacheLengths=null,this.getCurveLengths()}getCurveLengths(){if(this.cacheLengths&&this.cacheLengths.length===this.curves.length)return this.cacheLengths;let e=[],t=0;for(let n=0,r=this.curves.length;n<r;n++)t+=this.curves[n].getLength(),e.push(t);return this.cacheLengths=e,e}getSpacedPoints(e=40){let t=[];for(let n=0;n<=e;n++)t.push(this.getPoint(n/e));return this.autoClose&&t.push(t[0]),t}getPoints(e=12){let t=[],n;for(let r=0,i=this.curves;r<i.length;r++){let a=i[r],o=a.isEllipseCurve?e*2:a.isLineCurve||a.isLineCurve3?1:a.isSplineCurve?e*a.points.length:e,s=a.getPoints(o);for(let e=0;e<s.length;e++){let r=s[e];n&&n.equals(r)||(t.push(r),n=r)}}return this.autoClose&&t.length>1&&!t[t.length-1].equals(t[0])&&t.push(t[0]),t}copy(e){super.copy(e),this.curves=[];for(let t=0,n=e.curves.length;t<n;t++){let n=e.curves[t];this.curves.push(n.clone())}return this.autoClose=e.autoClose,this.cacheLengths=null,this}toJSON(){let e=super.toJSON();e.autoClose=this.autoClose,e.curves=[];for(let t=0,n=this.curves.length;t<n;t++){let n=this.curves[t];e.curves.push(n.toJSON())}return e}fromJSON(e){super.fromJSON(e),this.autoClose=e.autoClose,this.curves=[];for(let t=0,n=e.curves.length;t<n;t++){let n=e.curves[t];this.curves.push(new ka[n.type]().fromJSON(n))}return this.cacheLengths=null,this}},ja=class extends Aa{constructor(e){super(),this.type=`Path`,this.currentPoint=new I,e&&this.setFromPoints(e)}setFromPoints(e){this.moveTo(e[0].x,e[0].y);for(let t=1,n=e.length;t<n;t++)this.lineTo(e[t].x,e[t].y);return this}moveTo(e,t){return this.currentPoint.set(e,t),this}lineTo(e,t){let n=new wa(this.currentPoint.clone(),new I(e,t));return this.curves.push(n),this.currentPoint.set(e,t),this}quadraticCurveTo(e,t,n,r){let i=new Ea(this.currentPoint.clone(),new I(e,t),new I(n,r));return this.curves.push(i),this.currentPoint.set(n,r),this}bezierCurveTo(e,t,n,r,i,a){let o=new Sa(this.currentPoint.clone(),new I(e,t),new I(n,r),new I(i,a));return this.curves.push(o),this.currentPoint.set(i,a),this}splineThru(e){let t=new Oa([this.currentPoint.clone()].concat(e));return this.curves.push(t),this.currentPoint.copy(e[e.length-1]),this}arc(e,t,n,r,i,a){let o=this.currentPoint.x,s=this.currentPoint.y;return this.absarc(e+o,t+s,n,r,i,a),this}absarc(e,t,n,r,i,a){return this.absellipse(e,t,n,n,r,i,a),this}ellipse(e,t,n,r,i,a,o,s){let c=this.currentPoint.x,l=this.currentPoint.y;return this.absellipse(e+c,t+l,n,r,i,a,o,s),this}absellipse(e,t,n,r,i,a,o,s){let c=new ra(e,t,n,r,i,a,o,s);if(this.curves.length>0){let e=c.getPoint(0);e.equals(this.currentPoint)||this.lineTo(e.x,e.y)}this.curves.push(c);let l=c.getPoint(1);return this.currentPoint.copy(l),this}copy(e){return super.copy(e),this.currentPoint.copy(e.currentPoint),this}toJSON(){let e=super.toJSON();return e.currentPoint=this.currentPoint.toArray(),e}fromJSON(e){return super.fromJSON(e),this.currentPoint.fromArray(e.currentPoint),this}},Ma=class extends ja{constructor(e){super(e),this.uuid=dt(),this.type=`Shape`,this.holes=[]}getPointsHoles(e){let t=[];for(let n=0,r=this.holes.length;n<r;n++)t[n]=this.holes[n].getPoints(e);return t}extractPoints(e){return{shape:this.getPoints(e),holes:this.getPointsHoles(e)}}copy(e){super.copy(e),this.holes=[];for(let t=0,n=e.holes.length;t<n;t++){let n=e.holes[t];this.holes.push(n.clone())}return this}toJSON(){let e=super.toJSON();e.uuid=this.uuid,e.holes=[];for(let t=0,n=this.holes.length;t<n;t++){let n=this.holes[t];e.holes.push(n.toJSON())}return e}fromJSON(e){super.fromJSON(e),this.uuid=e.uuid,this.holes=[];for(let t=0,n=e.holes.length;t<n;t++){let n=e.holes[t];this.holes.push(new ja().fromJSON(n))}return this}};function Na(e,t,n=2){let r=t&&t.length,i=r?t[0]*n:e.length,a=Pa(e,0,i,n,!0),o=[];if(!a||a.next===a.prev)return o;let s,c,l;if(r&&(a=Va(e,t,a,n)),e.length>80*n){s=e[0],c=e[1];let t=s,r=c;for(let a=n;a<i;a+=n){let n=e[a],i=e[a+1];n<s&&(s=n),i<c&&(c=i),n>t&&(t=n),i>r&&(r=i)}l=Math.max(t-s,r-c),l=l===0?0:32767/l}return Ia(a,o,n,s,c,l,0),o}function Pa(e,t,n,r,i){let a;if(i===fo(e,t,n,r)>0)for(let i=t;i<n;i+=r)a=co(i/r|0,e[i],e[i+1],a);else for(let i=n-r;i>=t;i-=r)a=co(i/r|0,e[i],e[i+1],a);return a&&eo(a,a.next)&&(lo(a),a=a.next),a}function Fa(e,t){if(!e)return e;t||=e;let n=e,r;do if(r=!1,!n.steiner&&(eo(n,n.next)||$a(n.prev,n,n.next)===0)){if(lo(n),n=t=n.prev,n===n.next)break;r=!0}else n=n.next;while(r||n!==t);return t}function Ia(e,t,n,r,i,a,o){if(!e)return;!o&&a&&Ka(e,r,i,a);let s=e;for(;e.prev!==e.next;){let c=e.prev,l=e.next;if(a?Ra(e,r,i,a):La(e))t.push(c.i,e.i,l.i),lo(e),e=l.next,s=l.next;else if(e=l,e===s){o?o===1?(e=za(Fa(e),t),Ia(e,t,n,r,i,a,2)):o===2&&Ba(e,t,n,r,i,a):Ia(Fa(e),t,n,r,i,a,1);break}}}function La(e){let t=e.prev,n=e,r=e.next;if($a(t,n,r)>=0)return!1;let i=t.x,a=n.x,o=r.x,s=t.y,c=n.y,l=r.y,u=Math.min(i,a,o),d=Math.min(s,c,l),f=Math.max(i,a,o),p=Math.max(s,c,l),m=r.next;for(;m!==t;){if(m.x>=u&&m.x<=f&&m.y>=d&&m.y<=p&&Za(i,s,a,c,o,l,m.x,m.y)&&$a(m.prev,m,m.next)>=0)return!1;m=m.next}return!0}function Ra(e,t,n,r){let i=e.prev,a=e,o=e.next;if($a(i,a,o)>=0)return!1;let s=i.x,c=a.x,l=o.x,u=i.y,d=a.y,f=o.y,p=Math.min(s,c,l),m=Math.min(u,d,f),h=Math.max(s,c,l),g=Math.max(u,d,f),_=Ja(p,m,t,n,r),v=Ja(h,g,t,n,r),y=e.prevZ,b=e.nextZ;for(;y&&y.z>=_&&b&&b.z<=v;){if(y.x>=p&&y.x<=h&&y.y>=m&&y.y<=g&&y!==i&&y!==o&&Za(s,u,c,d,l,f,y.x,y.y)&&$a(y.prev,y,y.next)>=0||(y=y.prevZ,b.x>=p&&b.x<=h&&b.y>=m&&b.y<=g&&b!==i&&b!==o&&Za(s,u,c,d,l,f,b.x,b.y)&&$a(b.prev,b,b.next)>=0))return!1;b=b.nextZ}for(;y&&y.z>=_;){if(y.x>=p&&y.x<=h&&y.y>=m&&y.y<=g&&y!==i&&y!==o&&Za(s,u,c,d,l,f,y.x,y.y)&&$a(y.prev,y,y.next)>=0)return!1;y=y.prevZ}for(;b&&b.z<=v;){if(b.x>=p&&b.x<=h&&b.y>=m&&b.y<=g&&b!==i&&b!==o&&Za(s,u,c,d,l,f,b.x,b.y)&&$a(b.prev,b,b.next)>=0)return!1;b=b.nextZ}return!0}function za(e,t){let n=e;do{let r=n.prev,i=n.next.next;!eo(r,i)&&to(r,n,n.next,i)&&ao(r,i)&&ao(i,r)&&(t.push(r.i,n.i,i.i),lo(n),lo(n.next),n=e=i),n=n.next}while(n!==e);return Fa(n)}function Ba(e,t,n,r,i,a){let o=e;do{let e=o.next.next;for(;e!==o.prev;){if(o.i!==e.i&&Qa(o,e)){let s=so(o,e);o=Fa(o,o.next),s=Fa(s,s.next),Ia(o,t,n,r,i,a,0),Ia(s,t,n,r,i,a,0);return}e=e.next}o=o.next}while(o!==e)}function Va(e,t,n,r){let i=[];for(let n=0,a=t.length;n<a;n++){let o=Pa(e,t[n]*r,n<a-1?t[n+1]*r:e.length,r,!1);o===o.next&&(o.steiner=!0),i.push(Ya(o))}i.sort(Ha);for(let e=0;e<i.length;e++)n=Ua(i[e],n);return n}function Ha(e,t){let n=e.x-t.x;return n===0&&(n=e.y-t.y,n===0&&(n=(e.next.y-e.y)/(e.next.x-e.x)-(t.next.y-t.y)/(t.next.x-t.x))),n}function Ua(e,t){let n=Wa(e,t);if(!n)return t;let r=so(n,e);return Fa(r,r.next),Fa(n,n.next)}function Wa(e,t){let n=t,r=e.x,i=e.y,a=-1/0,o;if(eo(e,n))return n;do{if(eo(e,n.next))return n.next;if(i<=n.y&&i>=n.next.y&&n.next.y!==n.y){let e=n.x+(i-n.y)*(n.next.x-n.x)/(n.next.y-n.y);if(e<=r&&e>a&&(a=e,o=n.x<n.next.x?n:n.next,e===r))return o}n=n.next}while(n!==t);if(!o)return null;let s=o,c=o.x,l=o.y,u=1/0;n=o;do{if(r>=n.x&&n.x>=c&&r!==n.x&&Xa(i<l?r:a,i,c,l,i<l?a:r,i,n.x,n.y)){let t=Math.abs(i-n.y)/(r-n.x);ao(n,e)&&(t<u||t===u&&(n.x>o.x||n.x===o.x&&Ga(o,n)))&&(o=n,u=t)}n=n.next}while(n!==s);return o}function Ga(e,t){return $a(e.prev,e,t.prev)<0&&$a(t.next,e,e.next)<0}function Ka(e,t,n,r){let i=e;do i.z===0&&(i.z=Ja(i.x,i.y,t,n,r)),i.prevZ=i.prev,i.nextZ=i.next,i=i.next;while(i!==e);i.prevZ.nextZ=null,i.prevZ=null,qa(i)}function qa(e){let t,n=1;do{let r=e,i;e=null;let a=null;for(t=0;r;){t++;let o=r,s=0;for(let e=0;e<n&&(s++,o=o.nextZ,o);e++);let c=n;for(;s>0||c>0&&o;)s!==0&&(c===0||!o||r.z<=o.z)?(i=r,r=r.nextZ,s--):(i=o,o=o.nextZ,c--),a?a.nextZ=i:e=i,i.prevZ=a,a=i;r=o}a.nextZ=null,n*=2}while(t>1);return e}function Ja(e,t,n,r,i){return e=(e-n)*i|0,t=(t-r)*i|0,e=(e|e<<8)&16711935,e=(e|e<<4)&252645135,e=(e|e<<2)&858993459,e=(e|e<<1)&1431655765,t=(t|t<<8)&16711935,t=(t|t<<4)&252645135,t=(t|t<<2)&858993459,t=(t|t<<1)&1431655765,e|t<<1}function Ya(e){let t=e,n=e;do(t.x<n.x||t.x===n.x&&t.y<n.y)&&(n=t),t=t.next;while(t!==e);return n}function Xa(e,t,n,r,i,a,o,s){return(i-o)*(t-s)>=(e-o)*(a-s)&&(e-o)*(r-s)>=(n-o)*(t-s)&&(n-o)*(a-s)>=(i-o)*(r-s)}function Za(e,t,n,r,i,a,o,s){return(e!==o||t!==s)&&Xa(e,t,n,r,i,a,o,s)}function Qa(e,t){return e.next.i!==t.i&&e.prev.i!==t.i&&!io(e,t)&&(ao(e,t)&&ao(t,e)&&oo(e,t)&&($a(e.prev,e,t.prev)||$a(e,t.prev,t))||eo(e,t)&&$a(e.prev,e,e.next)>0&&$a(t.prev,t,t.next)>0)}function $a(e,t,n){return(t.y-e.y)*(n.x-t.x)-(t.x-e.x)*(n.y-t.y)}function eo(e,t){return e.x===t.x&&e.y===t.y}function to(e,t,n,r){let i=ro($a(e,t,n)),a=ro($a(e,t,r)),o=ro($a(n,r,e)),s=ro($a(n,r,t));return!!(i!==a&&o!==s||i===0&&no(e,n,t)||a===0&&no(e,r,t)||o===0&&no(n,e,r)||s===0&&no(n,t,r))}function no(e,t,n){return t.x<=Math.max(e.x,n.x)&&t.x>=Math.min(e.x,n.x)&&t.y<=Math.max(e.y,n.y)&&t.y>=Math.min(e.y,n.y)}function ro(e){return e>0?1:e<0?-1:0}function io(e,t){let n=e;do{if(n.i!==e.i&&n.next.i!==e.i&&n.i!==t.i&&n.next.i!==t.i&&to(n,n.next,e,t))return!0;n=n.next}while(n!==e);return!1}function ao(e,t){return $a(e.prev,e,e.next)<0?$a(e,t,e.next)>=0&&$a(e,e.prev,t)>=0:$a(e,t,e.prev)<0||$a(e,e.next,t)<0}function oo(e,t){let n=e,r=!1,i=(e.x+t.x)/2,a=(e.y+t.y)/2;do n.y>a!=n.next.y>a&&n.next.y!==n.y&&i<(n.next.x-n.x)*(a-n.y)/(n.next.y-n.y)+n.x&&(r=!r),n=n.next;while(n!==e);return r}function so(e,t){let n=uo(e.i,e.x,e.y),r=uo(t.i,t.x,t.y),i=e.next,a=t.prev;return e.next=t,t.prev=e,n.next=i,i.prev=n,r.next=n,n.prev=r,a.next=r,r.prev=a,r}function co(e,t,n,r){let i=uo(e,t,n);return r?(i.next=r.next,i.prev=r,r.next.prev=i,r.next=i):(i.prev=i,i.next=i),i}function lo(e){e.next.prev=e.prev,e.prev.next=e.next,e.prevZ&&(e.prevZ.nextZ=e.nextZ),e.nextZ&&(e.nextZ.prevZ=e.prevZ)}function uo(e,t,n){return{i:e,x:t,y:n,prev:null,next:null,z:0,prevZ:null,nextZ:null,steiner:!1}}function fo(e,t,n,r){let i=0;for(let a=t,o=n-r;a<n;a+=r)i+=(e[o]-e[a])*(e[a+1]+e[o+1]),o=a;return i}var po=class{static triangulate(e,t,n=2){return Na(e,t,n)}},mo=class e{static area(e){let t=e.length,n=0;for(let r=t-1,i=0;i<t;r=i++)n+=e[r].x*e[i].y-e[i].x*e[r].y;return n*.5}static isClockWise(t){return e.area(t)<0}static triangulateShape(e,t){let n=[],r=[],i=[];ho(e),go(n,e);let a=e.length;t.forEach(ho);for(let e=0;e<t.length;e++)r.push(a),a+=t[e].length,go(n,t[e]);let o=po.triangulate(n,r);for(let e=0;e<o.length;e+=3)i.push(o.slice(e,e+3));return i}};function ho(e){let t=e.length;t>2&&e[t-1].equals(e[0])&&e.pop()}function go(e,t){for(let n=0;n<t.length;n++)e.push(t[n].x),e.push(t[n].y)}var _o=class e extends Ir{constructor(e=new Ma([new I(.5,.5),new I(-.5,.5),new I(-.5,-.5),new I(.5,-.5)]),t={}){super(),this.type=`ExtrudeGeometry`,this.parameters={shapes:e,options:t},e=Array.isArray(e)?e:[e];let n=this,r=[],i=[];for(let t=0,n=e.length;t<n;t++){let n=e[t];a(n)}this.setAttribute(`position`,new wr(r,3)),this.setAttribute(`uv`,new wr(i,2)),this.computeVertexNormals();function a(e){let a=[],o=t.curveSegments===void 0?12:t.curveSegments,s=t.steps===void 0?1:t.steps,c=t.depth===void 0?1:t.depth,l=t.bevelEnabled===void 0||t.bevelEnabled,u=t.bevelThickness===void 0?.2:t.bevelThickness,d=t.bevelSize===void 0?u-.1:t.bevelSize,f=t.bevelOffset===void 0?0:t.bevelOffset,p=t.bevelSegments===void 0?3:t.bevelSegments,m=t.extrudePath,h=t.UVGenerator===void 0?vo:t.UVGenerator,g,_=!1,v,y,b,x;if(m){g=m.getSpacedPoints(s),_=!0,l=!1;let e=m.isCatmullRomCurve3?m.closed:!1;v=m.computeFrenetFrames(s,e),y=new L,b=new L,x=new L}l||(p=0,u=0,d=0,f=0);let S=e.extractPoints(o),C=S.shape,w=S.holes;if(!mo.isClockWise(C)){C=C.reverse();for(let e=0,t=w.length;e<t;e++){let t=w[e];mo.isClockWise(t)&&(w[e]=t.reverse())}}function T(e){let t=e[0];for(let n=1;n<=e.length;n++){let r=n%e.length,i=e[r],a=i.x-t.x,o=i.y-t.y,s=a*a+o*o,c=Math.max(Math.abs(i.x),Math.abs(i.y),Math.abs(t.x),Math.abs(t.y));s<=10000000000000001e-36*c*c?(e.splice(r,1),n--):t=i}}T(C),w.forEach(T);let E=w.length,D=C;for(let e=0;e<E;e++){let t=w[e];C=C.concat(t)}function O(e,t,n){return t||nt(`ExtrudeGeometry: vec does not exist`),e.clone().addScaledVector(t,n)}let k=C.length;function A(e,t,n){let r,i,a,o=e.x-t.x,s=e.y-t.y,c=n.x-e.x,l=n.y-e.y,u=o*o+s*s,d=o*l-s*c;if(Math.abs(d)>2**-52){let d=Math.sqrt(u),f=Math.sqrt(c*c+l*l),p=t.x-s/d,m=t.y+o/d,h=n.x-l/f,g=n.y+c/f,_=((h-p)*l-(g-m)*c)/(o*l-s*c);r=p+o*_-e.x,i=m+s*_-e.y;let v=r*r+i*i;if(v<=2)return new I(r,i);a=Math.sqrt(v/2)}else{let e=!1;o>2**-52?c>2**-52&&(e=!0):o<-(2**-52)?c<-(2**-52)&&(e=!0):Math.sign(s)===Math.sign(l)&&(e=!0),e?(r=-s,i=o,a=Math.sqrt(u)):(r=o,i=s,a=Math.sqrt(u/2))}return new I(r/a,i/a)}let ee=[];for(let e=0,t=D.length,n=t-1,r=e+1;e<t;e++,n++,r++)n===t&&(n=0),r===t&&(r=0),ee[e]=A(D[e],D[n],D[r]);let j=[],te,M=ee.concat();for(let e=0,t=E;e<t;e++){let t=w[e];te=[];for(let e=0,n=t.length,r=n-1,i=e+1;e<n;e++,r++,i++)r===n&&(r=0),i===n&&(i=0),te[e]=A(t[e],t[r],t[i]);j.push(te),M=M.concat(te)}let ne;if(p===0)ne=mo.triangulateShape(D,w);else{let e=[],t=[];for(let n=0;n<p;n++){let r=n/p,i=u*Math.cos(r*Math.PI/2),a=d*Math.sin(r*Math.PI/2)+f;for(let t=0,n=D.length;t<n;t++){let n=O(D[t],ee[t],a);se(n.x,n.y,-i),r===0&&e.push(n)}for(let e=0,n=E;e<n;e++){let n=w[e];te=j[e];let o=[];for(let e=0,t=n.length;e<t;e++){let t=O(n[e],te[e],a);se(t.x,t.y,-i),r===0&&o.push(t)}r===0&&t.push(o)}}ne=mo.triangulateShape(e,t)}let N=ne.length,re=d+f;for(let e=0;e<k;e++){let t=l?O(C[e],M[e],re):C[e];_?(b.copy(v.normals[0]).multiplyScalar(t.x),y.copy(v.binormals[0]).multiplyScalar(t.y),x.copy(g[0]).add(b).add(y),se(x.x,x.y,x.z)):se(t.x,t.y,0)}for(let e=1;e<=s;e++)for(let t=0;t<k;t++){let n=l?O(C[t],M[t],re):C[t];_?(b.copy(v.normals[e]).multiplyScalar(n.x),y.copy(v.binormals[e]).multiplyScalar(n.y),x.copy(g[e]).add(b).add(y),se(x.x,x.y,x.z)):se(n.x,n.y,c/s*e)}for(let e=p-1;e>=0;e--){let t=e/p,n=u*Math.cos(t*Math.PI/2),r=d*Math.sin(t*Math.PI/2)+f;for(let e=0,t=D.length;e<t;e++){let t=O(D[e],ee[e],r);se(t.x,t.y,c+n)}for(let e=0,t=w.length;e<t;e++){let t=w[e];te=j[e];for(let e=0,i=t.length;e<i;e++){let i=O(t[e],te[e],r);_?se(i.x,i.y+g[s-1].y,g[s-1].x+n):se(i.x,i.y,c+n)}}}ie(),ae();function ie(){let e=r.length/3;if(l){let e=0,t=k*e;for(let e=0;e<N;e++){let n=ne[e];ce(n[2]+t,n[1]+t,n[0]+t)}e=s+p*2,t=k*e;for(let e=0;e<N;e++){let n=ne[e];ce(n[0]+t,n[1]+t,n[2]+t)}}else{for(let e=0;e<N;e++){let t=ne[e];ce(t[2],t[1],t[0])}for(let e=0;e<N;e++){let t=ne[e];ce(t[0]+k*s,t[1]+k*s,t[2]+k*s)}}n.addGroup(e,r.length/3-e,0)}function ae(){let e=r.length/3,t=0;oe(D,t),t+=D.length;for(let e=0,n=w.length;e<n;e++){let n=w[e];oe(n,t),t+=n.length}n.addGroup(e,r.length/3-e,1)}function oe(e,t){let n=e.length;for(;--n>=0;){let r=n,i=n-1;i<0&&(i=e.length-1);for(let e=0,n=s+p*2;e<n;e++){let n=k*e,a=k*(e+1);le(t+r+n,t+i+n,t+i+a,t+r+a)}}}function se(e,t,n){a.push(e),a.push(t),a.push(n)}function ce(e,t,i){ue(e),ue(t),ue(i);let a=r.length/3,o=h.generateTopUV(n,r,a-3,a-2,a-1);de(o[0]),de(o[1]),de(o[2])}function le(e,t,i,a){ue(e),ue(t),ue(a),ue(t),ue(i),ue(a);let o=r.length/3,s=h.generateSideWallUV(n,r,o-6,o-3,o-2,o-1);de(s[0]),de(s[1]),de(s[3]),de(s[1]),de(s[2]),de(s[3])}function ue(e){r.push(a[e*3+0]),r.push(a[e*3+1]),r.push(a[e*3+2])}function de(e){i.push(e.x),i.push(e.y)}}}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}toJSON(){let e=super.toJSON(),t=this.parameters.shapes,n=this.parameters.options;return yo(t,n,e)}static fromJSON(t,n){let r=[];for(let e=0,i=t.shapes.length;e<i;e++){let i=n[t.shapes[e]];r.push(i)}let i=t.options.extrudePath;return i!==void 0&&(t.options.extrudePath=new ka[i.type]().fromJSON(i)),new e(r,t.options)}},vo={generateTopUV:function(e,t,n,r,i){let a=t[n*3],o=t[n*3+1],s=t[r*3],c=t[r*3+1],l=t[i*3],u=t[i*3+1];return[new I(a,o),new I(s,c),new I(l,u)]},generateSideWallUV:function(e,t,n,r,i,a){let o=t[n*3],s=t[n*3+1],c=t[n*3+2],l=t[r*3],u=t[r*3+1],d=t[r*3+2],f=t[i*3],p=t[i*3+1],m=t[i*3+2],h=t[a*3],g=t[a*3+1],_=t[a*3+2];return Math.abs(s-u)<Math.abs(o-l)?[new I(o,1-c),new I(l,1-d),new I(f,1-m),new I(h,1-_)]:[new I(s,1-c),new I(u,1-d),new I(p,1-m),new I(g,1-_)]}};function yo(e,t,n){if(n.shapes=[],Array.isArray(e))for(let t=0,r=e.length;t<r;t++){let r=e[t];n.shapes.push(r.uuid)}else n.shapes.push(e.uuid);return n.options=Object.assign({},t),t.extrudePath!==void 0&&(n.options.extrudePath=t.extrudePath.toJSON()),n}var bo=class e extends ta{constructor(e=1,t=0){let n=(1+Math.sqrt(5))/2,r=[-1,n,0,1,n,0,-1,-n,0,1,-n,0,0,-1,n,0,1,n,0,-1,-n,0,1,-n,n,0,-1,n,0,1,-n,0,-1,-n,0,1];super(r,[0,11,5,0,5,1,0,1,7,0,7,10,0,10,11,1,5,9,5,11,4,11,10,2,10,7,6,7,1,8,3,9,4,3,4,2,3,2,6,3,6,8,3,8,9,4,9,5,2,4,11,6,2,10,8,6,7,9,8,1],e,t),this.type=`IcosahedronGeometry`,this.parameters={radius:e,detail:t}}static fromJSON(t){return new e(t.radius,t.detail)}},xo=class e extends Ir{constructor(e=[new I(0,-.5),new I(.5,0),new I(0,.5)],t=12,n=0,r=Math.PI*2){super(),this.type=`LatheGeometry`,this.parameters={points:e,segments:t,phiStart:n,phiLength:r},t=Math.floor(t),r=ft(r,0,Math.PI*2);let i=[],a=[],o=[],s=[],c=[],l=1/t,u=new L,d=new I,f=new L,p=new L,m=new L,h=0,g=0;for(let t=0;t<=e.length-1;t++)switch(t){case 0:h=e[t+1].x-e[t].x,g=e[t+1].y-e[t].y,f.x=g*1,f.y=-h,f.z=g*0,m.copy(f),f.normalize(),s.push(f.x,f.y,f.z);break;case e.length-1:m.normalize(),s.push(m.x,m.y,m.z);break;default:h=e[t+1].x-e[t].x,g=e[t+1].y-e[t].y,f.x=g*1,f.y=-h,f.z=g*0,p.copy(f),f.x+=m.x,f.y+=m.y,f.z+=m.z,f.normalize(),s.push(f.x,f.y,f.z),m.copy(p)}for(let i=0;i<=t;i++){let f=n+i*l*r,p=Math.sin(f),m=Math.cos(f);for(let n=0;n<=e.length-1;n++){u.x=e[n].x*p,u.y=e[n].y,u.z=e[n].x*m,a.push(u.x,u.y,u.z),d.x=i/t,d.y=n/(e.length-1),o.push(d.x,d.y);let r=s[3*n+0]*p,l=s[3*n+1],f=s[3*n+0]*m;c.push(r,l,f)}}for(let n=0;n<t;n++)for(let t=0;t<e.length-1;t++){let r=t+n*e.length,a=r,o=r+e.length,s=r+e.length+1,c=r+1;i.push(a,o,c),i.push(s,c,o)}this.setIndex(i),this.setAttribute(`position`,new wr(a,3)),this.setAttribute(`uv`,new wr(o,2)),this.setAttribute(`normal`,new wr(c,3))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(t){return new e(t.points,t.segments,t.phiStart,t.phiLength)}},So=class e extends Ir{constructor(e=1,t=1,n=1,r=1){super(),this.type=`PlaneGeometry`,this.parameters={width:e,height:t,widthSegments:n,heightSegments:r};let i=e/2,a=t/2,o=Math.floor(n),s=Math.floor(r),c=o+1,l=s+1,u=e/o,d=t/s,f=[],p=[],m=[],h=[];for(let e=0;e<l;e++){let t=e*d-a;for(let n=0;n<c;n++){let r=n*u-i;p.push(r,-t,0),m.push(0,0,1),h.push(n/o),h.push(1-e/s)}}for(let e=0;e<s;e++)for(let t=0;t<o;t++){let n=t+c*e,r=t+c*(e+1),i=t+1+c*(e+1),a=t+1+c*e;f.push(n,r,a),f.push(r,i,a)}this.setIndex(f),this.setAttribute(`position`,new wr(p,3)),this.setAttribute(`normal`,new wr(m,3)),this.setAttribute(`uv`,new wr(h,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(t){return new e(t.width,t.height,t.widthSegments,t.heightSegments)}},Co=class e extends Ir{constructor(e=.5,t=1,n=32,r=1,i=0,a=Math.PI*2){super(),this.type=`RingGeometry`,this.parameters={innerRadius:e,outerRadius:t,thetaSegments:n,phiSegments:r,thetaStart:i,thetaLength:a},n=Math.max(3,n),r=Math.max(1,r);let o=[],s=[],c=[],l=[],u=e,d=(t-e)/r,f=new L,p=new I;for(let e=0;e<=r;e++){for(let e=0;e<=n;e++){let r=i+e/n*a;f.x=u*Math.cos(r),f.y=u*Math.sin(r),s.push(f.x,f.y,f.z),c.push(0,0,1),p.x=(f.x/t+1)/2,p.y=(f.y/t+1)/2,l.push(p.x,p.y)}u+=d}for(let e=0;e<r;e++){let t=e*(n+1);for(let e=0;e<n;e++){let r=e+t,i=r,a=r+n+1,s=r+n+2,c=r+1;o.push(i,a,c),o.push(a,s,c)}}this.setIndex(o),this.setAttribute(`position`,new wr(s,3)),this.setAttribute(`normal`,new wr(c,3)),this.setAttribute(`uv`,new wr(l,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(t){return new e(t.innerRadius,t.outerRadius,t.thetaSegments,t.phiSegments,t.thetaStart,t.thetaLength)}},wo=class e extends Ir{constructor(e=1,t=32,n=16,r=0,i=Math.PI*2,a=0,o=Math.PI){super(),this.type=`SphereGeometry`,this.parameters={radius:e,widthSegments:t,heightSegments:n,phiStart:r,phiLength:i,thetaStart:a,thetaLength:o},t=Math.max(3,Math.floor(t)),n=Math.max(2,Math.floor(n));let s=Math.min(a+o,Math.PI),c=0,l=[],u=new L,d=new L,f=[],p=[],m=[],h=[];for(let f=0;f<=n;f++){let g=[],_=f/n,v=a+_*o,y=e*Math.cos(v),b=Math.sqrt(e*e-y*y),x=0;f===0&&a===0?x=.5/t:f===n&&s===Math.PI&&(x=-.5/t);for(let e=0;e<=t;e++){let n=e/t,a=r+n*i;u.x=-b*Math.cos(a),u.y=y,u.z=b*Math.sin(a),p.push(u.x,u.y,u.z),d.copy(u).normalize(),m.push(d.x,d.y,d.z),h.push(n+x,1-_),g.push(c++)}l.push(g)}for(let e=0;e<n;e++)for(let r=0;r<t;r++){let t=l[e][r+1],i=l[e][r],o=l[e+1][r],c=l[e+1][r+1];(e!==0||a>0)&&f.push(t,i,c),(e!==n-1||s<Math.PI)&&f.push(i,o,c)}this.setIndex(f),this.setAttribute(`position`,new wr(p,3)),this.setAttribute(`normal`,new wr(m,3)),this.setAttribute(`uv`,new wr(h,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(t){return new e(t.radius,t.widthSegments,t.heightSegments,t.phiStart,t.phiLength,t.thetaStart,t.thetaLength)}},To=class e extends Ir{constructor(e=1,t=.4,n=12,r=48,i=Math.PI*2,a=0,o=Math.PI*2){super(),this.type=`TorusGeometry`,this.parameters={radius:e,tube:t,radialSegments:n,tubularSegments:r,arc:i,thetaStart:a,thetaLength:o},n=Math.floor(n),r=Math.floor(r);let s=[],c=[],l=[],u=[],d=new L,f=new L,p=new L;for(let s=0;s<=n;s++){let m=a+s/n*o;for(let a=0;a<=r;a++){let o=a/r*i;f.x=(e+t*Math.cos(m))*Math.cos(o),f.y=(e+t*Math.cos(m))*Math.sin(o),f.z=t*Math.sin(m),c.push(f.x,f.y,f.z),d.x=e*Math.cos(o),d.y=e*Math.sin(o),p.subVectors(f,d).normalize(),l.push(p.x,p.y,p.z),u.push(a/r),u.push(s/n)}}for(let e=1;e<=n;e++)for(let t=1;t<=r;t++){let n=(r+1)*e+t-1,i=(r+1)*(e-1)+t-1,a=(r+1)*(e-1)+t,o=(r+1)*e+t;s.push(n,i,o),s.push(i,a,o)}this.setIndex(s),this.setAttribute(`position`,new wr(c,3)),this.setAttribute(`normal`,new wr(l,3)),this.setAttribute(`uv`,new wr(u,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(t){return new e(t.radius,t.tube,t.radialSegments,t.tubularSegments,t.arc,t.thetaStart,t.thetaLength)}};function Eo(e){let t={};for(let n in e){t[n]={};for(let r in e[n]){let i=e[n][r];if(Oo(i))i.isRenderTargetTexture?(tt(`UniformsUtils: Textures of render targets cannot be cloned via cloneUniforms() or mergeUniforms().`),t[n][r]=null):t[n][r]=i.clone();else if(Array.isArray(i)){if(Oo(i[0])){let e=[];for(let t=0,n=i.length;t<n;t++)e[t]=i[t].clone();t[n][r]=e}else t[n][r]=i.slice()}else t[n][r]=i}}return t}function Do(e){let t={};for(let n=0;n<e.length;n++){let r=Eo(e[n]);for(let e in r)t[e]=r[e]}return t}function Oo(e){return e&&(e.isColor||e.isMatrix3||e.isMatrix4||e.isVector2||e.isVector3||e.isVector4||e.isTexture||e.isQuaternion)}function ko(e){let t=[];for(let n=0;n<e.length;n++)t.push(e[n].clone());return t}function Ao(e){let t=e.getRenderTarget();return t===null?e.outputColorSpace:t.isXRRenderTarget===!0?t.texture.colorSpace:Ut.workingColorSpace}var jo={clone:Eo,merge:Do},Mo=`void main() {
	gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
}`,No=`void main() {
	gl_FragColor = vec4( 1.0, 0.0, 0.0, 1.0 );
}`,Po=class extends Hr{constructor(e){super(),this.isShaderMaterial=!0,this.type=`ShaderMaterial`,this.defines={},this.uniforms={},this.uniformsGroups=[],this.vertexShader=Mo,this.fragmentShader=No,this.linewidth=1,this.wireframe=!1,this.wireframeLinewidth=1,this.fog=!1,this.lights=!1,this.clipping=!1,this.forceSinglePass=!0,this.extensions={clipCullDistance:!1,multiDraw:!1},this.defaultAttributeValues={color:[1,1,1],uv:[0,0],uv1:[0,0]},this.index0AttributeName=void 0,this.uniformsNeedUpdate=!1,this.glslVersion=null,e!==void 0&&this.setValues(e)}copy(e){return super.copy(e),this.fragmentShader=e.fragmentShader,this.vertexShader=e.vertexShader,this.uniforms=Eo(e.uniforms),this.uniformsGroups=ko(e.uniformsGroups),this.defines=Object.assign({},e.defines),this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.fog=e.fog,this.lights=e.lights,this.clipping=e.clipping,this.extensions=Object.assign({},e.extensions),this.glslVersion=e.glslVersion,this.defaultAttributeValues=Object.assign({},e.defaultAttributeValues),this.index0AttributeName=e.index0AttributeName,this.uniformsNeedUpdate=e.uniformsNeedUpdate,this}toJSON(e){let t=super.toJSON(e);t.glslVersion=this.glslVersion,t.uniforms={};for(let n in this.uniforms){let r=this.uniforms[n].value;r&&r.isTexture?t.uniforms[n]={type:`t`,value:r.toJSON(e).uuid}:r&&r.isColor?t.uniforms[n]={type:`c`,value:r.getHex()}:r&&r.isVector2?t.uniforms[n]={type:`v2`,value:r.toArray()}:r&&r.isVector3?t.uniforms[n]={type:`v3`,value:r.toArray()}:r&&r.isVector4?t.uniforms[n]={type:`v4`,value:r.toArray()}:r&&r.isMatrix3?t.uniforms[n]={type:`m3`,value:r.toArray()}:r&&r.isMatrix4?t.uniforms[n]={type:`m4`,value:r.toArray()}:t.uniforms[n]={value:r}}Object.keys(this.defines).length>0&&(t.defines=this.defines),t.vertexShader=this.vertexShader,t.fragmentShader=this.fragmentShader,t.lights=this.lights,t.clipping=this.clipping;let n={};for(let e in this.extensions)this.extensions[e]===!0&&(n[e]=!0);return Object.keys(n).length>0&&(t.extensions=n),t}fromJSON(e,t){if(super.fromJSON(e,t),e.uniforms!==void 0)for(let n in e.uniforms){let r=e.uniforms[n];switch(this.uniforms[n]={},r.type){case`t`:this.uniforms[n].value=t[r.value]||null;break;case`c`:this.uniforms[n].value=new R().setHex(r.value);break;case`v2`:this.uniforms[n].value=new I().fromArray(r.value);break;case`v3`:this.uniforms[n].value=new L().fromArray(r.value);break;case`v4`:this.uniforms[n].value=new en().fromArray(r.value);break;case`m3`:this.uniforms[n].value=new Rt().fromArray(r.value);break;case`m4`:this.uniforms[n].value=new on().fromArray(r.value);break;default:this.uniforms[n].value=r.value}}if(e.defines!==void 0&&(this.defines=e.defines),e.vertexShader!==void 0&&(this.vertexShader=e.vertexShader),e.fragmentShader!==void 0&&(this.fragmentShader=e.fragmentShader),e.glslVersion!==void 0&&(this.glslVersion=e.glslVersion),e.extensions!==void 0)for(let t in e.extensions)this.extensions[t]=e.extensions[t];return e.lights!==void 0&&(this.lights=e.lights),e.clipping!==void 0&&(this.clipping=e.clipping),this}},Fo=class extends Po{constructor(e){super(e),this.isRawShaderMaterial=!0,this.type=`RawShaderMaterial`}},Io=class extends Hr{constructor(e){super(),this.isMeshStandardMaterial=!0,this.type=`MeshStandardMaterial`,this.defines={STANDARD:``},this.color=new R(16777215),this.roughness=1,this.metalness=0,this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.emissive=new R(0),this.emissiveIntensity=1,this.emissiveMap=null,this.bumpMap=null,this.bumpScale=1,this.normalMap=null,this.normalMapType=0,this.normalScale=new I(1,1),this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.roughnessMap=null,this.metalnessMap=null,this.alphaMap=null,this.envMap=null,this.envMapRotation=new gn,this.envMapIntensity=1,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap=`round`,this.wireframeLinejoin=`round`,this.flatShading=!1,this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.defines={STANDARD:``},this.color.copy(e.color),this.roughness=e.roughness,this.metalness=e.metalness,this.map=e.map,this.lightMap=e.lightMap,this.lightMapIntensity=e.lightMapIntensity,this.aoMap=e.aoMap,this.aoMapIntensity=e.aoMapIntensity,this.emissive.copy(e.emissive),this.emissiveMap=e.emissiveMap,this.emissiveIntensity=e.emissiveIntensity,this.bumpMap=e.bumpMap,this.bumpScale=e.bumpScale,this.normalMap=e.normalMap,this.normalMapType=e.normalMapType,this.normalScale.copy(e.normalScale),this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this.roughnessMap=e.roughnessMap,this.metalnessMap=e.metalnessMap,this.alphaMap=e.alphaMap,this.envMap=e.envMap,this.envMapRotation.copy(e.envMapRotation),this.envMapIntensity=e.envMapIntensity,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.wireframeLinecap=e.wireframeLinecap,this.wireframeLinejoin=e.wireframeLinejoin,this.flatShading=e.flatShading,this.fog=e.fog,this}},Lo=class extends Hr{constructor(e){super(),this.isMeshDepthMaterial=!0,this.type=`MeshDepthMaterial`,this.depthPacking=ze,this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.wireframe=!1,this.wireframeLinewidth=1,this.setValues(e)}copy(e){return super.copy(e),this.depthPacking=e.depthPacking,this.map=e.map,this.alphaMap=e.alphaMap,this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this}},Ro=class extends Hr{constructor(e){super(),this.isMeshDistanceMaterial=!0,this.type=`MeshDistanceMaterial`,this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.setValues(e)}copy(e){return super.copy(e),this.map=e.map,this.alphaMap=e.alphaMap,this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this}},zo=class extends Ti{constructor(e){super(),this.isLineDashedMaterial=!0,this.type=`LineDashedMaterial`,this.scale=1,this.dashSize=3,this.gapSize=1,this.setValues(e)}copy(e){return super.copy(e),this.scale=e.scale,this.dashSize=e.dashSize,this.gapSize=e.gapSize,this}};function Bo(e,t){return!e||e.constructor===t?e:typeof t.BYTES_PER_ELEMENT==`number`?new t(e):Array.prototype.slice.call(e)}function Vo(e){return e!==void 0&&e.inTangents!==void 0&&e.outTangents!==void 0}var Ho=class{constructor(e,t,n,r){this.parameterPositions=e,this._cachedIndex=0,this.resultBuffer=r===void 0?new t.constructor(n):r,this.sampleValues=t,this.valueSize=n,this.settings=null,this.DefaultSettings_={}}evaluate(e){let t=this.parameterPositions,n=this._cachedIndex,r=t[n],i=t[n-1];validate_interval:{seek:{let a;linear_scan:{forward_scan:if(!(e<r)){for(let a=n+2;;){if(r===void 0){if(e<i)break forward_scan;return n=t.length,this._cachedIndex=n,this.copySampleValue_(n-1)}if(n===a)break;if(i=r,r=t[++n],e<r)break seek}a=t.length;break linear_scan}if(!(e>=i)){let o=t[1];e<o&&(n=2,i=o);for(let a=n-2;;){if(i===void 0)return this._cachedIndex=0,this.copySampleValue_(0);if(n===a)break;if(r=i,i=t[--n-1],e>=i)break seek}a=n,n=0;break linear_scan}break validate_interval}for(;n<a;){let r=n+a>>>1;e<t[r]?a=r:n=r+1}if(r=t[n],i=t[n-1],i===void 0)return this._cachedIndex=0,this.copySampleValue_(0);if(r===void 0)return n=t.length,this._cachedIndex=n,this.copySampleValue_(n-1)}this._cachedIndex=n,this.intervalChanged_(n,i,r)}return this.interpolate_(n,i,e,r)}getSettings_(){return this.settings||this.DefaultSettings_}copySampleValue_(e){let t=this.resultBuffer,n=this.sampleValues,r=this.valueSize,i=e*r;for(let e=0;e!==r;++e)t[e]=n[i+e];return t}interpolate_(){throw Error(`THREE.Interpolant: Call to abstract method.`)}intervalChanged_(){}},Uo=class extends Ho{constructor(e,t,n,r){super(e,t,n,r),this._weightPrev=-0,this._offsetPrev=-0,this._weightNext=-0,this._offsetNext=-0,this.DefaultSettings_={endingStart:Le,endingEnd:Le}}intervalChanged_(e,t,n){let r=this.parameterPositions,i=e-2,a=e+1,o=r[i],s=r[a];if(o===void 0)switch(this.getSettings_().endingStart){case Re:i=e,o=2*t-n;break;case F:i=r.length-2,o=t+r[i]-r[i+1];break;default:i=e,o=n}if(s===void 0)switch(this.getSettings_().endingEnd){case Re:a=e,s=2*n-t;break;case F:a=1,s=n+r[1]-r[0];break;default:a=e-1,s=t}let c=(n-t)*.5,l=this.valueSize;this._weightPrev=c/(t-o),this._weightNext=c/(s-n),this._offsetPrev=i*l,this._offsetNext=a*l}interpolate_(e,t,n,r){let i=this.resultBuffer,a=this.sampleValues,o=this.valueSize,s=e*o,c=s-o,l=this._offsetPrev,u=this._offsetNext,d=this._weightPrev,f=this._weightNext,p=(n-t)/(r-t),m=p*p,h=m*p,g=-d*h+2*d*m-d*p,_=(1+d)*h+(-1.5-2*d)*m+(-.5+d)*p+1,v=(-1-f)*h+(1.5+f)*m+.5*p,y=f*h-f*m;for(let e=0;e!==o;++e)i[e]=g*a[l+e]+_*a[c+e]+v*a[s+e]+y*a[u+e];return i}},Wo=class extends Ho{constructor(e,t,n,r){super(e,t,n,r)}interpolate_(e,t,n,r){let i=this.resultBuffer,a=this.sampleValues,o=this.valueSize,s=e*o,c=s-o,l=(n-t)/(r-t),u=1-l;for(let e=0;e!==o;++e)i[e]=a[c+e]*u+a[s+e]*l;return i}},Go=class extends Ho{constructor(e,t,n,r){super(e,t,n,r)}interpolate_(e){return this.copySampleValue_(e-1)}},Ko=class extends Ho{interpolate_(e,t,n,r){let i=this.resultBuffer,a=this.sampleValues,o=this.valueSize,s=e*o,c=s-o,l=this.inTangents,u=this.outTangents;if(!l||!u){let e=(n-t)/(r-t),l=1-e;for(let t=0;t!==o;++t)i[t]=a[c+t]*l+a[s+t]*e;return i}let d=o*2,f=e-1;for(let p=0;p!==o;++p){let o=a[c+p],m=a[s+p],h=f*d+p*2,g=u[h],_=u[h+1],v=e*d+p*2,y=l[v],b=l[v+1],x=Yo(n,t,g,y,r);i[p]=qo(x,o,_,b,m)}return i}};function qo(e,t,n,r,i){let a=1-e;return a*a*a*t+3*a*a*e*n+3*a*e*e*r+e*e*e*i}function Jo(e,t,n,r,i){let a=1-e;return 3*a*a*(n-t)+6*a*e*(r-n)+3*e*e*(i-r)}function Yo(e,t,n,r,i){let a=(e-t)/(i-t);for(let o=0;o<8;o++){let o=qo(a,t,n,r,i)-e;if(Math.abs(o)<1e-10)break;let s=Jo(a,t,n,r,i);if(Math.abs(s)<1e-10)break;a=Math.max(0,Math.min(1,a-o/s))}return a}var Xo=class{constructor(e,t,n,r){if(e===void 0)throw Error(`THREE.KeyframeTrack: track name is undefined`);if(t===void 0||t.length===0)throw Error(`THREE.KeyframeTrack: no keyframes in track named `+e);this.name=e,this.times=Bo(t,this.TimeBufferType),this.values=Bo(n,this.ValueBufferType),this.setInterpolation(r||this.DefaultInterpolation)}static toJSON(e){let t=e.constructor,n;if(t.toJSON!==this.toJSON)n=t.toJSON(e);else{n={name:e.name,times:Bo(e.times,Array),values:Bo(e.values,Array)};let t=e.getInterpolation();t!==e.DefaultInterpolation&&(n.interpolation=t),Vo(e.settings)&&(n.settings={inTangents:Bo(e.settings.inTangents,Array),outTangents:Bo(e.settings.outTangents,Array)})}return n.type=e.ValueTypeName,n}InterpolantFactoryMethodDiscrete(e){return new Go(this.times,this.values,this.getValueSize(),e)}InterpolantFactoryMethodLinear(e){return new Wo(this.times,this.values,this.getValueSize(),e)}InterpolantFactoryMethodSmooth(e){return new Uo(this.times,this.values,this.getValueSize(),e)}InterpolantFactoryMethodBezier(e){let t=new Ko(this.times,this.values,this.getValueSize(),e);return this.settings&&(t.inTangents=this.settings.inTangents,t.outTangents=this.settings.outTangents),t}setInterpolation(e){let t;switch(e){case Pe:t=this.InterpolantFactoryMethodDiscrete;break;case Fe:t=this.InterpolantFactoryMethodLinear;break;case P:t=this.InterpolantFactoryMethodSmooth;break;case Ie:t=this.InterpolantFactoryMethodBezier}if(t===void 0){let t=`unsupported interpolation for `+this.ValueTypeName+` keyframe track named `+this.name;if(this.createInterpolant===void 0){if(e!==this.DefaultInterpolation)this.setInterpolation(this.DefaultInterpolation);else throw Error(t)}return tt(`KeyframeTrack:`,t),this}return this.createInterpolant=t,this}getInterpolation(){switch(this.createInterpolant){case this.InterpolantFactoryMethodDiscrete:return Pe;case this.InterpolantFactoryMethodLinear:return Fe;case this.InterpolantFactoryMethodSmooth:return P;case this.InterpolantFactoryMethodBezier:return Ie}}getValueSize(){return this.values.length/this.times.length}shift(e){if(e!==0){let t=this.times;for(let n=0,r=t.length;n!==r;++n)t[n]+=e;Vo(this.settings)&&(Zo(this.settings.inTangents,e),Zo(this.settings.outTangents,e))}return this}scale(e){if(e!==1){let t=this.times;for(let n=0,r=t.length;n!==r;++n)t[n]*=e;Vo(this.settings)&&(Qo(this.settings.inTangents,e),Qo(this.settings.outTangents,e))}return this}trim(e,t){let n=this.times,r=n.length,i=0,a=r-1;for(;i!==r&&n[i]<e;)++i;for(;a!==-1&&n[a]>t;)--a;if(++a,i!==0||a!==r){i>=a&&(a=Math.max(a,1),i=a-1);let e=this.getValueSize();this.times=n.slice(i,a),this.values=this.values.slice(i*e,a*e)}return this}validate(){let e=!0,t=this.getValueSize();t-Math.floor(t)!==0&&(nt(`KeyframeTrack: Invalid value size in track.`,this),e=!1);let n=this.times,r=this.values,i=n.length;i===0&&(nt(`KeyframeTrack: Track is empty.`,this),e=!1);let a=null;for(let t=0;t!==i;t++){let r=n[t];if(typeof r==`number`&&isNaN(r)){nt(`KeyframeTrack: Time is not a valid number.`,this,t,r),e=!1;break}if(a!==null&&a>r){nt(`KeyframeTrack: Out of order keys.`,this,t,r,a),e=!1;break}a=r}if(r!==void 0&&Ye(r))for(let t=0,n=r.length;t!==n;++t){let n=r[t];if(isNaN(n)){nt(`KeyframeTrack: Value is not a valid number.`,this,t,n),e=!1;break}}return e}optimize(){let e=this.times.slice(),t=this.values.slice(),n=this.getValueSize(),r=this.getInterpolation()===P,i=e.length-1,a=1;for(let o=1;o<i;++o){let i=!1,s=e[o];if(s!==e[o+1]&&(o!==1||s!==e[0])){if(r)i=!0;else{let e=o*n,r=e-n,a=e+n;for(let o=0;o!==n;++o){let n=t[e+o];if(n!==t[r+o]||n!==t[a+o]){i=!0;break}}}}if(i){if(o!==a){e[a]=e[o];let r=o*n,i=a*n;for(let e=0;e!==n;++e)t[i+e]=t[r+e]}++a}}if(i>0){e[a]=e[i];for(let e=i*n,r=a*n,o=0;o!==n;++o)t[r+o]=t[e+o];++a}return a===e.length?(this.times=e,this.values=t):(this.times=e.slice(0,a),this.values=t.slice(0,a*n)),this}clone(){let e=this.times.slice(),t=this.values.slice(),n=this.constructor,r=new n(this.name,e,t);return r.createInterpolant=this.createInterpolant,Vo(this.settings)&&(r.settings={inTangents:this.settings.inTangents.slice(),outTangents:this.settings.outTangents.slice()}),r}};function Zo(e,t){for(let n=0,r=e.length;n!==r;n+=2)e[n]+=t}function Qo(e,t){for(let n=0,r=e.length;n!==r;n+=2)e[n]*=t}Xo.prototype.ValueTypeName=``,Xo.prototype.TimeBufferType=Float32Array,Xo.prototype.ValueBufferType=Float32Array,Xo.prototype.DefaultInterpolation=Fe;var $o=class extends Xo{constructor(e,t,n){super(e,t,n)}};$o.prototype.ValueTypeName=`bool`,$o.prototype.ValueBufferType=Array,$o.prototype.DefaultInterpolation=Pe,$o.prototype.InterpolantFactoryMethodLinear=void 0,$o.prototype.InterpolantFactoryMethodSmooth=void 0;var es=class extends Xo{constructor(e,t,n,r){super(e,t,n,r)}};es.prototype.ValueTypeName=`color`;var ts=class extends Xo{constructor(e,t,n,r){super(e,t,n,r)}};ts.prototype.ValueTypeName=`number`;var ns=class extends Ho{constructor(e,t,n,r){super(e,t,n,r)}interpolate_(e,t,n,r){let i=this.resultBuffer,a=this.sampleValues,o=this.valueSize,s=(n-t)/(r-t),c=e*o;for(let e=c+o;c!==e;c+=4)Ft.slerpFlat(i,0,a,c-o,a,c,s);return i}},rs=class extends Xo{constructor(e,t,n,r){super(e,t,n,r)}InterpolantFactoryMethodLinear(e){return new ns(this.times,this.values,this.getValueSize(),e)}};rs.prototype.ValueTypeName=`quaternion`,rs.prototype.InterpolantFactoryMethodSmooth=void 0;var is=class extends Xo{constructor(e,t,n){super(e,t,n)}};is.prototype.ValueTypeName=`string`,is.prototype.ValueBufferType=Array,is.prototype.DefaultInterpolation=Pe,is.prototype.InterpolantFactoryMethodLinear=void 0,is.prototype.InterpolantFactoryMethodSmooth=void 0;var as=class extends Xo{constructor(e,t,n,r){super(e,t,n,r)}};as.prototype.ValueTypeName=`vector`;var os=class extends Nn{static registerNode(e){this.prototype._lightNode=e}constructor(e,t=1){super(),this.isLight=!0,this.type=`Light`,this.color=new R(e),this.intensity=t}copy(e,t){return super.copy(e,t),this.color.copy(e.color),this.intensity=e.intensity,this}toJSON(e){let t=super.toJSON(e);return t.object.color=this.color.getHex(),t.object.intensity=this.intensity,t}},ss=class extends os{constructor(e,t,n){super(e,n),this.isHemisphereLight=!0,this.type=`HemisphereLight`,this.position.copy(Nn.DEFAULT_UP),this.updateMatrix(),this.groundColor=new R(t)}copy(e,t){return super.copy(e,t),this.groundColor.copy(e.groundColor),this}toJSON(e){let t=super.toJSON(e);return t.object.groundColor=this.groundColor.getHex(),t}},cs=new on,ls=new L,us=new L,ds=class{constructor(e){this.camera=e,this.intensity=1,this.bias=0,this.biasNode=null,this.normalBias=0,this.radius=1,this.blurSamples=8,this.mapSize=new I(512,512),this.mapType=l,this.map=null,this.mapPass=null,this.matrix=new on,this.autoUpdate=!0,this.needsUpdate=!1,this._frustum=new Si,this._frameExtents=new I(1,1),this._viewportCount=1,this._viewports=[new en(0,0,1,1)]}getViewportCount(){return this._viewportCount}getCamera(){return this.camera}getFrustum(){return this._frustum}updateMatrices(e){let t=this.camera;ls.setFromMatrixPosition(e.matrixWorld),t.position.copy(ls),us.setFromMatrixPosition(e.target.matrixWorld),t.lookAt(us),t.updateMatrixWorld(),this._updateMatrix(t,this.matrix,this._frustum)}_updateMatrix(e,t,n,r){cs.multiplyMatrices(e.projectionMatrix,e.matrixWorldInverse),n.setFromProjectionMatrix(cs,e.coordinateSystem,e.reversedDepth);let i=this._frameExtents,a=r?r.z/i.x:1,o=r?r.w/i.y:1,s=r?r.x/i.x:0,c=r?r.y/i.y:0;e.coordinateSystem===2001||e.reversedDepth?t.set(.5*a,0,0,.5*a+s,0,.5*o,0,.5*o+c,0,0,1,0,0,0,0,1):t.set(.5*a,0,0,.5*a+s,0,.5*o,0,.5*o+c,0,0,.5,.5,0,0,0,1),t.multiply(cs)}getViewport(e){return this._viewports[e]}getFrameExtents(){return this._frameExtents}dispose(){this.map&&this.map.dispose(),this.mapPass&&this.mapPass.dispose()}copy(e){return this.camera=e.camera.clone(),this.intensity=e.intensity,this.bias=e.bias,this.radius=e.radius,this.autoUpdate=e.autoUpdate,this.needsUpdate=e.needsUpdate,this.normalBias=e.normalBias,this.blurSamples=e.blurSamples,this.mapSize.copy(e.mapSize),this.mapType=e.mapType,this.biasNode=e.biasNode,this}clone(){return new this.constructor().copy(this)}toJSON(){let e={};return e.intensity=this.intensity,e.bias=this.bias,e.normalBias=this.normalBias,e.radius=this.radius,e.blurSamples=this.blurSamples,e.mapSize=this.mapSize.toArray(),e.mapType=this.mapType,e.camera=this.camera.toJSON(!1).object,delete e.camera.matrix,e}},fs=new L,ps=new Ft,ms=new L,hs=class extends Nn{constructor(){super(),this.isCamera=!0,this.type=`Camera`,this.matrixWorldInverse=new on,this.projectionMatrix=new on,this.projectionMatrixInverse=new on,this.coordinateSystem=qe,this._reversedDepth=!1}get reversedDepth(){return this._reversedDepth}copy(e,t){return super.copy(e,t),this.matrixWorldInverse.copy(e.matrixWorldInverse),this.projectionMatrix.copy(e.projectionMatrix),this.projectionMatrixInverse.copy(e.projectionMatrixInverse),this.coordinateSystem=e.coordinateSystem,this}getWorldDirection(e){return super.getWorldDirection(e).negate()}updateMatrixWorld(e){super.updateMatrixWorld(e),this.matrixWorld.decompose(fs,ps,ms),ms.x===1&&ms.y===1&&ms.z===1?this.matrixWorldInverse.copy(this.matrixWorld).invert():this.matrixWorldInverse.compose(fs,ps,ms.set(1,1,1)).invert()}updateWorldMatrix(e,t,n=!1){super.updateWorldMatrix(e,t,n),this.matrixWorld.decompose(fs,ps,ms),ms.x===1&&ms.y===1&&ms.z===1?this.matrixWorldInverse.copy(this.matrixWorld).invert():this.matrixWorldInverse.compose(fs,ps,ms.set(1,1,1)).invert()}clone(){return new this.constructor().copy(this)}},gs=new L,_s=new I,vs=new I,ys=class extends hs{constructor(e=50,t=1,n=.1,r=2e3){super(),this.isPerspectiveCamera=!0,this.type=`PerspectiveCamera`,this.fov=e,this.zoom=1,this.near=n,this.far=r,this.focus=10,this.aspect=t,this.view=null,this.filmGauge=35,this.filmOffset=0,this.updateProjectionMatrix()}copy(e,t){return super.copy(e,t),this.fov=e.fov,this.zoom=e.zoom,this.near=e.near,this.far=e.far,this.focus=e.focus,this.aspect=e.aspect,this.view=e.view===null?null:Object.assign({},e.view),this.filmGauge=e.filmGauge,this.filmOffset=e.filmOffset,this}setFocalLength(e){let t=.5*this.getFilmHeight()/e;this.fov=ut*2*Math.atan(t),this.updateProjectionMatrix()}getFocalLength(){let e=Math.tan(lt*.5*this.fov);return .5*this.getFilmHeight()/e}getEffectiveFOV(){return ut*2*Math.atan(Math.tan(lt*.5*this.fov)/this.zoom)}getFilmWidth(){return this.filmGauge*Math.min(this.aspect,1)}getFilmHeight(){return this.filmGauge/Math.max(this.aspect,1)}getViewBounds(e,t,n){gs.set(-1,-1,.5).applyMatrix4(this.projectionMatrixInverse),t.set(gs.x,gs.y).multiplyScalar(-e/gs.z),gs.set(1,1,.5).applyMatrix4(this.projectionMatrixInverse),n.set(gs.x,gs.y).multiplyScalar(-e/gs.z)}getViewSize(e,t){return this.getViewBounds(e,_s,vs),t.subVectors(vs,_s)}setViewOffset(e,t,n,r,i,a){this.aspect=e/t,this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=e,this.view.fullHeight=t,this.view.offsetX=n,this.view.offsetY=r,this.view.width=i,this.view.height=a,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){let e=this.near,t=e*Math.tan(lt*.5*this.fov)/this.zoom,n=2*t,r=this.aspect*n,i=-.5*r,a=this.view;if(this.view!==null&&this.view.enabled){let e=a.fullWidth,o=a.fullHeight;i+=a.offsetX*r/e,t-=a.offsetY*n/o,r*=a.width/e,n*=a.height/o}let o=this.filmOffset;o!==0&&(i+=e*o/this.getFilmWidth()),this.projectionMatrix.makePerspective(i,i+r,t,t-n,e,this.far,this.coordinateSystem,this.reversedDepth),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(e){let t=super.toJSON(e);return t.object.fov=this.fov,t.object.zoom=this.zoom,t.object.near=this.near,t.object.far=this.far,t.object.focus=this.focus,t.object.aspect=this.aspect,this.view!==null&&(t.object.view=Object.assign({},this.view)),t.object.filmGauge=this.filmGauge,t.object.filmOffset=this.filmOffset,t}},bs=class extends ds{constructor(){super(new ys(90,1,.5,500)),this.isPointLightShadow=!0}},xs=class extends os{constructor(e,t,n=0,r=2){super(e,t),this.isPointLight=!0,this.type=`PointLight`,this.distance=n,this.decay=r,this.shadow=new bs}get power(){return this.intensity*4*Math.PI}set power(e){this.intensity=e/(4*Math.PI)}dispose(){super.dispose(),this.shadow.dispose()}copy(e,t){return super.copy(e,t),this.distance=e.distance,this.decay=e.decay,this.shadow=e.shadow.clone(),this}toJSON(e){let t=super.toJSON(e);return t.object.distance=this.distance,t.object.decay=this.decay,t.object.shadow=this.shadow.toJSON(),t}},Ss=class extends hs{constructor(e=-1,t=1,n=1,r=-1,i=.1,a=2e3){super(),this.isOrthographicCamera=!0,this.type=`OrthographicCamera`,this.zoom=1,this.view=null,this.left=e,this.right=t,this.top=n,this.bottom=r,this.near=i,this.far=a,this.updateProjectionMatrix()}copy(e,t){return super.copy(e,t),this.left=e.left,this.right=e.right,this.top=e.top,this.bottom=e.bottom,this.near=e.near,this.far=e.far,this.zoom=e.zoom,this.view=e.view===null?null:Object.assign({},e.view),this}setViewOffset(e,t,n,r,i,a){this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=e,this.view.fullHeight=t,this.view.offsetX=n,this.view.offsetY=r,this.view.width=i,this.view.height=a,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){let e=(this.right-this.left)/(2*this.zoom),t=(this.top-this.bottom)/(2*this.zoom),n=(this.right+this.left)/2,r=(this.top+this.bottom)/2,i=n-e,a=n+e,o=r+t,s=r-t;if(this.view!==null&&this.view.enabled){let e=(this.right-this.left)/this.view.fullWidth/this.zoom,t=(this.top-this.bottom)/this.view.fullHeight/this.zoom;i+=e*this.view.offsetX,a=i+e*this.view.width,o-=t*this.view.offsetY,s=o-t*this.view.height}this.projectionMatrix.makeOrthographic(i,a,o,s,this.near,this.far,this.coordinateSystem,this.reversedDepth),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(e){let t=super.toJSON(e);return t.object.zoom=this.zoom,t.object.left=this.left,t.object.right=this.right,t.object.top=this.top,t.object.bottom=this.bottom,t.object.near=this.near,t.object.far=this.far,this.view!==null&&(t.object.view=Object.assign({},this.view)),t}},Cs=class extends ds{constructor(){super(new Ss(-5,5,5,-5,.5,500)),this.isDirectionalLightShadow=!0}},ws=class extends os{constructor(e,t){super(e,t),this.isDirectionalLight=!0,this.type=`DirectionalLight`,this.position.copy(Nn.DEFAULT_UP),this.updateMatrix(),this.target=new Nn,this.shadow=new Cs}dispose(){super.dispose(),this.shadow.dispose()}copy(e){return super.copy(e),this.target=e.target.clone(),this.shadow=e.shadow.clone(),this}toJSON(e){let t=super.toJSON(e);return t.object.shadow=this.shadow.toJSON(),t.object.target=this.target.uuid,t}},Ts=class extends os{constructor(e,t){super(e,t),this.isAmbientLight=!0,this.type=`AmbientLight`}},Es=-90,Ds=1,Os=class extends Nn{constructor(e,t,n){super(),this.type=`CubeCamera`,this.renderTarget=n,this.coordinateSystem=null,this.activeMipmapLevel=0;let r=new ys(Es,Ds,e,t);r.layers=this.layers,this.add(r);let i=new ys(Es,Ds,e,t);i.layers=this.layers,this.add(i);let a=new ys(Es,Ds,e,t);a.layers=this.layers,this.add(a);let o=new ys(Es,Ds,e,t);o.layers=this.layers,this.add(o);let s=new ys(Es,Ds,e,t);s.layers=this.layers,this.add(s);let c=new ys(Es,Ds,e,t);c.layers=this.layers,this.add(c)}updateCoordinateSystem(){let e=this.coordinateSystem,t=this.children.concat(),[n,r,i,a,o,s]=t;for(let e of t)this.remove(e);if(e===2e3)n.up.set(0,1,0),n.lookAt(1,0,0),r.up.set(0,1,0),r.lookAt(-1,0,0),i.up.set(0,0,-1),i.lookAt(0,1,0),a.up.set(0,0,1),a.lookAt(0,-1,0),o.up.set(0,1,0),o.lookAt(0,0,1),s.up.set(0,1,0),s.lookAt(0,0,-1);else if(e===2001)n.up.set(0,-1,0),n.lookAt(-1,0,0),r.up.set(0,-1,0),r.lookAt(1,0,0),i.up.set(0,0,1),i.lookAt(0,1,0),a.up.set(0,0,-1),a.lookAt(0,-1,0),o.up.set(0,-1,0),o.lookAt(0,0,1),s.up.set(0,-1,0),s.lookAt(0,0,-1);else throw Error(`THREE.CubeCamera.updateCoordinateSystem(): Invalid coordinate system: `+e);for(let e of t)this.add(e),e.updateMatrixWorld()}update(e,t){this.parent===null&&this.updateMatrixWorld();let{renderTarget:n,activeMipmapLevel:r}=this;this.coordinateSystem!==e.coordinateSystem&&(this.coordinateSystem=e.coordinateSystem,this.updateCoordinateSystem());let[i,a,o,s,c,l]=this.children,u=e.getRenderTarget(),d=e.getActiveCubeFace(),f=e.getActiveMipmapLevel(),p=e.xr.enabled;e.xr.enabled=!1;let m=n.texture.mipmapsAutoUpdate;n.texture.mipmapsAutoUpdate=!1;let h=!1;h=e.isWebGLRenderer===!0?e.state.buffers.depth.getReversed():e.reversedDepthBuffer,e.setRenderTarget(n,0,r),h&&e.autoClear===!1&&e.clearDepth(),e.render(t,i),e.setRenderTarget(n,1,r),h&&e.autoClear===!1&&e.clearDepth(),e.render(t,a),e.setRenderTarget(n,2,r),h&&e.autoClear===!1&&e.clearDepth(),e.render(t,o),e.setRenderTarget(n,3,r),h&&e.autoClear===!1&&e.clearDepth(),e.render(t,s),e.setRenderTarget(n,4,r),h&&e.autoClear===!1&&e.clearDepth(),e.render(t,c),n.texture.mipmapsAutoUpdate=m,e.setRenderTarget(n,5,r),h&&e.autoClear===!1&&e.clearDepth(),e.render(t,l),e.setRenderTarget(u,d,f),e.xr.enabled=p,n.texture.needsPMREMUpdate=!0}},ks=class extends ys{constructor(e=[]){super(),this.isArrayCamera=!0,this.isMultiViewCamera=!1,this.cameras=e,this.perCameraFrustumCulled=!1}},As=class{constructor(){this._previousTime=0,this._currentTime=0,this._startTime=performance.now(),this._delta=0,this._elapsed=0,this._timescale=1,this._document=null,this._pageVisibilityHandler=null}connect(e){this._document=e,e.hidden!==void 0&&(this._pageVisibilityHandler=js.bind(this),e.addEventListener(`visibilitychange`,this._pageVisibilityHandler,!1))}disconnect(){this._pageVisibilityHandler!==null&&(this._document.removeEventListener(`visibilitychange`,this._pageVisibilityHandler),this._pageVisibilityHandler=null),this._document=null}getDelta(){return this._delta/1e3}getElapsed(){return this._elapsed/1e3}getTimescale(){return this._timescale}setTimescale(e){return this._timescale=e,this}reset(){return this._currentTime=performance.now()-this._startTime,this}dispose(){this.disconnect()}update(e){return this._pageVisibilityHandler!==null&&this._document.hidden===!0?this._delta=0:(this._previousTime=this._currentTime,this._currentTime=(e===void 0?performance.now():e)-this._startTime,this._delta=(this._currentTime-this._previousTime)*this._timescale,this._elapsed+=this._delta),this}};function js(){this._document.hidden===!1&&this.reset()}var Ms=`\\[\\]\\.:\\/`,Ns=RegExp(`[\\[\\]\\.:\\/]`,`g`),Ps=`[^\\[\\]\\.:\\/]`,Fs=`[^`+Ms.replace(`\\.`,``)+`]`,Is=`((?:WC+[\\/:])*)`.replace(`WC`,Ps),Ls=`(WCOD+)?`.replace(`WCOD`,Fs),Rs=`(?:\\.(WC+)(?:\\[(.+)\\])?)?`.replace(`WC`,Ps),zs=`\\.(WC+)(?:\\[(.+)\\])?`.replace(`WC`,Ps),Bs=RegExp(`^`+Is+Ls+Rs+zs+`$`),Vs=[`material`,`materials`,`bones`,`map`],Hs=class{constructor(e,t,n){let r=n||Us.parseTrackName(t);this._targetGroup=e,this._bindings=e.subscribe_(t,r)}getValue(e,t){this.bind();let n=this._targetGroup.nCachedObjects_,r=this._bindings[n];r!==void 0&&r.getValue(e,t)}setValue(e,t){let n=this._bindings;for(let r=this._targetGroup.nCachedObjects_,i=n.length;r!==i;++r)n[r].setValue(e,t)}bind(){let e=this._bindings;for(let t=this._targetGroup.nCachedObjects_,n=e.length;t!==n;++t)e[t].bind()}unbind(){let e=this._bindings;for(let t=this._targetGroup.nCachedObjects_,n=e.length;t!==n;++t)e[t].unbind()}},Us=class e{constructor(t,n,r){this.path=n,this.parsedPath=r||e.parseTrackName(n),this.node=e.findNode(t,this.parsedPath.nodeName),this.rootNode=t,this.getValue=this._getValue_unbound,this.setValue=this._setValue_unbound}static create(t,n,r){return t&&t.isAnimationObjectGroup?new e.Composite(t,n,r):new e(t,n,r)}static sanitizeNodeName(e){return e.replace(/\s/g,`_`).replace(Ns,``)}static parseTrackName(e){let t=Bs.exec(e);if(t===null)throw Error(`THREE.PropertyBinding: Cannot parse trackName: `+e);let n={nodeName:t[2],objectName:t[3],objectIndex:t[4],propertyName:t[5],propertyIndex:t[6]},r=n.nodeName&&n.nodeName.lastIndexOf(`.`);if(r!==void 0&&r!==-1){let e=n.nodeName.substring(r+1);Vs.indexOf(e)!==-1&&(n.nodeName=n.nodeName.substring(0,r),n.objectName=e)}if(n.propertyName===null||n.propertyName.length===0)throw Error(`THREE.PropertyBinding: can not parse propertyName from trackName: `+e);return n}static findNode(e,t){if(t===void 0||t===``||t===`.`||t===-1||t===e.name||t===e.uuid)return e;if(e.skeleton){let n=e.skeleton.getBoneByName(t);if(n!==void 0)return n}if(e.children){let n=function(e){for(let r=0;r<e.length;r++){let i=e[r];if(i.name===t||i.uuid===t)return i;let a=n(i.children);if(a)return a}return null},r=n(e.children);if(r)return r}return null}_getValue_unavailable(){}_setValue_unavailable(){}_getValue_direct(e,t){e[t]=this.targetObject[this.propertyName]}_getValue_array(e,t){let n=this.resolvedProperty;for(let r=0,i=n.length;r!==i;++r)e[t++]=n[r]}_getValue_arrayElement(e,t){e[t]=this.resolvedProperty[this.propertyIndex]}_getValue_toArray(e,t){this.resolvedProperty.toArray(e,t)}_setValue_direct(e,t){this.targetObject[this.propertyName]=e[t]}_setValue_direct_setNeedsUpdate(e,t){this.targetObject[this.propertyName]=e[t],this.targetObject.needsUpdate=!0}_setValue_direct_setMatrixWorldNeedsUpdate(e,t){this.targetObject[this.propertyName]=e[t],this.targetObject.matrixWorldNeedsUpdate=!0}_setValue_array(e,t){let n=this.resolvedProperty;for(let r=0,i=n.length;r!==i;++r)n[r]=e[t++]}_setValue_array_setNeedsUpdate(e,t){let n=this.resolvedProperty;for(let r=0,i=n.length;r!==i;++r)n[r]=e[t++];this.targetObject.needsUpdate=!0}_setValue_array_setMatrixWorldNeedsUpdate(e,t){let n=this.resolvedProperty;for(let r=0,i=n.length;r!==i;++r)n[r]=e[t++];this.targetObject.matrixWorldNeedsUpdate=!0}_setValue_arrayElement(e,t){this.resolvedProperty[this.propertyIndex]=e[t]}_setValue_arrayElement_setNeedsUpdate(e,t){this.resolvedProperty[this.propertyIndex]=e[t],this.targetObject.needsUpdate=!0}_setValue_arrayElement_setMatrixWorldNeedsUpdate(e,t){this.resolvedProperty[this.propertyIndex]=e[t],this.targetObject.matrixWorldNeedsUpdate=!0}_setValue_fromArray(e,t){this.resolvedProperty.fromArray(e,t)}_setValue_fromArray_setNeedsUpdate(e,t){this.resolvedProperty.fromArray(e,t),this.targetObject.needsUpdate=!0}_setValue_fromArray_setMatrixWorldNeedsUpdate(e,t){this.resolvedProperty.fromArray(e,t),this.targetObject.matrixWorldNeedsUpdate=!0}_getValue_unbound(e,t){this.bind(),this.getValue(e,t)}_setValue_unbound(e,t){this.bind(),this.setValue(e,t)}bind(){let t=this.node,n=this.parsedPath,r=n.objectName,i=n.propertyName,a=n.propertyIndex;if(t||(t=e.findNode(this.rootNode,n.nodeName),this.node=t),this.getValue=this._getValue_unavailable,this.setValue=this._setValue_unavailable,!t){tt(`PropertyBinding: No target node found for track: `+this.path+`.`);return}if(r){let e=n.objectIndex;switch(r){case`materials`:if(!t.material){nt(`PropertyBinding: Can not bind to material as node does not have a material.`,this);return}if(!t.material.materials){nt(`PropertyBinding: Can not bind to material.materials as node.material does not have a materials array.`,this);return}t=t.material.materials;break;case`bones`:if(!t.skeleton){nt(`PropertyBinding: Can not bind to bones as node does not have a skeleton.`,this);return}t=t.skeleton.bones;for(let n=0;n<t.length;n++)if(t[n].name===e){e=n;break}break;case`map`:if(`map`in t){t=t.map;break}if(!t.material){nt(`PropertyBinding: Can not bind to material as node does not have a material.`,this);return}if(!t.material.map){nt(`PropertyBinding: Can not bind to material.map as node.material does not have a map.`,this);return}t=t.material.map;break;default:if(t[r]===void 0){nt(`PropertyBinding: Can not bind to objectName of node undefined.`,this);return}t=t[r]}if(e!==void 0){if(t[e]===void 0){nt(`PropertyBinding: Trying to bind to objectIndex of objectName, but is undefined.`,this,t);return}t=t[e]}}let o=t[i];if(o===void 0){let e=n.nodeName;nt(`PropertyBinding: Trying to update property for track: `+e+`.`+i+` but it wasn't found.`,t);return}let s=this.Versioning.None;this.targetObject=t,t.isMaterial===!0?s=this.Versioning.NeedsUpdate:t.isObject3D===!0&&(s=this.Versioning.MatrixWorldNeedsUpdate);let c=this.BindingType.Direct;if(a!==void 0){if(i===`morphTargetInfluences`){if(!t.geometry){nt(`PropertyBinding: Can not bind to morphTargetInfluences because node does not have a geometry.`,this);return}if(!t.geometry.morphAttributes){nt(`PropertyBinding: Can not bind to morphTargetInfluences because node does not have a geometry.morphAttributes.`,this);return}t.morphTargetDictionary[a]!==void 0&&(a=t.morphTargetDictionary[a])}c=this.BindingType.ArrayElement,this.resolvedProperty=o,this.propertyIndex=a}else o.fromArray!==void 0&&o.toArray!==void 0?(c=this.BindingType.HasFromToArray,this.resolvedProperty=o):Array.isArray(o)?(c=this.BindingType.EntireArray,this.resolvedProperty=o):this.propertyName=i;this.getValue=this.GetterByBindingType[c],this.setValue=this.SetterByBindingTypeAndVersioning[c][s]}unbind(){this.node=null,this.getValue=this._getValue_unbound,this.setValue=this._setValue_unbound}};Us.Composite=Hs,Us.prototype.BindingType={Direct:0,EntireArray:1,ArrayElement:2,HasFromToArray:3},Us.prototype.Versioning={None:0,NeedsUpdate:1,MatrixWorldNeedsUpdate:2},Us.prototype.GetterByBindingType=[Us.prototype._getValue_direct,Us.prototype._getValue_array,Us.prototype._getValue_arrayElement,Us.prototype._getValue_toArray],Us.prototype.SetterByBindingTypeAndVersioning=[[Us.prototype._setValue_direct,Us.prototype._setValue_direct_setNeedsUpdate,Us.prototype._setValue_direct_setMatrixWorldNeedsUpdate],[Us.prototype._setValue_array,Us.prototype._setValue_array_setNeedsUpdate,Us.prototype._setValue_array_setMatrixWorldNeedsUpdate],[Us.prototype._setValue_arrayElement,Us.prototype._setValue_arrayElement_setNeedsUpdate,Us.prototype._setValue_arrayElement_setMatrixWorldNeedsUpdate],[Us.prototype._setValue_fromArray,Us.prototype._setValue_fromArray_setNeedsUpdate,Us.prototype._setValue_fromArray_setMatrixWorldNeedsUpdate]];var Ws=new on,Gs=class{constructor(e,t,n=0,r=1/0){this.ray=new qr(e,t),this.near=n,this.far=r,this.camera=null,this.layers=new _n,this.params={Mesh:{},Line:{threshold:1},LOD:{},Points:{threshold:1},Sprite:{}}}set(e,t){this.ray.set(e,t)}setFromCamera(e,t){t.isPerspectiveCamera?(this.ray.origin.setFromMatrixPosition(t.matrixWorld),this.ray.direction.set(e.x,e.y,.5).unproject(t).sub(this.ray.origin).normalize(),this.camera=t):t.isOrthographicCamera?(this.ray.origin.set(e.x,e.y,t.projectionMatrix.elements[14]).unproject(t),this.ray.direction.set(0,0,-1).transformDirection(t.matrixWorld),this.camera=t):nt(`Raycaster: Unsupported camera type: `+t.type)}setFromXRController(e){return Ws.identity().extractRotation(e.matrixWorld),this.ray.origin.setFromMatrixPosition(e.matrixWorld),this.ray.direction.set(0,0,-1).applyMatrix4(Ws),this}intersectObject(e,t=!0,n=[]){return qs(e,this,n,t),n.sort(Ks),n}intersectObjects(e,t=!0,n=[]){for(let r=0,i=e.length;r<i;r++)qs(e[r],this,n,t);return n.sort(Ks),n}};function Ks(e,t){return e.distance-t.distance}function qs(e,t,n,r){let i=!0;if(e.layers.test(t.layers)&&e.raycast(t,n)===!1&&(i=!1),i===!0&&r===!0){let r=e.children;for(let e=0,i=r.length;e<i;e++)qs(r[e],t,n,!0)}}(class{static{this.prototype.isMatrix2=!0}constructor(e,t,n,r){this.elements=[1,0,0,1],e!==void 0&&this.set(e,t,n,r)}identity(){return this.set(1,0,0,1),this}fromArray(e,t=0){for(let n=0;n<4;n++)this.elements[n]=e[n+t];return this}set(e,t,n,r){let i=this.elements;return i[0]=e,i[2]=t,i[1]=n,i[3]=r,this}});function Js(e,t,n,r){let i=Ys(r);switch(n){case S:return e*t;case D:return e*t/i.components*i.byteLength;case O:return e*t/i.components*i.byteLength;case k:return e*t*2/i.components*i.byteLength;case A:return e*t*2/i.components*i.byteLength;case C:return e*t*3/i.components*i.byteLength;case w:return e*t*4/i.components*i.byteLength;case ee:return e*t*4/i.components*i.byteLength;case j:case te:return Math.floor((e+3)/4)*Math.floor((t+3)/4)*8;case M:case ne:return Math.floor((e+3)/4)*Math.floor((t+3)/4)*16;case re:case ae:return Math.max(e,16)*Math.max(t,8)/4;case N:case ie:return Math.max(e,8)*Math.max(t,8)/2;case oe:case se:case le:case ue:return Math.floor((e+3)/4)*Math.floor((t+3)/4)*8;case ce:case de:case fe:return Math.floor((e+3)/4)*Math.floor((t+3)/4)*16;case pe:return Math.floor((e+3)/4)*Math.floor((t+3)/4)*16;case me:return Math.floor((e+4)/5)*Math.floor((t+3)/4)*16;case he:return Math.floor((e+4)/5)*Math.floor((t+4)/5)*16;case ge:return Math.floor((e+5)/6)*Math.floor((t+4)/5)*16;case _e:return Math.floor((e+5)/6)*Math.floor((t+5)/6)*16;case ve:return Math.floor((e+7)/8)*Math.floor((t+4)/5)*16;case ye:return Math.floor((e+7)/8)*Math.floor((t+5)/6)*16;case be:return Math.floor((e+7)/8)*Math.floor((t+7)/8)*16;case xe:return Math.floor((e+9)/10)*Math.floor((t+4)/5)*16;case Se:return Math.floor((e+9)/10)*Math.floor((t+5)/6)*16;case Ce:return Math.floor((e+9)/10)*Math.floor((t+7)/8)*16;case we:return Math.floor((e+9)/10)*Math.floor((t+9)/10)*16;case Te:return Math.floor((e+11)/12)*Math.floor((t+9)/10)*16;case Ee:return Math.floor((e+11)/12)*Math.floor((t+11)/12)*16;case De:case Oe:case ke:return Math.ceil(e/4)*Math.ceil(t/4)*16;case Ae:case je:return Math.ceil(e/4)*Math.ceil(t/4)*8;case Me:case Ne:return Math.ceil(e/4)*Math.ceil(t/4)*16}throw Error(`Unable to determine texture byte length for ${n} format.`)}function Ys(e){switch(e){case l:case u:return{byteLength:1,components:1};case f:case d:case g:return{byteLength:2,components:1};case _:case v:return{byteLength:2,components:4};case m:case p:case h:return{byteLength:4,components:1};case b:case x:return{byteLength:4,components:3}}throw Error(`THREE.TextureUtils: Unknown texture type ${e}.`)}typeof __THREE_DEVTOOLS__<`u`&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent(`register`,{detail:{revision:`187`}})),typeof window<`u`&&(window.__THREE__?tt(`WARNING: Multiple instances of Three.js being imported.`):window.__THREE__=`187`);function Xs(){let e=null,t=!1,n=null,r=null;function i(t,a){r=e.requestAnimationFrame(i),n(t,a)}return{start:function(){t!==!0&&n!==null&&e!==null&&(r=e.requestAnimationFrame(i),t=!0)},stop:function(){e!==null&&e.cancelAnimationFrame(r),t=!1},setAnimationLoop:function(e){n=e},setContext:function(t){e=t}}}function Zs(e){let t=new WeakMap;function n(t,n){let r=t.array,i=t.usage,a=r.byteLength,o=e.createBuffer();e.bindBuffer(n,o),e.bufferData(n,r,i),t.onUploadCallback();let s;if(r instanceof Float32Array)s=e.FLOAT;else if(typeof Float16Array<`u`&&r instanceof Float16Array)s=e.HALF_FLOAT;else if(r instanceof Uint16Array)s=t.isFloat16BufferAttribute?e.HALF_FLOAT:e.UNSIGNED_SHORT;else if(r instanceof Int16Array)s=e.SHORT;else if(r instanceof Uint32Array)s=e.UNSIGNED_INT;else if(r instanceof Int32Array)s=e.INT;else if(r instanceof Int8Array)s=e.BYTE;else if(r instanceof Uint8Array)s=e.UNSIGNED_BYTE;else if(r instanceof Uint8ClampedArray)s=e.UNSIGNED_BYTE;else throw Error(`THREE.WebGLAttributes: Unsupported buffer data format: `+r);return{buffer:o,type:s,bytesPerElement:r.BYTES_PER_ELEMENT,version:t.version,size:a}}function r(t,n,r){let i=n.array,a=n.updateRanges;if(e.bindBuffer(r,t),a.length===0)e.bufferSubData(r,0,i);else{a.sort((e,t)=>e.start-t.start);let t=0;for(let e=1;e<a.length;e++){let n=a[t],r=a[e];r.start<=n.start+n.count+1?n.count=Math.max(n.count,r.start+r.count-n.start):(++t,a[t]=r)}a.length=t+1;for(let t=0,n=a.length;t<n;t++){let n=a[t];e.bufferSubData(r,n.start*i.BYTES_PER_ELEMENT,i,n.start,n.count)}n.clearUpdateRanges()}n.onUploadCallback()}function i(e){return e.isInterleavedBufferAttribute&&(e=e.data),t.get(e)}function a(n){n.isInterleavedBufferAttribute&&(n=n.data);let r=t.get(n);r&&(e.deleteBuffer(r.buffer),t.delete(n))}function o(e,i){if(e.isInterleavedBufferAttribute&&(e=e.data),e.isGLBufferAttribute){let n=t.get(e);(!n||n.version<e.version)&&t.set(e,{buffer:e.buffer,type:e.type,bytesPerElement:e.elementSize,version:e.version});return}let a=t.get(e);if(a===void 0)t.set(e,n(e,i));else if(a.version<e.version){if(a.size!==e.array.byteLength)throw Error(`THREE.WebGLAttributes: The size of the buffer attribute's array buffer does not match the original size. Resizing buffer attributes is not supported.`);r(a.buffer,e,i),a.version=e.version}}return{get:i,remove:a,update:o}}var Qs={alphahash_fragment:`#ifdef USE_ALPHAHASH
	if ( diffuseColor.a < getAlphaHashThreshold( vPosition ) ) discard;
#endif`,alphahash_pars_fragment:`#ifdef USE_ALPHAHASH
	const float ALPHA_HASH_SCALE = 0.05;
	float hash2D( vec2 value ) {
		return fract( 1.0e4 * sin( 17.0 * value.x + 0.1 * value.y ) * ( 0.1 + abs( sin( 13.0 * value.y + value.x ) ) ) );
	}
	float hash3D( vec3 value ) {
		return hash2D( vec2( hash2D( value.xy ), value.z ) );
	}
	float getAlphaHashThreshold( vec3 position ) {
		float maxDeriv = max(
			length( dFdx( position.xyz ) ),
			length( dFdy( position.xyz ) )
		);
		float pixScale = 1.0 / ( ALPHA_HASH_SCALE * maxDeriv );
		vec2 pixScales = vec2(
			exp2( floor( log2( pixScale ) ) ),
			exp2( ceil( log2( pixScale ) ) )
		);
		vec2 alpha = vec2(
			hash3D( floor( pixScales.x * position.xyz ) ),
			hash3D( floor( pixScales.y * position.xyz ) )
		);
		float lerpFactor = fract( log2( pixScale ) );
		float x = ( 1.0 - lerpFactor ) * alpha.x + lerpFactor * alpha.y;
		float a = min( lerpFactor, 1.0 - lerpFactor );
		vec3 cases = vec3(
			x * x / ( 2.0 * a * ( 1.0 - a ) ),
			( x - 0.5 * a ) / ( 1.0 - a ),
			1.0 - ( ( 1.0 - x ) * ( 1.0 - x ) / ( 2.0 * a * ( 1.0 - a ) ) )
		);
		float threshold = ( x < ( 1.0 - a ) )
			? ( ( x < a ) ? cases.x : cases.y )
			: cases.z;
		return clamp( threshold , 1.0e-6, 1.0 );
	}
#endif`,alphamap_fragment:`#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, vAlphaMapUv ).g;
#endif`,alphamap_pars_fragment:`#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,alphatest_fragment:`#ifdef USE_ALPHATEST
	#ifdef ALPHA_TO_COVERAGE
	diffuseColor.a = smoothstep( alphaTest, alphaTest + fwidth( diffuseColor.a ), diffuseColor.a );
	if ( diffuseColor.a == 0.0 ) discard;
	#else
	if ( diffuseColor.a < alphaTest ) discard;
	#endif
#endif`,alphatest_pars_fragment:`#ifdef USE_ALPHATEST
	uniform float alphaTest;
#endif`,aomap_fragment:`#ifdef USE_AOMAP
	float ambientOcclusion = ( texture2D( aoMap, vAoMapUv ).r - 1.0 ) * aoMapIntensity + 1.0;
	reflectedLight.indirectDiffuse *= ambientOcclusion;
	#if defined( USE_CLEARCOAT ) 
		clearcoatSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_SHEEN ) 
		sheenSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_ENVMAP ) && defined( STANDARD )
		float dotNV = saturate( dot( geometryNormal, geometryViewDir ) );
		reflectedLight.indirectSpecular *= computeSpecularOcclusion( dotNV, ambientOcclusion, material.roughness );
	#endif
#endif`,aomap_pars_fragment:`#ifdef USE_AOMAP
	uniform sampler2D aoMap;
	uniform float aoMapIntensity;
#endif`,batching_pars_vertex:`#ifdef USE_BATCHING
	#if ! defined( GL_ANGLE_multi_draw )
	#define gl_DrawID _gl_DrawID
	uniform int _gl_DrawID;
	#endif
	uniform highp sampler2D batchingTexture;
	uniform highp usampler2D batchingIdTexture;
	mat4 getBatchingMatrix( const in float i ) {
		int size = textureSize( batchingTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( batchingTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( batchingTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( batchingTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( batchingTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
	float getIndirectIndex( const in int i ) {
		int size = textureSize( batchingIdTexture, 0 ).x;
		int x = i % size;
		int y = i / size;
		return float( texelFetch( batchingIdTexture, ivec2( x, y ), 0 ).r );
	}
#endif
#ifdef USE_BATCHING_COLOR
	uniform sampler2D batchingColorTexture;
	vec4 getBatchingColor( const in float i ) {
		int size = textureSize( batchingColorTexture, 0 ).x;
		int j = int( i );
		int x = j % size;
		int y = j / size;
		return texelFetch( batchingColorTexture, ivec2( x, y ), 0 );
	}
#endif`,batching_vertex:`#ifdef USE_BATCHING
	mat4 batchingMatrix = getBatchingMatrix( getIndirectIndex( gl_DrawID ) );
#endif`,begin_vertex:`vec3 transformed = vec3( position );
#ifdef USE_ALPHAHASH
	vPosition = vec3( position );
#endif`,beginnormal_vertex:`vec3 objectNormal = vec3( normal );
#ifdef USE_TANGENT
	vec3 objectTangent = vec3( tangent.xyz );
#endif`,bsdfs:`float G_BlinnPhong_Implicit( ) {
	return 0.25;
}
float D_BlinnPhong( const in float shininess, const in float dotNH ) {
	return RECIPROCAL_PI * ( shininess * 0.5 + 1.0 ) * pow( dotNH, shininess );
}
vec3 BRDF_BlinnPhong( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in vec3 specularColor, const in float shininess ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( specularColor, 1.0, dotVH );
	float G = G_BlinnPhong_Implicit( );
	float D = D_BlinnPhong( shininess, dotNH );
	return F * ( G * D );
} // validated`,iridescence_fragment:`#ifdef USE_IRIDESCENCE
	const mat3 XYZ_TO_REC709 = mat3(
		 3.2404542, -0.9692660,  0.0556434,
		-1.5371385,  1.8760108, -0.2040259,
		-0.4985314,  0.0415560,  1.0572252
	);
	vec3 Fresnel0ToIor( vec3 fresnel0 ) {
		vec3 sqrtF0 = sqrt( fresnel0 );
		return ( vec3( 1.0 ) + sqrtF0 ) / ( vec3( 1.0 ) - sqrtF0 );
	}
	vec3 IorToFresnel0( vec3 transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - vec3( incidentIor ) ) / ( transmittedIor + vec3( incidentIor ) ) );
	}
	float IorToFresnel0( float transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - incidentIor ) / ( transmittedIor + incidentIor ));
	}
	vec3 evalSensitivity( float OPD, vec3 shift ) {
		float phase = 2.0 * PI * OPD * 1.0e-9;
		vec3 val = vec3( 5.4856e-13, 4.4201e-13, 5.2481e-13 );
		vec3 pos = vec3( 1.6810e+06, 1.7953e+06, 2.2084e+06 );
		vec3 var = vec3( 4.3278e+09, 9.3046e+09, 6.6121e+09 );
		vec3 xyz = val * sqrt( 2.0 * PI * var ) * cos( pos * phase + shift ) * exp( - pow2( phase ) * var );
		xyz.x += 9.7470e-14 * sqrt( 2.0 * PI * 4.5282e+09 ) * cos( 2.2399e+06 * phase + shift[ 0 ] ) * exp( - 4.5282e+09 * pow2( phase ) );
		xyz /= 1.0685e-7;
		vec3 rgb = XYZ_TO_REC709 * xyz;
		return rgb;
	}
	vec3 evalIridescence( float outsideIOR, float eta2, float cosTheta1, float thinFilmThickness, vec3 baseF0 ) {
		vec3 I;
		float iridescenceIOR = mix( outsideIOR, eta2, smoothstep( 0.0, 0.03, thinFilmThickness ) );
		float sinTheta2Sq = pow2( outsideIOR / iridescenceIOR ) * ( 1.0 - pow2( cosTheta1 ) );
		float cosTheta2Sq = 1.0 - sinTheta2Sq;
		if ( cosTheta2Sq < 0.0 ) {
			return vec3( 1.0 );
		}
		float cosTheta2 = sqrt( cosTheta2Sq );
		float R0 = IorToFresnel0( iridescenceIOR, outsideIOR );
		float R12 = F_Schlick( R0, 1.0, cosTheta1 );
		float T121 = 1.0 - R12;
		float phi12 = 0.0;
		if ( iridescenceIOR < outsideIOR ) phi12 = PI;
		float phi21 = PI - phi12;
		vec3 baseIOR = Fresnel0ToIor( clamp( baseF0, 0.0, 0.9999 ) );		vec3 R1 = IorToFresnel0( baseIOR, iridescenceIOR );
		vec3 R23 = F_Schlick( R1, 1.0, cosTheta2 );
		vec3 phi23 = vec3( 0.0 );
		if ( baseIOR[ 0 ] < iridescenceIOR ) phi23[ 0 ] = PI;
		if ( baseIOR[ 1 ] < iridescenceIOR ) phi23[ 1 ] = PI;
		if ( baseIOR[ 2 ] < iridescenceIOR ) phi23[ 2 ] = PI;
		float OPD = 2.0 * iridescenceIOR * thinFilmThickness * cosTheta2;
		vec3 phi = vec3( phi21 ) + phi23;
		vec3 R123 = clamp( R12 * R23, 1e-5, 0.9999 );
		vec3 r123 = sqrt( R123 );
		vec3 Rs = pow2( T121 ) * R23 / ( vec3( 1.0 ) - R123 );
		vec3 C0 = R12 + Rs;
		I = C0;
		vec3 Cm = Rs - T121;
		for ( int m = 1; m <= 2; ++ m ) {
			Cm *= r123;
			vec3 Sm = 2.0 * evalSensitivity( float( m ) * OPD, float( m ) * phi );
			I += Cm * Sm;
		}
		return max( I, vec3( 0.0 ) );
	}
#endif`,bumpmap_pars_fragment:`#ifdef USE_BUMPMAP
	uniform sampler2D bumpMap;
	uniform float bumpScale;
	vec2 dHdxy_fwd() {
		vec2 dSTdx = dFdx( vBumpMapUv );
		vec2 dSTdy = dFdy( vBumpMapUv );
		float Hll = bumpScale * texture2D( bumpMap, vBumpMapUv ).x;
		float dBx = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdx ).x - Hll;
		float dBy = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdy ).x - Hll;
		return vec2( dBx, dBy );
	}
	vec3 perturbNormalArb( vec3 surf_pos, vec3 surf_norm, vec2 dHdxy, float faceDirection ) {
		vec3 vSigmaX = normalize( dFdx( surf_pos.xyz ) );
		vec3 vSigmaY = normalize( dFdy( surf_pos.xyz ) );
		vec3 vN = surf_norm;
		vec3 R1 = cross( vSigmaY, vN );
		vec3 R2 = cross( vN, vSigmaX );
		float fDet = dot( vSigmaX, R1 ) * faceDirection;
		vec3 vGrad = sign( fDet ) * ( dHdxy.x * R1 + dHdxy.y * R2 );
		return normalize( abs( fDet ) * surf_norm - vGrad );
	}
#endif`,clipping_planes_fragment:`#if NUM_CLIPPING_PLANES > 0
	vec4 plane;
	#ifdef ALPHA_TO_COVERAGE
		float distanceToPlane, distanceGradient;
		float clipOpacity = 1.0;
		#pragma unroll_loop_start
		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;
			distanceGradient = fwidth( distanceToPlane ) / 2.0;
			clipOpacity *= smoothstep( - distanceGradient, distanceGradient, distanceToPlane );
			if ( clipOpacity == 0.0 ) discard;
		}
		#pragma unroll_loop_end
		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
			float unionClipOpacity = 1.0;
			#pragma unroll_loop_start
			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
				plane = clippingPlanes[ i ];
				distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;
				distanceGradient = fwidth( distanceToPlane ) / 2.0;
				unionClipOpacity *= 1.0 - smoothstep( - distanceGradient, distanceGradient, distanceToPlane );
			}
			#pragma unroll_loop_end
			clipOpacity *= 1.0 - unionClipOpacity;
		#endif
		diffuseColor.a *= clipOpacity;
		if ( diffuseColor.a == 0.0 ) discard;
	#else
		#pragma unroll_loop_start
		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			if ( dot( vClipPosition, plane.xyz ) > plane.w ) discard;
		}
		#pragma unroll_loop_end
		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
			bool clipped = true;
			#pragma unroll_loop_start
			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
				plane = clippingPlanes[ i ];
				clipped = ( dot( vClipPosition, plane.xyz ) > plane.w ) && clipped;
			}
			#pragma unroll_loop_end
			if ( clipped ) discard;
		#endif
	#endif
#endif`,clipping_planes_pars_fragment:`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
	uniform vec4 clippingPlanes[ NUM_CLIPPING_PLANES ];
#endif`,clipping_planes_pars_vertex:`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
#endif`,clipping_planes_vertex:`#if NUM_CLIPPING_PLANES > 0
	vClipPosition = - mvPosition.xyz;
#endif`,color_fragment:`#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA )
	diffuseColor *= vColor;
#endif`,color_pars_fragment:`#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA )
	varying vec4 vColor;
#endif`,color_pars_vertex:`#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )
	varying vec4 vColor;
#endif`,color_vertex:`#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )
	vColor = vec4( 1.0 );
#endif
#ifdef USE_COLOR_ALPHA
	vColor *= color;
#elif defined( USE_COLOR )
	vColor.rgb *= color;
#endif
#ifdef USE_INSTANCING_COLOR
	vColor.rgb *= instanceColor.rgb;
#endif
#ifdef USE_BATCHING_COLOR
	vColor *= getBatchingColor( getIndirectIndex( gl_DrawID ) );
#endif`,common:`#define PI 3.141592653589793
#define PI2 6.283185307179586
#define PI_HALF 1.5707963267948966
#define RECIPROCAL_PI 0.3183098861837907
#define RECIPROCAL_PI2 0.15915494309189535
#define EPSILON 1e-6
#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
#define whiteComplement( a ) ( 1.0 - saturate( a ) )
float pow2( const in float x ) { return x*x; }
vec3 pow2( const in vec3 x ) { return x*x; }
float pow3( const in float x ) { return x*x*x; }
float pow4( const in float x ) { float x2 = x*x; return x2*x2; }
float max3( const in vec3 v ) { return max( max( v.x, v.y ), v.z ); }
float average( const in vec3 v ) { return dot( v, vec3( 0.3333333 ) ); }
highp float rand( const in vec2 uv ) {
	const highp float a = 12.9898, b = 78.233, c = 43758.5453;
	highp float dt = dot( uv.xy, vec2( a,b ) ), sn = mod( dt, PI );
	return fract( sin( sn ) * c );
}
#ifdef HIGH_PRECISION
	float precisionSafeLength( vec3 v ) { return length( v ); }
#else
	float precisionSafeLength( vec3 v ) {
		float maxComponent = max3( abs( v ) );
		return length( v / maxComponent ) * maxComponent;
	}
#endif
struct IncidentLight {
	vec3 color;
	vec3 direction;
	bool visible;
};
struct ReflectedLight {
	vec3 directDiffuse;
	vec3 directSpecular;
	vec3 indirectDiffuse;
	vec3 indirectSpecular;
};
#ifdef USE_ALPHAHASH
	varying vec3 vPosition;
#endif
vec3 transformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );
}
#define inverseTransformDirection transformDirectionByInverseViewMatrix
vec3 transformNormalByInverseViewMatrix( in vec3 normal, in mat4 viewMatrix ) {
	return normalize( ( vec4( normal, 0.0 ) * viewMatrix ).xyz );
}
vec3 transformDirectionByInverseViewMatrix( in vec3 dir, in mat4 viewMatrix ) {
	return normalize( ( vec4( dir, 0.0 ) * viewMatrix ).xyz );
}
bool isPerspectiveMatrix( mat4 m ) {
	return m[ 2 ][ 3 ] == - 1.0;
}
vec2 equirectUv( in vec3 dir ) {
	float u = atan( dir.z, dir.x ) * RECIPROCAL_PI2 + 0.5;
	float v = asin( clamp( dir.y, - 1.0, 1.0 ) ) * RECIPROCAL_PI + 0.5;
	return vec2( u, v );
}
vec3 BRDF_Lambert( const in vec3 diffuseColor ) {
	return RECIPROCAL_PI * diffuseColor;
}
vec3 F_Schlick( const in vec3 f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
}
float F_Schlick( const in float f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
} // validated`,defaultnormal_vertex:`vec3 transformedNormal = objectNormal;
#ifdef USE_TANGENT
	vec3 transformedTangent = objectTangent;
#endif
#ifdef USE_BATCHING
	mat3 bm = mat3( batchingMatrix );
	transformedNormal /= vec3( dot( bm[ 0 ], bm[ 0 ] ), dot( bm[ 1 ], bm[ 1 ] ), dot( bm[ 2 ], bm[ 2 ] ) );
	transformedNormal = bm * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = bm * transformedTangent;
	#endif
#endif
#ifdef USE_INSTANCING
	mat3 im = mat3( instanceMatrix );
	transformedNormal /= vec3( dot( im[ 0 ], im[ 0 ] ), dot( im[ 1 ], im[ 1 ] ), dot( im[ 2 ], im[ 2 ] ) );
	transformedNormal = im * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = im * transformedTangent;
	#endif
#endif
transformedNormal = normalMatrix * transformedNormal;
#ifdef FLIP_SIDED
	transformedNormal = - transformedNormal;
#endif
#ifdef USE_TANGENT
	transformedTangent = ( modelViewMatrix * vec4( transformedTangent, 0.0 ) ).xyz;
#endif`,displacementmap_pars_vertex:`#ifdef USE_DISPLACEMENTMAP
	uniform sampler2D displacementMap;
	uniform float displacementScale;
	uniform float displacementBias;
#endif`,displacementmap_vertex:`#ifdef USE_DISPLACEMENTMAP
	transformed += normalize( objectNormal ) * ( texture2D( displacementMap, vDisplacementMapUv ).x * displacementScale + displacementBias );
#endif`,emissivemap_fragment:`#ifdef USE_EMISSIVEMAP
	vec4 emissiveColor = texture2D( emissiveMap, vEmissiveMapUv );
	#ifdef DECODE_VIDEO_TEXTURE_EMISSIVE
		emissiveColor = sRGBTransferEOTF( emissiveColor );
	#endif
	totalEmissiveRadiance *= emissiveColor.rgb;
#endif`,emissivemap_pars_fragment:`#ifdef USE_EMISSIVEMAP
	uniform sampler2D emissiveMap;
#endif`,colorspace_fragment:`gl_FragColor = linearToOutputTexel( gl_FragColor );`,colorspace_pars_fragment:`vec4 LinearTransferOETF( in vec4 value ) {
	return value;
}
vec4 sRGBTransferEOTF( in vec4 value ) {
	return vec4( mix( pow( value.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), value.rgb * 0.0773993808, vec3( lessThanEqual( value.rgb, vec3( 0.04045 ) ) ) ), value.a );
}
vec4 sRGBTransferOETF( in vec4 value ) {
	return vec4( mix( pow( value.rgb, vec3( 0.41666 ) ) * 1.055 - vec3( 0.055 ), value.rgb * 12.92, vec3( lessThanEqual( value.rgb, vec3( 0.0031308 ) ) ) ), value.a );
}`,envmap_fragment:`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vec3 cameraToFrag;
		if ( isOrthographic ) {
			cameraToFrag = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToFrag = normalize( vWorldPosition - cameraPosition );
		}
		vec3 worldNormal = transformNormalByInverseViewMatrix( normal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vec3 reflectVec = reflect( cameraToFrag, worldNormal );
		#else
			vec3 reflectVec = refract( cameraToFrag, worldNormal, refractionRatio );
		#endif
	#else
		vec3 reflectVec = vReflect;
	#endif
	#ifdef ENVMAP_TYPE_CUBE
		vec4 envColor = textureCube( envMap, envMapRotation * reflectVec );
		#ifdef ENVMAP_BLENDING_MULTIPLY
			outgoingLight = mix( outgoingLight, outgoingLight * envColor.xyz, specularStrength * reflectivity );
		#elif defined( ENVMAP_BLENDING_MIX )
			outgoingLight = mix( outgoingLight, envColor.xyz, specularStrength * reflectivity );
		#elif defined( ENVMAP_BLENDING_ADD )
			outgoingLight += envColor.xyz * specularStrength * reflectivity;
		#endif
	#endif
#endif`,envmap_common_pars_fragment:`#ifdef USE_ENVMAP
	uniform float envMapIntensity;
	uniform mat3 envMapRotation;
	uniform samplerCube envMap;
	#ifdef ENVMAP_TYPE_PMREM
		float roughnessToMip( const in float roughness ) {
			float r = clamp( roughness, 0.0, 1.0 );
			return ENVMAP_MAX_LOD * r * ( 2.0 - r );
		}
	#endif
#endif`,envmap_pars_fragment:`#ifdef USE_ENVMAP
	uniform float reflectivity;
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		varying vec3 vWorldPosition;
		uniform float refractionRatio;
	#else
		varying vec3 vReflect;
	#endif
#endif`,envmap_pars_vertex:`#ifdef USE_ENVMAP
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		
		varying vec3 vWorldPosition;
	#else
		varying vec3 vReflect;
		uniform float refractionRatio;
	#endif
#endif`,envmap_physical_pars_fragment:`#ifdef USE_ENVMAP
	vec3 getIBLIrradiance( const in vec3 normal ) {
		#ifdef ENVMAP_TYPE_PMREM
			vec3 worldNormal = transformNormalByInverseViewMatrix( normal, viewMatrix );
			vec4 envMapColor = textureLod( envMap, envMapRotation * worldNormal, ENVMAP_MAX_LOD );
			return PI * envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	vec3 getIBLRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness ) {
		#ifdef ENVMAP_TYPE_PMREM
			vec3 reflectVec = reflect( - viewDir, normal );
			reflectVec = normalize( mix( reflectVec, normal, pow4( roughness ) ) );
			reflectVec = transformDirectionByInverseViewMatrix( reflectVec, viewMatrix );
			vec4 envMapColor = textureLod( envMap, envMapRotation * reflectVec, roughnessToMip( roughness ) );
			return envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	#ifdef USE_RETROREFLECTION
		vec3 getIBLRetroRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness ) {
			#ifdef ENVMAP_TYPE_PMREM
				vec3 retroVec = normalize( mix( viewDir, normal, pow4( roughness ) ) );
				retroVec = transformDirectionByInverseViewMatrix( retroVec, viewMatrix );
				vec4 envMapColor = textureLod( envMap, envMapRotation * retroVec, roughnessToMip( roughness ) );
				return envMapColor.rgb * envMapIntensity;
			#else
				return vec3( 0.0 );
			#endif
		}
	#endif
	#ifdef USE_ANISOTROPY
		vec3 getIBLAnisotropyRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness, const in vec3 bitangent, const in float anisotropy ) {
			#ifdef ENVMAP_TYPE_PMREM
				vec3 bentNormal = cross( bitangent, viewDir );
				bentNormal = normalize( cross( bentNormal, bitangent ) );
				bentNormal = normalize( mix( bentNormal, normal, pow2( pow2( 1.0 - anisotropy * ( 1.0 - roughness ) ) ) ) );
				return getIBLRadiance( viewDir, bentNormal, roughness );
			#else
				return vec3( 0.0 );
			#endif
		}
		#ifdef USE_RETROREFLECTION
			vec3 getIBLAnisotropyRetroRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness, const in vec3 bitangent, const in float anisotropy ) {
				#ifdef ENVMAP_TYPE_PMREM
					vec3 bentNormal = cross( bitangent, viewDir );
					bentNormal = normalize( cross( bentNormal, bitangent ) );
					bentNormal = normalize( mix( bentNormal, normal, pow2( pow2( 1.0 - anisotropy * ( 1.0 - roughness ) ) ) ) );
					return getIBLRetroRadiance( viewDir, bentNormal, roughness );
				#else
					return vec3( 0.0 );
				#endif
			}
		#endif
	#endif
#endif`,envmap_vertex:`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vWorldPosition = worldPosition.xyz;
	#else
		vec3 cameraToVertex;
		if ( isOrthographic ) {
			cameraToVertex = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToVertex = normalize( worldPosition.xyz - cameraPosition );
		}
		vec3 worldNormal = transformNormalByInverseViewMatrix( transformedNormal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vReflect = reflect( cameraToVertex, worldNormal );
		#else
			vReflect = refract( cameraToVertex, worldNormal, refractionRatio );
		#endif
	#endif
#endif`,fog_vertex:`#ifdef USE_FOG
	vFogDepth = - mvPosition.z;
#endif`,fog_pars_vertex:`#ifdef USE_FOG
	varying float vFogDepth;
#endif`,fog_fragment:`#ifdef USE_FOG
	#ifdef FOG_EXP2
		float fogFactor = 1.0 - exp( - fogDensity * fogDensity * vFogDepth * vFogDepth );
	#else
		float fogFactor = smoothstep( fogNear, fogFar, vFogDepth );
	#endif
	gl_FragColor.rgb = mix( gl_FragColor.rgb, fogColor, fogFactor );
#endif`,fog_pars_fragment:`#ifdef USE_FOG
	uniform vec3 fogColor;
	varying float vFogDepth;
	#ifdef FOG_EXP2
		uniform float fogDensity;
	#else
		uniform float fogNear;
		uniform float fogFar;
	#endif
#endif`,gradientmap_pars_fragment:`#ifdef USE_GRADIENTMAP
	uniform sampler2D gradientMap;
#endif
vec3 getGradientIrradiance( vec3 normal, vec3 lightDirection ) {
	float dotNL = dot( normal, lightDirection );
	vec2 coord = vec2( dotNL * 0.5 + 0.5, 0.0 );
	#ifdef USE_GRADIENTMAP
		return vec3( texture2D( gradientMap, coord ).r );
	#else
		vec2 fw = fwidth( coord ) * 0.5;
		return mix( vec3( 0.7 ), vec3( 1.0 ), smoothstep( 0.7 - fw.x, 0.7 + fw.x, coord.x ) );
	#endif
}`,lightmap_pars_fragment:`#ifdef USE_LIGHTMAP
	uniform sampler2D lightMap;
	uniform float lightMapIntensity;
#endif`,lights_lambert_fragment:`LambertMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularStrength = specularStrength;`,lights_lambert_pars_fragment:`varying vec3 vViewPosition;
struct LambertMaterial {
	vec3 diffuseColor;
	float specularStrength;
};
void RE_Direct_Lambert( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Lambert( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Lambert
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Lambert`,lights_pars_begin:`uniform bool receiveShadow;
uniform vec3 ambientLightColor;
#if defined( USE_LIGHT_PROBES )
	uniform vec3 lightProbe[ 9 ];
#endif
vec3 shGetIrradianceAt( in vec3 normal, in vec3 shCoefficients[ 9 ] ) {
	float x = normal.x, y = normal.y, z = normal.z;
	vec3 result = shCoefficients[ 0 ] * 0.886227;
	result += shCoefficients[ 1 ] * 2.0 * 0.511664 * y;
	result += shCoefficients[ 2 ] * 2.0 * 0.511664 * z;
	result += shCoefficients[ 3 ] * 2.0 * 0.511664 * x;
	result += shCoefficients[ 4 ] * 2.0 * 0.429043 * x * y;
	result += shCoefficients[ 5 ] * 2.0 * 0.429043 * y * z;
	result += shCoefficients[ 6 ] * ( 0.743125 * z * z - 0.247708 );
	result += shCoefficients[ 7 ] * 2.0 * 0.429043 * x * z;
	result += shCoefficients[ 8 ] * 0.429043 * ( x * x - y * y );
	return result;
}
vec3 getLightProbeIrradiance( const in vec3 lightProbe[ 9 ], const in vec3 normal ) {
	vec3 worldNormal = transformNormalByInverseViewMatrix( normal, viewMatrix );
	vec3 irradiance = shGetIrradianceAt( worldNormal, lightProbe );
	return irradiance;
}
vec3 getAmbientLightIrradiance( const in vec3 ambientLightColor ) {
	vec3 irradiance = ambientLightColor;
	return irradiance;
}
float getDistanceAttenuation( const in float lightDistance, const in float cutoffDistance, const in float decayExponent ) {
	float distanceFalloff = 1.0 / max( pow( lightDistance, decayExponent ), 0.01 );
	if ( cutoffDistance > 0.0 ) {
		distanceFalloff *= pow2( saturate( 1.0 - pow4( lightDistance / cutoffDistance ) ) );
	}
	return distanceFalloff;
}
float getSpotAttenuation( const in float coneCosine, const in float penumbraCosine, const in float angleCosine ) {
	return smoothstep( coneCosine, penumbraCosine, angleCosine );
}
#if NUM_SUN_LIGHTS > 0
	struct SunLight {
		vec3 direction;
		vec3 color;
	};
	uniform SunLight sunLights[ NUM_SUN_LIGHTS ];
	void getSunLightInfo( const in SunLight sunLight, out IncidentLight light ) {
		light.color = sunLight.color;
		light.direction = sunLight.direction;
		light.visible = true;
	}
#endif
#if NUM_DIR_LIGHTS > 0
	struct DirectionalLight {
		vec3 direction;
		vec3 color;
	};
	uniform DirectionalLight directionalLights[ NUM_DIR_LIGHTS ];
	void getDirectionalLightInfo( const in DirectionalLight directionalLight, out IncidentLight light ) {
		light.color = directionalLight.color;
		light.direction = directionalLight.direction;
		light.visible = true;
	}
#endif
#if NUM_POINT_LIGHTS > 0
	struct PointLight {
		vec3 position;
		vec3 color;
		float distance;
		float decay;
	};
	uniform PointLight pointLights[ NUM_POINT_LIGHTS ];
	void getPointLightInfo( const in PointLight pointLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = pointLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float lightDistance = length( lVector );
		light.color = pointLight.color;
		light.color *= getDistanceAttenuation( lightDistance, pointLight.distance, pointLight.decay );
		light.visible = ( light.color != vec3( 0.0 ) );
	}
#endif
#if NUM_SPOT_LIGHTS > 0
	struct SpotLight {
		vec3 position;
		vec3 direction;
		vec3 color;
		float distance;
		float decay;
		float coneCos;
		float penumbraCos;
	};
	uniform SpotLight spotLights[ NUM_SPOT_LIGHTS ];
	void getSpotLightInfo( const in SpotLight spotLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = spotLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float angleCos = dot( light.direction, spotLight.direction );
		float spotAttenuation = getSpotAttenuation( spotLight.coneCos, spotLight.penumbraCos, angleCos );
		if ( spotAttenuation > 0.0 ) {
			float lightDistance = length( lVector );
			light.color = spotLight.color * spotAttenuation;
			light.color *= getDistanceAttenuation( lightDistance, spotLight.distance, spotLight.decay );
			light.visible = ( light.color != vec3( 0.0 ) );
		} else {
			light.color = vec3( 0.0 );
			light.visible = false;
		}
	}
#endif
#if NUM_RECT_AREA_LIGHTS > 0
	struct RectAreaLight {
		vec3 color;
		vec3 position;
		vec3 halfWidth;
		vec3 halfHeight;
	};
	uniform sampler2D ltc_1;	uniform sampler2D ltc_2;
	uniform RectAreaLight rectAreaLights[ NUM_RECT_AREA_LIGHTS ];
#endif
#if NUM_HEMI_LIGHTS > 0
	struct HemisphereLight {
		vec3 direction;
		vec3 skyColor;
		vec3 groundColor;
	};
	uniform HemisphereLight hemisphereLights[ NUM_HEMI_LIGHTS ];
	vec3 getHemisphereLightIrradiance( const in HemisphereLight hemiLight, const in vec3 normal ) {
		float dotNL = dot( normal, hemiLight.direction );
		float hemiDiffuseWeight = 0.5 * dotNL + 0.5;
		vec3 irradiance = mix( hemiLight.groundColor, hemiLight.skyColor, hemiDiffuseWeight );
		return irradiance;
	}
#endif
#include <lightprobes_pars_fragment>`,lights_toon_fragment:`ToonMaterial material;
material.diffuseColor = diffuseColor.rgb;`,lights_toon_pars_fragment:`varying vec3 vViewPosition;
struct ToonMaterial {
	vec3 diffuseColor;
};
void RE_Direct_Toon( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	vec3 irradiance = getGradientIrradiance( geometryNormal, directLight.direction ) * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Toon( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Toon
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Toon`,lights_phong_fragment:`BlinnPhongMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularColor = specular;
material.specularShininess = shininess;
material.specularStrength = specularStrength;`,lights_phong_pars_fragment:`varying vec3 vViewPosition;
struct BlinnPhongMaterial {
	vec3 diffuseColor;
	vec3 specularColor;
	float specularShininess;
	float specularStrength;
};
void RE_Direct_BlinnPhong( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
	reflectedLight.directSpecular += irradiance * BRDF_BlinnPhong( directLight.direction, geometryViewDir, geometryNormal, material.specularColor, material.specularShininess ) * material.specularStrength;
}
void RE_IndirectDiffuse_BlinnPhong( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_BlinnPhong
#define RE_IndirectDiffuse		RE_IndirectDiffuse_BlinnPhong`,lights_physical_fragment:`PhysicalMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.diffuseContribution = diffuseColor.rgb * ( 1.0 - metalnessFactor );
material.metalness = metalnessFactor;
vec3 dxy = max( abs( dFdx( nonPerturbedNormal ) ), abs( dFdy( nonPerturbedNormal ) ) );
float geometryRoughness = max( max( dxy.x, dxy.y ), dxy.z );
material.roughness = max( roughnessFactor, 0.045 );
material.roughness += geometryRoughness;
material.roughness = min( material.roughness, 1.0 );
#ifdef USE_DIFFUSE_ROUGHNESS
	float diffuseRoughnessFactor = diffuseRoughness;
	#ifdef USE_DIFFUSE_ROUGHNESSMAP
		diffuseRoughnessFactor *= texture2D( diffuseRoughnessMap, vDiffuseRoughnessMapUv ).r;
	#endif
	material.diffuseRoughness = saturate( diffuseRoughnessFactor );
#endif
#ifdef IOR
	material.ior = ior;
	#ifdef USE_SPECULAR
		float specularIntensityFactor = specularIntensity;
		vec3 specularColorFactor = specularColor;
		#ifdef USE_SPECULAR_COLORMAP
			specularColorFactor *= texture2D( specularColorMap, vSpecularColorMapUv ).rgb;
		#endif
		#ifdef USE_SPECULAR_INTENSITYMAP
			specularIntensityFactor *= texture2D( specularIntensityMap, vSpecularIntensityMapUv ).a;
		#endif
		material.specularF90 = mix( specularIntensityFactor, 1.0, metalnessFactor );
	#else
		float specularIntensityFactor = 1.0;
		vec3 specularColorFactor = vec3( 1.0 );
		material.specularF90 = 1.0;
	#endif
	material.specularColor = min( pow2( ( material.ior - 1.0 ) / ( material.ior + 1.0 ) ) * specularColorFactor, vec3( 1.0 ) ) * specularIntensityFactor;
	material.specularColorBlended = mix( material.specularColor, diffuseColor.rgb, metalnessFactor );
#else
	material.specularColor = vec3( 0.04 );
	material.specularColorBlended = mix( material.specularColor, diffuseColor.rgb, metalnessFactor );
	material.specularF90 = 1.0;
#endif
#ifdef USE_CLEARCOAT
	material.clearcoat = clearcoat;
	material.clearcoatRoughness = clearcoatRoughness;
	material.clearcoatF0 = vec3( 0.04 );
	material.clearcoatF90 = 1.0;
	#ifdef USE_CLEARCOATMAP
		material.clearcoat *= texture2D( clearcoatMap, vClearcoatMapUv ).x;
	#endif
	#ifdef USE_CLEARCOAT_ROUGHNESSMAP
		material.clearcoatRoughness *= texture2D( clearcoatRoughnessMap, vClearcoatRoughnessMapUv ).y;
	#endif
	material.clearcoat = saturate( material.clearcoat );	material.clearcoatRoughness = max( material.clearcoatRoughness, 0.045 );
	material.clearcoatRoughness += geometryRoughness;
	material.clearcoatRoughness = min( material.clearcoatRoughness, 1.0 );
#endif
#ifdef USE_DISPERSION
	material.dispersion = dispersion;
#endif
#ifdef USE_RETROREFLECTION
	material.retroreflectivity = retroreflectivity;
#endif
#ifdef USE_IRIDESCENCE
	material.iridescence = iridescence;
	material.iridescenceIOR = iridescenceIOR;
	#ifdef USE_IRIDESCENCEMAP
		material.iridescence *= texture2D( iridescenceMap, vIridescenceMapUv ).r;
	#endif
	#ifdef USE_IRIDESCENCE_THICKNESSMAP
		material.iridescenceThickness = (iridescenceThicknessMaximum - iridescenceThicknessMinimum) * texture2D( iridescenceThicknessMap, vIridescenceThicknessMapUv ).g + iridescenceThicknessMinimum;
	#else
		material.iridescenceThickness = iridescenceThicknessMaximum;
	#endif
#endif
#ifdef USE_SHEEN
	material.sheenColor = sheenColor;
	#ifdef USE_SHEEN_COLORMAP
		material.sheenColor *= texture2D( sheenColorMap, vSheenColorMapUv ).rgb;
	#endif
	material.sheenRoughness = clamp( sheenRoughness, 0.0001, 1.0 );
	#ifdef USE_SHEEN_ROUGHNESSMAP
		material.sheenRoughness *= texture2D( sheenRoughnessMap, vSheenRoughnessMapUv ).a;
	#endif
#endif
#ifdef USE_ANISOTROPY
	#ifdef USE_ANISOTROPYMAP
		mat2 anisotropyMat = mat2( anisotropyVector.x, anisotropyVector.y, - anisotropyVector.y, anisotropyVector.x );
		vec3 anisotropyPolar = texture2D( anisotropyMap, vAnisotropyMapUv ).rgb;
		vec2 anisotropyV = anisotropyMat * normalize( 2.0 * anisotropyPolar.rg - vec2( 1.0 ) ) * anisotropyPolar.b;
	#else
		vec2 anisotropyV = anisotropyVector;
	#endif
	material.anisotropy = length( anisotropyV );
	if( material.anisotropy == 0.0 ) {
		anisotropyV = vec2( 1.0, 0.0 );
	} else {
		anisotropyV /= material.anisotropy;
		material.anisotropy = saturate( material.anisotropy );
	}
	material.alphaT = mix( pow2( material.roughness ), 1.0, pow2( material.anisotropy ) );
	material.anisotropyT = tbn[ 0 ] * anisotropyV.x + tbn[ 1 ] * anisotropyV.y;
	material.anisotropyB = tbn[ 1 ] * anisotropyV.x - tbn[ 0 ] * anisotropyV.y;
#endif`,lights_physical_pars_fragment:`uniform sampler2D dfgLUT;
struct PhysicalMaterial {
	vec3 diffuseColor;
	vec3 diffuseContribution;
	vec3 specularColor;
	vec3 specularColorBlended;
	float roughness;
	float metalness;
	float specularF90;
	float dispersion;
	vec2 dfg;
	vec3 multiScatteringCompensation;
	#ifdef USE_DIFFUSE_ROUGHNESS
		float diffuseRoughness;
	#endif
	#ifdef USE_RETROREFLECTION
		float retroreflectivity;
	#endif
	#ifdef USE_CLEARCOAT
		float clearcoat;
		float clearcoatRoughness;
		vec3 clearcoatF0;
		float clearcoatF90;
	#endif
	#ifdef USE_IRIDESCENCE
		float iridescence;
		float iridescenceIOR;
		float iridescenceThickness;
		vec3 iridescenceFresnel;
		vec3 iridescenceF0Dielectric;
		vec3 iridescenceF0Metallic;
	#endif
	#ifdef USE_SHEEN
		vec3 sheenColor;
		float sheenRoughness;
	#endif
	#ifdef IOR
		float ior;
	#endif
	#ifdef USE_TRANSMISSION
		float transmission;
		float transmissionAlpha;
		float thickness;
		float attenuationDistance;
		vec3 attenuationColor;
	#endif
	#ifdef USE_ANISOTROPY
		float anisotropy;
		float alphaT;
		vec3 anisotropyT;
		vec3 anisotropyB;
	#endif
};
vec3 clearcoatSpecularDirect = vec3( 0.0 );
vec3 clearcoatSpecularIndirect = vec3( 0.0 );
vec3 sheenSpecularDirect = vec3( 0.0 );
vec3 sheenSpecularIndirect = vec3(0.0 );
vec3 Schlick_to_F0( const in vec3 f, const in float f90, const in float dotVH ) {
    float x = clamp( 1.0 - dotVH, 0.0, 1.0 );
    float x2 = x * x;
    float x5 = clamp( x * x2 * x2, 0.0, 0.9999 );
    return ( f - vec3( f90 ) * x5 ) / ( 1.0 - x5 );
}
#ifdef USE_DIFFUSE_ROUGHNESS
	const float EON_EPSILON = 1e-7;
	float FON_DirectionalAlbedo( const in float mu, const in float roughness, const in float A ) {
		float muComp = 1.0 - mu;
		float gOverPi = muComp * ( 0.0571085289 + muComp * ( 0.491881867 + muComp * ( - 0.332181442 + muComp * 0.0714429953 ) ) );
		return A * ( 1.0 + roughness * gOverPi );
	}
	vec3 BRDF_EON( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in vec3 diffuseColor, const in float roughness ) {
		vec3 rho = saturate( diffuseColor );
		if ( roughness <= EON_EPSILON ) return BRDF_Lambert( rho );
		float dotNL = saturate( dot( normal, lightDir ) );
		float dotNV = saturate( dot( normal, viewDir ) );
		float s = dot( lightDir, viewDir ) - dotNL * dotNV;
		float sOverT = ( s > 0.0 ) ? s / max( max( dotNL, dotNV ), EON_EPSILON ) : s;
		float A = 1.0 / ( 1.0 + ( 0.5 - 2.0 / ( 3.0 * PI ) ) * roughness );
		vec3 singleScatter = rho * RECIPROCAL_PI * A * ( 1.0 + roughness * sOverT );
		float averageAlbedo = A * ( 1.0 + ( 2.0 / 3.0 - 28.0 / ( 15.0 * PI ) ) * roughness );
		float albedoV = FON_DirectionalAlbedo( dotNV, roughness, A );
		float albedoL = FON_DirectionalAlbedo( dotNL, roughness, A );
		vec3 rhoMultiScatter = rho * rho * averageAlbedo / max( vec3( EON_EPSILON ), vec3( 1.0 ) - rho * ( 1.0 - averageAlbedo ) );
		vec3 multiScatter = rhoMultiScatter * RECIPROCAL_PI
			* max( EON_EPSILON, 1.0 - albedoV )
			* max( EON_EPSILON, 1.0 - albedoL )
			/ max( EON_EPSILON, 1.0 - averageAlbedo );
		return singleScatter + multiScatter;
	}
	vec3 EON_DirectionalAlbedo( const in vec3 diffuseColor, const in float roughness, const in float dotNV ) {
		vec3 rho = saturate( diffuseColor );
		if ( roughness <= EON_EPSILON ) return rho;
		float A = 1.0 / ( 1.0 + ( 0.5 - 2.0 / ( 3.0 * PI ) ) * roughness );
		float directionalAlbedo = FON_DirectionalAlbedo( dotNV, roughness, A );
		float averageAlbedo = A * ( 1.0 + ( 2.0 / 3.0 - 28.0 / ( 15.0 * PI ) ) * roughness );
		vec3 rhoMultiScatter = rho * rho * averageAlbedo / max( vec3( EON_EPSILON ), vec3( 1.0 ) - rho * ( 1.0 - averageAlbedo ) );
		return rho * directionalAlbedo + rhoMultiScatter * ( 1.0 - directionalAlbedo );
	}
#endif
float V_GGX_SmithCorrelated( const in float alpha, const in float dotNL, const in float dotNV ) {
	float a2 = pow2( alpha );
	float gv = dotNL * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNV ) );
	float gl = dotNV * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNL ) );
	return 0.5 / max( gv + gl, EPSILON );
}
float D_GGX( const in float alpha, const in float dotNH ) {
	float a2 = pow2( alpha );
	float denom = pow2( dotNH ) * ( a2 - 1.0 ) + 1.0;
	return RECIPROCAL_PI * a2 / pow2( denom );
}
#ifdef USE_ANISOTROPY
	float V_GGX_SmithCorrelated_Anisotropic( const in float alphaT, const in float alphaB, const in float dotTV, const in float dotBV, const in float dotTL, const in float dotBL, const in float dotNV, const in float dotNL ) {
		float gv = dotNL * length( vec3( alphaT * dotTV, alphaB * dotBV, dotNV ) );
		float gl = dotNV * length( vec3( alphaT * dotTL, alphaB * dotBL, dotNL ) );
		return 0.5 / max( gv + gl, EPSILON );
	}
	float D_GGX_Anisotropic( const in float alphaT, const in float alphaB, const in float dotNH, const in float dotTH, const in float dotBH ) {
		float a2 = alphaT * alphaB;
		highp vec3 v = vec3( alphaB * dotTH, alphaT * dotBH, a2 * dotNH );
		highp float v2 = dot( v, v );
		float w2 = a2 / v2;
		return RECIPROCAL_PI * a2 * pow2 ( w2 );
	}
#endif
#ifdef USE_CLEARCOAT
	vec3 BRDF_GGX_Clearcoat( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material) {
		vec3 f0 = material.clearcoatF0;
		float f90 = material.clearcoatF90;
		float roughness = max( material.clearcoatRoughness, 0.045 );
		float alpha = pow2( roughness );
		vec3 halfDir = normalize( lightDir + viewDir );
		float dotNL = saturate( dot( normal, lightDir ) );
		float dotNV = saturate( dot( normal, viewDir ) );
		float dotNH = saturate( dot( normal, halfDir ) );
		float dotVH = saturate( dot( viewDir, halfDir ) );
		vec3 F = F_Schlick( f0, f90, dotVH );
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
		return F * ( V * D );
	}
#endif
vec3 BRDF_GGX( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material ) {
	vec3 f0 = material.specularColorBlended;
	float f90 = material.specularF90;
	float roughness = max( material.roughness, 0.045 );
	float alpha = pow2( roughness );
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( f0, f90, dotVH );
	#ifdef USE_IRIDESCENCE
		F = mix( F, material.iridescenceFresnel, material.iridescence );
	#endif
	#ifdef USE_ANISOTROPY
		float dotTL = dot( material.anisotropyT, lightDir );
		float dotTV = dot( material.anisotropyT, viewDir );
		float dotTH = dot( material.anisotropyT, halfDir );
		float dotBL = dot( material.anisotropyB, lightDir );
		float dotBV = dot( material.anisotropyB, viewDir );
		float dotBH = dot( material.anisotropyB, halfDir );
		float alphaT = max( material.alphaT, alpha );
		float V = V_GGX_SmithCorrelated_Anisotropic( alphaT, alpha, dotTV, dotBV, dotTL, dotBL, dotNV, dotNL );
		float D = D_GGX_Anisotropic( alphaT, alpha, dotNH, dotTH, dotBH );
	#else
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
	#endif
	return F * ( V * D );
}
vec2 LTC_Uv( const in vec3 N, const in vec3 V, const in float roughness ) {
	const float LUT_SIZE = 64.0;
	const float LUT_SCALE = ( LUT_SIZE - 1.0 ) / LUT_SIZE;
	const float LUT_BIAS = 0.5 / LUT_SIZE;
	float dotNV = saturate( dot( N, V ) );
	vec2 uv = vec2( roughness, sqrt( 1.0 - dotNV ) );
	uv = uv * LUT_SCALE + LUT_BIAS;
	return uv;
}
float LTC_ClippedSphereFormFactor( const in vec3 f ) {
	float l = length( f );
	return max( ( l * l + f.z ) / ( l + 1.0 ), 0.0 );
}
vec3 LTC_EdgeVectorFormFactor( const in vec3 v1, const in vec3 v2 ) {
	float x = dot( v1, v2 );
	float y = abs( x );
	float a = 0.8543985 + ( 0.4965155 + 0.0145206 * y ) * y;
	float b = 3.4175940 + ( 4.1616724 + y ) * y;
	float v = a / b;
	float theta_sintheta = ( x > 0.0 ) ? v : 0.5 * inversesqrt( max( 1.0 - x * x, 1e-7 ) ) - v;
	return cross( v1, v2 ) * theta_sintheta;
}
vec3 LTC_Evaluate( const in vec3 N, const in vec3 V, const in vec3 P, const in mat3 mInv, const in vec3 rectCoords[ 4 ] ) {
	vec3 v1 = rectCoords[ 1 ] - rectCoords[ 0 ];
	vec3 v2 = rectCoords[ 3 ] - rectCoords[ 0 ];
	vec3 lightNormal = cross( v1, v2 );
	if( dot( lightNormal, P - rectCoords[ 0 ] ) < 0.0 ) return vec3( 0.0 );
	vec3 T1, T2;
	T1 = normalize( V - N * dot( V, N ) );
	T2 = - cross( N, T1 );
	mat3 mat = mInv * transpose( mat3( T1, T2, N ) );
	vec3 coords[ 4 ];
	coords[ 0 ] = mat * ( rectCoords[ 0 ] - P );
	coords[ 1 ] = mat * ( rectCoords[ 1 ] - P );
	coords[ 2 ] = mat * ( rectCoords[ 2 ] - P );
	coords[ 3 ] = mat * ( rectCoords[ 3 ] - P );
	coords[ 0 ] = normalize( coords[ 0 ] );
	coords[ 1 ] = normalize( coords[ 1 ] );
	coords[ 2 ] = normalize( coords[ 2 ] );
	coords[ 3 ] = normalize( coords[ 3 ] );
	vec3 vectorFormFactor = vec3( 0.0 );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 0 ], coords[ 1 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 1 ], coords[ 2 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 2 ], coords[ 3 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 3 ], coords[ 0 ] );
	float result = LTC_ClippedSphereFormFactor( vectorFormFactor );
	return vec3( result );
}
#if defined( USE_SHEEN )
float D_Charlie( float roughness, float dotNH ) {
	float alpha = pow2( roughness );
	float invAlpha = 1.0 / alpha;
	float cos2h = dotNH * dotNH;
	float sin2h = max( 1.0 - cos2h, 0.0078125 );
	return ( 2.0 + invAlpha ) * pow( sin2h, invAlpha * 0.5 ) / ( 2.0 * PI );
}
float V_Neubelt( float dotNV, float dotNL ) {
	return saturate( 1.0 / ( 4.0 * ( dotNL + dotNV - dotNL * dotNV ) ) );
}
vec3 BRDF_Sheen( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, vec3 sheenColor, const in float sheenRoughness ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float D = D_Charlie( sheenRoughness, dotNH );
	float V = V_Neubelt( dotNV, dotNL );
	return sheenColor * ( D * V );
}
#endif
float IBLSheenBRDF( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	float r2 = roughness * roughness;
	float rInv = 1.0 / ( roughness + 0.1 );
	float a = -1.9362 + 1.0678 * roughness + 0.4573 * r2 - 0.8469 * rInv;
	float b = -0.6014 + 0.5538 * roughness - 0.4670 * r2 - 0.1255 * rInv;
	float DG = exp( a * dotNV + b );
	return saturate( DG );
}
vec3 EnvironmentBRDF( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	vec2 fab = texture2D( dfgLUT, vec2( roughness, dotNV ) ).rg;
	return specularColor * fab.x + specularF90 * fab.y;
}
#ifdef USE_IRIDESCENCE
void computeMultiscatteringIridescence( const in vec2 fab, const in vec3 specularColor, const in float specularF90, const in float iridescence, const in vec3 iridescenceF0, inout vec3 singleScatter, inout vec3 multiScatter ) {
#else
void computeMultiscattering( const in vec2 fab, const in vec3 specularColor, const in float specularF90, inout vec3 singleScatter, inout vec3 multiScatter ) {
#endif
	#ifdef USE_IRIDESCENCE
		vec3 Fr = mix( specularColor, iridescenceF0, iridescence );
	#else
		vec3 Fr = specularColor;
	#endif
	vec3 FssEss = Fr * fab.x + specularF90 * fab.y;
	float Ess = fab.x + fab.y;
	float Ems = 1.0 - Ess;
	vec3 Favg = Fr + ( 1.0 - Fr ) * 0.047619;	vec3 Fms = FssEss * Favg / ( 1.0 - Ems * Favg );
	singleScatter += FssEss;
	multiScatter += Fms * Ems;
}
#if NUM_RECT_AREA_LIGHTS > 0
	void RE_Direct_RectArea_Physical( const in RectAreaLight rectAreaLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
		vec3 normal = geometryNormal;
		vec3 viewDir = geometryViewDir;
		vec3 position = geometryPosition;
		vec3 lightPos = rectAreaLight.position;
		vec3 halfWidth = rectAreaLight.halfWidth;
		vec3 halfHeight = rectAreaLight.halfHeight;
		vec3 lightColor = rectAreaLight.color;
		float roughness = material.roughness;
		vec3 rectCoords[ 4 ];
		rectCoords[ 0 ] = lightPos + halfWidth - halfHeight;		rectCoords[ 1 ] = lightPos - halfWidth - halfHeight;
		rectCoords[ 2 ] = lightPos - halfWidth + halfHeight;
		rectCoords[ 3 ] = lightPos + halfWidth + halfHeight;
		vec2 uv = LTC_Uv( normal, viewDir, roughness );
		vec4 t1 = texture2D( ltc_1, uv );
		vec4 t2 = texture2D( ltc_2, uv );
		mat3 mInv = mat3(
			vec3( t1.x, 0, t1.y ),
			vec3(    0, 1,    0 ),
			vec3( t1.z, 0, t1.w )
		);
		vec3 fresnel = ( material.specularColorBlended * t2.x + ( material.specularF90 - material.specularColorBlended ) * t2.y );
		reflectedLight.directSpecular += lightColor * fresnel * LTC_Evaluate( normal, viewDir, position, mInv, rectCoords );
		reflectedLight.directDiffuse += lightColor * material.diffuseContribution * LTC_Evaluate( normal, viewDir, position, mat3( 1.0 ), rectCoords );
		#ifdef USE_CLEARCOAT
			vec3 Ncc = geometryClearcoatNormal;
			vec2 uvClearcoat = LTC_Uv( Ncc, viewDir, material.clearcoatRoughness );
			vec4 t1Clearcoat = texture2D( ltc_1, uvClearcoat );
			vec4 t2Clearcoat = texture2D( ltc_2, uvClearcoat );
			mat3 mInvClearcoat = mat3(
				vec3( t1Clearcoat.x, 0, t1Clearcoat.y ),
				vec3(             0, 1,             0 ),
				vec3( t1Clearcoat.z, 0, t1Clearcoat.w )
			);
			vec3 fresnelClearcoat = material.clearcoatF0 * t2Clearcoat.x + ( material.clearcoatF90 - material.clearcoatF0 ) * t2Clearcoat.y;
			clearcoatSpecularDirect += lightColor * fresnelClearcoat * LTC_Evaluate( Ncc, viewDir, position, mInvClearcoat, rectCoords );
		#endif
	}
#endif
void RE_Direct_Physical( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	#ifdef USE_CLEARCOAT
		float dotNLcc = saturate( dot( geometryClearcoatNormal, directLight.direction ) );
		vec3 ccIrradiance = dotNLcc * directLight.color;
		clearcoatSpecularDirect += ccIrradiance * BRDF_GGX_Clearcoat( directLight.direction, geometryViewDir, geometryClearcoatNormal, material );
	#endif
	#ifdef USE_SHEEN
 
 		sheenSpecularDirect += irradiance * BRDF_Sheen( directLight.direction, geometryViewDir, geometryNormal, material.sheenColor, material.sheenRoughness );
 
 		float sheenAlbedoV = IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
 		float sheenAlbedoL = IBLSheenBRDF( geometryNormal, directLight.direction, material.sheenRoughness );
 
 		float sheenEnergyComp = 1.0 - max3( material.sheenColor ) * max( sheenAlbedoV, sheenAlbedoL );
 
 		irradiance *= sheenEnergyComp;
 
 	#endif
	vec3 specularBRDF = BRDF_GGX( directLight.direction, geometryViewDir, geometryNormal, material );
	#ifdef USE_RETROREFLECTION
		vec3 retroViewDir = reflect( - geometryViewDir, geometryNormal );
		vec3 retroSpecularBRDF = BRDF_GGX( directLight.direction, retroViewDir, geometryNormal, material );
		specularBRDF = mix( specularBRDF, retroSpecularBRDF, saturate( material.retroreflectivity ) );
	#endif
	reflectedLight.directSpecular += irradiance * specularBRDF * material.multiScatteringCompensation;
	vec3 halfDir = normalize( directLight.direction + geometryViewDir );
	float dotVH = saturate( dot( geometryViewDir, halfDir ) );
	vec3 F = F_Schlick( material.specularColor, material.specularF90, dotVH );
	#ifdef USE_RETROREFLECTION
		vec3 retroHalfDir = normalize( directLight.direction + retroViewDir );
		float dotRetroVH = saturate( dot( retroViewDir, retroHalfDir ) );
		vec3 retroF = F_Schlick( material.specularColor, material.specularF90, dotRetroVH );
		F = mix( F, retroF, saturate( material.retroreflectivity ) );
	#endif
	#ifdef USE_DIFFUSE_ROUGHNESS
		vec3 diffuseBRDF = BRDF_EON( directLight.direction, geometryViewDir, geometryNormal, material.diffuseColor, material.diffuseRoughness ) * ( 1.0 - material.metalness );
	#else
		vec3 diffuseBRDF = BRDF_Lambert( material.diffuseContribution );
	#endif
	reflectedLight.directDiffuse += irradiance * diffuseBRDF * ( 1.0 - F );
}
void RE_IndirectDiffuse_Physical( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	vec3 singleScattering = vec3( 0.0 );
	vec3 multiScattering = vec3( 0.0 );
	#ifdef USE_IRIDESCENCE
		computeMultiscatteringIridescence( material.dfg, material.specularColor, material.specularF90, material.iridescence, material.iridescenceF0Dielectric, singleScattering, multiScattering );
	#else
		computeMultiscattering( material.dfg, material.specularColor, material.specularF90, singleScattering, multiScattering );
	#endif
	#ifdef USE_DIFFUSE_ROUGHNESS
		float dotNV = saturate( dot( geometryNormal, geometryViewDir ) );
		vec3 diffuseAlbedo = EON_DirectionalAlbedo( material.diffuseColor, material.diffuseRoughness, dotNV ) * ( 1.0 - material.metalness );
		vec3 diffuse = irradiance * RECIPROCAL_PI * diffuseAlbedo * ( 1.0 - singleScattering - multiScattering );
	#else
		vec3 diffuse = irradiance * BRDF_Lambert( material.diffuseContribution ) * ( 1.0 - singleScattering - multiScattering );
	#endif
	#ifdef USE_SHEEN
		float sheenAlbedo = IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
		sheenSpecularIndirect += irradiance * material.sheenColor * sheenAlbedo * RECIPROCAL_PI;
		float sheenEnergyComp = 1.0 - max3( material.sheenColor ) * sheenAlbedo;
		diffuse *= sheenEnergyComp;
	#endif
	reflectedLight.indirectDiffuse += diffuse;
}
void RE_IndirectSpecular_Physical( const in vec3 radiance, const in vec3 irradiance, const in vec3 clearcoatRadiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight) {
	#ifdef USE_CLEARCOAT
		clearcoatSpecularIndirect += clearcoatRadiance * EnvironmentBRDF( geometryClearcoatNormal, geometryViewDir, material.clearcoatF0, material.clearcoatF90, material.clearcoatRoughness );
	#endif
	#ifdef USE_SHEEN
		sheenSpecularIndirect += irradiance * material.sheenColor * IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness ) * RECIPROCAL_PI;
 	#endif
	vec3 singleScatteringDielectric = vec3( 0.0 );
	vec3 multiScatteringDielectric = vec3( 0.0 );
	vec3 singleScatteringMetallic = vec3( 0.0 );
	vec3 multiScatteringMetallic = vec3( 0.0 );
	#ifdef USE_IRIDESCENCE
		computeMultiscatteringIridescence( material.dfg, material.specularColor, material.specularF90, material.iridescence, material.iridescenceF0Dielectric, singleScatteringDielectric, multiScatteringDielectric );
		computeMultiscatteringIridescence( material.dfg, material.diffuseColor, material.specularF90, material.iridescence, material.iridescenceF0Metallic, singleScatteringMetallic, multiScatteringMetallic );
	#else
		computeMultiscattering( material.dfg, material.specularColor, material.specularF90, singleScatteringDielectric, multiScatteringDielectric );
		computeMultiscattering( material.dfg, material.diffuseColor, material.specularF90, singleScatteringMetallic, multiScatteringMetallic );
	#endif
	vec3 singleScattering = mix( singleScatteringDielectric, singleScatteringMetallic, material.metalness );
	vec3 multiScattering = mix( multiScatteringDielectric, multiScatteringMetallic, material.metalness );
	vec3 totalScatteringDielectric = singleScatteringDielectric + multiScatteringDielectric;
	#ifdef USE_DIFFUSE_ROUGHNESS
		float dotNV = saturate( dot( geometryNormal, geometryViewDir ) );
		vec3 diffuse = EON_DirectionalAlbedo( material.diffuseColor, material.diffuseRoughness, dotNV ) * ( 1.0 - material.metalness ) * ( 1.0 - totalScatteringDielectric );
	#else
		vec3 diffuse = material.diffuseContribution * ( 1.0 - totalScatteringDielectric );
	#endif
	vec3 cosineWeightedIrradiance = irradiance * RECIPROCAL_PI;
	vec3 indirectSpecular = radiance * singleScattering;
	indirectSpecular += multiScattering * cosineWeightedIrradiance;
	vec3 indirectDiffuse = diffuse * cosineWeightedIrradiance;
	#ifdef USE_SHEEN
		float sheenAlbedo = IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
		float sheenEnergyComp = 1.0 - max3( material.sheenColor ) * sheenAlbedo;
		indirectSpecular *= sheenEnergyComp;
		indirectDiffuse *= sheenEnergyComp;
	#endif
	reflectedLight.indirectSpecular += indirectSpecular;
	reflectedLight.indirectDiffuse += indirectDiffuse;
}
#define RE_Direct				RE_Direct_Physical
#define RE_Direct_RectArea		RE_Direct_RectArea_Physical
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Physical
#define RE_IndirectSpecular		RE_IndirectSpecular_Physical
float computeSpecularOcclusion( const in float dotNV, const in float ambientOcclusion, const in float roughness ) {
	return saturate( pow( dotNV + ambientOcclusion, exp2( - 16.0 * roughness - 1.0 ) ) - 1.0 + ambientOcclusion );
}`,lights_fragment_begin:`
vec3 geometryPosition = - vViewPosition;
vec3 geometryNormal = normal;
vec3 geometryViewDir = ( isOrthographic ) ? vec3( 0, 0, 1 ) : normalize( vViewPosition );
vec3 geometryClearcoatNormal = vec3( 0.0 );
#ifdef USE_CLEARCOAT
	geometryClearcoatNormal = clearcoatNormal;
#endif
#ifdef USE_IRIDESCENCE
	float dotNVi = saturate( dot( normal, geometryViewDir ) );
	if ( material.iridescenceThickness == 0.0 ) {
		material.iridescence = 0.0;
	} else {
		material.iridescence = saturate( material.iridescence );
	}
	if ( material.iridescence > 0.0 ) {
		vec3 iridescenceFresnelDielectric = evalIridescence( 1.0, material.iridescenceIOR, dotNVi, material.iridescenceThickness, material.specularColor );
		vec3 iridescenceFresnelMetallic = evalIridescence( 1.0, material.iridescenceIOR, dotNVi, material.iridescenceThickness, material.diffuseColor );
		material.iridescenceFresnel = mix( iridescenceFresnelDielectric, iridescenceFresnelMetallic, material.metalness );
		material.iridescenceF0Dielectric = Schlick_to_F0( iridescenceFresnelDielectric, 1.0, dotNVi );
		material.iridescenceF0Metallic = Schlick_to_F0( iridescenceFresnelMetallic, 1.0, dotNVi );
	}
#endif
#ifdef STANDARD
	float dotNVms = saturate( dot( geometryNormal, geometryViewDir ) );
	material.dfg = texture2D( dfgLUT, vec2( material.roughness, dotNVms ) ).rg;
	#if ( NUM_SUN_LIGHTS > 0 || NUM_DIR_LIGHTS > 0 || NUM_POINT_LIGHTS > 0 || NUM_SPOT_LIGHTS > 0 )
		float EssMs = material.dfg.x + material.dfg.y;
		material.multiScatteringCompensation = 1.0 + material.specularColorBlended * ( 1.0 / EssMs - 1.0 );
	#endif
#endif
IncidentLight directLight;
#if ( NUM_POINT_LIGHTS > 0 ) && defined( RE_Direct )
	PointLight pointLight;
	#if defined( USE_SHADOWMAP ) && NUM_POINT_LIGHT_SHADOWS > 0
	PointLightShadow pointLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHTS; i ++ ) {
		pointLight = pointLights[ i ];
		getPointLightInfo( pointLight, geometryPosition, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_POINT_LIGHT_SHADOWS ) && ( defined( SHADOWMAP_TYPE_PCF ) || defined( SHADOWMAP_TYPE_BASIC ) )
		pointLightShadow = pointLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getPointShadow( pointShadowMap[ i ], pointLightShadow.shadowMapSize, pointLightShadow.shadowIntensity, pointLightShadow.shadowBias, pointLightShadow.shadowRadius, vPointShadowCoord[ i ], pointLightShadow.shadowCameraNear, pointLightShadow.shadowCameraFar ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_SPOT_LIGHTS > 0 ) && defined( RE_Direct )
	SpotLight spotLight;
	vec4 spotColor;
	vec3 spotLightCoord;
	bool inSpotLightMap;
	#if defined( USE_SHADOWMAP ) && NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHTS; i ++ ) {
		spotLight = spotLights[ i ];
		getSpotLightInfo( spotLight, geometryPosition, directLight );
		#if ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#define SPOT_LIGHT_MAP_INDEX UNROLLED_LOOP_INDEX
		#elif ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		#define SPOT_LIGHT_MAP_INDEX NUM_SPOT_LIGHT_MAPS
		#else
		#define SPOT_LIGHT_MAP_INDEX ( UNROLLED_LOOP_INDEX - NUM_SPOT_LIGHT_SHADOWS + NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#endif
		#if ( SPOT_LIGHT_MAP_INDEX < NUM_SPOT_LIGHT_MAPS )
			spotLightCoord = vSpotLightCoord[ i ].xyz / vSpotLightCoord[ i ].w;
			inSpotLightMap = all( lessThan( abs( spotLightCoord * 2. - 1. ), vec3( 1.0 ) ) );
			spotColor = texture2D( spotLightMap[ SPOT_LIGHT_MAP_INDEX ], spotLightCoord.xy );
			directLight.color = inSpotLightMap ? directLight.color * spotColor.rgb : directLight.color;
		#endif
		#undef SPOT_LIGHT_MAP_INDEX
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		spotLightShadow = spotLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( spotShadowMap[ i ], spotLightShadow.shadowMapSize, spotLightShadow.shadowIntensity, spotLightShadow.shadowBias, spotLightShadow.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_SUN_LIGHTS > 0 ) && defined( RE_Direct )
	SunLight sunLight;
	#if defined( USE_SHADOWMAP ) && NUM_SUN_LIGHT_SHADOWS > 0
	SunLightShadow sunLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SUN_LIGHTS; i ++ ) {
		sunLight = sunLights[ i ];
		getSunLightInfo( sunLight, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_SUN_LIGHT_SHADOWS )
		sunLightShadow = sunLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getSunShadow( sunShadowMap[ i ], sunLightShadow, UNROLLED_LOOP_INDEX ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_DIR_LIGHTS > 0 ) && defined( RE_Direct )
	DirectionalLight directionalLight;
	#if defined( USE_SHADOWMAP ) && NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHTS; i ++ ) {
		directionalLight = directionalLights[ i ];
		getDirectionalLightInfo( directionalLight, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_DIR_LIGHT_SHADOWS )
		directionalLightShadow = directionalLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( directionalShadowMap[ i ], directionalLightShadow.shadowMapSize, directionalLightShadow.shadowIntensity, directionalLightShadow.shadowBias, directionalLightShadow.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_RECT_AREA_LIGHTS > 0 ) && defined( RE_Direct_RectArea )
	RectAreaLight rectAreaLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_RECT_AREA_LIGHTS; i ++ ) {
		rectAreaLight = rectAreaLights[ i ];
		RE_Direct_RectArea( rectAreaLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if defined( RE_IndirectDiffuse )
	vec3 iblIrradiance = vec3( 0.0 );
	vec3 irradiance = getAmbientLightIrradiance( ambientLightColor );
	#if defined( USE_LIGHT_PROBES )
		irradiance += getLightProbeIrradiance( lightProbe, geometryNormal );
	#endif
	#if ( NUM_HEMI_LIGHTS > 0 )
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_HEMI_LIGHTS; i ++ ) {
			irradiance += getHemisphereLightIrradiance( hemisphereLights[ i ], geometryNormal );
		}
		#pragma unroll_loop_end
	#endif
	#if NUM_LIGHT_PROBE_GRIDS > 0
		vec3 probeWorldPos = ( ( vec4( geometryPosition, 1.0 ) - viewMatrix[ 3 ] ) * viewMatrix ).xyz;
		vec3 probeWorldNormal = transformNormalByInverseViewMatrix( geometryNormal, viewMatrix );
		int probeGrid = - 1;
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_LIGHT_PROBE_GRIDS; i ++ ) {
			if ( isInsideLightProbeGrid( probeWorldPos, probeWorldNormal, probesMin[ i ], probesMax[ i ], probesResolution[ i ] ) ) probeGrid = UNROLLED_LOOP_INDEX;
		}
		#pragma unroll_loop_end
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_LIGHT_PROBE_GRIDS; i ++ ) {
			if ( probeGrid == UNROLLED_LOOP_INDEX ) irradiance += getLightProbeGridIrradiance( probesSH[ i ], probesMin[ i ], probesMax[ i ], probesResolution[ i ], probeWorldPos, probeWorldNormal );
		}
		#pragma unroll_loop_end
	#endif
#endif
#if defined( RE_IndirectSpecular )
	vec3 radiance = vec3( 0.0 );
	vec3 clearcoatRadiance = vec3( 0.0 );
#endif`,lights_fragment_maps:`#if defined( RE_IndirectDiffuse )
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		vec3 lightMapIrradiance = lightMapTexel.rgb * lightMapIntensity;
		irradiance += lightMapIrradiance;
	#endif
	#if defined( USE_ENVMAP ) && defined( ENVMAP_TYPE_PMREM )
		#if defined( STANDARD ) || defined( LAMBERT ) || defined( PHONG )
			iblIrradiance += getIBLIrradiance( geometryNormal );
		#endif
	#endif
#endif
#if defined( USE_ENVMAP ) && defined( RE_IndirectSpecular )
	#ifdef USE_ANISOTROPY
		vec3 iblRadiance = getIBLAnisotropyRadiance( geometryViewDir, geometryNormal, material.roughness, material.anisotropyB, material.anisotropy );
	#else
		vec3 iblRadiance = getIBLRadiance( geometryViewDir, geometryNormal, material.roughness );
	#endif
	#ifdef USE_RETROREFLECTION
		#ifdef USE_ANISOTROPY
			vec3 retroIBLRadiance = getIBLAnisotropyRetroRadiance( geometryViewDir, geometryNormal, material.roughness, material.anisotropyB, material.anisotropy );
		#else
			vec3 retroIBLRadiance = getIBLRetroRadiance( geometryViewDir, geometryNormal, material.roughness );
		#endif
		iblRadiance = mix( iblRadiance, retroIBLRadiance, saturate( material.retroreflectivity ) );
	#endif
	radiance += iblRadiance;
	#ifdef USE_CLEARCOAT
		clearcoatRadiance += getIBLRadiance( geometryViewDir, geometryClearcoatNormal, material.clearcoatRoughness );
	#endif
#endif`,lights_fragment_end:`#if defined( RE_IndirectDiffuse )
	#if defined( LAMBERT ) || defined( PHONG )
		irradiance += iblIrradiance;
	#endif
	RE_IndirectDiffuse( irradiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif
#if defined( RE_IndirectSpecular )
	RE_IndirectSpecular( radiance, iblIrradiance, clearcoatRadiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif`,lightprobes_pars_fragment:`#if NUM_LIGHT_PROBE_GRIDS > 0
uniform highp sampler3D probesSH[ NUM_LIGHT_PROBE_GRIDS ];
uniform vec3 probesMin[ NUM_LIGHT_PROBE_GRIDS ];
uniform vec3 probesMax[ NUM_LIGHT_PROBE_GRIDS ];
uniform vec3 probesResolution[ NUM_LIGHT_PROBE_GRIDS ];
bool isInsideLightProbeGrid( vec3 worldPos, vec3 worldNormal, vec3 probesMin, vec3 probesMax, vec3 probesResolution ) {
	vec3 spacing = ( probesMax - probesMin ) / probesResolution;
	vec3 samplePos = worldPos + worldNormal * spacing * 0.5;
	vec3 margin = spacing * 0.01;
	return all( greaterThanEqual( samplePos, probesMin - margin ) ) && all( lessThanEqual( samplePos, probesMax + margin ) );
}
vec3 getLightProbeGridIrradiance( highp sampler3D probesSH, vec3 probesMin, vec3 probesMax, vec3 probesResolution, vec3 worldPos, vec3 worldNormal ) {
	vec3 res = probesResolution;
	vec3 gridRange = probesMax - probesMin;
	vec3 probeSpacing = gridRange / res;
	vec3 samplePos = worldPos + worldNormal * probeSpacing * 0.5;
	vec3 uvw = clamp( ( samplePos - probesMin ) / gridRange, 0.5 / res, 1.0 - 0.5 / res );
	float nz          = res.z;
	float paddedSlices = nz + 2.0;
	float atlasDepth  = 7.0 * paddedSlices;
	float uvZBase     = uvw.z * nz + 1.0;
	vec4 s0 = texture( probesSH, vec3( uvw.xy, ( uvZBase                       ) / atlasDepth ) );
	vec4 s1 = texture( probesSH, vec3( uvw.xy, ( uvZBase +       paddedSlices   ) / atlasDepth ) );
	vec4 s2 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 2.0 * paddedSlices   ) / atlasDepth ) );
	vec4 s3 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 3.0 * paddedSlices   ) / atlasDepth ) );
	vec4 s4 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 4.0 * paddedSlices   ) / atlasDepth ) );
	vec4 s5 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 5.0 * paddedSlices   ) / atlasDepth ) );
	vec4 s6 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 6.0 * paddedSlices   ) / atlasDepth ) );
	vec3 c0 = s0.xyz;
	vec3 c1 = vec3( s0.w, s1.xy );
	vec3 c2 = vec3( s1.zw, s2.x );
	vec3 c3 = s2.yzw;
	vec3 c4 = s3.xyz;
	vec3 c5 = vec3( s3.w, s4.xy );
	vec3 c6 = vec3( s4.zw, s5.x );
	vec3 c7 = s5.yzw;
	vec3 c8 = s6.xyz;
	float x = worldNormal.x, y = worldNormal.y, z = worldNormal.z;
	vec3 result = c0 * 0.886227;
	result += c1 * 2.0 * 0.511664 * y;
	result += c2 * 2.0 * 0.511664 * z;
	result += c3 * 2.0 * 0.511664 * x;
	result += c4 * 2.0 * 0.429043 * x * y;
	result += c5 * 2.0 * 0.429043 * y * z;
	result += c6 * ( 0.743125 * z * z - 0.247708 );
	result += c7 * 2.0 * 0.429043 * x * z;
	result += c8 * 0.429043 * ( x * x - y * y );
	return max( result, vec3( 0.0 ) );
}
#endif`,logdepthbuf_fragment:`#if defined( USE_LOGARITHMIC_DEPTH_BUFFER )
	gl_FragDepth = vIsPerspective == 0.0 ? gl_FragCoord.z : log2( vFragDepth ) * logDepthBufFC * 0.5;
#endif`,logdepthbuf_pars_fragment:`#if defined( USE_LOGARITHMIC_DEPTH_BUFFER )
	uniform float logDepthBufFC;
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,logdepthbuf_pars_vertex:`#ifdef USE_LOGARITHMIC_DEPTH_BUFFER
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,logdepthbuf_vertex:`#ifdef USE_LOGARITHMIC_DEPTH_BUFFER
	vFragDepth = 1.0 + gl_Position.w;
	vIsPerspective = float( isPerspectiveMatrix( projectionMatrix ) );
#endif`,map_fragment:`#ifdef USE_MAP
	vec4 sampledDiffuseColor = texture2D( map, vMapUv );
	#ifdef DECODE_VIDEO_TEXTURE
		sampledDiffuseColor = sRGBTransferEOTF( sampledDiffuseColor );
	#endif
	diffuseColor *= sampledDiffuseColor;
#endif`,map_pars_fragment:`#ifdef USE_MAP
	uniform sampler2D map;
#endif`,map_particle_fragment:`#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
	#if defined( USE_POINTS_UV )
		vec2 uv = vUv;
	#else
		vec2 uv = ( uvTransform * vec3( gl_PointCoord.x, 1.0 - gl_PointCoord.y, 1 ) ).xy;
	#endif
#endif
#ifdef USE_MAP
	diffuseColor *= texture2D( map, uv );
#endif
#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, uv ).g;
#endif`,map_particle_pars_fragment:`#if defined( USE_POINTS_UV )
	varying vec2 vUv;
#else
	#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
		uniform mat3 uvTransform;
	#endif
#endif
#ifdef USE_MAP
	uniform sampler2D map;
#endif
#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,metalnessmap_fragment:`float metalnessFactor = metalness;
#ifdef USE_METALNESSMAP
	vec4 texelMetalness = texture2D( metalnessMap, vMetalnessMapUv );
	metalnessFactor *= texelMetalness.b;
#endif`,metalnessmap_pars_fragment:`#ifdef USE_METALNESSMAP
	uniform sampler2D metalnessMap;
#endif`,morphinstance_vertex:`#ifdef USE_INSTANCING_MORPH
	float morphTargetInfluences[ MORPHTARGETS_COUNT ];
	float morphTargetBaseInfluence = texelFetch( morphTexture, ivec2( 0, gl_InstanceID ), 0 ).r;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		morphTargetInfluences[i] =  texelFetch( morphTexture, ivec2( i + 1, gl_InstanceID ), 0 ).r;
	}
#endif`,morphcolor_vertex:`#if defined( USE_MORPHCOLORS )
	#if defined( USE_COLOR_ALPHA )
		vColor *= morphTargetBaseInfluence;
	#elif defined( USE_COLOR )
		vColor.rgb *= morphTargetBaseInfluence;
	#endif
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		#if defined( USE_COLOR_ALPHA )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ) * morphTargetInfluences[ i ];
		#elif defined( USE_COLOR )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor.rgb += getMorph( gl_VertexID, i, 2 ).rgb * morphTargetInfluences[ i ];
		#endif
	}
#endif`,morphnormal_vertex:`#ifdef USE_MORPHNORMALS
	objectNormal *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		if ( morphTargetInfluences[ i ] != 0.0 ) objectNormal += getMorph( gl_VertexID, i, 1 ).xyz * morphTargetInfluences[ i ];
	}
#endif`,morphtarget_pars_vertex:`#ifdef USE_MORPHTARGETS
	#ifndef USE_INSTANCING_MORPH
		uniform float morphTargetBaseInfluence;
		uniform float morphTargetInfluences[ MORPHTARGETS_COUNT ];
	#endif
	uniform sampler2DArray morphTargetsTexture;
	uniform ivec2 morphTargetsTextureSize;
	vec4 getMorph( const in int vertexIndex, const in int morphTargetIndex, const in int offset ) {
		int texelIndex = vertexIndex * MORPHTARGETS_TEXTURE_STRIDE + offset;
		int y = texelIndex / morphTargetsTextureSize.x;
		int x = texelIndex - y * morphTargetsTextureSize.x;
		ivec3 morphUV = ivec3( x, y, morphTargetIndex );
		return texelFetch( morphTargetsTexture, morphUV, 0 );
	}
#endif`,morphtarget_vertex:`#ifdef USE_MORPHTARGETS
	transformed *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		if ( morphTargetInfluences[ i ] != 0.0 ) transformed += getMorph( gl_VertexID, i, 0 ).xyz * morphTargetInfluences[ i ];
	}
#endif`,normal_fragment_begin:`float faceDirection = gl_FrontFacing ? 1.0 : - 1.0;
#ifdef FLAT_SHADED
	vec3 fdx = dFdx( vViewPosition );
	vec3 fdy = dFdy( vViewPosition );
	vec3 normal = normalize( cross( fdx, fdy ) );
#else
	vec3 normal = normalize( vNormal );
	#ifdef DOUBLE_SIDED
		normal *= faceDirection;
	#endif
#endif
#if defined( USE_NORMALMAP_TANGENTSPACE ) || defined( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY )
	#ifdef USE_TANGENT
		mat3 tbn = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn = getTangentFrame( - vViewPosition, normal,
		#if defined( USE_NORMALMAP )
			vNormalMapUv
		#elif defined( USE_CLEARCOAT_NORMALMAP )
			vClearcoatNormalMapUv
		#else
			vUv
		#endif
		);
	#endif
	#ifdef DOUBLE_SIDED
		tbn[0] *= faceDirection;
		tbn[1] *= faceDirection;
	#endif
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	#ifdef USE_TANGENT
		mat3 tbn2 = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn2 = getTangentFrame( - vViewPosition, normal, vClearcoatNormalMapUv );
	#endif
	#ifdef DOUBLE_SIDED
		tbn2[0] *= faceDirection;
		tbn2[1] *= faceDirection;
	#endif
#endif
vec3 nonPerturbedNormal = normal;`,normal_fragment_maps:`#ifdef USE_NORMALMAP_OBJECTSPACE
	normal = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	#ifdef FLIP_SIDED
		normal = - normal;
	#endif
	#ifdef DOUBLE_SIDED
		normal = normal * faceDirection;
	#endif
	normal = normalize( normalMatrix * normal );
#elif defined( USE_NORMALMAP_TANGENTSPACE )
	vec3 mapN = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	#if defined( USE_PACKED_NORMALMAP )
		mapN = vec3( mapN.xy, sqrt( saturate( 1.0 - dot( mapN.xy, mapN.xy ) ) ) );
	#endif
	mapN.xy *= normalScale;
	normal = normalize( tbn * mapN );
#elif defined( USE_BUMPMAP )
	normal = perturbNormalArb( - vViewPosition, normal, dHdxy_fwd(), faceDirection );
#endif`,normal_pars_fragment:`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,normal_pars_vertex:`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,normal_vertex:`#ifndef FLAT_SHADED
	vNormal = normalize( transformedNormal );
	#ifdef USE_TANGENT
		vTangent = normalize( transformedTangent );
		vBitangent = normalize( cross( vNormal, vTangent ) * tangent.w );
		#ifdef FLIP_SIDED
			vBitangent = - vBitangent;
		#endif
	#endif
#endif`,normalmap_pars_fragment:`#ifdef USE_NORMALMAP
	uniform sampler2D normalMap;
	uniform vec2 normalScale;
#endif
#ifdef USE_NORMALMAP_OBJECTSPACE
	uniform mat3 normalMatrix;
#endif
#if ! defined ( USE_TANGENT ) && ( defined ( USE_NORMALMAP_TANGENTSPACE ) || defined ( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY ) )
	mat3 getTangentFrame( vec3 eye_pos, vec3 surf_norm, vec2 uv ) {
		vec3 q0 = dFdx( eye_pos.xyz );
		vec3 q1 = dFdy( eye_pos.xyz );
		vec2 st0 = dFdx( uv.st );
		vec2 st1 = dFdy( uv.st );
		vec3 N = surf_norm;
		vec3 q1perp = cross( q1, N );
		vec3 q0perp = cross( N, q0 );
		vec3 T = q1perp * st0.x + q0perp * st1.x;
		vec3 B = q1perp * st0.y + q0perp * st1.y;
		float det = max( dot( T, T ), dot( B, B ) );
		float scale = ( det == 0.0 ) ? 0.0 : inversesqrt( det );
		return mat3( T * scale, B * scale, N );
	}
#endif`,clearcoat_normal_fragment_begin:`#ifdef USE_CLEARCOAT
	vec3 clearcoatNormal = nonPerturbedNormal;
#endif`,clearcoat_normal_fragment_maps:`#ifdef USE_CLEARCOAT_NORMALMAP
	vec3 clearcoatMapN = texture2D( clearcoatNormalMap, vClearcoatNormalMapUv ).xyz * 2.0 - 1.0;
	clearcoatMapN.xy *= clearcoatNormalScale;
	clearcoatNormal = normalize( tbn2 * clearcoatMapN );
#endif`,clearcoat_pars_fragment:`#ifdef USE_CLEARCOATMAP
	uniform sampler2D clearcoatMap;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform sampler2D clearcoatNormalMap;
	uniform vec2 clearcoatNormalScale;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform sampler2D clearcoatRoughnessMap;
#endif`,iridescence_pars_fragment:`#ifdef USE_IRIDESCENCEMAP
	uniform sampler2D iridescenceMap;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform sampler2D iridescenceThicknessMap;
#endif`,opaque_fragment:`#ifdef OPAQUE
diffuseColor.a = 1.0;
#endif
#ifdef USE_TRANSMISSION
diffuseColor.a *= material.transmissionAlpha;
#endif
gl_FragColor = vec4( outgoingLight, diffuseColor.a );`,packing:`vec3 packNormalToRGB( const in vec3 normal ) {
	return normalize( normal ) * 0.5 + 0.5;
}
vec3 unpackRGBToNormal( const in vec3 rgb ) {
	return 2.0 * rgb.xyz - 1.0;
}
const float PackUpscale = 256. / 255.;const float UnpackDownscale = 255. / 256.;const float ShiftRight8 = 1. / 256.;
const float Inv255 = 1. / 255.;
const vec4 PackFactors = vec4( 1.0, 256.0, 256.0 * 256.0, 256.0 * 256.0 * 256.0 );
const vec2 UnpackFactors2 = vec2( UnpackDownscale, 1.0 / PackFactors.g );
const vec3 UnpackFactors3 = vec3( UnpackDownscale / PackFactors.rg, 1.0 / PackFactors.b );
const vec4 UnpackFactors4 = vec4( UnpackDownscale / PackFactors.rgb, 1.0 / PackFactors.a );
vec4 packDepthToRGBA( const in float v ) {
	if( v <= 0.0 )
		return vec4( 0., 0., 0., 0. );
	if( v >= 1.0 )
		return vec4( 1., 1., 1., 1. );
	float vuf;
	float af = modf( v * PackFactors.a, vuf );
	float bf = modf( vuf * ShiftRight8, vuf );
	float gf = modf( vuf * ShiftRight8, vuf );
	return vec4( vuf * Inv255, gf * PackUpscale, bf * PackUpscale, af );
}
vec3 packDepthToRGB( const in float v ) {
	if( v <= 0.0 )
		return vec3( 0., 0., 0. );
	if( v >= 1.0 )
		return vec3( 1., 1., 1. );
	float vuf;
	float bf = modf( v * PackFactors.b, vuf );
	float gf = modf( vuf * ShiftRight8, vuf );
	return vec3( vuf * Inv255, gf * PackUpscale, bf );
}
vec2 packDepthToRG( const in float v ) {
	if( v <= 0.0 )
		return vec2( 0., 0. );
	if( v >= 1.0 )
		return vec2( 1., 1. );
	float vuf;
	float gf = modf( v * 256., vuf );
	return vec2( vuf * Inv255, gf );
}
float unpackRGBAToDepth( const in vec4 v ) {
	return dot( v, UnpackFactors4 );
}
float unpackRGBToDepth( const in vec3 v ) {
	return dot( v, UnpackFactors3 );
}
float unpackRGToDepth( const in vec2 v ) {
	return v.r * UnpackFactors2.r + v.g * UnpackFactors2.g;
}
vec4 pack2HalfToRGBA( const in vec2 v ) {
	vec4 r = vec4( v.x, fract( v.x * 255.0 ), v.y, fract( v.y * 255.0 ) );
	return vec4( r.x - r.y / 255.0, r.y, r.z - r.w / 255.0, r.w );
}
vec2 unpackRGBATo2Half( const in vec4 v ) {
	return vec2( v.x + ( v.y / 255.0 ), v.z + ( v.w / 255.0 ) );
}
float viewZToOrthographicDepth( const in float viewZ, const in float near, const in float far ) {
	return ( viewZ + near ) / ( near - far );
}
float orthographicDepthToViewZ( const in float depth, const in float near, const in float far ) {
	#ifdef USE_REVERSED_DEPTH_BUFFER
	
		return depth * ( far - near ) - far;
	#else
		return depth * ( near - far ) - near;
	#endif
}
float viewZToPerspectiveDepth( const in float viewZ, const in float near, const in float far ) {
	return ( ( near + viewZ ) * far ) / ( ( far - near ) * viewZ );
}
float perspectiveDepthToViewZ( const in float depth, const in float near, const in float far ) {
	
	#ifdef USE_REVERSED_DEPTH_BUFFER
		return ( near * far ) / ( ( near - far ) * depth - near );
	#else
		return ( near * far ) / ( ( far - near ) * depth - far );
	#endif
}`,premultiplied_alpha_fragment:`#ifdef PREMULTIPLIED_ALPHA
	gl_FragColor.rgb *= gl_FragColor.a;
#endif`,project_vertex:`vec4 mvPosition = vec4( transformed, 1.0 );
#ifdef USE_BATCHING
	mvPosition = batchingMatrix * mvPosition;
#endif
#ifdef USE_INSTANCING
	mvPosition = instanceMatrix * mvPosition;
#endif
mvPosition = modelViewMatrix * mvPosition;
gl_Position = projectionMatrix * mvPosition;`,dithering_fragment:`#ifdef DITHERING
	gl_FragColor.rgb = dithering( gl_FragColor.rgb );
#endif`,dithering_pars_fragment:`#ifdef DITHERING
	vec3 dithering( vec3 color ) {
		float grid_position = rand( gl_FragCoord.xy );
		vec3 dither_shift_RGB = vec3( 0.25 / 255.0, -0.25 / 255.0, 0.25 / 255.0 );
		dither_shift_RGB = mix( 2.0 * dither_shift_RGB, -2.0 * dither_shift_RGB, grid_position );
		return color + dither_shift_RGB;
	}
#endif`,roughnessmap_fragment:`float roughnessFactor = roughness;
#ifdef USE_ROUGHNESSMAP
	vec4 texelRoughness = texture2D( roughnessMap, vRoughnessMapUv );
	roughnessFactor *= texelRoughness.g;
#endif`,roughnessmap_pars_fragment:`#ifdef USE_ROUGHNESSMAP
	uniform sampler2D roughnessMap;
#endif`,shadowmap_pars_fragment:`#if NUM_SPOT_LIGHT_COORDS > 0
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#if NUM_SPOT_LIGHT_MAPS > 0
	uniform sampler2D spotLightMap[ NUM_SPOT_LIGHT_MAPS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_SUN_LIGHT_SHADOWS > 0
		#define SUN_LIGHT_CASCADES 2
		#if defined( SHADOWMAP_TYPE_PCF )
			uniform sampler2DShadow sunShadowMap[ NUM_SUN_LIGHT_SHADOWS ];
		#else
			uniform sampler2D sunShadowMap[ NUM_SUN_LIGHT_SHADOWS ];
		#endif
		uniform mat4 sunShadowMatrix[ NUM_SUN_LIGHT_SHADOWS * SUN_LIGHT_CASCADES ];
		uniform vec4 sunShadowCascade[ NUM_SUN_LIGHT_SHADOWS * SUN_LIGHT_CASCADES ];
		varying vec4 vSunShadowWorldPosition;
		varying vec3 vSunShadowWorldNormal;
		struct SunLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SunLightShadow sunLightShadows[ NUM_SUN_LIGHT_SHADOWS ];
	#endif
	#if NUM_DIR_LIGHT_SHADOWS > 0
		#if defined( SHADOWMAP_TYPE_PCF )
			uniform sampler2DShadow directionalShadowMap[ NUM_DIR_LIGHT_SHADOWS ];
		#else
			uniform sampler2D directionalShadowMap[ NUM_DIR_LIGHT_SHADOWS ];
		#endif
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		#if defined( SHADOWMAP_TYPE_PCF )
			uniform sampler2DShadow spotShadowMap[ NUM_SPOT_LIGHT_SHADOWS ];
		#else
			uniform sampler2D spotShadowMap[ NUM_SPOT_LIGHT_SHADOWS ];
		#endif
		struct SpotLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		#if defined( SHADOWMAP_TYPE_PCF )
			uniform samplerCubeShadow pointShadowMap[ NUM_POINT_LIGHT_SHADOWS ];
		#elif defined( SHADOWMAP_TYPE_BASIC )
			uniform samplerCube pointShadowMap[ NUM_POINT_LIGHT_SHADOWS ];
		#endif
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
	#if defined( SHADOWMAP_TYPE_PCF )
		float interleavedGradientNoise( vec2 position ) {
			return fract( 52.9829189 * fract( dot( position, vec2( 0.06711056, 0.00583715 ) ) ) );
		}
		vec2 vogelDiskSample( int sampleIndex, int samplesCount, float phi ) {
			const float goldenAngle = 2.399963229728653;
			float r = sqrt( ( float( sampleIndex ) + 0.5 ) / float( samplesCount ) );
			float theta = float( sampleIndex ) * goldenAngle + phi;
			return vec2( cos( theta ), sin( theta ) ) * r;
		}
	#endif
	#if defined( SHADOWMAP_TYPE_PCF )
		float getShadow( sampler2DShadow shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
			float shadow = 1.0;
			shadowCoord.xyz /= shadowCoord.w;
			#ifdef USE_REVERSED_DEPTH_BUFFER
				shadowCoord.z -= shadowBias;
			#else
				shadowCoord.z += shadowBias;
			#endif
			bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
			bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
			if ( frustumTest ) {
				vec2 texelSize = vec2( 1.0 ) / shadowMapSize;
				vec2 radius = shadowRadius * texelSize;
				float phi = interleavedGradientNoise( gl_FragCoord.xy ) * PI2;
				shadow = (
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 0, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 1, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 2, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 3, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 4, 5, phi ) * radius, shadowCoord.z ) )
				) * 0.2;
			}
			return mix( 1.0, shadow, shadowIntensity );
		}
	#elif defined( SHADOWMAP_TYPE_VSM )
		float getShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
			float shadow = 1.0;
			shadowCoord.xyz /= shadowCoord.w;
			#ifdef USE_REVERSED_DEPTH_BUFFER
				shadowCoord.z -= shadowBias;
			#else
				shadowCoord.z += shadowBias;
			#endif
			bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
			bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
			if ( frustumTest ) {
				vec2 distribution = texture2D( shadowMap, shadowCoord.xy ).rg;
				float mean = distribution.x;
				float variance = distribution.y * distribution.y;
				#ifdef USE_REVERSED_DEPTH_BUFFER
					float hard_shadow = step( mean, shadowCoord.z );
				#else
					float hard_shadow = step( shadowCoord.z, mean );
				#endif
				
				if ( hard_shadow == 1.0 ) {
					shadow = 1.0;
				} else {
					variance = max( variance, 0.0000001 );
					float d = shadowCoord.z - mean;
					float p_max = variance / ( variance + d * d );
					p_max = clamp( ( p_max - 0.3 ) / 0.65, 0.0, 1.0 );
					shadow = max( hard_shadow, p_max );
				}
			}
			return mix( 1.0, shadow, shadowIntensity );
		}
	#else
		float getShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
			float shadow = 1.0;
			shadowCoord.xyz /= shadowCoord.w;
			#ifdef USE_REVERSED_DEPTH_BUFFER
				shadowCoord.z -= shadowBias;
			#else
				shadowCoord.z += shadowBias;
			#endif
			bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
			bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
			if ( frustumTest ) {
				float depth = texture2D( shadowMap, shadowCoord.xy ).r;
				#ifdef USE_REVERSED_DEPTH_BUFFER
					shadow = step( depth, shadowCoord.z );
				#else
					shadow = step( shadowCoord.z, depth );
				#endif
			}
			return mix( 1.0, shadow, shadowIntensity );
		}
	#endif
	#if NUM_SUN_LIGHT_SHADOWS > 0
		float getSunShadow(
			#if defined( SHADOWMAP_TYPE_PCF )
				sampler2DShadow shadowMap,
			#else
				sampler2D shadowMap,
			#endif
			SunLightShadow sunLightShadow,
			int shadowIndex
		) {
			vec4 shadowWorldPosition = vec4( vSunShadowWorldPosition.xyz + vSunShadowWorldNormal * sunLightShadow.shadowNormalBias, 1.0 );
			float viewDepth = vSunShadowWorldPosition.w;
			int cascadeOffset = shadowIndex * SUN_LIGHT_CASCADES;
			float shadow = 1.0;
			for ( int i = SUN_LIGHT_CASCADES - 1; i >= 0; i -- ) {
				vec4 cascade = sunShadowCascade[ cascadeOffset + i ];
				if ( viewDepth >= cascade.x && viewDepth < cascade.y ) {
					float cascadeShadow = getShadow(
						shadowMap,
						sunLightShadow.shadowMapSize,
						sunLightShadow.shadowIntensity,
						sunLightShadow.shadowBias,
						sunLightShadow.shadowRadius,
						sunShadowMatrix[ cascadeOffset + i ] * shadowWorldPosition
					);
					shadow = mix( cascadeShadow, shadow, smoothstep( cascade.z, cascade.y, viewDepth ) );
				}
			}
			return shadow;
		}
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
	#if defined( SHADOWMAP_TYPE_PCF )
	float getPointShadow( samplerCubeShadow shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord, float shadowCameraNear, float shadowCameraFar ) {
		float shadow = 1.0;
		vec3 lightToPosition = shadowCoord.xyz;
		vec3 bd3D = normalize( lightToPosition );
		vec3 absVec = abs( lightToPosition );
		float viewSpaceZ = max( max( absVec.x, absVec.y ), absVec.z );
		if ( viewSpaceZ - shadowCameraFar <= 0.0 && viewSpaceZ - shadowCameraNear >= 0.0 ) {
			float lightDistance = length( lightToPosition );
			float depthRange = shadowCameraFar - shadowCameraNear;
			#ifdef USE_REVERSED_DEPTH_BUFFER
				float depthA = - shadowCameraNear / depthRange - shadowBias;
				float depthB = shadowCameraNear * shadowCameraFar / ( depthRange * lightDistance );
			#else
				float depthA = shadowCameraFar / depthRange + shadowBias;
				float depthB = - shadowCameraNear * shadowCameraFar / ( depthRange * lightDistance );
			#endif
			float texelSize = shadowRadius / shadowMapSize.x;
			vec3 absDir = abs( bd3D );
			vec3 tangent = absDir.x > absDir.z ? vec3( 0.0, 1.0, 0.0 ) : vec3( 1.0, 0.0, 0.0 );
			tangent = normalize( cross( bd3D, tangent ) );
			vec3 bitangent = cross( bd3D, tangent );
			float phi = interleavedGradientNoise( gl_FragCoord.xy ) * PI2;
			shadow = 0.0;
			for ( int i = 0; i < 5; i ++ ) {
				vec2 offset = vogelDiskSample( i, 5, phi );
				vec3 direction = bd3D + ( tangent * offset.x + bitangent * offset.y ) * texelSize;
				vec3 absDirection = abs( direction );
				float dp = depthA + depthB / max( max( absDirection.x, absDirection.y ), absDirection.z );
				shadow += texture( shadowMap, vec4( direction, dp ) );
			}
			shadow *= 0.2;
		}
		return mix( 1.0, shadow, shadowIntensity );
	}
	#elif defined( SHADOWMAP_TYPE_BASIC )
	float getPointShadow( samplerCube shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord, float shadowCameraNear, float shadowCameraFar ) {
		float shadow = 1.0;
		vec3 lightToPosition = shadowCoord.xyz;
		vec3 absVec = abs( lightToPosition );
		float viewSpaceZ = max( max( absVec.x, absVec.y ), absVec.z );
		if ( viewSpaceZ - shadowCameraFar <= 0.0 && viewSpaceZ - shadowCameraNear >= 0.0 ) {
			float dp = ( shadowCameraFar * ( viewSpaceZ - shadowCameraNear ) ) / ( viewSpaceZ * ( shadowCameraFar - shadowCameraNear ) );
			dp += shadowBias;
			vec3 bd3D = normalize( lightToPosition );
			float depth = textureCube( shadowMap, bd3D ).r;
			#ifdef USE_REVERSED_DEPTH_BUFFER
				depth = 1.0 - depth;
			#endif
			shadow = step( dp, depth );
		}
		return mix( 1.0, shadow, shadowIntensity );
	}
	#endif
	#endif
#endif`,shadowmap_pars_vertex:`#if NUM_SPOT_LIGHT_COORDS > 0
	uniform mat4 spotLightMatrix[ NUM_SPOT_LIGHT_COORDS ];
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_SUN_LIGHT_SHADOWS > 0
		varying vec4 vSunShadowWorldPosition;
		varying vec3 vSunShadowWorldNormal;
	#endif
	#if NUM_DIR_LIGHT_SHADOWS > 0
		uniform mat4 directionalShadowMatrix[ NUM_DIR_LIGHT_SHADOWS ];
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		struct SpotLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		uniform mat4 pointShadowMatrix[ NUM_POINT_LIGHT_SHADOWS ];
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
#endif`,shadowmap_vertex:`#if ( defined( USE_SHADOWMAP ) && ( NUM_DIR_LIGHT_SHADOWS > 0 || NUM_SUN_LIGHT_SHADOWS > 0 || NUM_POINT_LIGHT_SHADOWS > 0 ) ) || ( NUM_SPOT_LIGHT_COORDS > 0 )
	#ifdef HAS_NORMAL
		vec3 shadowWorldNormal = transformNormalByInverseViewMatrix( transformedNormal, viewMatrix );
	#else
		vec3 shadowWorldNormal = vec3( 0.0 );
	#endif
	vec4 shadowWorldPosition;
#endif
#if defined( USE_SHADOWMAP )
	#if NUM_SUN_LIGHT_SHADOWS > 0
		vSunShadowWorldPosition = vec4( worldPosition.xyz, - mvPosition.z );
		vSunShadowWorldNormal = shadowWorldNormal;
	#endif
	#if NUM_DIR_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * directionalLightShadows[ i ].shadowNormalBias, 0 );
			vDirectionalShadowCoord[ i ] = directionalShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * pointLightShadows[ i ].shadowNormalBias, 0 );
			vPointShadowCoord[ i ] = pointShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
#endif
#if NUM_SPOT_LIGHT_COORDS > 0
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_COORDS; i ++ ) {
		shadowWorldPosition = worldPosition;
		#if ( defined( USE_SHADOWMAP ) && UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
			shadowWorldPosition.xyz += shadowWorldNormal * spotLightShadows[ i ].shadowNormalBias;
		#endif
		vSpotLightCoord[ i ] = spotLightMatrix[ i ] * shadowWorldPosition;
	}
	#pragma unroll_loop_end
#endif`,shadowmask_pars_fragment:`float getShadowMask() {
	float shadow = 1.0;
	#ifdef USE_SHADOWMAP
	#if NUM_SUN_LIGHT_SHADOWS > 0
	SunLightShadow sunLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SUN_LIGHT_SHADOWS; i ++ ) {
		sunLight = sunLightShadows[ i ];
		shadow *= receiveShadow ? getSunShadow( sunShadowMap[ i ], sunLight, UNROLLED_LOOP_INDEX ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
		directionalLight = directionalLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( directionalShadowMap[ i ], directionalLight.shadowMapSize, directionalLight.shadowIntensity, directionalLight.shadowBias, directionalLight.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_SHADOWS; i ++ ) {
		spotLight = spotLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( spotShadowMap[ i ], spotLight.shadowMapSize, spotLight.shadowIntensity, spotLight.shadowBias, spotLight.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0 && ( defined( SHADOWMAP_TYPE_PCF ) || defined( SHADOWMAP_TYPE_BASIC ) )
	PointLightShadow pointLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
		pointLight = pointLightShadows[ i ];
		shadow *= receiveShadow ? getPointShadow( pointShadowMap[ i ], pointLight.shadowMapSize, pointLight.shadowIntensity, pointLight.shadowBias, pointLight.shadowRadius, vPointShadowCoord[ i ], pointLight.shadowCameraNear, pointLight.shadowCameraFar ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#endif
	return shadow;
}`,skinbase_vertex:`#ifdef USE_SKINNING
	mat4 boneMatX = getBoneMatrix( skinIndex.x );
	mat4 boneMatY = getBoneMatrix( skinIndex.y );
	mat4 boneMatZ = getBoneMatrix( skinIndex.z );
	mat4 boneMatW = getBoneMatrix( skinIndex.w );
#endif`,skinning_pars_vertex:`#ifdef USE_SKINNING
	uniform mat4 bindMatrix;
	uniform mat4 bindMatrixInverse;
	uniform highp sampler2D boneTexture;
	mat4 getBoneMatrix( const in float i ) {
		int size = textureSize( boneTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( boneTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( boneTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( boneTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( boneTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
#endif`,skinning_vertex:`#ifdef USE_SKINNING
	vec4 skinVertex = bindMatrix * vec4( transformed, 1.0 );
	vec4 skinned = vec4( 0.0 );
	skinned += boneMatX * skinVertex * skinWeight.x;
	skinned += boneMatY * skinVertex * skinWeight.y;
	skinned += boneMatZ * skinVertex * skinWeight.z;
	skinned += boneMatW * skinVertex * skinWeight.w;
	transformed = ( bindMatrixInverse * skinned ).xyz;
#endif`,skinnormal_vertex:`#ifdef USE_SKINNING
	mat4 skinMatrix = mat4( 0.0 );
	skinMatrix += skinWeight.x * boneMatX;
	skinMatrix += skinWeight.y * boneMatY;
	skinMatrix += skinWeight.z * boneMatZ;
	skinMatrix += skinWeight.w * boneMatW;
	skinMatrix = bindMatrixInverse * skinMatrix * bindMatrix;
	objectNormal = vec4( skinMatrix * vec4( objectNormal, 0.0 ) ).xyz;
	#ifdef USE_TANGENT
		objectTangent = vec4( skinMatrix * vec4( objectTangent, 0.0 ) ).xyz;
	#endif
#endif`,specularmap_fragment:`float specularStrength;
#ifdef USE_SPECULARMAP
	vec4 texelSpecular = texture2D( specularMap, vSpecularMapUv );
	specularStrength = texelSpecular.r;
#else
	specularStrength = 1.0;
#endif`,specularmap_pars_fragment:`#ifdef USE_SPECULARMAP
	uniform sampler2D specularMap;
#endif`,tonemapping_fragment:`#if defined( TONE_MAPPING )
	gl_FragColor.rgb = toneMapping( gl_FragColor.rgb );
#endif`,tonemapping_pars_fragment:`#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
uniform float toneMappingExposure;
vec3 LinearToneMapping( vec3 color ) {
	return saturate( toneMappingExposure * color );
}
vec3 ReinhardToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	return saturate( color / ( vec3( 1.0 ) + color ) );
}
vec3 CineonToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	color = max( vec3( 0.0 ), color - 0.004 );
	return pow( ( color * ( 6.2 * color + 0.5 ) ) / ( color * ( 6.2 * color + 1.7 ) + 0.06 ), vec3( 2.2 ) );
}
vec3 RRTAndODTFit( vec3 v ) {
	vec3 a = v * ( v + 0.0245786 ) - 0.000090537;
	vec3 b = v * ( 0.983729 * v + 0.4329510 ) + 0.238081;
	return a / b;
}
vec3 ACESFilmicToneMapping( vec3 color ) {
	const mat3 ACESInputMat = mat3(
		vec3( 0.59719, 0.07600, 0.02840 ),		vec3( 0.35458, 0.90834, 0.13383 ),
		vec3( 0.04823, 0.01566, 0.83777 )
	);
	const mat3 ACESOutputMat = mat3(
		vec3(  1.60475, -0.10208, -0.00327 ),		vec3( -0.53108,  1.10813, -0.07276 ),
		vec3( -0.07367, -0.00605,  1.07602 )
	);
	color *= toneMappingExposure / 0.6;
	color = ACESInputMat * color;
	color = RRTAndODTFit( color );
	color = ACESOutputMat * color;
	return saturate( color );
}
const mat3 LINEAR_REC2020_TO_LINEAR_SRGB = mat3(
	vec3( 1.6605, - 0.1246, - 0.0182 ),
	vec3( - 0.5876, 1.1329, - 0.1006 ),
	vec3( - 0.0728, - 0.0083, 1.1187 )
);
const mat3 LINEAR_SRGB_TO_LINEAR_REC2020 = mat3(
	vec3( 0.6274, 0.0691, 0.0164 ),
	vec3( 0.3293, 0.9195, 0.0880 ),
	vec3( 0.0433, 0.0113, 0.8956 )
);
vec3 agxDefaultContrastApprox( vec3 x ) {
	vec3 x2 = x * x;
	vec3 x4 = x2 * x2;
	return + 15.5 * x4 * x2
		- 40.14 * x4 * x
		+ 31.96 * x4
		- 6.868 * x2 * x
		+ 0.4298 * x2
		+ 0.1191 * x
		- 0.00232;
}
vec3 AgXToneMapping( vec3 color ) {
	const mat3 AgXInsetMatrix = mat3(
		vec3( 0.856627153315983, 0.137318972929847, 0.11189821299995 ),
		vec3( 0.0951212405381588, 0.761241990602591, 0.0767994186031903 ),
		vec3( 0.0482516061458583, 0.101439036467562, 0.811302368396859 )
	);
	const mat3 AgXOutsetMatrix = mat3(
		vec3( 1.1271005818144368, - 0.1413297634984383, - 0.14132976349843826 ),
		vec3( - 0.11060664309660323, 1.157823702216272, - 0.11060664309660294 ),
		vec3( - 0.016493938717834573, - 0.016493938717834257, 1.2519364065950405 )
	);
	const float AgxMinEv = - 12.47393;	const float AgxMaxEv = 4.026069;
	color *= toneMappingExposure;
	color = LINEAR_SRGB_TO_LINEAR_REC2020 * color;
	color = AgXInsetMatrix * color;
	color = max( color, 1e-10 );	color = log2( color );
	color = ( color - AgxMinEv ) / ( AgxMaxEv - AgxMinEv );
	color = clamp( color, 0.0, 1.0 );
	color = agxDefaultContrastApprox( color );
	color = AgXOutsetMatrix * color;
	color = pow( max( vec3( 0.0 ), color ), vec3( 2.2 ) );
	color = LINEAR_REC2020_TO_LINEAR_SRGB * color;
	color = clamp( color, 0.0, 1.0 );
	return color;
}
vec3 NeutralToneMapping( vec3 color ) {
	const float StartCompression = 0.8 - 0.04;
	const float Desaturation = 0.15;
	color *= toneMappingExposure;
	float x = min( color.r, min( color.g, color.b ) );
	float offset = x < 0.08 ? x - 6.25 * x * x : 0.04;
	color -= offset;
	float peak = max( color.r, max( color.g, color.b ) );
	if ( peak < StartCompression ) return color;
	float d = 1. - StartCompression;
	float newPeak = 1. - d * d / ( peak + d - StartCompression );
	color *= newPeak / peak;
	float g = 1. - 1. / ( Desaturation * ( peak - newPeak ) + 1. );
	return mix( color, vec3( newPeak ), g );
}
vec3 CustomToneMapping( vec3 color ) { return color; }`,transmission_fragment:`#ifdef USE_TRANSMISSION
	material.transmission = transmission;
	material.transmissionAlpha = 1.0;
	material.thickness = thickness;
	material.attenuationDistance = attenuationDistance;
	material.attenuationColor = attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		material.transmission *= texture2D( transmissionMap, vTransmissionMapUv ).r;
	#endif
	#ifdef USE_THICKNESSMAP
		material.thickness *= texture2D( thicknessMap, vThicknessMapUv ).g;
	#endif
	vec3 pos = vWorldPosition;
	vec3 v = normalize( cameraPosition - pos );
	vec3 n = transformNormalByInverseViewMatrix( normal, viewMatrix );
	vec4 transmitted = getIBLVolumeRefraction(
		n, v, material.roughness, material.diffuseContribution, material.specularColorBlended, material.specularF90,
		pos, modelMatrix, viewMatrix, projectionMatrix, material.dispersion, material.ior, material.thickness,
		material.attenuationColor, material.attenuationDistance );
	material.transmissionAlpha = mix( material.transmissionAlpha, transmitted.a, material.transmission );
	totalDiffuse = mix( totalDiffuse, transmitted.rgb, material.transmission );
#endif`,transmission_pars_fragment:`#ifdef USE_TRANSMISSION
	uniform float transmission;
	uniform float thickness;
	uniform float attenuationDistance;
	uniform vec3 attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		uniform sampler2D transmissionMap;
	#endif
	#ifdef USE_THICKNESSMAP
		uniform sampler2D thicknessMap;
	#endif
	uniform vec2 transmissionSamplerSize;
	uniform sampler2D transmissionSamplerMap;
	uniform mat4 modelMatrix;
	uniform mat4 projectionMatrix;
	varying vec3 vWorldPosition;
	float w0( float a ) {
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - a + 3.0 ) - 3.0 ) + 1.0 );
	}
	float w1( float a ) {
		return ( 1.0 / 6.0 ) * ( a *  a * ( 3.0 * a - 6.0 ) + 4.0 );
	}
	float w2( float a ){
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - 3.0 * a + 3.0 ) + 3.0 ) + 1.0 );
	}
	float w3( float a ) {
		return ( 1.0 / 6.0 ) * ( a * a * a );
	}
	float g0( float a ) {
		return w0( a ) + w1( a );
	}
	float g1( float a ) {
		return w2( a ) + w3( a );
	}
	float h0( float a ) {
		return - 1.0 + w1( a ) / ( w0( a ) + w1( a ) );
	}
	float h1( float a ) {
		return 1.0 + w3( a ) / ( w2( a ) + w3( a ) );
	}
	vec4 bicubic( sampler2D tex, vec2 uv, vec4 texelSize, float lod ) {
		uv = uv * texelSize.zw + 0.5;
		vec2 iuv = floor( uv );
		vec2 fuv = fract( uv );
		float g0x = g0( fuv.x );
		float g1x = g1( fuv.x );
		float h0x = h0( fuv.x );
		float h1x = h1( fuv.x );
		float h0y = h0( fuv.y );
		float h1y = h1( fuv.y );
		vec2 p0 = ( vec2( iuv.x + h0x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p1 = ( vec2( iuv.x + h1x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p2 = ( vec2( iuv.x + h0x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		vec2 p3 = ( vec2( iuv.x + h1x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		return g0( fuv.y ) * ( g0x * textureLod( tex, p0, lod ) + g1x * textureLod( tex, p1, lod ) ) +
			g1( fuv.y ) * ( g0x * textureLod( tex, p2, lod ) + g1x * textureLod( tex, p3, lod ) );
	}
	vec4 textureBicubic( sampler2D sampler, vec2 uv, float lod ) {
		vec2 fLodSize = vec2( textureSize( sampler, int( lod ) ) );
		vec2 cLodSize = vec2( textureSize( sampler, int( lod + 1.0 ) ) );
		vec2 fLodSizeInv = 1.0 / fLodSize;
		vec2 cLodSizeInv = 1.0 / cLodSize;
		vec4 fSample = bicubic( sampler, uv, vec4( fLodSizeInv, fLodSize ), floor( lod ) );
		vec4 cSample = bicubic( sampler, uv, vec4( cLodSizeInv, cLodSize ), ceil( lod ) );
		return mix( fSample, cSample, fract( lod ) );
	}
	vec3 getVolumeTransmissionRay( const in vec3 n, const in vec3 v, const in float thickness, const in float ior, const in mat4 modelMatrix ) {
		vec3 refractionVector = refract( - v, normalize( n ), 1.0 / ior );
		vec3 modelScale;
		modelScale.x = length( vec3( modelMatrix[ 0 ].xyz ) );
		modelScale.y = length( vec3( modelMatrix[ 1 ].xyz ) );
		modelScale.z = length( vec3( modelMatrix[ 2 ].xyz ) );
		return normalize( refractionVector ) * thickness * modelScale;
	}
	float applyIorToRoughness( const in float roughness, const in float ior ) {
		return roughness * clamp( ior * 2.0 - 2.0, 0.0, 1.0 );
	}
	vec4 getTransmissionSample( const in vec2 fragCoord, const in float roughness, const in float ior ) {
		float lod = log2( transmissionSamplerSize.x ) * applyIorToRoughness( roughness, ior );
		return textureBicubic( transmissionSamplerMap, fragCoord.xy, lod );
	}
	vec3 volumeAttenuation( const in float transmissionDistance, const in vec3 attenuationColor, const in float attenuationDistance ) {
		if ( isinf( attenuationDistance ) ) {
			return vec3( 1.0 );
		} else {
			vec3 attenuationCoefficient = -log( attenuationColor ) / attenuationDistance;
			vec3 transmittance = exp( - attenuationCoefficient * transmissionDistance );			return transmittance;
		}
	}
	vec4 getIBLVolumeRefraction( const in vec3 n, const in vec3 v, const in float roughness, const in vec3 diffuseColor,
		const in vec3 specularColor, const in float specularF90, const in vec3 position, const in mat4 modelMatrix,
		const in mat4 viewMatrix, const in mat4 projMatrix, const in float dispersion, const in float ior, const in float thickness,
		const in vec3 attenuationColor, const in float attenuationDistance ) {
		vec4 transmittedLight;
		vec3 transmittance;
		#ifdef USE_DISPERSION
			float halfSpread = ( ior - 1.0 ) * 0.025 * dispersion;
			vec3 iors = vec3( ior - halfSpread, ior, ior + halfSpread );
			for ( int i = 0; i < 3; i ++ ) {
				vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, iors[ i ], modelMatrix );
				vec3 refractedRayExit = position + transmissionRay;
				vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
				vec2 refractionCoords = ndcPos.xy / ndcPos.w;
				refractionCoords += 1.0;
				refractionCoords /= 2.0;
				vec4 transmissionSample = getTransmissionSample( refractionCoords, roughness, iors[ i ] );
				transmittedLight[ i ] = transmissionSample[ i ];
				transmittedLight.a += transmissionSample.a;
				transmittance[ i ] = diffuseColor[ i ] * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance )[ i ];
			}
			transmittedLight.a /= 3.0;
		#else
			vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, ior, modelMatrix );
			vec3 refractedRayExit = position + transmissionRay;
			vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
			vec2 refractionCoords = ndcPos.xy / ndcPos.w;
			refractionCoords += 1.0;
			refractionCoords /= 2.0;
			transmittedLight = getTransmissionSample( refractionCoords, roughness, ior );
			transmittance = diffuseColor * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance );
		#endif
		vec3 attenuatedColor = transmittance * transmittedLight.rgb;
		vec3 F = EnvironmentBRDF( n, v, specularColor, specularF90, roughness );
		float transmittanceFactor = ( transmittance.r + transmittance.g + transmittance.b ) / 3.0;
		return vec4( ( 1.0 - F ) * attenuatedColor, 1.0 - ( 1.0 - transmittedLight.a ) * transmittanceFactor );
	}
#endif`,uv_pars_fragment:`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_DIFFUSE_ROUGHNESSMAP
	varying vec2 vDiffuseRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_SPECULARMAP
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,uv_pars_vertex:`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	uniform mat3 mapTransform;
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	uniform mat3 alphaMapTransform;
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	uniform mat3 lightMapTransform;
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	uniform mat3 aoMapTransform;
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	uniform mat3 bumpMapTransform;
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	uniform mat3 normalMapTransform;
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_DISPLACEMENTMAP
	uniform mat3 displacementMapTransform;
	varying vec2 vDisplacementMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	uniform mat3 emissiveMapTransform;
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	uniform mat3 metalnessMapTransform;
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	uniform mat3 roughnessMapTransform;
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_DIFFUSE_ROUGHNESSMAP
	uniform mat3 diffuseRoughnessMapTransform;
	varying vec2 vDiffuseRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	uniform mat3 anisotropyMapTransform;
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	uniform mat3 clearcoatMapTransform;
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform mat3 clearcoatNormalMapTransform;
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform mat3 clearcoatRoughnessMapTransform;
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	uniform mat3 sheenColorMapTransform;
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	uniform mat3 sheenRoughnessMapTransform;
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	uniform mat3 iridescenceMapTransform;
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform mat3 iridescenceThicknessMapTransform;
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SPECULARMAP
	uniform mat3 specularMapTransform;
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	uniform mat3 specularColorMapTransform;
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	uniform mat3 specularIntensityMapTransform;
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,uv_vertex:`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	vUv = vec3( uv, 1 ).xy;
#endif
#ifdef USE_MAP
	vMapUv = ( mapTransform * vec3( MAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ALPHAMAP
	vAlphaMapUv = ( alphaMapTransform * vec3( ALPHAMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_LIGHTMAP
	vLightMapUv = ( lightMapTransform * vec3( LIGHTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_AOMAP
	vAoMapUv = ( aoMapTransform * vec3( AOMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_BUMPMAP
	vBumpMapUv = ( bumpMapTransform * vec3( BUMPMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_NORMALMAP
	vNormalMapUv = ( normalMapTransform * vec3( NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_DISPLACEMENTMAP
	vDisplacementMapUv = ( displacementMapTransform * vec3( DISPLACEMENTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_EMISSIVEMAP
	vEmissiveMapUv = ( emissiveMapTransform * vec3( EMISSIVEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_METALNESSMAP
	vMetalnessMapUv = ( metalnessMapTransform * vec3( METALNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ROUGHNESSMAP
	vRoughnessMapUv = ( roughnessMapTransform * vec3( ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_DIFFUSE_ROUGHNESSMAP
	vDiffuseRoughnessMapUv = ( diffuseRoughnessMapTransform * vec3( DIFFUSE_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ANISOTROPYMAP
	vAnisotropyMapUv = ( anisotropyMapTransform * vec3( ANISOTROPYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOATMAP
	vClearcoatMapUv = ( clearcoatMapTransform * vec3( CLEARCOATMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	vClearcoatNormalMapUv = ( clearcoatNormalMapTransform * vec3( CLEARCOAT_NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	vClearcoatRoughnessMapUv = ( clearcoatRoughnessMapTransform * vec3( CLEARCOAT_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCEMAP
	vIridescenceMapUv = ( iridescenceMapTransform * vec3( IRIDESCENCEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	vIridescenceThicknessMapUv = ( iridescenceThicknessMapTransform * vec3( IRIDESCENCE_THICKNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_COLORMAP
	vSheenColorMapUv = ( sheenColorMapTransform * vec3( SHEEN_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	vSheenRoughnessMapUv = ( sheenRoughnessMapTransform * vec3( SHEEN_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULARMAP
	vSpecularMapUv = ( specularMapTransform * vec3( SPECULARMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_COLORMAP
	vSpecularColorMapUv = ( specularColorMapTransform * vec3( SPECULAR_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	vSpecularIntensityMapUv = ( specularIntensityMapTransform * vec3( SPECULAR_INTENSITYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_TRANSMISSIONMAP
	vTransmissionMapUv = ( transmissionMapTransform * vec3( TRANSMISSIONMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_THICKNESSMAP
	vThicknessMapUv = ( thicknessMapTransform * vec3( THICKNESSMAP_UV, 1 ) ).xy;
#endif`,worldpos_vertex:`#if defined( USE_ENVMAP ) || defined( DISTANCE ) || defined ( USE_SHADOWMAP ) || defined ( USE_TRANSMISSION ) || NUM_SPOT_LIGHT_COORDS > 0
	vec4 worldPosition = vec4( transformed, 1.0 );
	#ifdef USE_BATCHING
		worldPosition = batchingMatrix * worldPosition;
	#endif
	#ifdef USE_INSTANCING
		worldPosition = instanceMatrix * worldPosition;
	#endif
	worldPosition = modelMatrix * worldPosition;
#endif`,background_vert:`varying vec2 vUv;
uniform mat3 uvTransform;
void main() {
	vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	gl_Position = vec4( position.xy, 1.0, 1.0 );
}`,background_frag:`uniform sampler2D t2D;
uniform float backgroundIntensity;
varying vec2 vUv;
void main() {
	vec4 texColor = texture2D( t2D, vUv );
	#ifdef DECODE_VIDEO_TEXTURE
		texColor = vec4( mix( pow( texColor.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), texColor.rgb * 0.0773993808, vec3( lessThanEqual( texColor.rgb, vec3( 0.04045 ) ) ) ), texColor.w );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,backgroundCube_vert:`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,backgroundCube_frag:`uniform float backgroundBlurriness;
uniform float backgroundIntensity;
uniform mat3 backgroundRotation;
varying vec3 vWorldDirection;
#include <envmap_common_pars_fragment>
void main() {
	#ifdef ENVMAP_TYPE_PMREM
		vec4 texColor = textureLod( envMap, backgroundRotation * vWorldDirection, roughnessToMip( backgroundBlurriness ) );
	#else
		vec4 texColor = textureCube( envMap, backgroundRotation * vWorldDirection );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,cube_vert:`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,cube_frag:`uniform samplerCube tCube;
uniform float tFlip;
uniform float opacity;
varying vec3 vWorldDirection;
void main() {
	vec4 texColor = textureCube( tCube, vec3( tFlip * vWorldDirection.x, vWorldDirection.yz ) );
	gl_FragColor = texColor;
	gl_FragColor.a *= opacity;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,depth_vert:`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
varying vec2 vHighPrecisionZW;
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#include <morphinstance_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vHighPrecisionZW = gl_Position.zw;
}`,depth_frag:`#if DEPTH_PACKING == 3200
	uniform float opacity;
#endif
#include <common>
#include <packing>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
varying vec2 vHighPrecisionZW;
void main() {
	vec4 diffuseColor = vec4( 1.0 );
	#include <clipping_planes_fragment>
	#if DEPTH_PACKING == 3200
		diffuseColor.a = opacity;
	#endif
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <logdepthbuf_fragment>
	#ifdef USE_REVERSED_DEPTH_BUFFER
		float fragCoordZ = vHighPrecisionZW[ 0 ] / vHighPrecisionZW[ 1 ];
	#else
		float fragCoordZ = 0.5 * vHighPrecisionZW[ 0 ] / vHighPrecisionZW[ 1 ] + 0.5;
	#endif
	#if DEPTH_PACKING == 3200
		gl_FragColor = vec4( vec3( 1.0 - fragCoordZ ), opacity );
	#elif DEPTH_PACKING == 3201
		gl_FragColor = packDepthToRGBA( fragCoordZ );
	#elif DEPTH_PACKING == 3202
		gl_FragColor = vec4( packDepthToRGB( fragCoordZ ), 1.0 );
	#elif DEPTH_PACKING == 3203
		gl_FragColor = vec4( packDepthToRG( fragCoordZ ), 0.0, 1.0 );
	#endif
}`,distance_vert:`#define DISTANCE
varying vec3 vWorldPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#include <morphinstance_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <worldpos_vertex>
	#include <clipping_planes_vertex>
	vWorldPosition = worldPosition.xyz;
}`,distance_frag:`#define DISTANCE
uniform vec3 referencePosition;
uniform float nearDistance;
uniform float farDistance;
varying vec3 vWorldPosition;
#include <common>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( 1.0 );
	#include <clipping_planes_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	float dist = length( vWorldPosition - referencePosition );
	dist = ( dist - nearDistance ) / ( farDistance - nearDistance );
	dist = saturate( dist );
	gl_FragColor = vec4( dist, 0.0, 0.0, 1.0 );
}`,equirect_vert:`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
}`,equirect_frag:`uniform sampler2D tEquirect;
varying vec3 vWorldDirection;
#include <common>
void main() {
	vec3 direction = normalize( vWorldDirection );
	vec2 sampleUV = equirectUv( direction );
	gl_FragColor = texture2D( tEquirect, sampleUV );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,linedashed_vert:`uniform float scale;
attribute float lineDistance;
varying float vLineDistance;
#include <common>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	vLineDistance = scale * lineDistance;
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,linedashed_frag:`uniform vec3 diffuse;
uniform float opacity;
uniform float dashSize;
uniform float totalSize;
varying float vLineDistance;
#include <common>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	if ( mod( vLineDistance, totalSize ) > dashSize ) {
		discard;
	}
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,meshbasic_vert:`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#if defined ( USE_ENVMAP ) || defined ( USE_SKINNING )
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinbase_vertex>
		#include <skinnormal_vertex>
		#include <defaultnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <fog_vertex>
}`,meshbasic_frag:`uniform vec3 diffuse;
uniform float opacity;
#ifndef FLAT_SHADED
	varying vec3 vNormal;
#endif
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		reflectedLight.indirectDiffuse += lightMapTexel.rgb * lightMapIntensity * RECIPROCAL_PI;
	#else
		reflectedLight.indirectDiffuse += vec3( 1.0 );
	#endif
	#include <aomap_fragment>
	reflectedLight.indirectDiffuse *= diffuseColor.rgb;
	vec3 outgoingLight = reflectedLight.indirectDiffuse;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,meshlambert_vert:`#define LAMBERT
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,meshlambert_frag:`#define LAMBERT
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_lambert_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_lambert_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,meshmatcap_vert:`#define MATCAP
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <displacementmap_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
	vViewPosition = - mvPosition.xyz;
}`,meshmatcap_frag:`#define MATCAP
uniform vec3 diffuse;
uniform float opacity;
uniform sampler2D matcap;
varying vec3 vViewPosition;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	vec3 viewDir = normalize( vViewPosition );
	vec3 x = normalize( vec3( viewDir.z, 0.0, - viewDir.x ) );
	vec3 y = cross( viewDir, x );
	vec2 uv = vec2( dot( x, normal ), dot( y, normal ) ) * 0.495 + 0.5;
	#ifdef USE_MATCAP
		vec4 matcapColor = texture2D( matcap, uv );
	#else
		vec4 matcapColor = vec4( vec3( mix( 0.2, 0.8, uv.y ) ), 1.0 );
	#endif
	vec3 outgoingLight = diffuseColor.rgb * matcapColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,meshnormal_vert:`#define NORMAL
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	vViewPosition = - mvPosition.xyz;
#endif
}`,meshnormal_frag:`#define NORMAL
uniform float opacity;
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <uv_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( 0.0, 0.0, 0.0, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	gl_FragColor = vec4( normalize( normal ) * 0.5 + 0.5, diffuseColor.a );
	#ifdef OPAQUE
		gl_FragColor.a = 1.0;
	#endif
}`,meshphong_vert:`#define PHONG
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,meshphong_frag:`#define PHONG
uniform vec3 diffuse;
uniform vec3 emissive;
uniform vec3 specular;
uniform float shininess;
uniform float opacity;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_phong_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_phong_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + reflectedLight.directSpecular + reflectedLight.indirectSpecular + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,meshphysical_vert:`#define STANDARD
varying vec3 vViewPosition;
#ifdef USE_TRANSMISSION
	varying vec3 vWorldPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
#ifdef USE_TRANSMISSION
	vWorldPosition = worldPosition.xyz;
#endif
}`,meshphysical_frag:`#define STANDARD
#ifdef PHYSICAL
	#define IOR
	#define USE_SPECULAR
#endif
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float roughness;
uniform float metalness;
uniform float opacity;
#ifdef IOR
	uniform float ior;
#endif
#ifdef USE_SPECULAR
	uniform float specularIntensity;
	uniform vec3 specularColor;
	#ifdef USE_SPECULAR_COLORMAP
		uniform sampler2D specularColorMap;
	#endif
	#ifdef USE_SPECULAR_INTENSITYMAP
		uniform sampler2D specularIntensityMap;
	#endif
#endif
#ifdef USE_CLEARCOAT
	uniform float clearcoat;
	uniform float clearcoatRoughness;
#endif
#ifdef USE_DIFFUSE_ROUGHNESS
	uniform float diffuseRoughness;
	#ifdef USE_DIFFUSE_ROUGHNESSMAP
		uniform sampler2D diffuseRoughnessMap;
	#endif
#endif
#ifdef USE_DISPERSION
	uniform float dispersion;
#endif
#ifdef USE_RETROREFLECTION
	uniform float retroreflectivity;
#endif
#ifdef USE_IRIDESCENCE
	uniform float iridescence;
	uniform float iridescenceIOR;
	uniform float iridescenceThicknessMinimum;
	uniform float iridescenceThicknessMaximum;
#endif
#ifdef USE_SHEEN
	uniform vec3 sheenColor;
	uniform float sheenRoughness;
	#ifdef USE_SHEEN_COLORMAP
		uniform sampler2D sheenColorMap;
	#endif
	#ifdef USE_SHEEN_ROUGHNESSMAP
		uniform sampler2D sheenRoughnessMap;
	#endif
#endif
#ifdef USE_ANISOTROPY
	uniform vec2 anisotropyVector;
	#ifdef USE_ANISOTROPYMAP
		uniform sampler2D anisotropyMap;
	#endif
#endif
varying vec3 vViewPosition;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <iridescence_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_physical_pars_fragment>
#include <transmission_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <clearcoat_pars_fragment>
#include <iridescence_pars_fragment>
#include <roughnessmap_pars_fragment>
#include <metalnessmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <roughnessmap_fragment>
	#include <metalnessmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <clearcoat_normal_fragment_begin>
	#include <clearcoat_normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_physical_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 totalDiffuse = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse;
	vec3 totalSpecular = reflectedLight.directSpecular + reflectedLight.indirectSpecular;
	#include <transmission_fragment>
	vec3 outgoingLight = totalDiffuse + totalSpecular + totalEmissiveRadiance;
	#ifdef USE_SHEEN
 
		outgoingLight = outgoingLight + sheenSpecularDirect + sheenSpecularIndirect;
 
 	#endif
	#ifdef USE_CLEARCOAT
		float dotNVcc = saturate( dot( geometryClearcoatNormal, geometryViewDir ) );
		vec3 Fcc = F_Schlick( material.clearcoatF0, material.clearcoatF90, dotNVcc );
		outgoingLight = outgoingLight * ( 1.0 - material.clearcoat * Fcc ) + ( clearcoatSpecularDirect + clearcoatSpecularIndirect ) * material.clearcoat;
	#endif
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,meshtoon_vert:`#define TOON
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,meshtoon_frag:`#define TOON
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <gradientmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_toon_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_toon_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,points_vert:`uniform float size;
uniform float scale;
#include <common>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
#ifdef USE_POINTS_UV
	varying vec2 vUv;
	uniform mat3 uvTransform;
#endif
void main() {
	#ifdef USE_POINTS_UV
		vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	#endif
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	gl_PointSize = size;
	#ifdef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) gl_PointSize *= ( scale / - mvPosition.z );
	#endif
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <fog_vertex>
}`,points_frag:`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <color_pars_fragment>
#include <map_particle_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_particle_fragment>
	#include <color_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,shadow_vert:`#include <common>
#include <batching_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <shadowmap_pars_vertex>
void main() {
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,shadow_frag:`uniform vec3 color;
uniform float opacity;
#include <common>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <logdepthbuf_pars_fragment>
#include <shadowmap_pars_fragment>
#include <shadowmask_pars_fragment>
void main() {
	#include <logdepthbuf_fragment>
	gl_FragColor = vec4( color, opacity * ( 1.0 - getShadowMask() ) );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,sprite_vert:`uniform float rotation;
uniform vec2 center;
#include <common>
#include <uv_pars_vertex>
#include <fog_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	vec4 mvPosition = modelViewMatrix[ 3 ];
	vec2 scale = vec2( length( modelMatrix[ 0 ].xyz ), length( modelMatrix[ 1 ].xyz ) );
	#ifndef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) scale *= - mvPosition.z;
	#endif
	vec2 alignedPosition = ( position.xy - ( center - vec2( 0.5 ) ) ) * scale;
	vec2 rotatedPosition;
	rotatedPosition.x = cos( rotation ) * alignedPosition.x - sin( rotation ) * alignedPosition.y;
	rotatedPosition.y = sin( rotation ) * alignedPosition.x + cos( rotation ) * alignedPosition.y;
	mvPosition.xy += rotatedPosition;
	gl_Position = projectionMatrix * mvPosition;
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,sprite_frag:`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
}`},z={common:{diffuse:{value:new R(16777215)},opacity:{value:1},map:{value:null},mapTransform:{value:new Rt},alphaMap:{value:null},alphaMapTransform:{value:new Rt},alphaTest:{value:0}},specularmap:{specularMap:{value:null},specularMapTransform:{value:new Rt}},envmap:{envMap:{value:null},envMapRotation:{value:new Rt},reflectivity:{value:1},ior:{value:1.5},refractionRatio:{value:.98},dfgLUT:{value:null}},aomap:{aoMap:{value:null},aoMapIntensity:{value:1},aoMapTransform:{value:new Rt}},lightmap:{lightMap:{value:null},lightMapIntensity:{value:1},lightMapTransform:{value:new Rt}},bumpmap:{bumpMap:{value:null},bumpMapTransform:{value:new Rt},bumpScale:{value:1}},normalmap:{normalMap:{value:null},normalMapTransform:{value:new Rt},normalScale:{value:new I(1,1)}},displacementmap:{displacementMap:{value:null},displacementMapTransform:{value:new Rt},displacementScale:{value:1},displacementBias:{value:0}},emissivemap:{emissiveMap:{value:null},emissiveMapTransform:{value:new Rt}},metalnessmap:{metalnessMap:{value:null},metalnessMapTransform:{value:new Rt}},roughnessmap:{roughnessMap:{value:null},roughnessMapTransform:{value:new Rt}},gradientmap:{gradientMap:{value:null}},fog:{fogDensity:{value:25e-5},fogNear:{value:1},fogFar:{value:2e3},fogColor:{value:new R(16777215)}},lights:{ambientLightColor:{value:[]},lightProbe:{value:[]},sunLights:{value:[],properties:{direction:{},color:{}}},sunLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},sunShadowMatrix:{value:[]},sunShadowCascade:{value:[]},directionalLights:{value:[],properties:{direction:{},color:{}}},directionalLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},directionalShadowMatrix:{value:[]},spotLights:{value:[],properties:{color:{},position:{},direction:{},distance:{},coneCos:{},penumbraCos:{},decay:{}}},spotLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},spotLightMap:{value:[]},spotLightMatrix:{value:[]},pointLights:{value:[],properties:{color:{},position:{},decay:{},distance:{}}},pointLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{},shadowCameraNear:{},shadowCameraFar:{}}},pointShadowMatrix:{value:[]},hemisphereLights:{value:[],properties:{direction:{},skyColor:{},groundColor:{}}},rectAreaLights:{value:[],properties:{color:{},position:{},width:{},height:{}}},ltc_1:{value:null},ltc_2:{value:null},probesSH:{value:[]},probesMin:{value:[]},probesMax:{value:[]},probesResolution:{value:[]}},points:{diffuse:{value:new R(16777215)},opacity:{value:1},size:{value:1},scale:{value:1},map:{value:null},alphaMap:{value:null},alphaMapTransform:{value:new Rt},alphaTest:{value:0},uvTransform:{value:new Rt}},sprite:{diffuse:{value:new R(16777215)},opacity:{value:1},center:{value:new I(.5,.5)},rotation:{value:0},map:{value:null},mapTransform:{value:new Rt},alphaMap:{value:null},alphaMapTransform:{value:new Rt},alphaTest:{value:0}}},$s={basic:{uniforms:Do([z.common,z.specularmap,z.envmap,z.aomap,z.lightmap,z.fog]),vertexShader:Qs.meshbasic_vert,fragmentShader:Qs.meshbasic_frag},lambert:{uniforms:Do([z.common,z.specularmap,z.envmap,z.aomap,z.lightmap,z.emissivemap,z.bumpmap,z.normalmap,z.displacementmap,z.fog,z.lights,{emissive:{value:new R(0)},envMapIntensity:{value:1}}]),vertexShader:Qs.meshlambert_vert,fragmentShader:Qs.meshlambert_frag},phong:{uniforms:Do([z.common,z.specularmap,z.envmap,z.aomap,z.lightmap,z.emissivemap,z.bumpmap,z.normalmap,z.displacementmap,z.fog,z.lights,{emissive:{value:new R(0)},specular:{value:new R(1118481)},shininess:{value:30},envMapIntensity:{value:1}}]),vertexShader:Qs.meshphong_vert,fragmentShader:Qs.meshphong_frag},standard:{uniforms:Do([z.common,z.envmap,z.aomap,z.lightmap,z.emissivemap,z.bumpmap,z.normalmap,z.displacementmap,z.roughnessmap,z.metalnessmap,z.fog,z.lights,{emissive:{value:new R(0)},roughness:{value:1},metalness:{value:0},envMapIntensity:{value:1}}]),vertexShader:Qs.meshphysical_vert,fragmentShader:Qs.meshphysical_frag},toon:{uniforms:Do([z.common,z.aomap,z.lightmap,z.emissivemap,z.bumpmap,z.normalmap,z.displacementmap,z.gradientmap,z.fog,z.lights,{emissive:{value:new R(0)}}]),vertexShader:Qs.meshtoon_vert,fragmentShader:Qs.meshtoon_frag},matcap:{uniforms:Do([z.common,z.bumpmap,z.normalmap,z.displacementmap,z.fog,{matcap:{value:null}}]),vertexShader:Qs.meshmatcap_vert,fragmentShader:Qs.meshmatcap_frag},points:{uniforms:Do([z.points,z.fog]),vertexShader:Qs.points_vert,fragmentShader:Qs.points_frag},dashed:{uniforms:Do([z.common,z.fog,{scale:{value:1},dashSize:{value:1},totalSize:{value:2}}]),vertexShader:Qs.linedashed_vert,fragmentShader:Qs.linedashed_frag},depth:{uniforms:Do([z.common,z.displacementmap]),vertexShader:Qs.depth_vert,fragmentShader:Qs.depth_frag},normal:{uniforms:Do([z.common,z.bumpmap,z.normalmap,z.displacementmap,{opacity:{value:1}}]),vertexShader:Qs.meshnormal_vert,fragmentShader:Qs.meshnormal_frag},sprite:{uniforms:Do([z.sprite,z.fog]),vertexShader:Qs.sprite_vert,fragmentShader:Qs.sprite_frag},background:{uniforms:{uvTransform:{value:new Rt},t2D:{value:null},backgroundIntensity:{value:1}},vertexShader:Qs.background_vert,fragmentShader:Qs.background_frag},backgroundCube:{uniforms:{envMap:{value:null},backgroundBlurriness:{value:0},backgroundIntensity:{value:1},backgroundRotation:{value:new Rt}},vertexShader:Qs.backgroundCube_vert,fragmentShader:Qs.backgroundCube_frag},cube:{uniforms:{tCube:{value:null},tFlip:{value:-1},opacity:{value:1}},vertexShader:Qs.cube_vert,fragmentShader:Qs.cube_frag},equirect:{uniforms:{tEquirect:{value:null}},vertexShader:Qs.equirect_vert,fragmentShader:Qs.equirect_frag},distance:{uniforms:Do([z.common,z.displacementmap,{referencePosition:{value:new L},nearDistance:{value:1},farDistance:{value:1e3}}]),vertexShader:Qs.distance_vert,fragmentShader:Qs.distance_frag},shadow:{uniforms:Do([z.lights,z.fog,{color:{value:new R(0)},opacity:{value:1}}]),vertexShader:Qs.shadow_vert,fragmentShader:Qs.shadow_frag}};$s.physical={uniforms:Do([$s.standard.uniforms,{clearcoat:{value:0},clearcoatMap:{value:null},clearcoatMapTransform:{value:new Rt},clearcoatNormalMap:{value:null},clearcoatNormalMapTransform:{value:new Rt},clearcoatNormalScale:{value:new I(1,1)},clearcoatRoughness:{value:0},clearcoatRoughnessMap:{value:null},clearcoatRoughnessMapTransform:{value:new Rt},diffuseRoughness:{value:0},diffuseRoughnessMap:{value:null},diffuseRoughnessMapTransform:{value:new Rt},dispersion:{value:0},retroreflectivity:{value:0},iridescence:{value:0},iridescenceMap:{value:null},iridescenceMapTransform:{value:new Rt},iridescenceIOR:{value:1.3},iridescenceThicknessMinimum:{value:100},iridescenceThicknessMaximum:{value:400},iridescenceThicknessMap:{value:null},iridescenceThicknessMapTransform:{value:new Rt},sheen:{value:0},sheenColor:{value:new R(0)},sheenColorMap:{value:null},sheenColorMapTransform:{value:new Rt},sheenRoughness:{value:1},sheenRoughnessMap:{value:null},sheenRoughnessMapTransform:{value:new Rt},transmission:{value:0},transmissionMap:{value:null},transmissionMapTransform:{value:new Rt},transmissionSamplerSize:{value:new I},transmissionSamplerMap:{value:null},thickness:{value:0},thicknessMap:{value:null},thicknessMapTransform:{value:new Rt},attenuationDistance:{value:0},attenuationColor:{value:new R(0)},specularColor:{value:new R(1,1,1)},specularColorMap:{value:null},specularColorMapTransform:{value:new Rt},specularIntensity:{value:1},specularIntensityMap:{value:null},specularIntensityMapTransform:{value:new Rt},anisotropyVector:{value:new I},anisotropyMap:{value:null},anisotropyMapTransform:{value:new Rt}}]),vertexShader:Qs.meshphysical_vert,fragmentShader:Qs.meshphysical_frag};var ec={r:0,b:0,g:0},tc=new on,nc=new Rt;nc.set(-1,0,0,0,1,0,0,0,1);function rc(e,t,n,r,i,a){let o=new R(0),s=i===!0?0:1,c,l,u=null,d=0,f=null;function p(e){let n=e.isScene===!0?e.background:null;if(n&&n.isTexture){let r=e.backgroundBlurriness>0;n=t.get(n,r)}return n}function m(t){let r=!1,i=p(t);i===null?g(o,s):i&&i.isColor&&(g(i,1),r=!0);let c=e.xr.getEnvironmentBlendMode();c===`additive`?n.buffers.color.setClear(0,0,0,1,a):c===`alpha-blend`&&n.buffers.color.setClear(0,0,0,0,a),(e.autoClear||r)&&(n.buffers.depth.setTest(!0),n.buffers.depth.setMask(!0),n.buffers.color.setMask(!0),e.clear(e.autoClearColor,e.autoClearDepth,e.autoClearStencil))}function h(t,n){let i=p(n);i&&i.isCubeTexture?(l===void 0&&(l=new oi(new Xi(1,1,1),new Po({name:`BackgroundCubeMaterial`,uniforms:Eo($s.backgroundCube.uniforms),vertexShader:$s.backgroundCube.vertexShader,fragmentShader:$s.backgroundCube.fragmentShader,side:1,depthTest:!1,depthWrite:!1,fog:!1,allowOverride:!1})),l.geometry.deleteAttribute(`normal`),l.geometry.deleteAttribute(`uv`),l.onBeforeRender=function(e,t,n){this.matrixWorld.copyPosition(n.matrixWorld)},Object.defineProperty(l.material,"envMap",{get:function(){return this.uniforms.envMap.value}}),r.update(l)),l.material.uniforms.envMap.value=i,l.material.uniforms.backgroundBlurriness.value=n.backgroundBlurriness,l.material.uniforms.backgroundIntensity.value=n.backgroundIntensity,l.material.uniforms.backgroundRotation.value.setFromMatrix4(tc.makeRotationFromEuler(n.backgroundRotation)).transpose(),i.isRenderTargetTexture===!1&&l.material.uniforms.backgroundRotation.value.premultiply(nc),l.material.toneMapped=Ut.getTransfer(i.colorSpace)!==Ue,(u!==i||d!==i.version||f!==e.toneMapping)&&(l.material.needsUpdate=!0,u=i,d=i.version,f=e.toneMapping),l.layers.enableAll(),t.unshift(l,l.geometry,l.material,0,0,null)):i&&i.isTexture&&(c===void 0&&(c=new oi(new So(2,2),new Po({name:`BackgroundMaterial`,uniforms:Eo($s.background.uniforms),vertexShader:$s.background.vertexShader,fragmentShader:$s.background.fragmentShader,side:0,depthTest:!1,depthWrite:!1,fog:!1,allowOverride:!1})),c.geometry.deleteAttribute(`normal`),Object.defineProperty(c.material,"map",{get:function(){return this.uniforms.t2D.value}}),r.update(c)),c.material.uniforms.t2D.value=i,c.material.uniforms.backgroundIntensity.value=n.backgroundIntensity,c.material.toneMapped=Ut.getTransfer(i.colorSpace)!==Ue,i.matrixAutoUpdate===!0&&i.updateMatrix(),c.material.uniforms.uvTransform.value.copy(i.matrix),(u!==i||d!==i.version||f!==e.toneMapping)&&(c.material.needsUpdate=!0,u=i,d=i.version,f=e.toneMapping),c.layers.enableAll(),t.unshift(c,c.geometry,c.material,0,0,null))}function g(t,r){t.getRGB(ec,Ao(e)),n.buffers.color.setClear(ec.r,ec.g,ec.b,r,a)}function _(){l!==void 0&&(l.geometry.dispose(),l.material.dispose(),l=void 0),c!==void 0&&(c.geometry.dispose(),c.material.dispose(),c=void 0)}return{getClearColor:function(){return o},setClearColor:function(e,t=1){o.set(e),s=t,g(o,s)},getClearAlpha:function(){return s},setClearAlpha:function(e){s=e,g(o,s)},render:m,addToRenderList:h,dispose:_}}function ic(e,t){let n=e.getParameter(e.MAX_VERTEX_ATTRIBS),r={},i=f(null),a=i,o=!1;function s(n,r,i,s,c){let u=!1,f=d(n,s,i,r);a!==f&&(a=f,l(a.object)),u=p(n,s,i,c),u&&m(n,s,i,c),c!==null&&t.update(c,e.ELEMENT_ARRAY_BUFFER),(u||o)&&(o=!1,b(n,r,i,s),c!==null&&e.bindBuffer(e.ELEMENT_ARRAY_BUFFER,t.get(c).buffer))}function c(){return e.createVertexArray()}function l(t){return e.bindVertexArray(t)}function u(t){return e.deleteVertexArray(t)}function d(e,t,n,i){let a=i.wireframe===!0,o=r[t.id];o===void 0&&(o={},r[t.id]=o);let s=e.isInstancedMesh===!0?e.id:0,l=o[s];l===void 0&&(l={},o[s]=l);let u=l[n.id];u===void 0&&(u={},l[n.id]=u);let d=u[a];return d===void 0&&(d=f(c()),u[a]=d),d}function f(e){let t=[],r=[],i=[];for(let e=0;e<n;e++)t[e]=0,r[e]=0,i[e]=0;return{geometry:null,program:null,wireframe:!1,newAttributes:t,enabledAttributes:r,attributeDivisors:i,object:e,attributes:{},index:null}}function p(e,t,n,r){let i=a.attributes,o=t.attributes,s=0,c=n.getAttributes();for(let t in c)if(c[t].location>=0){let n=i[t],r=o[t];if(r===void 0&&(t===`instanceMatrix`&&e.instanceMatrix&&(r=e.instanceMatrix),t===`instanceColor`&&e.instanceColor&&(r=e.instanceColor)),n===void 0||n.attribute!==r||r&&n.data!==r.data)return!0;s++}return a.attributesNum!==s||a.index!==r}function m(e,t,n,r){let i={},o=t.attributes,s=0,c=n.getAttributes();for(let t in c)if(c[t].location>=0){let n=o[t];n===void 0&&(t===`instanceMatrix`&&e.instanceMatrix&&(n=e.instanceMatrix),t===`instanceColor`&&e.instanceColor&&(n=e.instanceColor));let r={};r.attribute=n,n&&n.data&&(r.data=n.data),i[t]=r,s++}a.attributes=i,a.attributesNum=s,a.index=r}function h(){let e=a.newAttributes;for(let t=0,n=e.length;t<n;t++)e[t]=0}function g(e){_(e,0)}function _(t,n){let r=a.newAttributes,i=a.enabledAttributes,o=a.attributeDivisors;r[t]=1,i[t]===0&&(e.enableVertexAttribArray(t),i[t]=1),o[t]!==n&&(e.vertexAttribDivisor(t,n),o[t]=n)}function v(){let t=a.newAttributes,n=a.enabledAttributes;for(let r=0,i=n.length;r<i;r++)n[r]!==t[r]&&(e.disableVertexAttribArray(r),n[r]=0)}function y(t,n,r,i,a,o,s){s===!0?e.vertexAttribIPointer(t,n,r,a,o):e.vertexAttribPointer(t,n,r,i,a,o)}function b(n,r,i,a){h();let o=a.attributes,s=i.getAttributes(),c=r.defaultAttributeValues;for(let r in s){let i=s[r];if(i.location>=0){let s=o[r];if(s===void 0&&(r===`instanceMatrix`&&n.instanceMatrix&&(s=n.instanceMatrix),r===`instanceColor`&&n.instanceColor&&(s=n.instanceColor)),s!==void 0){let r=s.normalized,o=s.itemSize,c=t.get(s);if(c===void 0)continue;let l=c.buffer,u=c.type,d=c.bytesPerElement,f=u===e.INT||u===e.UNSIGNED_INT||s.gpuType===1013;if(s.isInterleavedBufferAttribute){let t=s.data,c=t.isInterleavedBuffer===!0?t.stride:t.itemSize,p=s.offset;if(t.isInstancedInterleavedBuffer||t.isInstancedBufferAttribute){for(let e=0;e<i.locationSize;e++)_(i.location+e,t.meshPerAttribute);n.isInstancedMesh!==!0&&a._maxInstanceCount===void 0&&(a._maxInstanceCount=t.meshPerAttribute*t.count)}else for(let e=0;e<i.locationSize;e++)g(i.location+e);e.bindBuffer(e.ARRAY_BUFFER,l);for(let e=0;e<i.locationSize;e++)y(i.location+e,o/i.locationSize,u,r,c*d,(p+o/i.locationSize*e)*d,f)}else{if(s.isInstancedBufferAttribute){for(let e=0;e<i.locationSize;e++)_(i.location+e,s.meshPerAttribute);n.isInstancedMesh!==!0&&a._maxInstanceCount===void 0&&(a._maxInstanceCount=s.meshPerAttribute*s.count)}else for(let e=0;e<i.locationSize;e++)g(i.location+e);e.bindBuffer(e.ARRAY_BUFFER,l);for(let e=0;e<i.locationSize;e++)y(i.location+e,o/i.locationSize,u,r,o*d,o/i.locationSize*e*d,f)}}else if(c!==void 0){let t=c[r];if(t!==void 0)switch(t.length){case 2:e.vertexAttrib2fv(i.location,t);break;case 3:e.vertexAttrib3fv(i.location,t);break;case 4:e.vertexAttrib4fv(i.location,t);break;default:e.vertexAttrib1fv(i.location,t)}}}}v()}function x(){T();for(let e in r){let t=r[e];for(let e in t){let n=t[e];for(let e in n){let t=n[e];for(let e in t)u(t[e].object),delete t[e];delete n[e]}}delete r[e]}}function S(e){if(r[e.id]===void 0)return;let t=r[e.id];for(let e in t){let n=t[e];for(let e in n){let t=n[e];for(let e in t)u(t[e].object),delete t[e];delete n[e]}}delete r[e.id]}function C(e){for(let t in r){let n=r[t];for(let t in n){let r=n[t];if(r[e.id]===void 0)continue;let i=r[e.id];for(let e in i)u(i[e].object),delete i[e];delete r[e.id]}}}function w(e){for(let t in r){let n=r[t],i=e.isInstancedMesh===!0?e.id:0,a=n[i];if(a!==void 0){for(let e in a){let t=a[e];for(let e in t)u(t[e].object),delete t[e];delete a[e]}delete n[i],Object.keys(n).length===0&&delete r[t]}}}function T(){E(),o=!0,a!==i&&(a=i,l(a.object))}function E(){i.geometry=null,i.program=null,i.wireframe=!1}return{setup:s,reset:T,resetDefaultState:E,dispose:x,releaseStatesOfGeometry:S,releaseStatesOfObject:w,releaseStatesOfProgram:C,initAttributes:h,enableAttribute:g,disableUnusedAttributes:v}}function ac(e,t,n){let r;function i(e){r=e}function a(t,i){e.drawArrays(r,t,i),n.update(i,r,1)}function o(t,i,a){a!==0&&(e.drawArraysInstanced(r,t,i,a),n.update(i,r,a))}function s(e,i,a){if(a===0)return;t.get(`WEBGL_multi_draw`).multiDrawArraysWEBGL(r,e,0,i,0,a);let o=0;for(let e=0;e<a;e++)o+=i[e];n.update(o,r,1)}this.setMode=i,this.render=a,this.renderInstances=o,this.renderMultiDraw=s}function oc(e,t,n,r){let i;function a(){if(i!==void 0)return i;if(t.has(`EXT_texture_filter_anisotropic`)===!0){let n=t.get(`EXT_texture_filter_anisotropic`);i=e.getParameter(n.MAX_TEXTURE_MAX_ANISOTROPY_EXT)}else i=0;return i}function o(t){return t===1023||r.convert(t)===e.getParameter(e.IMPLEMENTATION_COLOR_READ_FORMAT)}function s(n){let i=n===1016&&(t.has(`EXT_color_buffer_half_float`)||t.has(`EXT_color_buffer_float`));return!(n!==1009&&n!==1015&&!i&&r.convert(n)!==e.getParameter(e.IMPLEMENTATION_COLOR_READ_TYPE))}function c(t){if(t===`highp`){if(e.getShaderPrecisionFormat(e.VERTEX_SHADER,e.HIGH_FLOAT).precision>0&&e.getShaderPrecisionFormat(e.FRAGMENT_SHADER,e.HIGH_FLOAT).precision>0)return`highp`;t=`mediump`}return t===`mediump`&&e.getShaderPrecisionFormat(e.VERTEX_SHADER,e.MEDIUM_FLOAT).precision>0&&e.getShaderPrecisionFormat(e.FRAGMENT_SHADER,e.MEDIUM_FLOAT).precision>0?`mediump`:`lowp`}let l=n.precision===void 0?`highp`:n.precision,u=c(l);u!==l&&(tt(`WebGLRenderer:`,l,`not supported, using`,u,`instead.`),l=u);let d=n.reversedDepthBuffer===!0&&t.has(`EXT_clip_control`),f=n.logarithmicDepthBuffer===!0&&d===!1;n.reversedDepthBuffer===!0&&d===!1&&tt(`WebGLRenderer: Unable to use reversed depth buffer due to missing EXT_clip_control extension. Fallback to default depth buffer.`),n.logarithmicDepthBuffer===!0&&d===!0&&tt(`WebGLRenderer: Logarithmic depth buffer is ignored when reversed depth buffer is enabled.`);let p=e.getParameter(e.MAX_TEXTURE_IMAGE_UNITS),m=e.getParameter(e.MAX_VERTEX_TEXTURE_IMAGE_UNITS),h=e.getParameter(e.MAX_TEXTURE_SIZE),g=e.getParameter(e.MAX_CUBE_MAP_TEXTURE_SIZE),_=e.getParameter(e.MAX_VERTEX_ATTRIBS),v=e.getParameter(e.MAX_VERTEX_UNIFORM_VECTORS),y=e.getParameter(e.MAX_VARYING_VECTORS),b=e.getParameter(e.MAX_FRAGMENT_UNIFORM_VECTORS),x=e.getParameter(e.MAX_SAMPLES),S=e.getParameter(e.SAMPLES);return{isWebGL2:!0,getMaxAnisotropy:a,getMaxPrecision:c,textureFormatReadable:o,textureTypeReadable:s,precision:l,logarithmicDepthBuffer:f,reversedDepthBuffer:d,maxTextures:p,maxVertexTextures:m,maxTextureSize:h,maxCubemapSize:g,maxAttributes:_,maxVertexUniforms:v,maxVaryings:y,maxFragmentUniforms:b,maxSamples:x,samples:S}}function sc(e){let t=this,n=null,r=0,i=!1,a=!1,o=new Br,s=new Rt,c={value:null,needsUpdate:!1};this.uniform=c,this.numPlanes=0,this.numIntersection=0,this.init=function(e,t){let n=e.length!==0||t||r!==0||i;return i=t,r=e.length,n},this.beginShadows=function(){a=!0,u(null)},this.endShadows=function(){a=!1},this.setGlobalState=function(e,t){n=u(e,t,0)},this.setState=function(t,o,s){let d=t.clippingPlanes,f=t.clipIntersection,p=t.clipShadows,m=e.get(t);if(!i||d===null||d.length===0||a&&!p)a?u(null):l();else{let e=a?0:r,t=e*4,i=m.clippingState||null;c.value=i,i=u(d,o,t,s);for(let e=0;e!==t;++e)i[e]=n[e];m.clippingState=i,this.numIntersection=f?this.numPlanes:0,this.numPlanes+=e}};function l(){c.value!==n&&(c.value=n,c.needsUpdate=r>0),t.numPlanes=r,t.numIntersection=0}function u(e,n,r,i){let a=e===null?0:e.length,l=null;if(a!==0){if(l=c.value,i!==!0||l===null){let t=r+a*4,i=n.matrixWorldInverse;s.getNormalMatrix(i),(l===null||l.length<t)&&(l=new Float32Array(t));for(let t=0,n=r;t!==a;++t,n+=4)o.copy(e[t]).applyMatrix4(i,s),o.normal.toArray(l,n),l[n+3]=o.constant}c.value=l,c.needsUpdate=!0}return t.numPlanes=a,t.numIntersection=0,l}}var cc=class extends nn{constructor(e=1,t={}){super(e,e,t),this.isWebGLCubeRenderTarget=!0;let n={width:e,height:e,depth:1},r=[n,n,n,n,n,n];this.texture=new Ki(r),this._setTextureOptions(t),this.texture.isRenderTargetTexture=!0}fromEquirectangularTexture(e,t){this.texture.type=t.type,this.texture.colorSpace=t.colorSpace,this.texture.generateMipmaps=t.generateMipmaps,this.texture.minFilter=t.minFilter,this.texture.magFilter=t.magFilter;let n={uniforms:{tEquirect:{value:null}},vertexShader:`

				varying vec3 vWorldDirection;

				vec3 transformDirection( in vec3 dir, in mat4 matrix ) {

					return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );

				}

				void main() {

					vWorldDirection = transformDirection( position, modelMatrix );

					#include <begin_vertex>
					#include <project_vertex>

				}
			`,fragmentShader:`

				uniform sampler2D tEquirect;

				varying vec3 vWorldDirection;

				#include <common>

				void main() {

					vec3 direction = normalize( vWorldDirection );

					vec2 sampleUV = equirectUv( direction );

					gl_FragColor = texture2D( tEquirect, sampleUV );

				}
			`},r=new Xi(5,5,5),i=new Po({name:`CubemapFromEquirect`,uniforms:Eo(n.uniforms),vertexShader:n.vertexShader,fragmentShader:n.fragmentShader,side:1,blending:0});i.uniforms.tEquirect.value=t;let a=new oi(r,i),s=t.minFilter;return t.minFilter===1008&&(t.minFilter=o),new Os(1,10,this).update(e,a),t.minFilter=s,a.geometry.dispose(),a.material.dispose(),this}clear(e,t=!0,n=!0,r=!0){let i=e.getRenderTarget();for(let i=0;i<6;i++)e.setRenderTarget(this,i),e.clear(t,n,r);e.setRenderTarget(i)}},lc=256,uc=3,dc=20,fc=256,pc=16,mc=3,hc=new L,gc=new R,_c=class e{constructor(e){this._renderer=e,this._cubeSize=0,this._sourceTarget=null,this._cubeCamera=new Os(1,10,null),this._boxMesh=new oi(new Xi(5,5,5),null),this._cubemapMaterial=null,this._equirectMaterial=null,this._blurMaterial=null,this._ggxMaterial=null,this._integrationMaterial=null}fromScene(e,t=0,n=.1,r=100,i={}){let{size:a=256,position:o=hc}=i,s=this._renderer;this._setSize(a);let c=this._allocateTarget(),l=this._getSourceTarget(!0);t>0&&(l.texture.mipmapsAutoUpdate=!1);let u=s.autoClear,d=s.autoClearColor,f=s.autoClearDepth,p=s.autoClearStencil,m=e.background;s.autoClear=!0,s.autoClearColor=!0,s.autoClearDepth=!0,s.autoClearStencil=!0,m===null&&(e.background=s.getClearColor(gc));let h=new Os(n,r,l);return h.position.copy(o),h.update(s,e),s.autoClear=u,s.autoClearColor=d,s.autoClearDepth=f,s.autoClearStencil=p,e.background=m,t>0&&(l.texture.mipmapsAutoUpdate=!0,this._blur(c,t)),this._applyPMREM(c),c}fromEquirectangular(e,t=null){return this._fromTexture(e,t)}fromCubemap(e,t=null){return this._fromTexture(e,t)}compileCubemapShader(){this._cubemapMaterial===null&&(this._cubemapMaterial=wc(),this._compileMaterial(this._cubemapMaterial))}compileEquirectangularShader(){this._equirectMaterial===null&&(this._equirectMaterial=Cc(),this._compileMaterial(this._equirectMaterial))}dispose(){this._sourceTarget!==null&&this._sourceTarget.dispose(),this._cubemapMaterial!==null&&this._cubemapMaterial.dispose(),this._equirectMaterial!==null&&this._equirectMaterial.dispose(),this._blurMaterial!==null&&this._blurMaterial.dispose(),this._ggxMaterial!==null&&this._ggxMaterial.dispose(),this._integrationMaterial!==null&&this._integrationMaterial.dispose(),this._boxMesh.geometry.dispose()}static lodToRoughness(e,t){return t>0?1-Math.sqrt(1-e/t):0}_setSize(e){this._cubeSize=Math.max(lc,kt(e))}_fromTexture(e,t){e.mapping===301||e.mapping===302?this._setSize(e.image.length===0?lc:e.image[0].width||e.image[0].image.width):this._setSize(e.image.width/4);let n=t||this._allocateTarget();return this._textureToCubemap(e),this._applyPMREM(n),n}_allocateTarget(){let e=this._cubeSize,t=vc(e,!1,!1),n=Math.log2(e)-uc;for(let r=0;r<=n;r++)t.texture.mipmaps.push({width:e>>r,height:e>>r});return t.texture.name=`PMREM`,t.texture.isPMREMTexture=!0,t}_getSourceTarget(e=!1){let t=this._cubeSize,n=this._sourceTarget;return(n===null||n.width!==t||e&&n.depthBuffer===!1)&&(n!==null&&n.dispose(),this._sourceTarget=vc(t,!0,e)),this._sourceTarget}_compileMaterial(e){this._boxMesh.material=e,this._renderer.compile(this._boxMesh,this._cubeCamera.children[0])}_renderCube(e,t,n){let r=this._boxMesh,i=this._cubeCamera;r.material=n,i.renderTarget=e,i.activeMipmapLevel=t;let a=e.width>>t;e.viewport.set(0,0,a,a),i.update(this._renderer,r),e.viewport.set(0,0,e.width,e.height)}_textureToCubemap(e){let t;e.mapping===301||e.mapping===302?(this._cubemapMaterial===null&&(this._cubemapMaterial=wc()),t=this._cubemapMaterial,t.uniforms.flipEnvMap.value=e.isRenderTargetTexture===!1?-1:1):(this._equirectMaterial===null&&(this._equirectMaterial=Cc()),t=this._equirectMaterial),t.uniforms.envMap.value=e,this._renderCube(this._getSourceTarget(),0,t)}_applyPMREM(t){this._ggxMaterial===null&&(this._ggxMaterial=bc(),this._integrationMaterial=xc());let n=this._cubeSize,r=t.texture.mipmaps.length-1,i=this._ggxMaterial.uniforms;i.envMap.value=this._sourceTarget.texture;let a=this._integrationMaterial.uniforms;a.envMap.value=this._sourceTarget.texture,a.sourceLod.value=Math.log2(n/pc);for(let o=0;o<=r;o++){let s=e.lodToRoughness(o,r);if(o>r-mc)a.roughness.value=s,this._renderCube(t,o,this._integrationMaterial);else{let e=s>0?Math.log2(n)+.5*Math.log2(6/(fc*s**4))+.5:0;i.roughness.value=s,i.lodBias.value=e,this._renderCube(t,o,this._ggxMaterial)}}}_blur(e,t){this._blurMaterial===null&&(this._blurMaterial=Sc());let n=this._blurMaterial,r=n.uniforms,i=this._sourceTarget;r.sigma.value=Math.min(t,Math.PI)/Math.SQRT2,r.envMap.value=i.texture,this._renderCube(e,0,n),r.envMap.value=e.texture,this._renderCube(i,0,n)}};function vc(e,t,n){return new cc(e,{minFilter:c,generateMipmaps:t,type:g,colorSpace:Ve,depthBuffer:n})}function yc(e,t,n){return new Po({name:e,uniforms:t,vertexShader:Qs.cube_vert,fragmentShader:n,side:1,blending:0,depthTest:!1,depthWrite:!1})}function bc(){return yc(`PMREMGGXConvolution`,{envMap:{value:null},roughness:{value:0},lodBias:{value:0}},`

		#define GGX_SAMPLES ${fc}u

		varying vec3 vWorldDirection;

		uniform samplerCube envMap;
		uniform float roughness;
		uniform float lodBias;

		#include <common>

		// Van der Corput radical inverse
		float radicalInverse_VdC( uint bits ) {

			bits = ( bits << 16u ) | ( bits >> 16u );
			bits = ( ( bits & 0x55555555u ) << 1u ) | ( ( bits & 0xAAAAAAAAu ) >> 1u );
			bits = ( ( bits & 0x33333333u ) << 2u ) | ( ( bits & 0xCCCCCCCCu ) >> 2u );
			bits = ( ( bits & 0x0F0F0F0Fu ) << 4u ) | ( ( bits & 0xF0F0F0F0u ) >> 4u );
			bits = ( ( bits & 0x00FF00FFu ) << 8u ) | ( ( bits & 0xFF00FF00u ) >> 8u );
			return float( bits ) * 2.3283064365386963e-10; // / 0x100000000

		}

		// Hammersley sequence
		vec2 hammersley( uint i, uint N ) {

			return vec2( float( i ) / float( N ), radicalInverse_VdC( i ) );

		}

		void main() {

			vec3 N = normalize( vWorldDirection );

			// For very low roughness, just sample the environment directly
			if ( roughness < 0.001 ) {

				gl_FragColor = vec4( textureLod( envMap, N, 0.0 ).rgb, 1.0 );
				return;

			}

			float alpha = roughness * roughness;
			float alpha2 = alpha * alpha;

			// Tangent space basis for VNDF sampling
			vec3 up = abs( N.z ) < 0.999 ? vec3( 0.0, 0.0, 1.0 ) : vec3( 1.0, 0.0, 0.0 );
			vec3 tangent = normalize( cross( up, N ) );
			vec3 bitangent = cross( N, tangent );

			vec3 prefilteredColor = vec3( 0.0 );
			float totalWeight = 0.0;

			for ( uint i = 0u; i < GGX_SAMPLES; i ++ ) {

				vec2 Xi = hammersley( i, GGX_SAMPLES );

				// With V = N, sample the reflected direction directly.
				float invQ = 1.0 / ( 1.0 - Xi.x + alpha2 * Xi.x );
				float NdotL = ( 1.0 - Xi.x - alpha2 * Xi.x ) * invQ;

				if ( NdotL > 0.0 ) {

					float phi = 2.0 * PI * Xi.y;
					float sinTheta = 2.0 * alpha * sqrt( Xi.x * ( 1.0 - Xi.x ) ) * invQ;
					vec3 L = N * NdotL + ( tangent * cos( phi ) + bitangent * sin( phi ) ) * sinTheta;

					// Match the source mip to the sample's solid angle. The terms
					// independent of the sample are precomputed in lodBias.
					float d = alpha2 * invQ;
					float lod = max( log2( d ) + lodBias, 0.0 );

					// Weight by NdotL for the split-sum approximation
					prefilteredColor += textureLod( envMap, L, lod ).rgb * NdotL;
					totalWeight += NdotL;

				}

			}

			gl_FragColor = vec4( prefilteredColor / totalWeight, 1.0 );

		}
	`)}function xc(){return yc(`PMREMGGXIntegration`,{envMap:{value:null},roughness:{value:0},sourceLod:{value:0},sourceSize:{value:pc}},`

		varying vec3 vWorldDirection;

		uniform samplerCube envMap;
		uniform float roughness;
		uniform float sourceLod;
		uniform int sourceSize;

		void main() {

			vec3 N = normalize( vWorldDirection );

			float alpha = roughness * roughness;
			float alpha2 = alpha * alpha;

			float texelSize = 2.0 / float( sourceSize );

			vec3 prefilteredColor = vec3( 0.0 );
			float totalWeight = 0.0;

			// Pair opposite texels: only the one in N's hemisphere contributes.
			for ( int face = 0; face < 3; face ++ ) {

				for ( int y = 0; y < sourceSize; y ++ ) {

					for ( int x = 0; x < sourceSize; x ++ ) {

						vec2 uv = ( vec2( x, y ) + 0.5 ) * texelSize - 1.0;
						vec3 texelDirection = face == 0 ? vec3( 1.0, uv ) : ( face == 1 ? vec3( uv.x, 1.0, uv.y ) : vec3( uv, 1.0 ) );

						float invDistance = inversesqrt( 1.0 + dot( uv, uv ) );
						float NdotL = dot( N, texelDirection );
						texelDirection *= NdotL < 0.0 ? - 1.0 : 1.0;
						NdotL = abs( NdotL ) * invDistance;

						// With V = N, NdotH squared is ( 1 + NdotL ) / 2. Common factors
						// in the GGX distribution and texel solid angle cancel when normalized.
						float d = 1.0 + alpha2 + ( alpha2 - 1.0 ) * NdotL;
						float weight = NdotL * invDistance * invDistance * invDistance / ( d * d );

						prefilteredColor += textureLod( envMap, texelDirection, sourceLod ).rgb * weight;
						totalWeight += weight;

					}

				}

			}

			gl_FragColor = vec4( prefilteredColor / totalWeight, 1.0 );

		}
	`)}function Sc(){return yc(`PMREMSphericalGaussianBlur`,{envMap:{value:null},sigma:{value:0}},`

		#define SAMPLES ${dc}
		#define GOLDEN_ANGLE 2.39996322973

		varying vec3 vWorldDirection;

		uniform samplerCube envMap;
		uniform float sigma;

		#include <common>

		void main() {

			vec3 outputDirection = normalize( vWorldDirection );

			vec3 up = abs( outputDirection.z ) < 0.999 ? vec3( 0.0, 0.0, 1.0 ) : vec3( 1.0, 0.0, 0.0 );
			vec3 tangent = normalize( cross( up, outputDirection ) );
			vec3 bitangent = cross( outputDirection, tangent );

			// Truncate the kernel at three standard deviations or at the antipode.
			float thetaMax = min( 3.0 * sigma, PI );
			float truncation = 1.0 - exp( - 0.5 * thetaMax * thetaMax / ( sigma * sigma ) );

			vec3 accumColor = vec3( 0.0 );
			float accumWeight = 0.0;

			for ( int i = 0; i < SAMPLES; i ++ ) {

				// Stratified inverse-CDF sampling of the Gaussian, placed on a golden-angle spiral.
				float stratum = ( float( i ) + 0.5 ) / float( SAMPLES );
				float theta = sigma * sqrt( - 2.0 * log( 1.0 - stratum * truncation ) );
				float phi = float( i ) * GOLDEN_ANGLE;

				vec3 offset = cos( phi ) * tangent + sin( phi ) * bitangent;
				vec3 sampleDirection = cos( theta ) * outputDirection + sin( theta ) * offset;

				// Correct the planar sample density to solid angle.
				float weight = sin( theta ) / theta;

				accumColor += weight * textureLod( envMap, sampleDirection, 0.0 ).rgb;
				accumWeight += weight;

			}

			gl_FragColor = vec4( accumColor / accumWeight, 1.0 );

		}
	`)}function Cc(){return yc(`PMREMEquirectangularToCubemap`,{envMap:{value:null}},`

		varying vec3 vWorldDirection;

		uniform sampler2D envMap;

		#include <common>

		void main() {

			// Average four subpixel samples to preserve small, bright features.
			vec3 direction = normalize( vWorldDirection );
			vec3 dx = dFdx( direction ) * 0.25;
			vec3 dy = dFdy( direction ) * 0.25;

			vec3 color = textureLod( envMap, equirectUv( normalize( direction - dx - dy ) ), 0.0 ).rgb;
			color += textureLod( envMap, equirectUv( normalize( direction + dx - dy ) ), 0.0 ).rgb;
			color += textureLod( envMap, equirectUv( normalize( direction - dx + dy ) ), 0.0 ).rgb;
			color += textureLod( envMap, equirectUv( normalize( direction + dx + dy ) ), 0.0 ).rgb;
			gl_FragColor = vec4( color * 0.25, 1.0 );

		}
	`)}function wc(){return yc(`PMREMCubemapToCubemap`,{envMap:{value:null},flipEnvMap:{value:-1}},`

		varying vec3 vWorldDirection;

		uniform samplerCube envMap;
		uniform float flipEnvMap;

		void main() {

			gl_FragColor = vec4( textureCube( envMap, vec3( flipEnvMap * vWorldDirection.x, vWorldDirection.yz ) ).rgb, 1.0 );

		}
	`)}function Tc(e){let t=new WeakMap,n=new WeakMap,r=null;function i(e,t=!1){return e==null?null:t?o(e):a(e)}function a(n){if(n&&n.isTexture){let r=n.mapping;if(r===303||r===304){if(t.has(n)){let e=t.get(n).texture;return s(e,n.mapping)}{let r=n.image;if(r&&r.height>0){let i=new cc(r.height);return i.fromEquirectangularTexture(e,n),t.set(n,i),n.addEventListener(`dispose`,l),s(i.texture,n.mapping)}return null}}}return n}function o(t){if(t&&t.isTexture&&t.isPMREMTexture!==!0){let i=t.mapping,a=i===303||i===304,o=i===301||i===302;if(a||o){let i=n.get(t),s=i===void 0?0:i.texture.pmremVersion;if(t.isRenderTargetTexture&&t.pmremVersion!==s)return r===null&&(r=new _c(e)),i=a?r.fromEquirectangular(t,i):r.fromCubemap(t,i),i.texture.pmremVersion=t.pmremVersion,n.set(t,i),i.texture;if(i!==void 0)return i.texture;{let s=t.image;return a&&s&&s.height>0||o&&s&&c(s)?(r===null&&(r=new _c(e)),i=a?r.fromEquirectangular(t):r.fromCubemap(t),i.texture.pmremVersion=t.pmremVersion,n.set(t,i),t.addEventListener(`dispose`,u),i.texture):null}}}return t}function s(e,t){return t===303?e.mapping=301:t===304&&(e.mapping=302),e}function c(e){let t=0;for(let n=0;n<6;n++)e[n]!==void 0&&t++;return t===6}function l(e){let n=e.target;n.removeEventListener(`dispose`,l);let r=t.get(n);r!==void 0&&(t.delete(n),r.dispose())}function u(e){let t=e.target;t.removeEventListener(`dispose`,u);let r=n.get(t);r!==void 0&&(n.delete(t),r.dispose())}function d(){t=new WeakMap,n=new WeakMap,r!==null&&(r.dispose(),r=null)}return{get:i,dispose:d}}function Ec(e){let t={};function n(n){if(t[n]!==void 0)return t[n];let r=e.getExtension(n);return t[n]=r,r}return{has:function(e){return n(e)!==null},init:function(){n(`EXT_color_buffer_float`),n(`WEBGL_clip_cull_distance`),n(`OES_texture_float_linear`),n(`EXT_color_buffer_half_float`),n(`WEBGL_multisampled_render_to_texture`),n(`WEBGL_render_shared_exponent`)},get:function(e){let t=n(e);return t===null&&rt(`WebGLRenderer: `+e+` extension not supported.`),t}}}function Dc(e,t,n,r){let i={},a=new WeakMap,o=new FinalizationRegistry(e=>delete i[e]);function s(e){c(e.target)}function c(e){e.index!==null&&t.remove(e.index);for(let n in e.attributes)t.remove(e.attributes[n]);e.removeEventListener(`dispose`,s),delete i[e.id],o.unregister(e);let c=a.get(e);c&&(t.remove(c),a.delete(e)),r.releaseStatesOfGeometry(e),e.isInstancedBufferGeometry===!0&&delete e._maxInstanceCount,n.memory.geometries--}function l(e,t){return i[t.id]===void 0&&(t.addEventListener(`dispose`,s),i[t.id]=new WeakRef(t),o.register(t,t.id,t),n.memory.geometries++),t}function u(n){let r=n.attributes;for(let n in r)t.update(r[n],e.ARRAY_BUFFER)}function d(e){let n=e.index,r=e.attributes.position,i=0;if(r===void 0)return;let o=n===null?r.array.length/3-1:n.array.length,s=new(r.count>=65535?Cr:Sr)(Math.ceil(o/3)*6,1),c=s.array;if(n!==null){let e=n.array;i=n.version;for(let t=0,n=0;t<o;t+=3){let r=e[t+0],i=e[t+1],a=e[t+2];c[n++]=r,c[n++]=i,c[n++]=i,c[n++]=a,c[n++]=a,c[n++]=r}}else{i=r.version;for(let e=0,t=0;e<o;e+=3){let n=e+0,r=e+1,i=e+2;c[t++]=n,c[t++]=r,c[t++]=r,c[t++]=i,c[t++]=i,c[t++]=n}}s.version=i;let l=a.get(e);l&&t.remove(l),a.set(e,s)}function f(e){let t=a.get(e);if(t){let n=e.index;n!==null&&t.version<n.version&&d(e)}else d(e);return a.get(e)}function p(){for(let e in i){let t=i[e].deref();t!==void 0&&c(t)}}return{get:l,update:u,getWireframeAttribute:f,dispose:p}}function Oc(e,t,n){let r;function i(e){r=e}let a,o;function s(e){a=e.type,o=e.bytesPerElement}function c(t,i){e.drawElements(r,i,a,t*o),n.update(i,r,1)}function l(t,i,s){s!==0&&(e.drawElementsInstanced(r,i,a,t*o,s),n.update(i,r,s))}function u(e,i,o){if(o===0)return;t.get(`WEBGL_multi_draw`).multiDrawElementsWEBGL(r,i,0,a,e,0,o);let s=0;for(let e=0;e<o;e++)s+=i[e];n.update(s,r,1)}this.setMode=i,this.setIndex=s,this.render=c,this.renderInstances=l,this.renderMultiDraw=u}function kc(e){let t={geometries:0,textures:0},n={frame:0,calls:0,triangles:0,points:0,lines:0};function r(t,r,i){switch(n.calls++,r){case e.TRIANGLES:n.triangles+=t/3*i;break;case e.LINES:n.lines+=t/2*i;break;case e.LINE_STRIP:n.lines+=i*(t-1);break;case e.LINE_LOOP:n.lines+=i*t;break;case e.POINTS:n.points+=i*t;break;default:nt(`WebGLInfo: Unknown draw mode:`,r)}}function i(){n.calls=0,n.triangles=0,n.points=0,n.lines=0}return{memory:t,render:n,programs:null,autoReset:!0,reset:i,update:r}}function Ac(e,t,n){let r=new WeakMap,i=new en;function a(a,o,s){let c=a.morphTargetInfluences,l=o.morphAttributes.position||o.morphAttributes.normal||o.morphAttributes.color,u=l===void 0?0:l.length,d=r.get(o);if(d===void 0||d.count!==u){d!==void 0&&d.texture.dispose();let e=o.morphAttributes.position!==void 0,n=o.morphAttributes.normal!==void 0,a=o.morphAttributes.color!==void 0,s=o.morphAttributes.position||[],c=o.morphAttributes.normal||[],l=o.morphAttributes.color||[],f=0;e===!0&&(f=1),n===!0&&(f=2),a===!0&&(f=3);let p=o.attributes.position.count*f,m=1;p>t.maxTextureSize&&(m=Math.ceil(p/t.maxTextureSize),p=t.maxTextureSize);let g=new Float32Array(p*m*4*u),_=new rn(g,p,m,u);_.type=h,_.needsUpdate=!0;let v=f*4;for(let t=0;t<u;t++){let r=s[t],o=c[t],u=l[t],d=p*m*4*t;for(let t=0;t<r.count;t++){let s=t*v;e===!0&&(i.fromBufferAttribute(r,t),g[d+s+0]=i.x,g[d+s+1]=i.y,g[d+s+2]=i.z,g[d+s+3]=0),n===!0&&(i.fromBufferAttribute(o,t),g[d+s+4]=i.x,g[d+s+5]=i.y,g[d+s+6]=i.z,g[d+s+7]=0),a===!0&&(i.fromBufferAttribute(u,t),g[d+s+8]=i.x,g[d+s+9]=i.y,g[d+s+10]=i.z,g[d+s+11]=u.itemSize===4?i.w:1)}}d={count:u,texture:_,size:new I(p,m)},r.set(o,d);function y(){_.dispose(),r.delete(o),o.removeEventListener(`dispose`,y)}o.addEventListener(`dispose`,y)}if(a.isInstancedMesh===!0&&a.morphTexture!==null)s.getUniforms().setValue(e,`morphTexture`,a.morphTexture,n);else{let t=0;for(let e=0;e<c.length;e++)t+=c[e];let n=o.morphTargetsRelative?1:1-t;s.getUniforms().setValue(e,`morphTargetBaseInfluence`,n),s.getUniforms().setValue(e,`morphTargetInfluences`,c)}s.getUniforms().setValue(e,`morphTargetsTexture`,d.texture,n),s.getUniforms().setValue(e,`morphTargetsTextureSize`,d.size)}return{update:a}}function jc(e,t,n,r,i){let a=new WeakMap;function o(r){let o=i.render.frame,s=r.geometry,l=t.get(r,s);if(a.get(l)!==o&&(t.update(l),a.set(l,o)),r.isInstancedMesh&&(r.hasEventListener(`dispose`,c)===!1&&r.addEventListener(`dispose`,c),a.get(r)!==o&&(n.update(r.instanceMatrix,e.ARRAY_BUFFER),r.instanceColor!==null&&n.update(r.instanceColor,e.ARRAY_BUFFER),a.set(r,o))),r.isSkinnedMesh){let e=r.skeleton;a.get(e)!==o&&(e.update(),a.set(e,o))}return l}function s(){a=new WeakMap}function c(e){let t=e.target;t.removeEventListener(`dispose`,c),r.releaseStatesOfObject(t),n.remove(t.instanceMatrix),t.instanceColor!==null&&n.remove(t.instanceColor)}return{update:o,dispose:s}}var Mc={1:`LINEAR_TONE_MAPPING`,2:`REINHARD_TONE_MAPPING`,3:`CINEON_TONE_MAPPING`,4:`ACES_FILMIC_TONE_MAPPING`,6:`AGX_TONE_MAPPING`,7:`NEUTRAL_TONE_MAPPING`,5:`CUSTOM_TONE_MAPPING`};function Nc(e,t,n,r,i,a){let o=new nn(t,n,{type:e,depthBuffer:i,stencilBuffer:a,samples:r?4:0,storeMultisampledDepthBuffer:!1,storeMultisampledStencilBuffer:!1,resolveDepthBuffer:!1,resolveStencilBuffer:!1}),s=null,c=null,l=null,u=new Ir;u.setAttribute(`position`,new wr([-1,3,0,-1,-1,0,3,-1,0],3)),u.setAttribute(`uv`,new wr([0,2,0,0,2,0],2));let d=new Fo({uniforms:{tDiffuse:{value:null}},vertexShader:`
			precision highp float;

			uniform mat4 modelViewMatrix;
			uniform mat4 projectionMatrix;

			attribute vec3 position;
			attribute vec2 uv;

			varying vec2 vUv;

			void main() {
				vUv = uv;
				gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
			}`,fragmentShader:`
			precision highp float;

			uniform sampler2D tDiffuse;

			varying vec2 vUv;

			#include <tonemapping_pars_fragment>
			#include <colorspace_pars_fragment>

			void main() {
				gl_FragColor = texture2D( tDiffuse, vUv );

				#ifdef LINEAR_TONE_MAPPING
					gl_FragColor.rgb = LinearToneMapping( gl_FragColor.rgb );
				#elif defined( REINHARD_TONE_MAPPING )
					gl_FragColor.rgb = ReinhardToneMapping( gl_FragColor.rgb );
				#elif defined( CINEON_TONE_MAPPING )
					gl_FragColor.rgb = CineonToneMapping( gl_FragColor.rgb );
				#elif defined( ACES_FILMIC_TONE_MAPPING )
					gl_FragColor.rgb = ACESFilmicToneMapping( gl_FragColor.rgb );
				#elif defined( AGX_TONE_MAPPING )
					gl_FragColor.rgb = AgXToneMapping( gl_FragColor.rgb );
				#elif defined( NEUTRAL_TONE_MAPPING )
					gl_FragColor.rgb = NeutralToneMapping( gl_FragColor.rgb );
				#elif defined( CUSTOM_TONE_MAPPING )
					gl_FragColor.rgb = CustomToneMapping( gl_FragColor.rgb );
				#endif

				#ifdef SRGB_TRANSFER
					gl_FragColor = sRGBTransferOETF( gl_FragColor );
				#endif
			}`,depthTest:!1,depthWrite:!1}),f=new oi(u,d),p=new Ss(-1,1,1,-1,0,1),m=null,h=null,_=!1,v,b=null,x=[],S=!1;this.setSize=function(e,t){o.setSize(e,t),s!==null&&s.setSize(e,t),c!==null&&c.setSize(e,t);for(let n=0;n<x.length;n++){let r=x[n];r.setSize&&r.setSize(e,t)}},this.setEffects=function(e){x=e,S=x.length>0&&x[0].isRenderPass===!0;let t=o.width,n=o.height;x.length>0&&s===null&&(s=new nn(t,n,{type:g,depthBuffer:!1,stencilBuffer:!1}),c=new nn(t,n,{type:g,depthBuffer:!1,stencilBuffer:!1}));let r=i===!0&&x.some(e=>e.needsDepthTexture===!0);r!==(o.depthTexture!==null)&&(r===!0&&l===null&&(l=new qi(t,n),a===!0&&(l.format=E,l.type=y)),o.dispose(),o.depthTexture=r?l:null,o.resolveDepthBuffer=r,o.storeMultisampledDepthBuffer=r);for(let e=0;e<x.length;e++){let i=x[e];i.setSize&&i.setSize(t,n),r&&i.needsDepthTexture===!0&&i.setDepthTexture&&i.setDepthTexture(l)}},this.begin=function(e,t){if(_||e.toneMapping===0&&x.length===0)return!1;if(b=t,t!==null){let e=t.width,n=t.height;(o.width!==e||o.height!==n)&&this.setSize(e,n)}return S===!1&&e.setRenderTarget(o),v=e.toneMapping,e.toneMapping=0,!0},this.hasRenderPass=function(){return S},this.end=function(e,t){e.toneMapping=v,_=!0;let n=o,r=s;for(let i=0;i<x.length;i++){let a=x[i];a.enabled!==!1&&(a.render(e,r,n,t),a.needsSwap!==!1&&(n=r,r=r===s?c:s))}if(m!==e.outputColorSpace||h!==e.toneMapping){m=e.outputColorSpace,h=e.toneMapping,d.defines={},Ut.getTransfer(m)===`srgb`&&(d.defines.SRGB_TRANSFER=``);let t=Mc[h];t&&(d.defines[t]=``),d.needsUpdate=!0}d.uniforms.tDiffuse.value=n.texture,e.setRenderTarget(b),e.render(f,p),b=null,_=!1},this.isCompositing=function(){return _},this.dispose=function(){o.dispose(),s!==null&&s.dispose(),c!==null&&c.dispose(),u.dispose(),d.dispose()}}var Pc=new $t,Fc=new qi(1,1),Ic=new Ji(1),Lc=new rn,Rc=new an,zc=new Ki,Bc=[],Vc=[],Hc=new Float32Array(16),Uc=new Float32Array(9),Wc=new Float32Array(4);function Gc(e,t,n){let r=e[0];if(r<=0||r>0)return e;let i=t*n,a=Bc[i];if(a===void 0&&(a=new Float32Array(i),Bc[i]=a),t!==0){r.toArray(a,0);for(let r=1,i=0;r!==t;++r)i+=n,e[r].toArray(a,i)}return a}function Kc(e,t){if(e.length!==t.length)return!1;for(let n=0,r=e.length;n<r;n++)if(e[n]!==t[n])return!1;return!0}function qc(e,t){for(let n=0,r=t.length;n<r;n++)e[n]=t[n]}function Jc(e,t){let n=Vc[t];n===void 0&&(n=new Int32Array(t),Vc[t]=n);for(let r=0;r!==t;++r)n[r]=e.allocateTextureUnit();return n}function Yc(e,t){let n=this.cache;n[0]!==t&&(e.uniform1f(this.addr,t),n[0]=t)}function Xc(e,t){let n=this.cache;if(t.x!==void 0)(n[0]!==t.x||n[1]!==t.y)&&(e.uniform2f(this.addr,t.x,t.y),n[0]=t.x,n[1]=t.y);else{if(Kc(n,t))return;e.uniform2fv(this.addr,t),qc(n,t)}}function Zc(e,t){let n=this.cache;if(t.x!==void 0)(n[0]!==t.x||n[1]!==t.y||n[2]!==t.z)&&(e.uniform3f(this.addr,t.x,t.y,t.z),n[0]=t.x,n[1]=t.y,n[2]=t.z);else if(t.r!==void 0)(n[0]!==t.r||n[1]!==t.g||n[2]!==t.b)&&(e.uniform3f(this.addr,t.r,t.g,t.b),n[0]=t.r,n[1]=t.g,n[2]=t.b);else{if(Kc(n,t))return;e.uniform3fv(this.addr,t),qc(n,t)}}function Qc(e,t){let n=this.cache;if(t.x!==void 0)(n[0]!==t.x||n[1]!==t.y||n[2]!==t.z||n[3]!==t.w)&&(e.uniform4f(this.addr,t.x,t.y,t.z,t.w),n[0]=t.x,n[1]=t.y,n[2]=t.z,n[3]=t.w);else{if(Kc(n,t))return;e.uniform4fv(this.addr,t),qc(n,t)}}function $c(e,t){let n=this.cache,r=t.elements;if(r===void 0){if(Kc(n,t))return;e.uniformMatrix2fv(this.addr,!1,t),qc(n,t)}else{if(Kc(n,r))return;Wc.set(r),e.uniformMatrix2fv(this.addr,!1,Wc),qc(n,r)}}function el(e,t){let n=this.cache,r=t.elements;if(r===void 0){if(Kc(n,t))return;e.uniformMatrix3fv(this.addr,!1,t),qc(n,t)}else{if(Kc(n,r))return;Uc.set(r),e.uniformMatrix3fv(this.addr,!1,Uc),qc(n,r)}}function tl(e,t){let n=this.cache,r=t.elements;if(r===void 0){if(Kc(n,t))return;e.uniformMatrix4fv(this.addr,!1,t),qc(n,t)}else{if(Kc(n,r))return;Hc.set(r),e.uniformMatrix4fv(this.addr,!1,Hc),qc(n,r)}}function nl(e,t){let n=this.cache;n[0]!==t&&(e.uniform1i(this.addr,t),n[0]=t)}function rl(e,t){let n=this.cache;if(t.x!==void 0)(n[0]!==t.x||n[1]!==t.y)&&(e.uniform2i(this.addr,t.x,t.y),n[0]=t.x,n[1]=t.y);else{if(Kc(n,t))return;e.uniform2iv(this.addr,t),qc(n,t)}}function il(e,t){let n=this.cache;if(t.x!==void 0)(n[0]!==t.x||n[1]!==t.y||n[2]!==t.z)&&(e.uniform3i(this.addr,t.x,t.y,t.z),n[0]=t.x,n[1]=t.y,n[2]=t.z);else{if(Kc(n,t))return;e.uniform3iv(this.addr,t),qc(n,t)}}function al(e,t){let n=this.cache;if(t.x!==void 0)(n[0]!==t.x||n[1]!==t.y||n[2]!==t.z||n[3]!==t.w)&&(e.uniform4i(this.addr,t.x,t.y,t.z,t.w),n[0]=t.x,n[1]=t.y,n[2]=t.z,n[3]=t.w);else{if(Kc(n,t))return;e.uniform4iv(this.addr,t),qc(n,t)}}function ol(e,t){let n=this.cache;n[0]!==t&&(e.uniform1ui(this.addr,t),n[0]=t)}function sl(e,t){let n=this.cache;if(t.x!==void 0)(n[0]!==t.x||n[1]!==t.y)&&(e.uniform2ui(this.addr,t.x,t.y),n[0]=t.x,n[1]=t.y);else{if(Kc(n,t))return;e.uniform2uiv(this.addr,t),qc(n,t)}}function cl(e,t){let n=this.cache;if(t.x!==void 0)(n[0]!==t.x||n[1]!==t.y||n[2]!==t.z)&&(e.uniform3ui(this.addr,t.x,t.y,t.z),n[0]=t.x,n[1]=t.y,n[2]=t.z);else{if(Kc(n,t))return;e.uniform3uiv(this.addr,t),qc(n,t)}}function ll(e,t){let n=this.cache;if(t.x!==void 0)(n[0]!==t.x||n[1]!==t.y||n[2]!==t.z||n[3]!==t.w)&&(e.uniform4ui(this.addr,t.x,t.y,t.z,t.w),n[0]=t.x,n[1]=t.y,n[2]=t.z,n[3]=t.w);else{if(Kc(n,t))return;e.uniform4uiv(this.addr,t),qc(n,t)}}function ul(e){return e.version===0&&(e.compareFunction=519,e.needsUpdate=!0),e}function dl(e,t,n){let r=this.cache,i=n.allocateTextureUnit();r[0]!==i&&(e.uniform1i(this.addr,i),r[0]=i);let a;a=this.type===e.SAMPLER_2D_SHADOW?ul(Fc):Pc,n.setTexture2D(t||a,i)}function fl(e,t,n){let r=this.cache,i=n.allocateTextureUnit();r[0]!==i&&(e.uniform1i(this.addr,i),r[0]=i),n.setTexture3D(t||Rc,i)}function pl(e,t,n){let r=this.cache,i=n.allocateTextureUnit();r[0]!==i&&(e.uniform1i(this.addr,i),r[0]=i);let a;a=this.type===e.SAMPLER_CUBE_SHADOW?ul(Ic):zc,n.setTextureCube(t||a,i)}function ml(e,t,n){let r=this.cache,i=n.allocateTextureUnit();r[0]!==i&&(e.uniform1i(this.addr,i),r[0]=i),n.setTexture2DArray(t||Lc,i)}function hl(e){switch(e){case 5126:return Yc;case 35664:return Xc;case 35665:return Zc;case 35666:return Qc;case 35674:return $c;case 35675:return el;case 35676:return tl;case 5124:case 35670:return nl;case 35667:case 35671:return rl;case 35668:case 35672:return il;case 35669:case 35673:return al;case 5125:return ol;case 36294:return sl;case 36295:return cl;case 36296:return ll;case 35678:case 36198:case 36298:case 36306:case 35682:return dl;case 35679:case 36299:case 36307:return fl;case 35680:case 36300:case 36308:case 36293:return pl;case 36289:case 36303:case 36311:case 36292:return ml}}function gl(e,t){e.uniform1fv(this.addr,t)}function _l(e,t){let n=Gc(t,this.size,2);e.uniform2fv(this.addr,n)}function vl(e,t){let n=Gc(t,this.size,3);e.uniform3fv(this.addr,n)}function yl(e,t){let n=Gc(t,this.size,4);e.uniform4fv(this.addr,n)}function bl(e,t){let n=Gc(t,this.size,4);e.uniformMatrix2fv(this.addr,!1,n)}function xl(e,t){let n=Gc(t,this.size,9);e.uniformMatrix3fv(this.addr,!1,n)}function Sl(e,t){let n=Gc(t,this.size,16);e.uniformMatrix4fv(this.addr,!1,n)}function Cl(e,t){e.uniform1iv(this.addr,t)}function wl(e,t){e.uniform2iv(this.addr,t)}function Tl(e,t){e.uniform3iv(this.addr,t)}function El(e,t){e.uniform4iv(this.addr,t)}function Dl(e,t){e.uniform1uiv(this.addr,t)}function Ol(e,t){e.uniform2uiv(this.addr,t)}function kl(e,t){e.uniform3uiv(this.addr,t)}function Al(e,t){e.uniform4uiv(this.addr,t)}function jl(e,t,n){let r=this.cache,i=t.length,a=Jc(n,i);Kc(r,a)||(e.uniform1iv(this.addr,a),qc(r,a));let o;o=this.type===e.SAMPLER_2D_SHADOW?ul(Fc):Pc;for(let e=0;e!==i;++e)n.setTexture2D(t[e]||o,a[e])}function Ml(e,t,n){let r=this.cache,i=t.length,a=Jc(n,i);Kc(r,a)||(e.uniform1iv(this.addr,a),qc(r,a));for(let e=0;e!==i;++e)n.setTexture3D(t[e]||Rc,a[e])}function Nl(e,t,n){let r=this.cache,i=t.length,a=Jc(n,i);Kc(r,a)||(e.uniform1iv(this.addr,a),qc(r,a));let o;o=this.type===e.SAMPLER_CUBE_SHADOW?ul(Ic):zc;for(let e=0;e!==i;++e)n.setTextureCube(t[e]||o,a[e])}function Pl(e,t,n){let r=this.cache,i=t.length,a=Jc(n,i);Kc(r,a)||(e.uniform1iv(this.addr,a),qc(r,a));for(let e=0;e!==i;++e)n.setTexture2DArray(t[e]||Lc,a[e])}function Fl(e){switch(e){case 5126:return gl;case 35664:return _l;case 35665:return vl;case 35666:return yl;case 35674:return bl;case 35675:return xl;case 35676:return Sl;case 5124:case 35670:return Cl;case 35667:case 35671:return wl;case 35668:case 35672:return Tl;case 35669:case 35673:return El;case 5125:return Dl;case 36294:return Ol;case 36295:return kl;case 36296:return Al;case 35678:case 36198:case 36298:case 36306:case 35682:return jl;case 35679:case 36299:case 36307:return Ml;case 35680:case 36300:case 36308:case 36293:return Nl;case 36289:case 36303:case 36311:case 36292:return Pl}}var Il=class{constructor(e,t,n){this.id=e,this.addr=n,this.cache=[],this.type=t.type,this.setValue=hl(t.type)}},Ll=class{constructor(e,t,n){this.id=e,this.addr=n,this.cache=[],this.type=t.type,this.size=t.size,this.setValue=Fl(t.type)}},Rl=class{constructor(e){this.id=e,this.seq=[],this.map={}}setValue(e,t,n){let r=this.seq;for(let i=0,a=r.length;i!==a;++i){let a=r[i];a.setValue(e,t[a.id],n)}}},zl=/(\w+)(\])?(\[|\.)?/g;function Bl(e,t){e.seq.push(t),e.map[t.id]=t}function Vl(e,t,n){let r=e.name,i=r.length;for(zl.lastIndex=0;;){let a=zl.exec(r),o=zl.lastIndex,s=a[1],c=a[2]===`]`,l=a[3];if(c&&(s|=0),l===void 0||l===`[`&&o+2===i){Bl(n,l===void 0?new Il(s,e,t):new Ll(s,e,t));break}{let e=n.map[s];e===void 0&&(e=new Rl(s),Bl(n,e)),n=e}}}var Hl=class{constructor(e,t){this.seq=[],this.map={};let n=e.getProgramParameter(t,e.ACTIVE_UNIFORMS);for(let r=0;r<n;++r){let n=e.getActiveUniform(t,r);Vl(n,e.getUniformLocation(t,n.name),this)}let r=[],i=[];for(let t of this.seq)t.type===e.SAMPLER_2D_SHADOW||t.type===e.SAMPLER_CUBE_SHADOW||t.type===e.SAMPLER_2D_ARRAY_SHADOW?r.push(t):i.push(t);r.length>0&&(this.seq=r.concat(i))}setValue(e,t,n,r){let i=this.map[t];i!==void 0&&i.setValue(e,n,r)}setOptional(e,t,n){let r=t[n];r!==void 0&&this.setValue(e,n,r)}static upload(e,t,n,r){for(let i=0,a=t.length;i!==a;++i){let a=t[i],o=n[a.id];o.needsUpdate!==!1&&a.setValue(e,o.value,r)}}static seqWithValue(e,t){let n=[];for(let r=0,i=e.length;r!==i;++r){let i=e[r];i.id in t&&n.push(i)}return n}};function Ul(e,t,n){let r=e.createShader(t);return e.shaderSource(r,n),e.compileShader(r),r}var Wl=37297,Gl=0;function Kl(e,t){let n=e.split(`
`),r=[],i=Math.max(t-6,0),a=Math.min(t+6,n.length);for(let e=i;e<a;e++){let i=e+1;r.push(`${i===t?`>`:` `} ${i}: ${n[e]}`)}return r.join(`
`)}var ql=new Rt;function Jl(e){Ut._getMatrix(ql,Ut.workingColorSpace,e);let t=`mat3( ${ql.elements.map(e=>e.toFixed(4))} )`;switch(Ut.getTransfer(e)){case He:return[t,`LinearTransferOETF`];case Ue:return[t,`sRGBTransferOETF`];default:return tt(`WebGLProgram: Unsupported color space: `,e),[t,`LinearTransferOETF`]}}function Yl(e,t,n){let r=e.getShaderParameter(t,e.COMPILE_STATUS),i=(e.getShaderInfoLog(t)||``).trim();if(r&&i===``)return``;let a=/ERROR: 0:(\d+)/.exec(i);if(a){let r=parseInt(a[1]);return n.toUpperCase()+`

`+i+`

`+Kl(e.getShaderSource(t),r)}return i}function Xl(e,t){let n=Jl(t);return[`vec4 ${e}( vec4 value ) {`,`	return ${n[1]}( vec4( ${n[0]} * value.rgb, value.a ) );`,`}`].join(`
`)}var Zl={1:`Linear`,2:`Reinhard`,3:`Cineon`,4:`ACESFilmic`,6:`AgX`,7:`Neutral`,5:`Custom`};function Ql(e,t){let n=Zl[t];return n===void 0?(tt(`WebGLProgram: Unsupported toneMapping:`,t),`vec3 `+e+`( vec3 color ) { return LinearToneMapping( color ); }`):`vec3 `+e+`( vec3 color ) { return `+n+`ToneMapping( color ); }`}var $l=new L;function eu(){return Ut.getLuminanceCoefficients($l),[`float luminance( const in vec3 rgb ) {`,`	const vec3 weights = vec3( ${$l.x.toFixed(4)}, ${$l.y.toFixed(4)}, ${$l.z.toFixed(4)} );`,`	return dot( weights, rgb );`,`}`].join(`
`)}function tu(e){return[e.extensionClipCullDistance?`#extension GL_ANGLE_clip_cull_distance : require`:``,e.extensionMultiDraw?`#extension GL_ANGLE_multi_draw : require`:``].filter(iu).join(`
`)}function nu(e){let t=[];for(let n in e){let r=e[n];r!==!1&&t.push(`#define `+n+` `+r)}return t.join(`
`)}function ru(e,t){let n={},r=e.getProgramParameter(t,e.ACTIVE_ATTRIBUTES);for(let i=0;i<r;i++){let r=e.getActiveAttrib(t,i),a=r.name,o=1;r.type===e.FLOAT_MAT2&&(o=2),r.type===e.FLOAT_MAT3&&(o=3),r.type===e.FLOAT_MAT4&&(o=4),n[a]={type:r.type,location:e.getAttribLocation(t,a),locationSize:o}}return n}function iu(e){return e!==``}function au(e,t){let n=t.numSpotLightShadows+t.numSpotLightMaps-t.numSpotLightShadowsWithMaps;return e.replace(/NUM_SUN_LIGHTS/g,t.numSunLights).replace(/NUM_DIR_LIGHTS/g,t.numDirLights).replace(/NUM_SPOT_LIGHTS/g,t.numSpotLights).replace(/NUM_SPOT_LIGHT_MAPS/g,t.numSpotLightMaps).replace(/NUM_SPOT_LIGHT_COORDS/g,n).replace(/NUM_RECT_AREA_LIGHTS/g,t.numRectAreaLights).replace(/NUM_POINT_LIGHTS/g,t.numPointLights).replace(/NUM_HEMI_LIGHTS/g,t.numHemiLights).replace(/NUM_SUN_LIGHT_SHADOWS/g,t.numSunLightShadows).replace(/NUM_DIR_LIGHT_SHADOWS/g,t.numDirLightShadows).replace(/NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS/g,t.numSpotLightShadowsWithMaps).replace(/NUM_SPOT_LIGHT_SHADOWS/g,t.numSpotLightShadows).replace(/NUM_POINT_LIGHT_SHADOWS/g,t.numPointLightShadows).replace(/NUM_LIGHT_PROBE_GRIDS/g,t.numLightProbeGrids)}function ou(e,t){return e.replace(/NUM_CLIPPING_PLANES/g,t.numClippingPlanes).replace(/UNION_CLIPPING_PLANES/g,t.numClippingPlanes-t.numClipIntersection)}var su=/^[ \t]*#include +<([\w\d./]+)>/gm;function cu(e){return e.replace(su,lu)}function lu(e,t){let n=Qs[t];if(n===void 0)throw Error(`THREE.WebGLProgram: Can not resolve #include <`+t+`>`);return cu(n)}var uu=/#pragma unroll_loop_start\s+for\s*\(\s*int\s+i\s*=\s*(\d+)\s*;\s*i\s*<\s*(\d+)\s*;\s*i\s*\+\+\s*\)\s*{([\s\S]+?)}\s+#pragma unroll_loop_end/g;function du(e){return e.replace(uu,fu)}function fu(e,t,n,r){let i=``;for(let e=parseInt(t);e<parseInt(n);e++)i+=r.replace(/\[\s*i\s*\]/g,`[ `+e+` ]`).replace(/UNROLLED_LOOP_INDEX/g,e);return i}function pu(e){let t=`precision ${e.precision} float;
	precision ${e.precision} int;
	precision ${e.precision} sampler2D;
	precision ${e.precision} samplerCube;
	precision ${e.precision} sampler3D;
	precision ${e.precision} sampler2DArray;
	precision ${e.precision} sampler2DShadow;
	precision ${e.precision} samplerCubeShadow;
	precision ${e.precision} sampler2DArrayShadow;
	precision ${e.precision} isampler2D;
	precision ${e.precision} isampler3D;
	precision ${e.precision} isamplerCube;
	precision ${e.precision} isampler2DArray;
	precision ${e.precision} usampler2D;
	precision ${e.precision} usampler3D;
	precision ${e.precision} usamplerCube;
	precision ${e.precision} usampler2DArray;
	`;return e.precision===`highp`?t+=`
#define HIGH_PRECISION`:e.precision===`mediump`?t+=`
#define MEDIUM_PRECISION`:e.precision===`lowp`&&(t+=`
#define LOW_PRECISION`),t}var mu={1:`SHADOWMAP_TYPE_PCF`,3:`SHADOWMAP_TYPE_VSM`};function hu(e){return mu[e.shadowMapType]||`SHADOWMAP_TYPE_BASIC`}var gu={302:`ENVMAP_MODE_REFRACTION`};function _u(e){return e.envMap===!1?`ENVMAP_MODE_REFLECTION`:gu[e.envMapMode]||`ENVMAP_MODE_REFLECTION`}var vu={0:`ENVMAP_BLENDING_MULTIPLY`,1:`ENVMAP_BLENDING_MIX`,2:`ENVMAP_BLENDING_ADD`};function yu(e){return e.envMap===!1?`ENVMAP_BLENDING_NONE`:vu[e.combine]||`ENVMAP_BLENDING_NONE`}function bu(e,t,n,r){let i=e.getContext(),a=n.defines,o=n.vertexShader,s=n.fragmentShader,c=hu(n),l=n.envMapPMREM===!0?`ENVMAP_TYPE_PMREM`:`ENVMAP_TYPE_CUBE`,u=_u(n),d=yu(n),f=tu(n),p=nu(a),m=i.createProgram(),h,g,_=n.glslVersion?`#version `+n.glslVersion+`
`:``;n.isRawShaderMaterial?(h=[`#define SHADER_TYPE `+n.shaderType,`#define SHADER_NAME `+n.shaderName,p].filter(iu).join(`
`),h.length>0&&(h+=`
`),g=[`#define SHADER_TYPE `+n.shaderType,`#define SHADER_NAME `+n.shaderName,p].filter(iu).join(`
`),g.length>0&&(g+=`
`)):(h=[pu(n),`#define SHADER_TYPE `+n.shaderType,`#define SHADER_NAME `+n.shaderName,p,n.extensionClipCullDistance?`#define USE_CLIP_DISTANCE`:``,n.batching?`#define USE_BATCHING`:``,n.batchingColor?`#define USE_BATCHING_COLOR`:``,n.instancing?`#define USE_INSTANCING`:``,n.instancingColor?`#define USE_INSTANCING_COLOR`:``,n.instancingMorph?`#define USE_INSTANCING_MORPH`:``,n.useFog&&n.fog?`#define USE_FOG`:``,n.useFog&&n.fogExp2?`#define FOG_EXP2`:``,n.map?`#define USE_MAP`:``,n.envMap?`#define USE_ENVMAP`:``,n.envMap?`#define `+u:``,n.lightMap?`#define USE_LIGHTMAP`:``,n.aoMap?`#define USE_AOMAP`:``,n.bumpMap?`#define USE_BUMPMAP`:``,n.normalMap?`#define USE_NORMALMAP`:``,n.normalMapObjectSpace?`#define USE_NORMALMAP_OBJECTSPACE`:``,n.normalMapTangentSpace?`#define USE_NORMALMAP_TANGENTSPACE`:``,n.displacementMap?`#define USE_DISPLACEMENTMAP`:``,n.emissiveMap?`#define USE_EMISSIVEMAP`:``,n.anisotropy?`#define USE_ANISOTROPY`:``,n.anisotropyMap?`#define USE_ANISOTROPYMAP`:``,n.clearcoatMap?`#define USE_CLEARCOATMAP`:``,n.clearcoatRoughnessMap?`#define USE_CLEARCOAT_ROUGHNESSMAP`:``,n.clearcoatNormalMap?`#define USE_CLEARCOAT_NORMALMAP`:``,n.diffuseRoughnessMap?`#define USE_DIFFUSE_ROUGHNESSMAP`:``,n.iridescenceMap?`#define USE_IRIDESCENCEMAP`:``,n.iridescenceThicknessMap?`#define USE_IRIDESCENCE_THICKNESSMAP`:``,n.specularMap?`#define USE_SPECULARMAP`:``,n.specularColorMap?`#define USE_SPECULAR_COLORMAP`:``,n.specularIntensityMap?`#define USE_SPECULAR_INTENSITYMAP`:``,n.roughnessMap?`#define USE_ROUGHNESSMAP`:``,n.metalnessMap?`#define USE_METALNESSMAP`:``,n.alphaMap?`#define USE_ALPHAMAP`:``,n.alphaHash?`#define USE_ALPHAHASH`:``,n.transmission?`#define USE_TRANSMISSION`:``,n.transmissionMap?`#define USE_TRANSMISSIONMAP`:``,n.thicknessMap?`#define USE_THICKNESSMAP`:``,n.sheenColorMap?`#define USE_SHEEN_COLORMAP`:``,n.sheenRoughnessMap?`#define USE_SHEEN_ROUGHNESSMAP`:``,n.mapUv?`#define MAP_UV `+n.mapUv:``,n.alphaMapUv?`#define ALPHAMAP_UV `+n.alphaMapUv:``,n.lightMapUv?`#define LIGHTMAP_UV `+n.lightMapUv:``,n.aoMapUv?`#define AOMAP_UV `+n.aoMapUv:``,n.emissiveMapUv?`#define EMISSIVEMAP_UV `+n.emissiveMapUv:``,n.bumpMapUv?`#define BUMPMAP_UV `+n.bumpMapUv:``,n.normalMapUv?`#define NORMALMAP_UV `+n.normalMapUv:``,n.displacementMapUv?`#define DISPLACEMENTMAP_UV `+n.displacementMapUv:``,n.metalnessMapUv?`#define METALNESSMAP_UV `+n.metalnessMapUv:``,n.roughnessMapUv?`#define ROUGHNESSMAP_UV `+n.roughnessMapUv:``,n.anisotropyMapUv?`#define ANISOTROPYMAP_UV `+n.anisotropyMapUv:``,n.clearcoatMapUv?`#define CLEARCOATMAP_UV `+n.clearcoatMapUv:``,n.clearcoatNormalMapUv?`#define CLEARCOAT_NORMALMAP_UV `+n.clearcoatNormalMapUv:``,n.clearcoatRoughnessMapUv?`#define CLEARCOAT_ROUGHNESSMAP_UV `+n.clearcoatRoughnessMapUv:``,n.diffuseRoughnessMapUv?`#define DIFFUSE_ROUGHNESSMAP_UV `+n.diffuseRoughnessMapUv:``,n.iridescenceMapUv?`#define IRIDESCENCEMAP_UV `+n.iridescenceMapUv:``,n.iridescenceThicknessMapUv?`#define IRIDESCENCE_THICKNESSMAP_UV `+n.iridescenceThicknessMapUv:``,n.sheenColorMapUv?`#define SHEEN_COLORMAP_UV `+n.sheenColorMapUv:``,n.sheenRoughnessMapUv?`#define SHEEN_ROUGHNESSMAP_UV `+n.sheenRoughnessMapUv:``,n.specularMapUv?`#define SPECULARMAP_UV `+n.specularMapUv:``,n.specularColorMapUv?`#define SPECULAR_COLORMAP_UV `+n.specularColorMapUv:``,n.specularIntensityMapUv?`#define SPECULAR_INTENSITYMAP_UV `+n.specularIntensityMapUv:``,n.transmissionMapUv?`#define TRANSMISSIONMAP_UV `+n.transmissionMapUv:``,n.thicknessMapUv?`#define THICKNESSMAP_UV `+n.thicknessMapUv:``,n.vertexTangents&&n.flatShading===!1?`#define USE_TANGENT`:``,n.vertexNormals?`#define HAS_NORMAL`:``,n.vertexColors?`#define USE_COLOR`:``,n.vertexAlphas?`#define USE_COLOR_ALPHA`:``,n.vertexUv1s?`#define USE_UV1`:``,n.vertexUv2s?`#define USE_UV2`:``,n.vertexUv3s?`#define USE_UV3`:``,n.pointsUvs?`#define USE_POINTS_UV`:``,n.flatShading?`#define FLAT_SHADED`:``,n.skinning?`#define USE_SKINNING`:``,n.morphTargets?`#define USE_MORPHTARGETS`:``,n.morphNormals&&n.flatShading===!1?`#define USE_MORPHNORMALS`:``,n.morphColors?`#define USE_MORPHCOLORS`:``,n.morphTargetsCount>0?`#define MORPHTARGETS_TEXTURE_STRIDE `+n.morphTextureStride:``,n.morphTargetsCount>0?`#define MORPHTARGETS_COUNT `+n.morphTargetsCount:``,n.doubleSided?`#define DOUBLE_SIDED`:``,n.flipSided?`#define FLIP_SIDED`:``,n.shadowMapEnabled?`#define USE_SHADOWMAP`:``,n.shadowMapEnabled?`#define `+c:``,n.sizeAttenuation?`#define USE_SIZEATTENUATION`:``,n.numLightProbes>0?`#define USE_LIGHT_PROBES`:``,n.logarithmicDepthBuffer?`#define USE_LOGARITHMIC_DEPTH_BUFFER`:``,n.reversedDepthBuffer?`#define USE_REVERSED_DEPTH_BUFFER`:``,`uniform mat4 modelMatrix;`,`uniform mat4 modelViewMatrix;`,`uniform mat4 projectionMatrix;`,`uniform mat4 viewMatrix;`,`uniform mat3 normalMatrix;`,`uniform vec3 cameraPosition;`,`uniform bool isOrthographic;`,`#ifdef USE_INSTANCING`,`	attribute mat4 instanceMatrix;`,`#endif`,`#ifdef USE_INSTANCING_COLOR`,`	attribute vec3 instanceColor;`,`#endif`,`#ifdef USE_INSTANCING_MORPH`,`	uniform sampler2D morphTexture;`,`#endif`,`attribute vec3 position;`,`attribute vec3 normal;`,`attribute vec2 uv;`,`#ifdef USE_UV1`,`	attribute vec2 uv1;`,`#endif`,`#ifdef USE_UV2`,`	attribute vec2 uv2;`,`#endif`,`#ifdef USE_UV3`,`	attribute vec2 uv3;`,`#endif`,`#ifdef USE_TANGENT`,`	attribute vec4 tangent;`,`#endif`,`#if defined( USE_COLOR_ALPHA )`,`	attribute vec4 color;`,`#elif defined( USE_COLOR )`,`	attribute vec3 color;`,`#endif`,`#ifdef USE_SKINNING`,`	attribute vec4 skinIndex;`,`	attribute vec4 skinWeight;`,`#endif`,`
`].filter(iu).join(`
`),g=[pu(n),`#define SHADER_TYPE `+n.shaderType,`#define SHADER_NAME `+n.shaderName,p,n.useFog&&n.fog?`#define USE_FOG`:``,n.useFog&&n.fogExp2?`#define FOG_EXP2`:``,n.alphaToCoverage?`#define ALPHA_TO_COVERAGE`:``,n.map?`#define USE_MAP`:``,n.matcap?`#define USE_MATCAP`:``,n.envMap?`#define USE_ENVMAP`:``,n.envMap?`#define `+l:``,n.envMap?`#define `+u:``,n.envMap?`#define `+d:``,n.envMapPMREM?`#define ENVMAP_MAX_LOD `+n.envMapMaxLod+`.0`:``,n.envMapPMREM?`#define ENVMAP_SIZE `+n.envMapSize+`.0`:``,n.lightMap?`#define USE_LIGHTMAP`:``,n.aoMap?`#define USE_AOMAP`:``,n.bumpMap?`#define USE_BUMPMAP`:``,n.normalMap?`#define USE_NORMALMAP`:``,n.normalMapObjectSpace?`#define USE_NORMALMAP_OBJECTSPACE`:``,n.normalMapTangentSpace?`#define USE_NORMALMAP_TANGENTSPACE`:``,n.packedNormalMap?`#define USE_PACKED_NORMALMAP`:``,n.emissiveMap?`#define USE_EMISSIVEMAP`:``,n.anisotropy?`#define USE_ANISOTROPY`:``,n.anisotropyMap?`#define USE_ANISOTROPYMAP`:``,n.clearcoat?`#define USE_CLEARCOAT`:``,n.clearcoatMap?`#define USE_CLEARCOATMAP`:``,n.clearcoatRoughnessMap?`#define USE_CLEARCOAT_ROUGHNESSMAP`:``,n.clearcoatNormalMap?`#define USE_CLEARCOAT_NORMALMAP`:``,n.diffuseRoughness?`#define USE_DIFFUSE_ROUGHNESS`:``,n.diffuseRoughnessMap?`#define USE_DIFFUSE_ROUGHNESSMAP`:``,n.dispersion?`#define USE_DISPERSION`:``,n.retroreflection?`#define USE_RETROREFLECTION`:``,n.iridescence?`#define USE_IRIDESCENCE`:``,n.iridescenceMap?`#define USE_IRIDESCENCEMAP`:``,n.iridescenceThicknessMap?`#define USE_IRIDESCENCE_THICKNESSMAP`:``,n.specularMap?`#define USE_SPECULARMAP`:``,n.specularColorMap?`#define USE_SPECULAR_COLORMAP`:``,n.specularIntensityMap?`#define USE_SPECULAR_INTENSITYMAP`:``,n.roughnessMap?`#define USE_ROUGHNESSMAP`:``,n.metalnessMap?`#define USE_METALNESSMAP`:``,n.alphaMap?`#define USE_ALPHAMAP`:``,n.alphaTest?`#define USE_ALPHATEST`:``,n.alphaHash?`#define USE_ALPHAHASH`:``,n.sheen?`#define USE_SHEEN`:``,n.sheenColorMap?`#define USE_SHEEN_COLORMAP`:``,n.sheenRoughnessMap?`#define USE_SHEEN_ROUGHNESSMAP`:``,n.transmission?`#define USE_TRANSMISSION`:``,n.transmissionMap?`#define USE_TRANSMISSIONMAP`:``,n.thicknessMap?`#define USE_THICKNESSMAP`:``,n.vertexTangents&&n.flatShading===!1?`#define USE_TANGENT`:``,n.vertexColors||n.instancingColor?`#define USE_COLOR`:``,n.vertexAlphas||n.batchingColor?`#define USE_COLOR_ALPHA`:``,n.vertexUv1s?`#define USE_UV1`:``,n.vertexUv2s?`#define USE_UV2`:``,n.vertexUv3s?`#define USE_UV3`:``,n.pointsUvs?`#define USE_POINTS_UV`:``,n.gradientMap?`#define USE_GRADIENTMAP`:``,n.flatShading?`#define FLAT_SHADED`:``,n.doubleSided?`#define DOUBLE_SIDED`:``,n.flipSided?`#define FLIP_SIDED`:``,n.shadowMapEnabled?`#define USE_SHADOWMAP`:``,n.shadowMapEnabled?`#define `+c:``,n.premultipliedAlpha?`#define PREMULTIPLIED_ALPHA`:``,n.numLightProbes>0?`#define USE_LIGHT_PROBES`:``,n.decodeVideoTexture?`#define DECODE_VIDEO_TEXTURE`:``,n.decodeVideoTextureEmissive?`#define DECODE_VIDEO_TEXTURE_EMISSIVE`:``,n.logarithmicDepthBuffer?`#define USE_LOGARITHMIC_DEPTH_BUFFER`:``,n.reversedDepthBuffer?`#define USE_REVERSED_DEPTH_BUFFER`:``,`uniform mat4 viewMatrix;`,`uniform vec3 cameraPosition;`,`uniform bool isOrthographic;`,n.toneMapping===0?``:`#define TONE_MAPPING`,n.toneMapping===0?``:Qs.tonemapping_pars_fragment,n.toneMapping===0?``:Ql(`toneMapping`,n.toneMapping),n.dithering?`#define DITHERING`:``,n.opaque?`#define OPAQUE`:``,Qs.colorspace_pars_fragment,Xl(`linearToOutputTexel`,n.outputColorSpace),eu(),n.useDepthPacking?`#define DEPTH_PACKING `+n.depthPacking:``,`
`].filter(iu).join(`
`)),o=cu(o),o=au(o,n),o=ou(o,n),s=cu(s),s=au(s,n),s=ou(s,n),o=du(o),s=du(s),n.isRawShaderMaterial!==!0&&(_=`#version 300 es
`,h=[f,`#define attribute in`,`#define varying out`,`#define texture2D texture`].join(`
`)+`
`+h,g=[`#define varying in`,n.glslVersion===`300 es`?``:`layout(location = 0) out highp vec4 pc_fragColor;`,n.glslVersion===`300 es`?``:`#define gl_FragColor pc_fragColor`,`#define gl_FragDepthEXT gl_FragDepth`,`#define texture2D texture`,`#define textureCube texture`,`#define texture2DProj textureProj`,`#define texture2DLodEXT textureLod`,`#define texture2DProjLodEXT textureProjLod`,`#define textureCubeLodEXT textureLod`,`#define texture2DGradEXT textureGrad`,`#define texture2DProjGradEXT textureProjGrad`,`#define textureCubeGradEXT textureGrad`].join(`
`)+`
`+g);let v=_+h+o,y=_+g+s,b=Ul(i,i.VERTEX_SHADER,v),x=Ul(i,i.FRAGMENT_SHADER,y);i.attachShader(m,b),i.attachShader(m,x),n.index0AttributeName===void 0?n.hasPositionAttribute===!0&&i.bindAttribLocation(m,0,`position`):i.bindAttribLocation(m,0,n.index0AttributeName),i.linkProgram(m);function S(t){if(e.debug.checkShaderErrors){let n=i.getProgramInfoLog(m)||``,r=i.getShaderInfoLog(b)||``,a=i.getShaderInfoLog(x)||``,o=n.trim(),s=r.trim(),c=a.trim(),l=!0,u=!0;if(i.getProgramParameter(m,i.LINK_STATUS)===!1){if(l=!1,typeof e.debug.onShaderError==`function`)e.debug.onShaderError(i,m,b,x);else{let e=Yl(i,b,`vertex`),n=Yl(i,x,`fragment`);nt(`WebGLProgram: Shader Error `+i.getError()+` - VALIDATE_STATUS `+i.getProgramParameter(m,i.VALIDATE_STATUS)+`

Material Name: `+t.name+`
Material Type: `+t.type+`

Program Info Log: `+o+`
`+e+`
`+n)}}else o===``?(s===``||c===``)&&(u=!1):tt(`WebGLProgram: Program Info Log:`,o);u&&(t.diagnostics={runnable:l,programLog:o,vertexShader:{log:s,prefix:h},fragmentShader:{log:c,prefix:g}})}i.deleteShader(b),i.deleteShader(x),C=new Hl(i,m),w=ru(i,m)}let C;this.getUniforms=function(){return C===void 0&&S(this),C};let w;this.getAttributes=function(){return w===void 0&&S(this),w};let T=n.rendererExtensionParallelShaderCompile===!1;return this.isReady=function(){return T===!1&&(T=i.getProgramParameter(m,Wl)),T},this.destroy=function(){r.releaseStatesOfProgram(this),i.deleteProgram(m),this.program=void 0},this.type=n.shaderType,this.name=n.shaderName,this.id=Gl++,this.cacheKey=t,this.usedTimes=1,this.program=m,this.vertexShader=b,this.fragmentShader=x,this}var xu=0,Su=class{constructor(){this.shaderCache=new Map,this.materialCache=new Map}update(e,t,n){let r=this._getShaderCacheForMaterial(e);return r.has(t)===!1&&(r.add(t),t.usedTimes++),r.has(n)===!1&&(r.add(n),n.usedTimes++),this}remove(e){let t=this.materialCache.get(e);for(let e of t)e.usedTimes--,e.usedTimes===0&&this.shaderCache.delete(e.code);return this.materialCache.delete(e),this}getVertexShaderStage(e){return this._getShaderStage(e.vertexShader)}getFragmentShaderStage(e){return this._getShaderStage(e.fragmentShader)}dispose(){this.shaderCache.clear(),this.materialCache.clear()}_getShaderCacheForMaterial(e){let t=this.materialCache,n=t.get(e);return n===void 0&&(n=new Set,t.set(e,n)),n}_getShaderStage(e){let t=this.shaderCache,n=t.get(e);return n===void 0&&(n=new Cu(e),t.set(e,n)),n}},Cu=class{constructor(e){this.id=xu++,this.code=e,this.usedTimes=0}};function wu(e){return e===1030||e===37490||e===36285}function Tu(e,t,n,r,i,a){let o=new _n,s=new Su,c=new Set,l=[],u=new Map,d=r.logarithmicDepthBuffer,f={MeshDepthMaterial:`depth`,MeshDistanceMaterial:`distance`,MeshNormalMaterial:`normal`,MeshBasicMaterial:`basic`,MeshLambertMaterial:`lambert`,MeshPhongMaterial:`phong`,MeshToonMaterial:`toon`,MeshStandardMaterial:`physical`,MeshPhysicalMaterial:`physical`,MeshMatcapMaterial:`matcap`,LineBasicMaterial:`basic`,LineDashedMaterial:`dashed`,PointsMaterial:`points`,ShadowMaterial:`shadow`,SpriteMaterial:`sprite`};function p(e){return c.add(e),e===0?`uv`:`uv${e}`}function m(i,o,l,u,m,h){let g=u.fog,_=m.geometry,v=i.isMeshStandardMaterial||i.isMeshLambertMaterial||i.isMeshPhongMaterial?u.environment:null,y=i.isMeshStandardMaterial||i.isMeshLambertMaterial&&!i.envMap||i.isMeshPhongMaterial&&!i.envMap,b=t.get(i.envMap||v,y),x=f[i.type],S=r.precision;i.precision!==null&&(S=r.getMaxPrecision(i.precision),S!==i.precision&&tt(`WebGLProgram.getParameters:`,i.precision,`not supported, using`,S,`instead.`));let C=_.morphAttributes.position||_.morphAttributes.normal||_.morphAttributes.color,w=C===void 0?0:C.length,T=0;_.morphAttributes.position!==void 0&&(T=1),_.morphAttributes.normal!==void 0&&(T=2),_.morphAttributes.color!==void 0&&(T=3);let E,D,O,k;if(x){let e=$s[x];E=e.vertexShader,D=e.fragmentShader}else{E=i.vertexShader,D=i.fragmentShader;let e=s.getVertexShaderStage(i),t=s.getFragmentShaderStage(i);s.update(i,e,t),O=e.id,k=t.id}let A=e.getRenderTarget(),ee=e.state.buffers.depth.getReversed(),j=m.isInstancedMesh===!0,te=m.isBatchedMesh===!0,M=!!i.map,ne=!!i.matcap,N=!!b,re=N&&b.isPMREMTexture===!0,ie=!!i.aoMap,ae=!!i.lightMap,oe=!!i.bumpMap&&i.wireframe===!1,se=!!i.normalMap,ce=!!i.displacementMap,le=!!i.emissiveMap,ue=!!i.metalnessMap,de=!!i.roughnessMap,fe=i.anisotropy>0,pe=i.clearcoat>0,me=i.diffuseRoughness>0,he=i.dispersion>0,ge=i.retroreflectivity>0,_e=i.iridescence>0,ve=i.sheen>0,ye=i.transmission>0,be=fe&&!!i.anisotropyMap,xe=pe&&!!i.clearcoatMap,Se=pe&&!!i.clearcoatNormalMap,Ce=pe&&!!i.clearcoatRoughnessMap,we=me&&!!i.diffuseRoughnessMap,Te=_e&&!!i.iridescenceMap,Ee=_e&&!!i.iridescenceThicknessMap,De=ve&&!!i.sheenColorMap,Oe=ve&&!!i.sheenRoughnessMap,ke=!!i.specularMap,Ae=!!i.specularColorMap,je=!!i.specularIntensityMap,Me=ye&&!!i.transmissionMap,Ne=ye&&!!i.thicknessMap,Pe=!!i.gradientMap,Fe=!!i.alphaMap,P=i.alphaTest>0,Ie=!!i.alphaHash,Le=!!i.extensions,Re=0;i.toneMapped&&(A===null||A.isXRRenderTarget===!0)&&(Re=e.toneMapping);let F=re?b.isCompressedCubeTexture?b.image[0].mipmaps:b.mipmaps:null,ze={shaderID:x,shaderType:i.type,shaderName:i.name,vertexShader:E,fragmentShader:D,defines:i.defines,customVertexShaderID:O,customFragmentShaderID:k,isRawShaderMaterial:i.isRawShaderMaterial===!0,glslVersion:i.glslVersion,precision:S,batching:te,batchingColor:te&&m._colorsTexture!==null,instancing:j,instancingColor:j&&m.instanceColor!==null,instancingMorph:j&&m.morphTexture!==null,outputColorSpace:A===null?e.outputColorSpace:A.isXRRenderTarget===!0?A.texture.colorSpace:Ut.workingColorSpace,alphaToCoverage:!!i.alphaToCoverage,map:M,matcap:ne,envMap:N,envMapMode:N&&b.mapping,envMapPMREM:re,envMapMaxLod:re?F.length-1:null,envMapSize:re?F[0].width:null,aoMap:ie,lightMap:ae,bumpMap:oe,normalMap:se,displacementMap:ce,emissiveMap:le,normalMapObjectSpace:se&&i.normalMapType===1,normalMapTangentSpace:se&&i.normalMapType===0,packedNormalMap:se&&i.normalMapType===0&&wu(i.normalMap.format),metalnessMap:ue,roughnessMap:de,anisotropy:fe,anisotropyMap:be,clearcoat:pe,clearcoatMap:xe,clearcoatNormalMap:Se,clearcoatRoughnessMap:Ce,diffuseRoughness:me,diffuseRoughnessMap:we,dispersion:he,retroreflection:ge,iridescence:_e,iridescenceMap:Te,iridescenceThicknessMap:Ee,sheen:ve,sheenColorMap:De,sheenRoughnessMap:Oe,specularMap:ke,specularColorMap:Ae,specularIntensityMap:je,transmission:ye,transmissionMap:Me,thicknessMap:Ne,gradientMap:Pe,opaque:i.transparent===!1&&i.blending===1&&i.alphaToCoverage===!1,alphaMap:Fe,alphaTest:P,alphaHash:Ie,combine:i.combine,mapUv:M&&p(i.map.channel),aoMapUv:ie&&p(i.aoMap.channel),lightMapUv:ae&&p(i.lightMap.channel),bumpMapUv:oe&&p(i.bumpMap.channel),normalMapUv:se&&p(i.normalMap.channel),displacementMapUv:ce&&p(i.displacementMap.channel),emissiveMapUv:le&&p(i.emissiveMap.channel),metalnessMapUv:ue&&p(i.metalnessMap.channel),roughnessMapUv:de&&p(i.roughnessMap.channel),anisotropyMapUv:be&&p(i.anisotropyMap.channel),clearcoatMapUv:xe&&p(i.clearcoatMap.channel),clearcoatNormalMapUv:Se&&p(i.clearcoatNormalMap.channel),clearcoatRoughnessMapUv:Ce&&p(i.clearcoatRoughnessMap.channel),diffuseRoughnessMapUv:we&&p(i.diffuseRoughnessMap.channel),iridescenceMapUv:Te&&p(i.iridescenceMap.channel),iridescenceThicknessMapUv:Ee&&p(i.iridescenceThicknessMap.channel),sheenColorMapUv:De&&p(i.sheenColorMap.channel),sheenRoughnessMapUv:Oe&&p(i.sheenRoughnessMap.channel),specularMapUv:ke&&p(i.specularMap.channel),specularColorMapUv:Ae&&p(i.specularColorMap.channel),specularIntensityMapUv:je&&p(i.specularIntensityMap.channel),transmissionMapUv:Me&&p(i.transmissionMap.channel),thicknessMapUv:Ne&&p(i.thicknessMap.channel),alphaMapUv:Fe&&p(i.alphaMap.channel),vertexTangents:!!_.attributes.tangent&&(se||fe),vertexNormals:!!_.attributes.normal,vertexColors:i.vertexColors,vertexAlphas:i.vertexColors===!0&&!!_.attributes.color&&_.attributes.color.itemSize===4,pointsUvs:m.isPoints===!0&&!!_.attributes.uv&&(M||Fe),fog:!!g,useFog:i.fog===!0,fogExp2:!!g&&g.isFogExp2,flatShading:i.wireframe===!1&&(i.flatShading===!0||_.attributes.normal===void 0&&se===!1&&(i.isMeshLambertMaterial||i.isMeshPhongMaterial||i.isMeshStandardMaterial||i.isMeshPhysicalMaterial)),sizeAttenuation:i.sizeAttenuation===!0,logarithmicDepthBuffer:d,reversedDepthBuffer:ee,skinning:m.isSkinnedMesh===!0,hasPositionAttribute:_.attributes.position!==void 0,morphTargets:_.morphAttributes.position!==void 0,morphNormals:_.morphAttributes.normal!==void 0,morphColors:_.morphAttributes.color!==void 0,morphTargetsCount:w,morphTextureStride:T,numSunLights:o.sun.length,numDirLights:o.directional.length,numPointLights:o.point.length,numSpotLights:o.spot.length,numSpotLightMaps:o.spotLightMap.length,numRectAreaLights:o.rectArea.length,numHemiLights:o.hemi.length,numSunLightShadows:o.sunShadowMap.length,numDirLightShadows:o.directionalShadowMap.length,numPointLightShadows:o.pointShadowMap.length,numSpotLightShadows:o.spotShadowMap.length,numSpotLightShadowsWithMaps:o.numSpotLightShadowsWithMaps,numLightProbes:o.numLightProbes,numLightProbeGrids:h.filter(e=>e.texture!==null).length,numClippingPlanes:a.numPlanes,numClipIntersection:a.numIntersection,dithering:i.dithering,shadowMapEnabled:e.shadowMap.enabled&&l.length>0,shadowMapType:e.shadowMap.type,toneMapping:Re,decodeVideoTexture:M&&i.map.isVideoTexture===!0&&Ut.getTransfer(i.map.colorSpace)===`srgb`,decodeVideoTextureEmissive:le&&i.emissiveMap.isVideoTexture===!0&&Ut.getTransfer(i.emissiveMap.colorSpace)===`srgb`,premultipliedAlpha:i.premultipliedAlpha,doubleSided:i.side===2,flipSided:i.side===1,useDepthPacking:i.depthPacking>=0,depthPacking:i.depthPacking||0,index0AttributeName:i.index0AttributeName,extensionClipCullDistance:Le&&i.extensions.clipCullDistance===!0&&n.has(`WEBGL_clip_cull_distance`),extensionMultiDraw:(Le&&i.extensions.multiDraw===!0||te)&&n.has(`WEBGL_multi_draw`),rendererExtensionParallelShaderCompile:n.has(`KHR_parallel_shader_compile`),customProgramCacheKey:i.customProgramCacheKey()};return ze.vertexUv1s=c.has(1),ze.vertexUv2s=c.has(2),ze.vertexUv3s=c.has(3),c.clear(),ze}function h(t){let n=[];if(t.shaderID?n.push(t.shaderID):(n.push(t.customVertexShaderID),n.push(t.customFragmentShaderID)),t.defines!==void 0)for(let e in t.defines)n.push(e),n.push(t.defines[e]);return t.isRawShaderMaterial===!1&&(g(n,t),_(n,t),n.push(e.outputColorSpace)),n.push(t.customProgramCacheKey),n.join()}function g(e,t){e.push(t.precision),e.push(t.outputColorSpace),e.push(t.envMapMode),e.push(t.envMapPMREM),e.push(t.envMapMaxLod),e.push(t.envMapSize),e.push(t.mapUv),e.push(t.alphaMapUv),e.push(t.lightMapUv),e.push(t.aoMapUv),e.push(t.bumpMapUv),e.push(t.normalMapUv),e.push(t.displacementMapUv),e.push(t.emissiveMapUv),e.push(t.metalnessMapUv),e.push(t.roughnessMapUv),e.push(t.anisotropyMapUv),e.push(t.clearcoatMapUv),e.push(t.clearcoatNormalMapUv),e.push(t.clearcoatRoughnessMapUv),e.push(t.diffuseRoughnessMapUv),e.push(t.iridescenceMapUv),e.push(t.iridescenceThicknessMapUv),e.push(t.sheenColorMapUv),e.push(t.sheenRoughnessMapUv),e.push(t.specularMapUv),e.push(t.specularColorMapUv),e.push(t.specularIntensityMapUv),e.push(t.transmissionMapUv),e.push(t.thicknessMapUv),e.push(t.combine),e.push(t.fogExp2),e.push(t.sizeAttenuation),e.push(t.morphTargetsCount),e.push(t.numSunLights),e.push(t.numDirLights),e.push(t.numPointLights),e.push(t.numSpotLights),e.push(t.numSpotLightMaps),e.push(t.numHemiLights),e.push(t.numRectAreaLights),e.push(t.numSunLightShadows),e.push(t.numDirLightShadows),e.push(t.numPointLightShadows),e.push(t.numSpotLightShadows),e.push(t.numSpotLightShadowsWithMaps),e.push(t.numLightProbes),e.push(t.numLightProbeGrids),e.push(t.shadowMapType),e.push(t.toneMapping),e.push(t.numClippingPlanes),e.push(t.numClipIntersection),e.push(t.depthPacking)}function _(e,t){o.disableAll(),t.instancing&&o.enable(0),t.instancingColor&&o.enable(1),t.instancingMorph&&o.enable(2),t.matcap&&o.enable(3),t.envMap&&o.enable(4),t.normalMapObjectSpace&&o.enable(5),t.normalMapTangentSpace&&o.enable(6),t.clearcoat&&o.enable(7),t.iridescence&&o.enable(8),t.alphaTest&&o.enable(9),t.vertexColors&&o.enable(10),t.vertexAlphas&&o.enable(11),t.vertexUv1s&&o.enable(12),t.vertexUv2s&&o.enable(13),t.vertexUv3s&&o.enable(14),t.vertexTangents&&o.enable(15),t.anisotropy&&o.enable(16),t.alphaHash&&o.enable(17),t.batching&&o.enable(18),t.dispersion&&o.enable(19),t.retroreflection&&o.enable(24),t.diffuseRoughness&&o.enable(25),t.batchingColor&&o.enable(20),t.gradientMap&&o.enable(21),t.packedNormalMap&&o.enable(22),t.vertexNormals&&o.enable(23),e.push(o.mask),o.disableAll(),t.fog&&o.enable(0),t.useFog&&o.enable(1),t.flatShading&&o.enable(2),t.logarithmicDepthBuffer&&o.enable(3),t.reversedDepthBuffer&&o.enable(4),t.skinning&&o.enable(5),t.morphTargets&&o.enable(6),t.morphNormals&&o.enable(7),t.morphColors&&o.enable(8),t.premultipliedAlpha&&o.enable(9),t.shadowMapEnabled&&o.enable(10),t.doubleSided&&o.enable(11),t.flipSided&&o.enable(12),t.useDepthPacking&&o.enable(13),t.dithering&&o.enable(14),t.transmission&&o.enable(15),t.sheen&&o.enable(16),t.opaque&&o.enable(17),t.pointsUvs&&o.enable(18),t.decodeVideoTexture&&o.enable(19),t.decodeVideoTextureEmissive&&o.enable(20),t.alphaToCoverage&&o.enable(21),t.numLightProbeGrids>0&&o.enable(22),t.hasPositionAttribute&&o.enable(23),e.push(o.mask)}function v(e){let t=f[e.type],n;if(t){let e=$s[t];n=jo.clone(e.uniforms)}else n=e.uniforms;return n}function y(t,n){let r=u.get(n);return r===void 0?(r=new bu(e,n,t,i),l.push(r),u.set(n,r)):++r.usedTimes,r}function b(e){if(--e.usedTimes===0){let t=l.indexOf(e);l[t]=l[l.length-1],l.pop(),u.delete(e.cacheKey),e.destroy()}}function x(e){s.remove(e)}function S(){s.dispose()}return{getParameters:m,getProgramCacheKey:h,getUniforms:v,acquireProgram:y,releaseProgram:b,releaseShaderCache:x,programs:l,dispose:S}}function Eu(){let e=new WeakMap;function t(t){return e.has(t)}function n(t){let n=e.get(t);return n===void 0&&(n={},e.set(t,n)),n}function r(t){e.delete(t)}function i(t,n,r){e.get(t)[n]=r}function a(){e=new WeakMap}return{has:t,get:n,remove:r,update:i,dispose:a}}function Du(e,t){return e.groupOrder===t.groupOrder?e.renderOrder===t.renderOrder?e.material.id===t.material.id?e.materialVariant===t.materialVariant?e.z===t.z?e.id-t.id:e.z-t.z:e.materialVariant-t.materialVariant:e.material.id-t.material.id:e.renderOrder-t.renderOrder:e.groupOrder-t.groupOrder}function Ou(e,t){return e.groupOrder===t.groupOrder?e.renderOrder===t.renderOrder?e.z===t.z?e.id-t.id:t.z-e.z:e.renderOrder-t.renderOrder:e.groupOrder-t.groupOrder}function ku(){let e=[],t=0,n=[],r=[],i=[];function a(){t=0,n.length=0,r.length=0,i.length=0}function o(e){let t=0;return e.isInstancedMesh&&(t+=2),e.isSkinnedMesh&&(t+=1),t}function s(n,r,i,a,s,c){let l=e[t];return l===void 0?(l={id:n.id,object:n,geometry:r,material:i,materialVariant:o(n),groupOrder:a,renderOrder:n.renderOrder,z:s,group:c},e[t]=l):(l.id=n.id,l.object=n,l.geometry=r,l.material=i,l.materialVariant=o(n),l.groupOrder=a,l.renderOrder=n.renderOrder,l.z=s,l.group=c),t++,l}function c(e,t,a,o,c,l,u){u.reversedDepth===!0&&(c=-c);let d=s(e,t,a,o,c,l);a.transmission>0?r.push(d):a.transparent===!0?i.push(d):n.push(d)}function l(e,t,a,o,c,l){let u=s(e,t,a,o,c,l);a.transmission>0?r.unshift(u):a.transparent===!0?i.unshift(u):n.unshift(u)}function u(e,t){n.length>1&&n.sort(e||Du),r.length>1&&r.sort(t||Ou),i.length>1&&i.sort(t||Ou)}function d(){for(let n=t,r=e.length;n<r;n++){let t=e[n];if(t.id===null)break;t.id=null,t.object=null,t.geometry=null,t.material=null,t.group=null}}return{opaque:n,transmissive:r,transparent:i,init:a,push:c,unshift:l,finish:d,sort:u}}function Au(){let e=new WeakMap;function t(t,n){let r=e.get(t),i;return r===void 0?(i=new ku,e.set(t,[i])):n>=r.length?(i=new ku,r.push(i)):i=r[n],i}function n(){e=new WeakMap}return{get:t,dispose:n}}function ju(){let e={};return{get:function(t){if(e[t.id]!==void 0)return e[t.id];let n;switch(t.type){case`SunLight`:case`DirectionalLight`:n={direction:new L,color:new R};break;case`SpotLight`:n={position:new L,direction:new L,color:new R,distance:0,coneCos:0,penumbraCos:0,decay:0};break;case`PointLight`:n={position:new L,color:new R,distance:0,decay:0};break;case`HemisphereLight`:n={direction:new L,skyColor:new R,groundColor:new R};break;case`RectAreaLight`:n={color:new R,position:new L,halfWidth:new L,halfHeight:new L}}return e[t.id]=n,n}}}function Mu(){let e={};return{get:function(t){if(e[t.id]!==void 0)return e[t.id];let n;switch(t.type){case`SunLight`:case`DirectionalLight`:n={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new I};break;case`SpotLight`:n={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new I};break;case`PointLight`:n={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new I,shadowCameraNear:1,shadowCameraFar:1e3}}return e[t.id]=n,n}}}var Nu=0;function Pu(e,t){return(t.castShadow?2:0)-(e.castShadow?2:0)+ +!!t.map-!!e.map}function Fu(e){let t=new ju,n=Mu(),r={version:0,hash:{sunLength:-1,directionalLength:-1,pointLength:-1,spotLength:-1,rectAreaLength:-1,hemiLength:-1,numSunShadows:-1,numDirectionalShadows:-1,numPointShadows:-1,numSpotShadows:-1,numSpotMaps:-1,numLightProbes:-1},ambient:[0,0,0],probe:[],sun:[],sunShadow:[],sunShadowMap:[],sunShadowMatrix:[],sunShadowCascade:[],directional:[],directionalShadow:[],directionalShadowMap:[],directionalShadowMatrix:[],spot:[],spotLightMap:[],spotShadow:[],spotShadowMap:[],spotLightMatrix:[],rectArea:[],rectAreaLTC1:null,rectAreaLTC2:null,point:[],pointShadow:[],pointShadowMap:[],pointShadowMatrix:[],hemi:[],numSpotLightShadowsWithMaps:0,numLightProbes:0};for(let e=0;e<9;e++)r.probe.push(new L);let i=new L,a=new on,o=new on;function s(i){let a=0,o=0,s=0;for(let e=0;e<9;e++)r.probe[e].set(0,0,0);let c=0,l=0,u=0,d=0,f=0,p=0,m=0,h=0,g=0,_=0,v=0,y=0,b=0,x=0;i.sort(Pu);for(let e=0,S=i.length;e<S;e++){let S=i[e],C=S.color,w=S.intensity,T=S.distance,E=null;if(S.shadow&&S.shadow.map&&(E=S.shadow.map.texture.format===1030?S.shadow.map.texture:S.shadow.map.depthTexture||S.shadow.map.texture),S.isAmbientLight)a+=C.r*w,o+=C.g*w,s+=C.b*w;else if(S.isLightProbe){for(let e=0;e<9;e++)r.probe[e].addScaledVector(S.sh.coefficients[e],w);x++}else if(S.isSunLight){let e=t.get(S);if(e.color.copy(S.color).multiplyScalar(S.intensity),S.castShadow){let e=S.shadow,t=n.get(S);t.shadowIntensity=e.intensity,t.shadowBias=e.bias,t.shadowNormalBias=e.normalBias,t.shadowRadius=e.radius,t.shadowMapSize.copy(e.mapSize).multiply(e.getFrameExtents()),r.sunShadow[l]=t,r.sunShadowMap[l]=E;let i=e.getViewportCount();for(let t=0;t<i;t++)r.sunShadowMatrix[u+t]=e.getMatrix(t),r.sunShadowCascade[u+t]=e._cascadeData[t];u+=i,l++}r.sun[c]=e,c++}else if(S.isDirectionalLight){let e=t.get(S);if(e.color.copy(S.color).multiplyScalar(S.intensity),S.castShadow){let e=S.shadow,t=n.get(S);t.shadowIntensity=e.intensity,t.shadowBias=e.bias,t.shadowNormalBias=e.normalBias,t.shadowRadius=e.radius,t.shadowMapSize=e.mapSize,r.directionalShadow[d]=t,r.directionalShadowMap[d]=E,r.directionalShadowMatrix[d]=S.shadow.matrix,g++}r.directional[d]=e,d++}else if(S.isSpotLight){let e=t.get(S);e.position.setFromMatrixPosition(S.matrixWorld),e.color.copy(C).multiplyScalar(w),e.distance=T,e.coneCos=Math.cos(S.angle),e.penumbraCos=Math.cos(S.angle*(1-S.penumbra)),e.decay=S.decay,r.spot[p]=e;let i=S.shadow;if(S.map&&(r.spotLightMap[y]=S.map,y++,i.updateMatrices(S),S.castShadow&&b++),r.spotLightMatrix[p]=i.matrix,S.castShadow){let e=n.get(S);e.shadowIntensity=i.intensity,e.shadowBias=i.bias,e.shadowNormalBias=i.normalBias,e.shadowRadius=i.radius,e.shadowMapSize=i.mapSize,r.spotShadow[p]=e,r.spotShadowMap[p]=E,v++}p++}else if(S.isRectAreaLight){let e=t.get(S);e.color.copy(C).multiplyScalar(w),e.halfWidth.set(S.width*.5,0,0),e.halfHeight.set(0,S.height*.5,0),r.rectArea[m]=e,m++}else if(S.isPointLight){let e=t.get(S);if(e.color.copy(S.color).multiplyScalar(S.intensity),e.distance=S.distance,e.decay=S.decay,S.castShadow){let e=S.shadow,t=n.get(S);t.shadowIntensity=e.intensity,t.shadowBias=e.bias,t.shadowNormalBias=e.normalBias,t.shadowRadius=e.radius,t.shadowMapSize=e.mapSize,t.shadowCameraNear=e.camera.near,t.shadowCameraFar=e.camera.far,r.pointShadow[f]=t,r.pointShadowMap[f]=E,r.pointShadowMatrix[f]=S.shadow.matrix,_++}r.point[f]=e,f++}else if(S.isHemisphereLight){let e=t.get(S);e.skyColor.copy(S.color).multiplyScalar(w),e.groundColor.copy(S.groundColor).multiplyScalar(w),r.hemi[h]=e,h++}}m>0&&(e.has(`OES_texture_float_linear`)===!0?(r.rectAreaLTC1=z.LTC_FLOAT_1,r.rectAreaLTC2=z.LTC_FLOAT_2):(r.rectAreaLTC1=z.LTC_HALF_1,r.rectAreaLTC2=z.LTC_HALF_2)),r.ambient[0]=a,r.ambient[1]=o,r.ambient[2]=s;let S=r.hash;(S.sunLength!==c||S.directionalLength!==d||S.pointLength!==f||S.spotLength!==p||S.rectAreaLength!==m||S.hemiLength!==h||S.numSunShadows!==l||S.numDirectionalShadows!==g||S.numPointShadows!==_||S.numSpotShadows!==v||S.numSpotMaps!==y||S.numLightProbes!==x)&&(r.sun.length=c,r.directional.length=d,r.spot.length=p,r.rectArea.length=m,r.point.length=f,r.hemi.length=h,r.sunShadow.length=l,r.sunShadowMap.length=l,r.sunShadowMatrix.length=u,r.sunShadowCascade.length=u,r.directionalShadow.length=g,r.directionalShadowMap.length=g,r.directionalShadowMatrix.length=g,r.pointShadow.length=_,r.pointShadowMap.length=_,r.pointShadowMatrix.length=_,r.spotShadow.length=v,r.spotShadowMap.length=v,r.spotLightMatrix.length=v+y-b,r.spotLightMap.length=y,r.numSpotLightShadowsWithMaps=b,r.numLightProbes=x,S.sunLength=c,S.directionalLength=d,S.pointLength=f,S.spotLength=p,S.rectAreaLength=m,S.hemiLength=h,S.numSunShadows=l,S.numDirectionalShadows=g,S.numPointShadows=_,S.numSpotShadows=v,S.numSpotMaps=y,S.numLightProbes=x,r.version=Nu++)}function c(e,t){let n=0,s=0,c=0,l=0,u=0,d=0,f=t.matrixWorldInverse;for(let t=0,p=e.length;t<p;t++){let p=e[t];if(p.isSunLight){let e=r.sun[n];e.direction.setFromMatrixPosition(p.matrixWorld),e.direction.transformDirection(f),n++}else if(p.isDirectionalLight){let e=r.directional[s];e.direction.setFromMatrixPosition(p.matrixWorld),i.setFromMatrixPosition(p.target.matrixWorld),e.direction.sub(i),e.direction.transformDirection(f),s++}else if(p.isSpotLight){let e=r.spot[l];e.position.setFromMatrixPosition(p.matrixWorld),e.position.applyMatrix4(f),e.direction.setFromMatrixPosition(p.matrixWorld),i.setFromMatrixPosition(p.target.matrixWorld),e.direction.sub(i),e.direction.transformDirection(f),l++}else if(p.isRectAreaLight){let e=r.rectArea[u];e.position.setFromMatrixPosition(p.matrixWorld),e.position.applyMatrix4(f),o.identity(),a.copy(p.matrixWorld),a.premultiply(f),o.extractRotation(a),e.halfWidth.set(p.width*.5,0,0),e.halfHeight.set(0,p.height*.5,0),e.halfWidth.applyMatrix4(o),e.halfHeight.applyMatrix4(o),u++}else if(p.isPointLight){let e=r.point[c];e.position.setFromMatrixPosition(p.matrixWorld),e.position.applyMatrix4(f),c++}else if(p.isHemisphereLight){let e=r.hemi[d];e.direction.setFromMatrixPosition(p.matrixWorld),e.direction.transformDirection(f),d++}}}return{setup:s,setupView:c,state:r}}function Iu(e){let t=new Fu(e),n=[],r=[],i=[];function a(e){u.camera=e,n.length=0,r.length=0,i.length=0}function o(e){e.isLightProbeGrid?i.push(e):n.push(e)}function s(e){r.push(e)}function c(){t.setup(n),i.sort((e,t)=>e.priority-t.priority||e.id-t.id)}function l(e){t.setupView(n,e)}let u={lightsArray:n,shadowsArray:r,lightProbeGridArray:i,camera:null,lights:t,transmissionRenderTarget:{},textureUnits:0};return{init:a,state:u,setupLights:c,setupLightsView:l,pushLight:o,pushShadow:s}}function Lu(e){let t=new WeakMap;function n(n,r=0){let i=t.get(n),a;return i===void 0?(a=new Iu(e),t.set(n,[a])):r>=i.length?(a=new Iu(e),i.push(a)):a=i[r],a}function r(){t=new WeakMap}return{get:n,dispose:r}}var Ru=`void main() {
	gl_Position = vec4( position, 1.0 );
}`,zu=`uniform sampler2D shadow_pass;
uniform vec2 resolution;
uniform float radius;
void main() {
	const float samples = float( VSM_SAMPLES );
	float mean = 0.0;
	float squared_mean = 0.0;
	float uvStride = samples <= 1.0 ? 0.0 : 2.0 / ( samples - 1.0 );
	float uvStart = samples <= 1.0 ? 0.0 : - 1.0;
	for ( float i = 0.0; i < samples; i ++ ) {
		float uvOffset = uvStart + i * uvStride;
		#ifdef HORIZONTAL_PASS
			vec2 distribution = texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( uvOffset, 0.0 ) * radius ) / resolution ).rg;
			mean += distribution.x;
			squared_mean += distribution.y * distribution.y + distribution.x * distribution.x;
		#else
			float depth = texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( 0.0, uvOffset ) * radius ) / resolution ).r;
			mean += depth;
			squared_mean += depth * depth;
		#endif
	}
	mean = mean / samples;
	squared_mean = squared_mean / samples;
	float std_dev = sqrt( max( 0.0, squared_mean - mean * mean ) );
	gl_FragColor = vec4( mean, std_dev, 0.0, 1.0 );
}`,Bu=[new L(1,0,0),new L(-1,0,0),new L(0,1,0),new L(0,-1,0),new L(0,0,1),new L(0,0,-1)],Vu=[new L(0,-1,0),new L(0,-1,0),new L(0,0,1),new L(0,0,-1),new L(0,-1,0),new L(0,-1,0)],Hu=new on,Uu=new L,Wu=new L;function Gu(e,t,n){let i=new Si,a=new I,s=new I,c=new en,l=new Lo,u=new Ro,d={},f=n.maxTextureSize,p={0:1,1:0,2:2},_=new Po({defines:{VSM_SAMPLES:8},uniforms:{shadow_pass:{value:null},resolution:{value:new I},radius:{value:4}},vertexShader:Ru,fragmentShader:zu}),v=_.clone();v.defines.HORIZONTAL_PASS=1;let y=new Ir;y.setAttribute(`position`,new xr(new Float32Array([-1,-1,.5,3,-1,.5,-1,3,.5]),3));let b=new oi(y,_),x=this;this.enabled=!1,this.autoUpdate=!0,this.needsUpdate=!1,this.type=1;let S=this.type;this.render=function(t,n,l){if(x.enabled===!1||x.autoUpdate===!1&&x.needsUpdate===!1||t.length===0)return;this.type===2&&(tt(`WebGLShadowMap: PCFSoftShadowMap has been removed. Using PCFShadowMap instead.`),this.type=1);let u=e.getRenderTarget(),d=e.getActiveCubeFace(),p=e.getActiveMipmapLevel(),_=e.state;_.setBlending(0),_.buffers.depth.getReversed()===!0?_.buffers.color.setClear(0,0,0,0):_.buffers.color.setClear(1,1,1,1),_.buffers.depth.setTest(!0),_.setScissorTest(!1);let v=S!==this.type;v&&n.traverse(function(e){e.material&&(Array.isArray(e.material)?e.material.forEach(e=>e.needsUpdate=!0):e.material.needsUpdate=!0)});for(let u=0,d=t.length;u<d;u++){let d=t[u],p=d.shadow;if(p===void 0){tt(`WebGLShadowMap:`,d,`has no shadow.`);continue}if(p.autoUpdate===!1&&p.needsUpdate===!1)continue;a.copy(p.mapSize);let y=p.getFrameExtents();a.multiply(y),s.copy(p.mapSize),(a.x>f||a.y>f)&&(a.x>f&&(s.x=Math.floor(f/y.x),a.x=s.x*y.x,p.mapSize.x=s.x),a.y>f&&(s.y=Math.floor(f/y.y),a.y=s.y*y.y,p.mapSize.y=s.y));let b=e.state.buffers.depth.getReversed();if(p.camera._reversedDepth=b,p.map===null||v===!0){if(p.map!==null&&(p.map.depthTexture!==null&&(p.map.depthTexture.dispose(),p.map.depthTexture=null),p.map.dispose()),this.type===3){if(d.isPointLight){tt(`WebGLShadowMap: VSM shadow maps are not supported for PointLights. Use PCF or BasicShadowMap instead.`);continue}p.map=new nn(a.x,a.y,{format:k,type:g,minFilter:o,magFilter:o,generateMipmaps:!1}),p.map.texture.name=d.name+`.shadowMap`,p.map.depthTexture=new qi(a.x,a.y,h),p.map.depthTexture.name=d.name+`.shadowMapDepth`,p.map.depthTexture.format=T,p.map.depthTexture.compareFunction=null,p.map.depthTexture.minFilter=r,p.map.depthTexture.magFilter=r}else d.isPointLight?(p.map=new cc(a.x),p.map.depthTexture=new Ji(a.x,m)):(p.map=new nn(a.x,a.y),p.map.depthTexture=new qi(a.x,a.y,m)),p.map.depthTexture.name=d.name+`.shadowMap`,p.map.depthTexture.format=T,this.type===1?(p.map.depthTexture.compareFunction=b?518:515,p.map.depthTexture.minFilter=o,p.map.depthTexture.magFilter=o):(p.map.depthTexture.compareFunction=null,p.map.depthTexture.minFilter=r,p.map.depthTexture.magFilter=r);p.camera.updateProjectionMatrix()}p.map.isWebGLCubeRenderTarget!==!0&&(p.map.width!==a.x||p.map.height!==a.y)&&p.map.setSize(a.x,a.y);let x=p.map.isWebGLCubeRenderTarget?6:p.getViewportCount();d.isPointLight!==!0&&p.updateMatrices(d,l);let S=p.camera.layers.mask&4294967294?p.camera.layers:l.layers;for(let t=0;t<x;t++){let r=p.getCamera(t);if(d.isPointLight){let e=p.camera,n=p.matrix,r=d.distance||e.far;r!==e.far&&(e.far=r,e.updateProjectionMatrix()),Uu.setFromMatrixPosition(d.matrixWorld),e.position.copy(Uu),Wu.copy(e.position),Wu.add(Bu[t]),e.up.copy(Vu[t]),e.lookAt(Wu),e.updateMatrixWorld(),n.makeTranslation(-Uu.x,-Uu.y,-Uu.z),Hu.multiplyMatrices(e.projectionMatrix,e.matrixWorldInverse),p._frustum.setFromProjectionMatrix(Hu,e.coordinateSystem,e.reversedDepth)}if(p.map.isWebGLCubeRenderTarget)e.setRenderTarget(p.map,t),e.clear();else{t===0&&(e.setRenderTarget(p.map),e.clear());let n=p.getViewport(t);c.set(s.x*n.x,s.y*n.y,s.x*n.z,s.y*n.w),_.viewport(c)}i=p.getFrustum(t),E(n,l,r,d,S,this.type)}p.isPointLightShadow!==!0&&this.type===3&&C(p,l),p.needsUpdate=!1}S=this.type,x.needsUpdate=!1,e.setRenderTarget(u,d,p)};function C(n,r){let i=t.update(b);_.defines.VSM_SAMPLES!==n.blurSamples&&(_.defines.VSM_SAMPLES=n.blurSamples,v.defines.VSM_SAMPLES=n.blurSamples,_.needsUpdate=!0,v.needsUpdate=!0),n.mapPass===null?n.mapPass=new nn(a.x,a.y,{format:k,type:g}):(n.mapPass.width!==n.map.width||n.mapPass.height!==n.map.height)&&n.mapPass.setSize(n.map.width,n.map.height),_.uniforms.shadow_pass.value=n.map.depthTexture,_.uniforms.resolution.value.set(n.map.width,n.map.height),_.uniforms.radius.value=n.radius,e.setRenderTarget(n.mapPass),e.clear(),e.renderBufferDirect(r,null,i,_,b,null),v.uniforms.shadow_pass.value=n.mapPass.texture,v.uniforms.resolution.value.set(n.map.width,n.map.height),v.uniforms.radius.value=n.radius,e.setRenderTarget(n.map),e.clear(),e.renderBufferDirect(r,null,i,v,b,null)}function w(t,n,r,i){let a=null,o=r.isPointLight===!0?t.customDistanceMaterial:t.customDepthMaterial;if(o!==void 0)a=o;else if(a=r.isPointLight===!0?u:l,e.localClippingEnabled&&n.clipShadows===!0&&Array.isArray(n.clippingPlanes)&&n.clippingPlanes.length!==0||n.displacementMap&&n.displacementScale!==0||n.alphaMap&&n.alphaTest>0||n.map&&n.alphaTest>0||n.alphaToCoverage===!0){let e=a.uuid,t=n.uuid,r=d[e];r===void 0&&(r={},d[e]=r);let i=r[t];i===void 0&&(i=a.clone(),r[t]=i,n.addEventListener(`dispose`,D)),a=i}if(a.visible=n.visible,a.wireframe=n.wireframe,i===3?a.side=n.shadowSide===null?n.side:n.shadowSide:a.side=n.shadowSide===null?p[n.side]:n.shadowSide,a.alphaMap=n.alphaMap,a.alphaTest=n.alphaToCoverage===!0?.5:n.alphaTest,a.map=n.map,a.clipShadows=n.clipShadows,a.clippingPlanes=n.clippingPlanes,a.clipIntersection=n.clipIntersection,a.displacementMap=n.displacementMap,a.displacementScale=n.displacementScale,a.displacementBias=n.displacementBias,a.wireframeLinewidth=n.wireframeLinewidth,a.linewidth=n.linewidth,r.isPointLight===!0&&a.isMeshDistanceMaterial===!0){let t=e.properties.get(a);t.light=r}return a}function E(n,r,a,o,s,c){if(n.visible===!1)return;if(n.layers.test(s)&&(n.isMesh||n.isLine||n.isPoints)&&(n.castShadow||n.receiveShadow&&c===3)&&(!n.frustumCulled||n.intersectsFrustum(i))){n.modelViewMatrix.multiplyMatrices(a.matrixWorldInverse,n.matrixWorld);let i=t.update(n),s=n.material;if(Array.isArray(s)){let t=i.groups;for(let l=0,u=t.length;l<u;l++){let u=t[l],d=s[u.materialIndex];if(d&&d.visible){let t=w(n,d,o,c);n.onBeforeShadow(e,n,r,a,i,t,u),e.renderBufferDirect(a,null,i,t,n,u),n.onAfterShadow(e,n,r,a,i,t,u)}}}else if(s.visible){let t=w(n,s,o,c);n.onBeforeShadow(e,n,r,a,i,t,null),e.renderBufferDirect(a,null,i,t,n,null),n.onAfterShadow(e,n,r,a,i,t,null)}}let l=n.children;for(let e=0,t=l.length;e<t;e++)E(l[e],r,a,o,s,c)}function D(e){e.target.removeEventListener(`dispose`,D);for(let t in d){let n=d[t],r=e.target.uuid;r in n&&(n[r].dispose(),delete n[r])}}}function Ku(e,t){function n(){let t=!1,n=new en,r=null,i=new en(0,0,0,0);return{setMask:function(n){r!==n&&!t&&(e.colorMask(n,n,n,n),r=n)},setLocked:function(e){t=e},setClear:function(t,r,a,o,s){s===!0&&(t*=o,r*=o,a*=o),n.set(t,r,a,o),i.equals(n)===!1&&(e.clearColor(t,r,a,o),i.copy(n))},reset:function(){t=!1,r=null,i.set(-1,0,0,0)}}}function r(){let n=!1,r=!1,i=null,a=null,o=null;return{setReversed:function(e){if(r!==e){let n=t.get(`EXT_clip_control`);e?n.clipControlEXT(n.LOWER_LEFT_EXT,n.ZERO_TO_ONE_EXT):n.clipControlEXT(n.LOWER_LEFT_EXT,n.NEGATIVE_ONE_TO_ONE_EXT),r=e;let i=o;o=null,this.setClear(i)}},getReversed:function(){return r},setTest:function(t){t?ue(e.DEPTH_TEST):de(e.DEPTH_TEST)},setMask:function(t){i!==t&&!n&&(e.depthMask(t),i=t)},setFunc:function(t){if(r&&(t=at[t]),a!==t){switch(t){case 0:e.depthFunc(e.NEVER);break;case 1:e.depthFunc(e.ALWAYS);break;case 2:e.depthFunc(e.LESS);break;case 3:e.depthFunc(e.LEQUAL);break;case 4:e.depthFunc(e.EQUAL);break;case 5:e.depthFunc(e.GEQUAL);break;case 6:e.depthFunc(e.GREATER);break;case 7:e.depthFunc(e.NOTEQUAL);break;default:e.depthFunc(e.LEQUAL)}a=t}},setLocked:function(e){n=e},setClear:function(t){o!==t&&(o=t,r&&(t=1-t),e.clearDepth(t))},reset:function(){n=!1,i=null,a=null,o=null,r=!1}}}function i(){let t=!1,n=null,r=null,i=null,a=null,o=null,s=null,c=null,l=null;return{setTest:function(n){t||(n?ue(e.STENCIL_TEST):de(e.STENCIL_TEST))},setMask:function(r){n!==r&&!t&&(e.stencilMask(r),n=r)},setFunc:function(t,n,o){(r!==t||i!==n||a!==o)&&(e.stencilFunc(t,n,o),r=t,i=n,a=o)},setOp:function(t,n,r){(o!==t||s!==n||c!==r)&&(e.stencilOp(t,n,r),o=t,s=n,c=r)},setLocked:function(e){t=e},setClear:function(t){l!==t&&(e.clearStencil(t),l=t)},reset:function(){t=!1,n=null,r=null,i=null,a=null,o=null,s=null,c=null,l=null}}}let a=new n,o=new r,s=new i,c={},l=new WeakMap,u={},d={},f={},p=new WeakMap,m=[],h=null,g=!1,_=null,v=null,y=null,b=null,x=null,S=null,C=null,w=new R(0,0,0),T=0,E=!1,D=null,O=null,k=null,A=null,ee=null,j=e.getParameter(e.MAX_COMBINED_TEXTURE_IMAGE_UNITS),te=!1,M=0,ne=e.getParameter(e.VERSION);ne.indexOf(`WebGL`)===-1?ne.indexOf(`OpenGL ES`)!==-1&&(M=parseFloat(/^OpenGL ES (\d)/.exec(ne)[1]),te=M>=2):(M=parseFloat(/^WebGL (\d)/.exec(ne)[1]),te=M>=1);let N=null,re={},ie=e.getParameter(e.SCISSOR_BOX),ae=e.getParameter(e.VIEWPORT),oe=new en().fromArray(ie),se=new en().fromArray(ae);function ce(t,n,r,i){let a=new Uint8Array(4),o=e.createTexture();e.bindTexture(t,o),e.texParameteri(t,e.TEXTURE_MIN_FILTER,e.NEAREST),e.texParameteri(t,e.TEXTURE_MAG_FILTER,e.NEAREST);for(let o=0;o<r;o++)t===e.TEXTURE_3D||t===e.TEXTURE_2D_ARRAY?e.texImage3D(n,0,e.RGBA,1,1,i,0,e.RGBA,e.UNSIGNED_BYTE,a):e.texImage2D(n+o,0,e.RGBA,1,1,0,e.RGBA,e.UNSIGNED_BYTE,a);return o}let le={};le[e.TEXTURE_2D]=ce(e.TEXTURE_2D,e.TEXTURE_2D,1),le[e.TEXTURE_CUBE_MAP]=ce(e.TEXTURE_CUBE_MAP,e.TEXTURE_CUBE_MAP_POSITIVE_X,6),le[e.TEXTURE_2D_ARRAY]=ce(e.TEXTURE_2D_ARRAY,e.TEXTURE_2D_ARRAY,1,1),le[e.TEXTURE_3D]=ce(e.TEXTURE_3D,e.TEXTURE_3D,1,1),a.setClear(0,0,0,1),o.setClear(1),s.setClear(0),ue(e.DEPTH_TEST),o.setFunc(3),ye(!1),be(1),ue(e.CULL_FACE),_e(0);function ue(t){u[t]!==!0&&(e.enable(t),u[t]=!0)}function de(t){u[t]!==!1&&(e.disable(t),u[t]=!1)}function fe(t,n){return f[t]!==n&&(e.bindFramebuffer(t,n),f[t]=n,t===e.DRAW_FRAMEBUFFER&&(f[e.FRAMEBUFFER]=n),t===e.FRAMEBUFFER&&(f[e.DRAW_FRAMEBUFFER]=n),!0)}function pe(t,n){let r=m,i=!1;if(t){r=p.get(n),r===void 0&&(r=[],p.set(n,r));let a=t.textures;if(r.length!==a.length||r[0]!==e.COLOR_ATTACHMENT0){for(let t=0,n=a.length;t<n;t++)r[t]=e.COLOR_ATTACHMENT0+t;r.length=a.length,i=!0}}else r[0]!==e.BACK&&(r[0]=e.BACK,i=!0);i&&e.drawBuffers(r)}function me(t){return h!==t&&(e.useProgram(t),h=t,!0)}let he={100:e.FUNC_ADD,101:e.FUNC_SUBTRACT,102:e.FUNC_REVERSE_SUBTRACT};he[103]=e.MIN,he[104]=e.MAX;let ge={200:e.ZERO,201:e.ONE,202:e.SRC_COLOR,204:e.SRC_ALPHA,210:e.SRC_ALPHA_SATURATE,208:e.DST_COLOR,206:e.DST_ALPHA,203:e.ONE_MINUS_SRC_COLOR,205:e.ONE_MINUS_SRC_ALPHA,209:e.ONE_MINUS_DST_COLOR,207:e.ONE_MINUS_DST_ALPHA,211:e.CONSTANT_COLOR,212:e.ONE_MINUS_CONSTANT_COLOR,213:e.CONSTANT_ALPHA,214:e.ONE_MINUS_CONSTANT_ALPHA};function _e(t,n,r,i,a,o,s,c,l,u){if(t===0)g===!0&&(de(e.BLEND),g=!1);else if(g===!1&&(ue(e.BLEND),g=!0),t!==5){if(t!==_||u!==E){if((v!==100||x!==100)&&(e.blendEquation(e.FUNC_ADD),v=100,x=100),u)switch(t){case 1:e.blendFuncSeparate(e.ONE,e.ONE_MINUS_SRC_ALPHA,e.ONE,e.ONE_MINUS_SRC_ALPHA);break;case 2:e.blendFunc(e.ONE,e.ONE);break;case 3:e.blendFuncSeparate(e.ZERO,e.ONE_MINUS_SRC_COLOR,e.ZERO,e.ONE);break;case 4:e.blendFuncSeparate(e.DST_COLOR,e.ONE_MINUS_SRC_ALPHA,e.ZERO,e.ONE);break;default:nt(`WebGLState: Invalid blending: `,t)}else switch(t){case 1:e.blendFuncSeparate(e.SRC_ALPHA,e.ONE_MINUS_SRC_ALPHA,e.ONE,e.ONE_MINUS_SRC_ALPHA);break;case 2:e.blendFuncSeparate(e.SRC_ALPHA,e.ONE,e.ONE,e.ONE);break;case 3:nt(`WebGLState: SubtractiveBlending requires material.premultipliedAlpha = true`);break;case 4:nt(`WebGLState: MultiplyBlending requires material.premultipliedAlpha = true`);break;default:nt(`WebGLState: Invalid blending: `,t)}y=null,b=null,S=null,C=null,w.set(0,0,0),T=0,_=t,E=u}}else a||=n,o||=r,s||=i,(n!==v||a!==x)&&(e.blendEquationSeparate(he[n],he[a]),v=n,x=a),(r!==y||i!==b||o!==S||s!==C)&&(e.blendFuncSeparate(ge[r],ge[i],ge[o],ge[s]),y=r,b=i,S=o,C=s),(c.equals(w)===!1||l!==T)&&(e.blendColor(c.r,c.g,c.b,l),w.copy(c),T=l),_=t,E=!1}function ve(t,n){t.side===2?de(e.CULL_FACE):ue(e.CULL_FACE);let r=t.side===1;n&&(r=!r),ye(r),t.blending===1&&t.transparent===!1?_e(0):_e(t.blending,t.blendEquation,t.blendSrc,t.blendDst,t.blendEquationAlpha,t.blendSrcAlpha,t.blendDstAlpha,t.blendColor,t.blendAlpha,t.premultipliedAlpha),o.setFunc(t.depthFunc),o.setTest(t.depthTest),o.setMask(t.depthWrite),a.setMask(t.colorWrite);let i=t.stencilWrite;s.setTest(i),i&&(s.setMask(t.stencilWriteMask),s.setFunc(t.stencilFunc,t.stencilRef,t.stencilFuncMask),s.setOp(t.stencilFail,t.stencilZFail,t.stencilZPass)),Se(t.polygonOffset,t.polygonOffsetFactor,t.polygonOffsetUnits),t.alphaToCoverage===!0?ue(e.SAMPLE_ALPHA_TO_COVERAGE):de(e.SAMPLE_ALPHA_TO_COVERAGE)}function ye(t){D!==t&&(t?e.frontFace(e.CW):e.frontFace(e.CCW),D=t)}function be(t){t===0?de(e.CULL_FACE):(ue(e.CULL_FACE),t!==O&&(t===1?e.cullFace(e.BACK):t===2?e.cullFace(e.FRONT):e.cullFace(e.FRONT_AND_BACK))),O=t}function xe(t){t!==k&&(te&&e.lineWidth(t),k=t)}function Se(t,n,r){t?(ue(e.POLYGON_OFFSET_FILL),(A!==n||ee!==r)&&(A=n,ee=r,o.getReversed()&&(n=-n,r=-r),e.polygonOffset(n,r))):de(e.POLYGON_OFFSET_FILL)}function Ce(t){t?ue(e.SCISSOR_TEST):de(e.SCISSOR_TEST)}function we(t){t===void 0&&(t=e.TEXTURE0+j-1),N!==t&&(e.activeTexture(t),N=t)}function Te(t,n,r){r===void 0&&(r=N===null?e.TEXTURE0+j-1:N);let i=re[r];i===void 0&&(i={type:void 0,texture:void 0},re[r]=i),(i.type!==t||i.texture!==n)&&(N!==r&&(e.activeTexture(r),N=r),e.bindTexture(t,n||le[t]),i.type=t,i.texture=n)}function Ee(){let t=re[N];t!==void 0&&t.type!==void 0&&(e.bindTexture(t.type,null),t.type=void 0,t.texture=void 0)}function De(){try{e.compressedTexImage2D(...arguments)}catch(e){nt(`WebGLState:`,e)}}function Oe(){try{e.compressedTexImage3D(...arguments)}catch(e){nt(`WebGLState:`,e)}}function ke(){try{e.texSubImage2D(...arguments)}catch(e){nt(`WebGLState:`,e)}}function Ae(){try{e.texSubImage3D(...arguments)}catch(e){nt(`WebGLState:`,e)}}function je(){try{e.compressedTexSubImage2D(...arguments)}catch(e){nt(`WebGLState:`,e)}}function Me(){try{e.compressedTexSubImage3D(...arguments)}catch(e){nt(`WebGLState:`,e)}}function Ne(){try{e.texStorage2D(...arguments)}catch(e){nt(`WebGLState:`,e)}}function Pe(){try{e.texStorage3D(...arguments)}catch(e){nt(`WebGLState:`,e)}}function Fe(){try{e.texImage2D(...arguments)}catch(e){nt(`WebGLState:`,e)}}function P(){try{e.texImage3D(...arguments)}catch(e){nt(`WebGLState:`,e)}}function Ie(t){return d[t]===void 0?e.getParameter(t):d[t]}function Le(t,n){d[t]!==n&&(e.pixelStorei(t,n),d[t]=n)}function Re(t){oe.equals(t)===!1&&(e.scissor(t.x,t.y,t.z,t.w),oe.copy(t))}function F(t){se.equals(t)===!1&&(e.viewport(t.x,t.y,t.z,t.w),se.copy(t))}function ze(t,n){let r=l.get(n);r===void 0&&(r=new WeakMap,l.set(n,r));let i=r.get(t);i===void 0&&(i=e.getUniformBlockIndex(n,t.name),e.uniformBlockBinding(n,i,i),r.set(t,i))}function Be(t,n,r){let i=l.get(n).get(t);c[i]!==r&&(e.bindBufferBase(e.UNIFORM_BUFFER,i,r),c[i]=r)}function Ve(){e.disable(e.BLEND),e.disable(e.CULL_FACE),e.disable(e.DEPTH_TEST),e.disable(e.POLYGON_OFFSET_FILL),e.disable(e.SCISSOR_TEST),e.disable(e.STENCIL_TEST),e.disable(e.SAMPLE_ALPHA_TO_COVERAGE),e.blendEquation(e.FUNC_ADD),e.blendFunc(e.ONE,e.ZERO),e.blendFuncSeparate(e.ONE,e.ZERO,e.ONE,e.ZERO),e.blendColor(0,0,0,0),e.colorMask(!0,!0,!0,!0),e.clearColor(0,0,0,0),e.depthMask(!0),e.depthFunc(e.LESS),o.setReversed(!1),e.clearDepth(1),e.stencilMask(4294967295),e.stencilFunc(e.ALWAYS,0,4294967295),e.stencilOp(e.KEEP,e.KEEP,e.KEEP),e.clearStencil(0),e.cullFace(e.BACK),e.frontFace(e.CCW),e.polygonOffset(0,0),e.activeTexture(e.TEXTURE0),e.bindFramebuffer(e.FRAMEBUFFER,null),e.bindFramebuffer(e.DRAW_FRAMEBUFFER,null),e.bindFramebuffer(e.READ_FRAMEBUFFER,null),e.useProgram(null),e.lineWidth(1),e.scissor(0,0,e.canvas.width,e.canvas.height),e.viewport(0,0,e.canvas.width,e.canvas.height),e.pixelStorei(e.PACK_ALIGNMENT,4),e.pixelStorei(e.UNPACK_ALIGNMENT,4),e.pixelStorei(e.UNPACK_FLIP_Y_WEBGL,!1),e.pixelStorei(e.UNPACK_PREMULTIPLY_ALPHA_WEBGL,!1),e.pixelStorei(e.UNPACK_COLORSPACE_CONVERSION_WEBGL,e.BROWSER_DEFAULT_WEBGL),e.pixelStorei(e.PACK_ROW_LENGTH,0),e.pixelStorei(e.PACK_SKIP_PIXELS,0),e.pixelStorei(e.PACK_SKIP_ROWS,0),e.pixelStorei(e.UNPACK_ROW_LENGTH,0),e.pixelStorei(e.UNPACK_IMAGE_HEIGHT,0),e.pixelStorei(e.UNPACK_SKIP_PIXELS,0),e.pixelStorei(e.UNPACK_SKIP_ROWS,0),e.pixelStorei(e.UNPACK_SKIP_IMAGES,0),u={},d={},N=null,re={},f={},c={},p=new WeakMap,m=[],h=null,g=!1,_=null,v=null,y=null,b=null,x=null,S=null,C=null,w=new R(0,0,0),T=0,E=!1,D=null,O=null,k=null,A=null,ee=null,oe.set(0,0,e.canvas.width,e.canvas.height),se.set(0,0,e.canvas.width,e.canvas.height),a.reset(),o.reset(),s.reset()}return{buffers:{color:a,depth:o,stencil:s},enable:ue,disable:de,bindFramebuffer:fe,drawBuffers:pe,useProgram:me,setBlending:_e,setMaterial:ve,setFlipSided:ye,setCullFace:be,setLineWidth:xe,setPolygonOffset:Se,setScissorTest:Ce,activeTexture:we,bindTexture:Te,unbindTexture:Ee,compressedTexImage2D:De,compressedTexImage3D:Oe,texImage2D:Fe,texImage3D:P,pixelStorei:Le,getParameter:Ie,updateUBOMapping:ze,uniformBlockBinding:Be,texStorage2D:Ne,texStorage3D:Pe,texSubImage2D:ke,texSubImage3D:Ae,compressedTexSubImage2D:je,compressedTexSubImage3D:Me,scissor:Re,viewport:F,reset:Ve}}function qu(l,u,d,f,p,m,h){let g=u.has(`WEBGL_multisampled_render_to_texture`)?u.get(`WEBGL_multisampled_render_to_texture`):null,_=typeof navigator>`u`?!1:/OculusBrowser/g.test(navigator.userAgent),v=new I,y=new WeakMap,b=new Set,x,S=new WeakMap,C=new Set,w=new FinalizationRegistry(e=>C.delete(e)),T=!1;try{T=typeof OffscreenCanvas<`u`&&new OffscreenCanvas(1,1).getContext(`2d`)!==null}catch{}function D(e,t){return T?new OffscreenCanvas(e,t):Xe(`canvas`)}function O(e,t,n){let r=1,i=Ve(e);if((i.width>n||i.height>n)&&(r=n/Math.max(i.width,i.height)),r<1){if(typeof HTMLImageElement<`u`&&e instanceof HTMLImageElement||typeof HTMLCanvasElement<`u`&&e instanceof HTMLCanvasElement||typeof ImageBitmap<`u`&&e instanceof ImageBitmap||typeof VideoFrame<`u`&&e instanceof VideoFrame){let n=Math.floor(r*i.width),a=Math.floor(r*i.height);x===void 0&&(x=D(n,a));let o=t?D(n,a):x;return o.width=n,o.height=a,o.getContext(`2d`).drawImage(e,0,0,n,a),tt(`WebGLRenderer: Texture has been resized from (`+i.width+`x`+i.height+`) to (`+n+`x`+a+`).`),o}return`data`in e&&tt(`WebGLRenderer: Image in DataTexture is too big (`+i.width+`x`+i.height+`).`),e}return e}function k(e){return e.generateMipmaps}function A(e){l.generateMipmap(e)}function ee(e){return e.isWebGLCubeRenderTarget?l.TEXTURE_CUBE_MAP:e.isWebGL3DRenderTarget?l.TEXTURE_3D:e.isWebGLArrayRenderTarget||e.isCompressedArrayTexture?l.TEXTURE_2D_ARRAY:l.TEXTURE_2D}function j(e,t,n,r,i,a=!1){if(e!==null){if(l[e]!==void 0)return l[e];tt(`WebGLRenderer: Attempt to use non-existing WebGL internal format '`+e+`'`)}let o;r&&(o=u.get(`EXT_texture_norm16`),o||tt(`WebGLRenderer: Unable to use normalized textures without EXT_texture_norm16 extension`));let s=t;if(t===l.RED&&(n===l.FLOAT&&(s=l.R32F),n===l.HALF_FLOAT&&(s=l.R16F),n===l.UNSIGNED_BYTE&&(s=l.R8),n===l.UNSIGNED_SHORT&&o&&(s=o.R16_EXT),n===l.SHORT&&o&&(s=o.R16_SNORM_EXT)),t===l.RED_INTEGER&&(n===l.UNSIGNED_BYTE&&(s=l.R8UI),n===l.UNSIGNED_SHORT&&(s=l.R16UI),n===l.UNSIGNED_INT&&(s=l.R32UI),n===l.BYTE&&(s=l.R8I),n===l.SHORT&&(s=l.R16I),n===l.INT&&(s=l.R32I)),t===l.RG&&(n===l.FLOAT&&(s=l.RG32F),n===l.HALF_FLOAT&&(s=l.RG16F),n===l.UNSIGNED_BYTE&&(s=l.RG8),n===l.UNSIGNED_SHORT&&o&&(s=o.RG16_EXT),n===l.SHORT&&o&&(s=o.RG16_SNORM_EXT)),t===l.RG_INTEGER&&(n===l.UNSIGNED_BYTE&&(s=l.RG8UI),n===l.UNSIGNED_SHORT&&(s=l.RG16UI),n===l.UNSIGNED_INT&&(s=l.RG32UI),n===l.BYTE&&(s=l.RG8I),n===l.SHORT&&(s=l.RG16I),n===l.INT&&(s=l.RG32I)),t===l.RGB_INTEGER&&(n===l.UNSIGNED_BYTE&&(s=l.RGB8UI),n===l.UNSIGNED_SHORT&&(s=l.RGB16UI),n===l.UNSIGNED_INT&&(s=l.RGB32UI),n===l.BYTE&&(s=l.RGB8I),n===l.SHORT&&(s=l.RGB16I),n===l.INT&&(s=l.RGB32I)),t===l.RGBA_INTEGER&&(n===l.UNSIGNED_BYTE&&(s=l.RGBA8UI),n===l.UNSIGNED_SHORT&&(s=l.RGBA16UI),n===l.UNSIGNED_INT&&(s=l.RGBA32UI),n===l.BYTE&&(s=l.RGBA8I),n===l.SHORT&&(s=l.RGBA16I),n===l.INT&&(s=l.RGBA32I)),t===l.RGB&&(n===l.UNSIGNED_SHORT&&o&&(s=o.RGB16_EXT),n===l.SHORT&&o&&(s=o.RGB16_SNORM_EXT),n===l.UNSIGNED_INT_5_9_9_9_REV&&(s=l.RGB9_E5),n===l.UNSIGNED_INT_10F_11F_11F_REV&&(s=l.R11F_G11F_B10F)),t===l.RGBA){let e=a?He:Ut.getTransfer(i);n===l.FLOAT&&(s=l.RGBA32F),n===l.HALF_FLOAT&&(s=l.RGBA16F),n===l.UNSIGNED_BYTE&&(s=e===`srgb`?l.SRGB8_ALPHA8:l.RGBA8),n===l.UNSIGNED_SHORT&&o&&(s=o.RGBA16_EXT),n===l.SHORT&&o&&(s=o.RGBA16_SNORM_EXT),n===l.UNSIGNED_SHORT_4_4_4_4&&(s=l.RGBA4),n===l.UNSIGNED_SHORT_5_5_5_1&&(s=l.RGB5_A1)}return(s===l.R16F||s===l.R32F||s===l.RG16F||s===l.RG32F||s===l.RGBA16F||s===l.RGBA32F)&&u.get(`EXT_color_buffer_float`),s}function te(e,t){let n;return e?t===null||t===1014||t===1020?n=l.DEPTH24_STENCIL8:t===1015?n=l.DEPTH32F_STENCIL8:t===1012&&(n=l.DEPTH24_STENCIL8,tt(`DepthTexture: 16 bit depth attachment is not supported with stencil. Using 24-bit attachment.`)):t===null||t===1014||t===1020?n=l.DEPTH_COMPONENT24:t===1015?n=l.DEPTH_COMPONENT32F:t===1012&&(n=l.DEPTH_COMPONENT16),n}function M(e,t){return k(e)===!0||e.isFramebufferTexture&&e.minFilter!==1003&&e.minFilter!==1006?Math.log2(Math.max(t.width,t.height))+1:e.mipmaps.length>0?e.mipmaps.length:e.isCompressedTexture&&Array.isArray(e.image)?t.mipmaps.length:1}function ne(e){let t=new WeakRef(e);f.get(e).__ref=t,C.add(t),w.register(e,t,t)}function N(e){let t=f.get(e).__ref;t!==void 0&&(C.delete(t),w.unregister(t))}function re(e){ae(e.target)}function ie(e){oe(e.target)}function ae(e){e.removeEventListener(`dispose`,re),N(e),ce(e),e.isVideoTexture&&y.delete(e),e.isHTMLTexture&&b.delete(e)}function oe(e){e.removeEventListener(`dispose`,ie),N(e),ue(e)}function se(){for(let e of C){let t=e.deref();t!==void 0&&(t.isRenderTarget===!0?oe(t):ae(t))}C.clear(),b.clear()}function ce(e){let t=f.get(e);if(t.__webglInit===void 0)return;let n=e.source,r=S.get(n);if(r){let i=r[t.__cacheKey];i.usedTimes--,i.usedTimes===0&&le(e),Object.keys(r).length===0&&S.delete(n)}f.remove(e)}function le(e){let t=f.get(e);l.deleteTexture(t.__webglTexture);let n=e.source,r=S.get(n);delete r[t.__cacheKey],h.memory.textures--}function ue(e){let t=f.get(e);t.__depthDisposeCallback&&t.__depthDisposeCallback();let n=e.depthTexture;if(n&&n.renderTarget===e&&ae(n),e.isWebGLCubeRenderTarget)for(let e=0;e<6;e++){if(Array.isArray(t.__webglFramebuffer[e]))for(let n=0;n<t.__webglFramebuffer[e].length;n++)l.deleteFramebuffer(t.__webglFramebuffer[e][n]);else l.deleteFramebuffer(t.__webglFramebuffer[e]);t.__webglDepthbuffer&&l.deleteRenderbuffer(t.__webglDepthbuffer[e])}else{if(Array.isArray(t.__webglFramebuffer))for(let e=0;e<t.__webglFramebuffer.length;e++)l.deleteFramebuffer(t.__webglFramebuffer[e]);else l.deleteFramebuffer(t.__webglFramebuffer);if(t.__webglDepthbuffer&&l.deleteRenderbuffer(t.__webglDepthbuffer),t.__webglMultisampledFramebuffer&&l.deleteFramebuffer(t.__webglMultisampledFramebuffer),t.__webglColorRenderbuffer)for(let e=0;e<t.__webglColorRenderbuffer.length;e++)t.__webglColorRenderbuffer[e]&&l.deleteRenderbuffer(t.__webglColorRenderbuffer[e]);t.__webglDepthRenderbuffer&&l.deleteRenderbuffer(t.__webglDepthRenderbuffer)}let r=e.textures;for(let e=0,t=r.length;e<t;e++){let t=f.get(r[e]);t.__webglTexture&&(l.deleteTexture(t.__webglTexture),h.memory.textures--),f.remove(r[e])}f.remove(e)}let de=0;function fe(){de=0}function pe(){return de}function me(e){de=e}function he(){let e=de;return e>=p.maxTextures&&tt(`WebGLTextures: Trying to use `+(e+1)+` texture units while this GPU supports only `+p.maxTextures),de+=1,e}function ge(e){let t=[];return t.push(e.wrapS),t.push(e.wrapT),t.push(e.wrapR||0),t.push(e.magFilter),t.push(e.minFilter),t.push(e.anisotropy),t.push(e.internalFormat),t.push(e.format),t.push(e.type),t.push(e.generateMipmaps),t.push(e.mipmapsAutoUpdate),t.push(e.premultiplyAlpha),t.push(e.flipY),t.push(e.unpackAlignment),t.push(e.colorSpace),t.join()}function _e(e,t){let n=f.get(e);if(e.isVideoTexture&&ze(e),e.isRenderTargetTexture===!1&&e.isExternalTexture!==!0&&e.version>0&&n.__version!==e.version){let r=e.image;if(r===null)tt(`WebGLRenderer: Texture marked for update but no image data found.`);else if(r.complete===!1)tt(`WebGLRenderer: Texture marked for update but image is incomplete`);else{Oe(n,e,t);return}}else e.isExternalTexture&&(n.__webglTexture=e.sourceTexture?e.sourceTexture:null);d.bindTexture(l.TEXTURE_2D,n.__webglTexture,l.TEXTURE0+t)}function ve(e,t){let n=f.get(e);e.isRenderTargetTexture===!1&&e.version>0&&n.__version!==e.version?Oe(n,e,t):(e.isExternalTexture&&(n.__webglTexture=e.sourceTexture?e.sourceTexture:null),d.bindTexture(l.TEXTURE_2D_ARRAY,n.__webglTexture,l.TEXTURE0+t))}function ye(e,t){let n=f.get(e);e.isRenderTargetTexture===!1&&e.version>0&&n.__version!==e.version?Oe(n,e,t):d.bindTexture(l.TEXTURE_3D,n.__webglTexture,l.TEXTURE0+t)}function be(e,t){let n=f.get(e);e.version>0&&n.__version!==e.version?ke(n,e,t):d.bindTexture(l.TEXTURE_CUBE_MAP,n.__webglTexture,l.TEXTURE0+t)}let xe={[e]:l.REPEAT,[t]:l.CLAMP_TO_EDGE,[n]:l.MIRRORED_REPEAT},Se={[r]:l.NEAREST,[i]:l.NEAREST_MIPMAP_NEAREST,[a]:l.NEAREST_MIPMAP_LINEAR,[o]:l.LINEAR,[s]:l.LINEAR_MIPMAP_NEAREST,[c]:l.LINEAR_MIPMAP_LINEAR},Ce={512:l.NEVER,519:l.ALWAYS,513:l.LESS,515:l.LEQUAL,514:l.EQUAL,518:l.GEQUAL,516:l.GREATER,517:l.NOTEQUAL};function we(e,t){if(t.type===1015&&u.has(`OES_texture_float_linear`)===!1&&(t.magFilter===1006||t.magFilter===1007||t.magFilter===1005||t.magFilter===1008||t.minFilter===1006||t.minFilter===1007||t.minFilter===1005||t.minFilter===1008)&&tt(`WebGLRenderer: Unable to use linear filtering with floating point textures. OES_texture_float_linear not supported on this device.`),l.texParameteri(e,l.TEXTURE_WRAP_S,xe[t.wrapS]),l.texParameteri(e,l.TEXTURE_WRAP_T,xe[t.wrapT]),(e===l.TEXTURE_3D||e===l.TEXTURE_2D_ARRAY)&&l.texParameteri(e,l.TEXTURE_WRAP_R,xe[t.wrapR]),l.texParameteri(e,l.TEXTURE_MAG_FILTER,Se[t.magFilter]),l.texParameteri(e,l.TEXTURE_MIN_FILTER,Se[t.minFilter]),t.compareFunction&&(l.texParameteri(e,l.TEXTURE_COMPARE_MODE,l.COMPARE_REF_TO_TEXTURE),l.texParameteri(e,l.TEXTURE_COMPARE_FUNC,Ce[t.compareFunction])),u.has(`EXT_texture_filter_anisotropic`)===!0){if(t.magFilter===1003||t.minFilter!==1005&&t.minFilter!==1008||t.type===1015&&u.has(`OES_texture_float_linear`)===!1)return;if(t.anisotropy>1||f.get(t).__currentAnisotropy){let n=u.get(`EXT_texture_filter_anisotropic`);l.texParameterf(e,n.TEXTURE_MAX_ANISOTROPY_EXT,Math.min(t.anisotropy,p.getMaxAnisotropy())),f.get(t).__currentAnisotropy=t.anisotropy}}}function Te(e,t){let n=!1;e.__webglInit===void 0&&(e.__webglInit=!0,t.addEventListener(`dispose`,re),ne(t));let r=t.source,i=S.get(r);i===void 0&&(i={},S.set(r,i));let a=ge(t);if(a!==e.__cacheKey){i[a]===void 0&&(i[a]={texture:l.createTexture(),usedTimes:0},h.memory.textures++,n=!0),i[a].usedTimes++;let r=i[e.__cacheKey];r!==void 0&&(i[e.__cacheKey].usedTimes--,r.usedTimes===0&&le(t)),e.__cacheKey=a,e.__webglTexture=i[a].texture}return n}function Ee(e,t,n){return Math.floor(Math.floor(e/n)/t)}function De(e,t,n,r){let i=e.updateRanges;if(i.length===0)d.texSubImage2D(l.TEXTURE_2D,0,0,0,t.width,t.height,n,r,t.data);else{i.sort((e,t)=>e.start-t.start);let a=0;for(let e=1;e<i.length;e++){let n=i[a],r=i[e],o=n.start+n.count,s=Ee(r.start,t.width,4),c=Ee(n.start,t.width,4);r.start<=o+1&&s===c&&Ee(r.start+r.count-1,t.width,4)===s?n.count=Math.max(n.count,r.start+r.count-n.start):(++a,i[a]=r)}i.length=a+1;let o=d.getParameter(l.UNPACK_ROW_LENGTH),s=d.getParameter(l.UNPACK_SKIP_PIXELS),c=d.getParameter(l.UNPACK_SKIP_ROWS);d.pixelStorei(l.UNPACK_ROW_LENGTH,t.width);for(let e=0,a=i.length;e<a;e++){let a=i[e],o=Math.floor(a.start/4),s=Math.ceil(a.count/4),c=o%t.width,u=Math.floor(o/t.width),f=s;d.pixelStorei(l.UNPACK_SKIP_PIXELS,c),d.pixelStorei(l.UNPACK_SKIP_ROWS,u),d.texSubImage2D(l.TEXTURE_2D,0,c,u,f,1,n,r,t.data)}e.clearUpdateRanges(),d.pixelStorei(l.UNPACK_ROW_LENGTH,o),d.pixelStorei(l.UNPACK_SKIP_PIXELS,s),d.pixelStorei(l.UNPACK_SKIP_ROWS,c)}}function Oe(e,t,n){let r=l.TEXTURE_2D;(t.isDataArrayTexture||t.isCompressedArrayTexture)&&(r=l.TEXTURE_2D_ARRAY),t.isData3DTexture&&(r=l.TEXTURE_3D);let i=Te(e,t),a=t.source;d.bindTexture(r,e.__webglTexture,l.TEXTURE0+n);let o=f.get(a);if(a.version!==o.__version||i===!0){if(d.activeTexture(l.TEXTURE0+n),!(typeof ImageBitmap<`u`&&t.image instanceof ImageBitmap)){let e=Ut.getPrimaries(Ut.workingColorSpace),n=t.colorSpace===``?null:Ut.getPrimaries(t.colorSpace),r=t.colorSpace===``||e===n?l.NONE:l.BROWSER_DEFAULT_WEBGL;d.pixelStorei(l.UNPACK_FLIP_Y_WEBGL,t.flipY),d.pixelStorei(l.UNPACK_PREMULTIPLY_ALPHA_WEBGL,t.premultiplyAlpha),d.pixelStorei(l.UNPACK_COLORSPACE_CONVERSION_WEBGL,r)}d.pixelStorei(l.UNPACK_ALIGNMENT,t.unpackAlignment);let e=O(t.image,!1,p.maxTextureSize);e=Be(t,e);let s=m.convert(t.format,t.colorSpace),c=m.convert(t.type),u=j(t.internalFormat,s,c,t.normalized,t.colorSpace,t.isVideoTexture);we(r,t);let f,h=t.mipmaps,g=t.isVideoTexture!==!0,_=o.__version===void 0||i===!0,v=a.dataReady,y=M(t,e);if(t.isDepthTexture)u=te(t.format===E,t.type),_&&(g?d.texStorage2D(l.TEXTURE_2D,1,u,e.width,e.height):d.texImage2D(l.TEXTURE_2D,0,u,e.width,e.height,0,s,c,null));else if(t.isDataTexture){if(h.length>0){g&&_&&d.texStorage2D(l.TEXTURE_2D,y,u,h[0].width,h[0].height);for(let e=0,t=h.length;e<t;e++)f=h[e],g?v&&d.texSubImage2D(l.TEXTURE_2D,e,0,0,f.width,f.height,s,c,f.data):d.texImage2D(l.TEXTURE_2D,e,u,f.width,f.height,0,s,c,f.data);t.generateMipmaps=!1}else g?(_&&d.texStorage2D(l.TEXTURE_2D,y,u,e.width,e.height),v&&De(t,e,s,c)):d.texImage2D(l.TEXTURE_2D,0,u,e.width,e.height,0,s,c,e.data)}else if(t.isCompressedTexture){if(t.isCompressedArrayTexture){g&&_&&d.texStorage3D(l.TEXTURE_2D_ARRAY,y,u,h[0].width,h[0].height,e.depth);for(let n=0,r=h.length;n<r;n++)if(f=h[n],t.format!==1023){if(s!==null){if(g){if(v){if(t.layerUpdates.size>0){let e=Js(f.width,f.height,t.format,t.type);for(let r of t.layerUpdates){let t=f.data.subarray(r*e/f.data.BYTES_PER_ELEMENT,(r+1)*e/f.data.BYTES_PER_ELEMENT);d.compressedTexSubImage3D(l.TEXTURE_2D_ARRAY,n,0,0,r,f.width,f.height,1,s,t)}}else d.compressedTexSubImage3D(l.TEXTURE_2D_ARRAY,n,0,0,0,f.width,f.height,e.depth,s,f.data)}}else d.compressedTexImage3D(l.TEXTURE_2D_ARRAY,n,u,f.width,f.height,e.depth,0,f.data,0,0)}else tt(`WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()`)}else g?v&&d.texSubImage3D(l.TEXTURE_2D_ARRAY,n,0,0,0,f.width,f.height,e.depth,s,c,f.data):d.texImage3D(l.TEXTURE_2D_ARRAY,n,u,f.width,f.height,e.depth,0,s,c,f.data);t.layerUpdates.size>0&&t.clearLayerUpdates()}else{g&&_&&d.texStorage2D(l.TEXTURE_2D,y,u,h[0].width,h[0].height);for(let e=0,n=h.length;e<n;e++)f=h[e],t.format===1023?g?v&&d.texSubImage2D(l.TEXTURE_2D,e,0,0,f.width,f.height,s,c,f.data):d.texImage2D(l.TEXTURE_2D,e,u,f.width,f.height,0,s,c,f.data):s===null?tt(`WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()`):g?v&&d.compressedTexSubImage2D(l.TEXTURE_2D,e,0,0,f.width,f.height,s,f.data):d.compressedTexImage2D(l.TEXTURE_2D,e,u,f.width,f.height,0,f.data)}}else if(t.isDataArrayTexture){if(g){if(_&&d.texStorage3D(l.TEXTURE_2D_ARRAY,y,u,e.width,e.height,e.depth),v){if(t.layerUpdates.size>0){let n=Js(e.width,e.height,t.format,t.type);for(let r of t.layerUpdates){let t=e.data.subarray(r*n/e.data.BYTES_PER_ELEMENT,(r+1)*n/e.data.BYTES_PER_ELEMENT);d.texSubImage3D(l.TEXTURE_2D_ARRAY,0,0,0,r,e.width,e.height,1,s,c,t)}t.clearLayerUpdates()}else d.texSubImage3D(l.TEXTURE_2D_ARRAY,0,0,0,0,e.width,e.height,e.depth,s,c,e.data)}}else d.texImage3D(l.TEXTURE_2D_ARRAY,0,u,e.width,e.height,e.depth,0,s,c,e.data)}else if(t.isData3DTexture)g?(_&&d.texStorage3D(l.TEXTURE_3D,y,u,e.width,e.height,e.depth),v&&d.texSubImage3D(l.TEXTURE_3D,0,0,0,0,e.width,e.height,e.depth,s,c,e.data)):d.texImage3D(l.TEXTURE_3D,0,u,e.width,e.height,e.depth,0,s,c,e.data);else if(t.isFramebufferTexture){if(_){if(g)d.texStorage2D(l.TEXTURE_2D,y,u,e.width,e.height);else{let t=e.width,n=e.height;for(let e=0;e<y;e++)d.texImage2D(l.TEXTURE_2D,e,u,t,n,0,s,c,null),t>>=1,n>>=1}}}else if(t.isHTMLTexture){if(`texElementImage2D`in l){let n=l.canvas;if(n.hasAttribute(`layoutsubtree`)||n.setAttribute(`layoutsubtree`,`true`),e.parentNode!==n){n.appendChild(e),b.add(t),n.onpaint=e=>{let t=e.changedElements;for(let e of b)t.includes(e.image)&&(e.needsUpdate=!0)},n.requestPaint();return}if(l.texElementImage2D.length===3)l.texElementImage2D(l.TEXTURE_2D,l.RGBA8,e);else{let t=l.RGBA,n=l.RGBA,r=l.UNSIGNED_BYTE;l.texElementImage2D(l.TEXTURE_2D,0,t,n,r,e)}l.texParameteri(l.TEXTURE_2D,l.TEXTURE_MIN_FILTER,l.LINEAR),l.texParameteri(l.TEXTURE_2D,l.TEXTURE_WRAP_S,l.CLAMP_TO_EDGE),l.texParameteri(l.TEXTURE_2D,l.TEXTURE_WRAP_T,l.CLAMP_TO_EDGE)}}else if(h.length>0){if(g&&_){let e=Ve(h[0]);d.texStorage2D(l.TEXTURE_2D,y,u,e.width,e.height)}for(let e=0,t=h.length;e<t;e++)f=h[e],g?v&&d.texSubImage2D(l.TEXTURE_2D,e,0,0,s,c,f):d.texImage2D(l.TEXTURE_2D,e,u,s,c,f);t.generateMipmaps=!1}else if(g){if(_){let t=Ve(e);d.texStorage2D(l.TEXTURE_2D,y,u,t.width,t.height)}v&&d.texSubImage2D(l.TEXTURE_2D,0,0,0,s,c,e)}else d.texImage2D(l.TEXTURE_2D,0,u,s,c,e);k(t)&&t.mipmapsAutoUpdate===!0&&A(r),o.__version=a.version,t.onUpdate&&t.onUpdate(t)}e.__version=t.version}function ke(e,t,n){if(t.image.length!==6)return;let r=Te(e,t),i=t.source;d.bindTexture(l.TEXTURE_CUBE_MAP,e.__webglTexture,l.TEXTURE0+n);let a=f.get(i);if(i.version!==a.__version||r===!0){d.activeTexture(l.TEXTURE0+n);let e=Ut.getPrimaries(Ut.workingColorSpace),o=t.colorSpace===``?null:Ut.getPrimaries(t.colorSpace),s=t.colorSpace===``||e===o?l.NONE:l.BROWSER_DEFAULT_WEBGL;d.pixelStorei(l.UNPACK_FLIP_Y_WEBGL,t.flipY),d.pixelStorei(l.UNPACK_PREMULTIPLY_ALPHA_WEBGL,t.premultiplyAlpha),d.pixelStorei(l.UNPACK_ALIGNMENT,t.unpackAlignment),d.pixelStorei(l.UNPACK_COLORSPACE_CONVERSION_WEBGL,s);let c=t.isCompressedTexture||t.image[0].isCompressedTexture,u=t.image[0]&&t.image[0].isDataTexture,f=[];for(let e=0;e<6;e++)!c&&!u?f[e]=O(t.image[e],!0,p.maxCubemapSize):f[e]=u?t.image[e].image:t.image[e],f[e]=Be(t,f[e]);let h=f[0],g=m.convert(t.format,t.colorSpace),_=m.convert(t.type),v=j(t.internalFormat,g,_,t.normalized,t.colorSpace),y=t.isVideoTexture!==!0,b=a.__version===void 0||r===!0,x=i.dataReady,S=M(t,h);we(l.TEXTURE_CUBE_MAP,t);let C;if(t.isDepthTexture){if(v=te(t.format===E,t.type),b){if(y)d.texStorage2D(l.TEXTURE_CUBE_MAP,1,v,h.width,h.height);else for(let e=0;e<6;e++)d.texImage2D(l.TEXTURE_CUBE_MAP_POSITIVE_X+e,0,v,h.width,h.height,0,g,_,null)}}else if(c){y&&b&&d.texStorage2D(l.TEXTURE_CUBE_MAP,S,v,h.width,h.height);for(let e=0;e<6;e++){C=f[e].mipmaps;for(let n=0;n<C.length;n++){let r=C[n];t.format===1023?y?x&&d.texSubImage2D(l.TEXTURE_CUBE_MAP_POSITIVE_X+e,n,0,0,r.width,r.height,g,_,r.data):d.texImage2D(l.TEXTURE_CUBE_MAP_POSITIVE_X+e,n,v,r.width,r.height,0,g,_,r.data):g===null?tt(`WebGLRenderer: Attempt to load unsupported compressed texture format in .setTextureCube()`):y?x&&d.compressedTexSubImage2D(l.TEXTURE_CUBE_MAP_POSITIVE_X+e,n,0,0,r.width,r.height,g,r.data):d.compressedTexImage2D(l.TEXTURE_CUBE_MAP_POSITIVE_X+e,n,v,r.width,r.height,0,r.data)}}}else{if(C=t.mipmaps,y&&b){C.length>0&&S++;let e=Ve(f[0]);d.texStorage2D(l.TEXTURE_CUBE_MAP,S,v,e.width,e.height)}for(let e=0;e<6;e++)if(u){y?x&&d.texSubImage2D(l.TEXTURE_CUBE_MAP_POSITIVE_X+e,0,0,0,f[e].width,f[e].height,g,_,f[e].data):d.texImage2D(l.TEXTURE_CUBE_MAP_POSITIVE_X+e,0,v,f[e].width,f[e].height,0,g,_,f[e].data);for(let t=0;t<C.length;t++){let n=C[t].image[e].image;y?x&&d.texSubImage2D(l.TEXTURE_CUBE_MAP_POSITIVE_X+e,t+1,0,0,n.width,n.height,g,_,n.data):d.texImage2D(l.TEXTURE_CUBE_MAP_POSITIVE_X+e,t+1,v,n.width,n.height,0,g,_,n.data)}}else{y?x&&d.texSubImage2D(l.TEXTURE_CUBE_MAP_POSITIVE_X+e,0,0,0,g,_,f[e]):d.texImage2D(l.TEXTURE_CUBE_MAP_POSITIVE_X+e,0,v,g,_,f[e]);for(let t=0;t<C.length;t++){let n=C[t];y?x&&d.texSubImage2D(l.TEXTURE_CUBE_MAP_POSITIVE_X+e,t+1,0,0,g,_,n.image[e]):d.texImage2D(l.TEXTURE_CUBE_MAP_POSITIVE_X+e,t+1,v,g,_,n.image[e])}}}k(t)&&t.mipmapsAutoUpdate===!0&&A(l.TEXTURE_CUBE_MAP),a.__version=i.version,t.onUpdate&&t.onUpdate(t)}e.__version=t.version}function Ae(e,t,n,r,i,a){let o=m.convert(n.format,n.colorSpace),s=m.convert(n.type),c=j(n.internalFormat,o,s,n.normalized,n.colorSpace),u=f.get(t),p=f.get(n);if(p.__renderTarget=t,!u.__hasExternalTextures){let e=Math.max(1,t.width>>a),n=Math.max(1,t.height>>a);i===l.TEXTURE_3D||i===l.TEXTURE_2D_ARRAY?d.texImage3D(i,a,c,e,n,t.depth,0,o,s,null):d.texImage2D(i,a,c,e,n,0,o,s,null)}d.bindFramebuffer(l.FRAMEBUFFER,e),F(t)?g.framebufferTexture2DMultisampleEXT(l.FRAMEBUFFER,r,i,p.__webglTexture,0,Re(t)):(i===l.TEXTURE_2D||i>=l.TEXTURE_CUBE_MAP_POSITIVE_X&&i<=l.TEXTURE_CUBE_MAP_NEGATIVE_Z)&&l.framebufferTexture2D(l.FRAMEBUFFER,r,i,p.__webglTexture,a),d.bindFramebuffer(l.FRAMEBUFFER,null)}function je(e,t,n){if(l.bindRenderbuffer(l.RENDERBUFFER,e),t.depthBuffer){let r=t.depthTexture,i=r&&r.isDepthTexture?r.type:null,a=te(t.stencilBuffer,i),o=t.stencilBuffer?l.DEPTH_STENCIL_ATTACHMENT:l.DEPTH_ATTACHMENT;F(t)?g.renderbufferStorageMultisampleEXT(l.RENDERBUFFER,Re(t),a,t.width,t.height):n?l.renderbufferStorageMultisample(l.RENDERBUFFER,Re(t),a,t.width,t.height):l.renderbufferStorage(l.RENDERBUFFER,a,t.width,t.height),l.framebufferRenderbuffer(l.FRAMEBUFFER,o,l.RENDERBUFFER,e)}else{let e=t.textures;for(let r=0;r<e.length;r++){let i=e[r],a=m.convert(i.format,i.colorSpace),o=m.convert(i.type),s=j(i.internalFormat,a,o,i.normalized,i.colorSpace);F(t)?g.renderbufferStorageMultisampleEXT(l.RENDERBUFFER,Re(t),s,t.width,t.height):n?l.renderbufferStorageMultisample(l.RENDERBUFFER,Re(t),s,t.width,t.height):l.renderbufferStorage(l.RENDERBUFFER,s,t.width,t.height)}}l.bindRenderbuffer(l.RENDERBUFFER,null)}function Me(e,t,n){let r=t.isWebGLCubeRenderTarget===!0;if(d.bindFramebuffer(l.FRAMEBUFFER,e),!(t.depthTexture&&t.depthTexture.isDepthTexture))throw Error(`THREE.WebGLTextures: renderTarget.depthTexture must be an instance of THREE.DepthTexture.`);let i=f.get(t.depthTexture);i.__renderTarget=t;let a=r?t.depthTexture.image[0]:t.depthTexture.image;i.__webglTexture&&a.width===t.width&&a.height===t.height||(a.width=t.width,a.height=t.height,t.depthTexture.needsUpdate=!0),r?be(t.depthTexture,0):_e(t.depthTexture,0);let o=i.__webglTexture,s=Re(t),c=r?l.TEXTURE_CUBE_MAP_POSITIVE_X+n:l.TEXTURE_2D,u=t.depthTexture.format===1027?l.DEPTH_STENCIL_ATTACHMENT:l.DEPTH_ATTACHMENT;if(t.depthTexture.format===1026)F(t)?g.framebufferTexture2DMultisampleEXT(l.FRAMEBUFFER,u,c,o,0,s):l.framebufferTexture2D(l.FRAMEBUFFER,u,c,o,0);else if(t.depthTexture.format===1027)F(t)?g.framebufferTexture2DMultisampleEXT(l.FRAMEBUFFER,u,c,o,0,s):l.framebufferTexture2D(l.FRAMEBUFFER,u,c,o,0);else throw Error(`THREE.WebGLTextures: Unknown depthTexture format.`)}function Ne(e){let t=f.get(e),n=e.isWebGLCubeRenderTarget===!0;if(t.__boundDepthTexture!==e.depthTexture){let n=e.depthTexture;if(t.__depthDisposeCallback&&t.__depthDisposeCallback(),n){let e=()=>{delete t.__boundDepthTexture,delete t.__depthDisposeCallback,n.removeEventListener(`dispose`,e)};n.addEventListener(`dispose`,e),t.__depthDisposeCallback=e}t.__boundDepthTexture=n}if(e.depthTexture&&!t.__autoAllocateDepthBuffer){if(n)for(let n=0;n<6;n++)Me(t.__webglFramebuffer[n],e,n);else e.texture.mipmaps.length>0?Me(t.__webglFramebuffer[0],e,0):Me(t.__webglFramebuffer,e,0)}else if(n){t.__webglDepthbuffer=[];for(let n=0;n<6;n++)if(d.bindFramebuffer(l.FRAMEBUFFER,t.__webglFramebuffer[n]),t.__webglDepthbuffer[n]===void 0)t.__webglDepthbuffer[n]=l.createRenderbuffer(),je(t.__webglDepthbuffer[n],e,!1);else{let r=e.stencilBuffer?l.DEPTH_STENCIL_ATTACHMENT:l.DEPTH_ATTACHMENT,i=t.__webglDepthbuffer[n];l.bindRenderbuffer(l.RENDERBUFFER,i),l.framebufferRenderbuffer(l.FRAMEBUFFER,r,l.RENDERBUFFER,i)}}else if(e.texture.mipmaps.length>0?d.bindFramebuffer(l.FRAMEBUFFER,t.__webglFramebuffer[0]):d.bindFramebuffer(l.FRAMEBUFFER,t.__webglFramebuffer),t.__webglDepthbuffer===void 0)t.__webglDepthbuffer=l.createRenderbuffer(),je(t.__webglDepthbuffer,e,!1);else{let n=e.stencilBuffer?l.DEPTH_STENCIL_ATTACHMENT:l.DEPTH_ATTACHMENT,r=t.__webglDepthbuffer;l.bindRenderbuffer(l.RENDERBUFFER,r),l.framebufferRenderbuffer(l.FRAMEBUFFER,n,l.RENDERBUFFER,r)}d.bindFramebuffer(l.FRAMEBUFFER,null)}function Pe(e,t,n){let r=f.get(e);t!==void 0&&Ae(r.__webglFramebuffer,e,e.texture,l.COLOR_ATTACHMENT0,l.TEXTURE_2D,0),n!==void 0&&Ne(e)}function Fe(e){let t=e.texture,n=f.get(e),r=f.get(t);e.addEventListener(`dispose`,ie),ne(e);let i=e.textures,a=e.isWebGLCubeRenderTarget===!0,o=i.length>1;if(o||(r.__webglTexture===void 0&&(r.__webglTexture=l.createTexture()),r.__version=t.version,h.memory.textures++),a){n.__webglFramebuffer=[];for(let e=0;e<6;e++)if(t.mipmaps.length>0){n.__webglFramebuffer[e]=[];for(let r=0;r<t.mipmaps.length;r++)n.__webglFramebuffer[e][r]=l.createFramebuffer()}else n.__webglFramebuffer[e]=l.createFramebuffer()}else{if(t.mipmaps.length>0){n.__webglFramebuffer=[];for(let e=0;e<t.mipmaps.length;e++)n.__webglFramebuffer[e]=l.createFramebuffer()}else n.__webglFramebuffer=l.createFramebuffer();if(o)for(let e=0,t=i.length;e<t;e++){let t=f.get(i[e]);t.__webglTexture===void 0&&(t.__webglTexture=l.createTexture(),h.memory.textures++)}if(e.samples>0&&F(e)===!1){n.__webglMultisampledFramebuffer=l.createFramebuffer(),n.__webglColorRenderbuffer=[],d.bindFramebuffer(l.FRAMEBUFFER,n.__webglMultisampledFramebuffer);for(let t=0;t<i.length;t++){let r=i[t];n.__webglColorRenderbuffer[t]=l.createRenderbuffer(),l.bindRenderbuffer(l.RENDERBUFFER,n.__webglColorRenderbuffer[t]);let a=m.convert(r.format,r.colorSpace),o=m.convert(r.type),s=j(r.internalFormat,a,o,r.normalized,r.colorSpace,e.isXRRenderTarget===!0),c=Re(e);l.renderbufferStorageMultisample(l.RENDERBUFFER,c,s,e.width,e.height),l.framebufferRenderbuffer(l.FRAMEBUFFER,l.COLOR_ATTACHMENT0+t,l.RENDERBUFFER,n.__webglColorRenderbuffer[t])}l.bindRenderbuffer(l.RENDERBUFFER,null),e.depthBuffer&&(n.__webglDepthRenderbuffer=l.createRenderbuffer(),je(n.__webglDepthRenderbuffer,e,!0)),d.bindFramebuffer(l.FRAMEBUFFER,null)}}if(a){d.bindTexture(l.TEXTURE_CUBE_MAP,r.__webglTexture),we(l.TEXTURE_CUBE_MAP,t);for(let r=0;r<6;r++)if(t.mipmaps.length>0)for(let i=0;i<t.mipmaps.length;i++)Ae(n.__webglFramebuffer[r][i],e,t,l.COLOR_ATTACHMENT0,l.TEXTURE_CUBE_MAP_POSITIVE_X+r,i);else Ae(n.__webglFramebuffer[r],e,t,l.COLOR_ATTACHMENT0,l.TEXTURE_CUBE_MAP_POSITIVE_X+r,0);k(t)?A(l.TEXTURE_CUBE_MAP):t.mipmaps.length>0&&l.texParameteri(l.TEXTURE_CUBE_MAP,l.TEXTURE_MAX_LEVEL,t.mipmaps.length-1),d.unbindTexture()}else if(o){for(let t=0,r=i.length;t<r;t++){let r=i[t],a=f.get(r),o=l.TEXTURE_2D;(e.isWebGL3DRenderTarget||e.isWebGLArrayRenderTarget)&&(o=e.isWebGL3DRenderTarget?l.TEXTURE_3D:l.TEXTURE_2D_ARRAY),d.bindTexture(o,a.__webglTexture),we(o,r),Ae(n.__webglFramebuffer,e,r,l.COLOR_ATTACHMENT0+t,o,0),k(r)&&A(o)}d.unbindTexture()}else{let i=l.TEXTURE_2D;if((e.isWebGL3DRenderTarget||e.isWebGLArrayRenderTarget)&&(i=e.isWebGL3DRenderTarget?l.TEXTURE_3D:l.TEXTURE_2D_ARRAY),d.bindTexture(i,r.__webglTexture),we(i,t),t.mipmaps.length>0)for(let r=0;r<t.mipmaps.length;r++)Ae(n.__webglFramebuffer[r],e,t,l.COLOR_ATTACHMENT0,i,r);else Ae(n.__webglFramebuffer,e,t,l.COLOR_ATTACHMENT0,i,0);k(t)?A(i):t.mipmaps.length>0&&l.texParameteri(i,l.TEXTURE_MAX_LEVEL,t.mipmaps.length-1),d.unbindTexture()}e.depthBuffer&&Ne(e)}function P(e){let t=e.textures;for(let n=0,r=t.length;n<r;n++){let r=t[n];if(k(r)&&r.mipmapsAutoUpdate===!0){let t=ee(e),n=f.get(r).__webglTexture;d.bindTexture(t,n),A(t),d.unbindTexture()}}}let Ie=[];function Le(e){if(e.samples>0){if(F(e)===!1){let t=e.textures,n=e.width,r=e.height,i=l.COLOR_BUFFER_BIT,a=e.stencilBuffer?l.DEPTH_STENCIL_ATTACHMENT:l.DEPTH_ATTACHMENT,o=f.get(e),s=t.length>1;if(s)for(let e=0;e<t.length;e++)d.bindFramebuffer(l.FRAMEBUFFER,o.__webglMultisampledFramebuffer),l.framebufferRenderbuffer(l.FRAMEBUFFER,l.COLOR_ATTACHMENT0+e,l.RENDERBUFFER,null),d.bindFramebuffer(l.FRAMEBUFFER,o.__webglFramebuffer),l.framebufferTexture2D(l.DRAW_FRAMEBUFFER,l.COLOR_ATTACHMENT0+e,l.TEXTURE_2D,null,0);d.bindFramebuffer(l.READ_FRAMEBUFFER,o.__webglMultisampledFramebuffer),e.texture.mipmaps.length>0?d.bindFramebuffer(l.DRAW_FRAMEBUFFER,o.__webglFramebuffer[0]):d.bindFramebuffer(l.DRAW_FRAMEBUFFER,o.__webglFramebuffer);for(let c=0;c<t.length;c++){if(e.resolveDepthBuffer&&(e.depthBuffer&&(i|=l.DEPTH_BUFFER_BIT),e.stencilBuffer&&e.resolveStencilBuffer&&(i|=l.STENCIL_BUFFER_BIT)),s){l.framebufferRenderbuffer(l.READ_FRAMEBUFFER,l.COLOR_ATTACHMENT0,l.RENDERBUFFER,o.__webglColorRenderbuffer[c]);let e=f.get(t[c]).__webglTexture;l.framebufferTexture2D(l.DRAW_FRAMEBUFFER,l.COLOR_ATTACHMENT0,l.TEXTURE_2D,e,0)}l.blitFramebuffer(0,0,n,r,0,0,n,r,i,l.NEAREST),_===!0&&(Ie.length=0,Ie.push(l.COLOR_ATTACHMENT0+c),e.depthBuffer&&e.storeMultisampledDepthBuffer===!1&&Ie.push(a),l.invalidateFramebuffer(l.READ_FRAMEBUFFER,Ie))}if(d.bindFramebuffer(l.READ_FRAMEBUFFER,null),d.bindFramebuffer(l.DRAW_FRAMEBUFFER,null),s)for(let e=0;e<t.length;e++){d.bindFramebuffer(l.FRAMEBUFFER,o.__webglMultisampledFramebuffer),l.framebufferRenderbuffer(l.FRAMEBUFFER,l.COLOR_ATTACHMENT0+e,l.RENDERBUFFER,o.__webglColorRenderbuffer[e]);let n=f.get(t[e]).__webglTexture;d.bindFramebuffer(l.FRAMEBUFFER,o.__webglFramebuffer),l.framebufferTexture2D(l.DRAW_FRAMEBUFFER,l.COLOR_ATTACHMENT0+e,l.TEXTURE_2D,n,0)}d.bindFramebuffer(l.DRAW_FRAMEBUFFER,o.__webglMultisampledFramebuffer)}else if(e.depthBuffer&&e.storeMultisampledDepthBuffer===!1&&_){let t=e.stencilBuffer?l.DEPTH_STENCIL_ATTACHMENT:l.DEPTH_ATTACHMENT;l.invalidateFramebuffer(l.DRAW_FRAMEBUFFER,[t])}}}function Re(e){return Math.min(p.maxSamples,e.samples)}function F(e){let t=f.get(e);return e.samples>0&&u.has(`WEBGL_multisampled_render_to_texture`)===!0&&t.__useRenderToTexture!==!1}function ze(e){let t=h.render.frame;y.get(e)!==t&&(y.set(e,t),e.update())}function Be(e,t){let n=e.colorSpace,r=e.format,i=e.type;return e.isCompressedTexture===!0||e.isVideoTexture===!0||n!==`srgb-linear`&&n!==``&&(Ut.getTransfer(n)===`srgb`?(r!==1023||i!==1009)&&tt(`WebGLTextures: sRGB encoded textures have to use RGBAFormat and UnsignedByteType.`):nt(`WebGLTextures: Unsupported texture color space:`,n)),t}function Ve(e){return typeof HTMLImageElement<`u`&&e instanceof HTMLImageElement?(v.width=e.naturalWidth||e.width,v.height=e.naturalHeight||e.height):typeof VideoFrame<`u`&&e instanceof VideoFrame?(v.width=e.displayWidth,v.height=e.displayHeight):(v.width=e.width,v.height=e.height),v}this.allocateTextureUnit=he,this.resetTextureUnits=fe,this.getTextureUnits=pe,this.setTextureUnits=me,this.setTexture2D=_e,this.setTexture2DArray=ve,this.setTexture3D=ye,this.setTextureCube=be,this.rebindTextures=Pe,this.setupRenderTarget=Fe,this.updateRenderTargetMipmap=P,this.updateMultisampleRenderTarget=Le,this.setupDepthRenderbuffer=Ne,this.setupFrameBufferTexture=Ae,this.useMultisampledRTT=F,this.dispose=se}function Ju(e,t){function n(n,r=``){let i,a=Ut.getTransfer(r);if(n===1009)return e.UNSIGNED_BYTE;if(n===1017)return e.UNSIGNED_SHORT_4_4_4_4;if(n===1018)return e.UNSIGNED_SHORT_5_5_5_1;if(n===35902)return e.UNSIGNED_INT_5_9_9_9_REV;if(n===35899)return e.UNSIGNED_INT_10F_11F_11F_REV;if(n===1010)return e.BYTE;if(n===1011)return e.SHORT;if(n===1012)return e.UNSIGNED_SHORT;if(n===1013)return e.INT;if(n===1014)return e.UNSIGNED_INT;if(n===1015)return e.FLOAT;if(n===1016)return e.HALF_FLOAT;if(n===1021)return e.ALPHA;if(n===1022)return e.RGB;if(n===1023)return e.RGBA;if(n===1026)return e.DEPTH_COMPONENT;if(n===1027)return e.DEPTH_STENCIL;if(n===1028)return e.RED;if(n===1029)return e.RED_INTEGER;if(n===1030)return e.RG;if(n===1031)return e.RG_INTEGER;if(n===1033)return e.RGBA_INTEGER;if(n===33776||n===33777||n===33778||n===33779){if(a===`srgb`){if(i=t.get(`WEBGL_compressed_texture_s3tc_srgb`),i!==null){if(n===33776)return i.COMPRESSED_SRGB_S3TC_DXT1_EXT;if(n===33777)return i.COMPRESSED_SRGB_ALPHA_S3TC_DXT1_EXT;if(n===33778)return i.COMPRESSED_SRGB_ALPHA_S3TC_DXT3_EXT;if(n===33779)return i.COMPRESSED_SRGB_ALPHA_S3TC_DXT5_EXT}else return null}else if(i=t.get(`WEBGL_compressed_texture_s3tc`),i!==null){if(n===33776)return i.COMPRESSED_RGB_S3TC_DXT1_EXT;if(n===33777)return i.COMPRESSED_RGBA_S3TC_DXT1_EXT;if(n===33778)return i.COMPRESSED_RGBA_S3TC_DXT3_EXT;if(n===33779)return i.COMPRESSED_RGBA_S3TC_DXT5_EXT}else return null}if(n===35840||n===35841||n===35842||n===35843){if(i=t.get(`WEBGL_compressed_texture_pvrtc`),i!==null){if(n===35840)return i.COMPRESSED_RGB_PVRTC_4BPPV1_IMG;if(n===35841)return i.COMPRESSED_RGB_PVRTC_2BPPV1_IMG;if(n===35842)return i.COMPRESSED_RGBA_PVRTC_4BPPV1_IMG;if(n===35843)return i.COMPRESSED_RGBA_PVRTC_2BPPV1_IMG}else return null}if(n===36196||n===37492||n===37496||n===37488||n===37489||n===37490||n===37491){if(i=t.get(`WEBGL_compressed_texture_etc`),i!==null){if(n===36196||n===37492)return a===`srgb`?i.COMPRESSED_SRGB8_ETC2:i.COMPRESSED_RGB8_ETC2;if(n===37496)return a===`srgb`?i.COMPRESSED_SRGB8_ALPHA8_ETC2_EAC:i.COMPRESSED_RGBA8_ETC2_EAC;if(n===37488)return i.COMPRESSED_R11_EAC;if(n===37489)return i.COMPRESSED_SIGNED_R11_EAC;if(n===37490)return i.COMPRESSED_RG11_EAC;if(n===37491)return i.COMPRESSED_SIGNED_RG11_EAC}else return null}if(n===37808||n===37809||n===37810||n===37811||n===37812||n===37813||n===37814||n===37815||n===37816||n===37817||n===37818||n===37819||n===37820||n===37821){if(i=t.get(`WEBGL_compressed_texture_astc`),i!==null){if(n===37808)return a===`srgb`?i.COMPRESSED_SRGB8_ALPHA8_ASTC_4x4_KHR:i.COMPRESSED_RGBA_ASTC_4x4_KHR;if(n===37809)return a===`srgb`?i.COMPRESSED_SRGB8_ALPHA8_ASTC_5x4_KHR:i.COMPRESSED_RGBA_ASTC_5x4_KHR;if(n===37810)return a===`srgb`?i.COMPRESSED_SRGB8_ALPHA8_ASTC_5x5_KHR:i.COMPRESSED_RGBA_ASTC_5x5_KHR;if(n===37811)return a===`srgb`?i.COMPRESSED_SRGB8_ALPHA8_ASTC_6x5_KHR:i.COMPRESSED_RGBA_ASTC_6x5_KHR;if(n===37812)return a===`srgb`?i.COMPRESSED_SRGB8_ALPHA8_ASTC_6x6_KHR:i.COMPRESSED_RGBA_ASTC_6x6_KHR;if(n===37813)return a===`srgb`?i.COMPRESSED_SRGB8_ALPHA8_ASTC_8x5_KHR:i.COMPRESSED_RGBA_ASTC_8x5_KHR;if(n===37814)return a===`srgb`?i.COMPRESSED_SRGB8_ALPHA8_ASTC_8x6_KHR:i.COMPRESSED_RGBA_ASTC_8x6_KHR;if(n===37815)return a===`srgb`?i.COMPRESSED_SRGB8_ALPHA8_ASTC_8x8_KHR:i.COMPRESSED_RGBA_ASTC_8x8_KHR;if(n===37816)return a===`srgb`?i.COMPRESSED_SRGB8_ALPHA8_ASTC_10x5_KHR:i.COMPRESSED_RGBA_ASTC_10x5_KHR;if(n===37817)return a===`srgb`?i.COMPRESSED_SRGB8_ALPHA8_ASTC_10x6_KHR:i.COMPRESSED_RGBA_ASTC_10x6_KHR;if(n===37818)return a===`srgb`?i.COMPRESSED_SRGB8_ALPHA8_ASTC_10x8_KHR:i.COMPRESSED_RGBA_ASTC_10x8_KHR;if(n===37819)return a===`srgb`?i.COMPRESSED_SRGB8_ALPHA8_ASTC_10x10_KHR:i.COMPRESSED_RGBA_ASTC_10x10_KHR;if(n===37820)return a===`srgb`?i.COMPRESSED_SRGB8_ALPHA8_ASTC_12x10_KHR:i.COMPRESSED_RGBA_ASTC_12x10_KHR;if(n===37821)return a===`srgb`?i.COMPRESSED_SRGB8_ALPHA8_ASTC_12x12_KHR:i.COMPRESSED_RGBA_ASTC_12x12_KHR}else return null}if(n===36492||n===36494||n===36495){if(i=t.get(`EXT_texture_compression_bptc`),i!==null){if(n===36492)return a===`srgb`?i.COMPRESSED_SRGB_ALPHA_BPTC_UNORM_EXT:i.COMPRESSED_RGBA_BPTC_UNORM_EXT;if(n===36494)return i.COMPRESSED_RGB_BPTC_SIGNED_FLOAT_EXT;if(n===36495)return i.COMPRESSED_RGB_BPTC_UNSIGNED_FLOAT_EXT}else return null}if(n===36283||n===36284||n===36285||n===36286){if(i=t.get(`EXT_texture_compression_rgtc`),i!==null){if(n===36283)return i.COMPRESSED_RED_RGTC1_EXT;if(n===36284)return i.COMPRESSED_SIGNED_RED_RGTC1_EXT;if(n===36285)return i.COMPRESSED_RED_GREEN_RGTC2_EXT;if(n===36286)return i.COMPRESSED_SIGNED_RED_GREEN_RGTC2_EXT}else return null}return n===1020?e.UNSIGNED_INT_24_8:e[n]===void 0?null:e[n]}return{convert:n}}var Yu=`
void main() {

	gl_Position = vec4( position, 1.0 );

}`,Xu=`
uniform sampler2DArray depthColor;
uniform float depthWidth;
uniform float depthHeight;

void main() {

	vec2 coord = vec2( gl_FragCoord.x / depthWidth, gl_FragCoord.y / depthHeight );

	if ( coord.x >= 1.0 ) {

		gl_FragDepth = texture( depthColor, vec3( coord.x - 1.0, coord.y, 1 ) ).r;

	} else {

		gl_FragDepth = texture( depthColor, vec3( coord.x, coord.y, 0 ) ).r;

	}

}`,Zu=class{constructor(){this.texture=null,this.mesh=null,this.depthNear=0,this.depthFar=0}init(e,t){if(this.texture===null){let n=new Yi(e.texture);(e.depthNear!==t.depthNear||e.depthFar!==t.depthFar)&&(this.depthNear=e.depthNear,this.depthFar=e.depthFar),this.texture=n}}getMesh(e){if(this.texture!==null&&this.mesh===null){let t=e.cameras[0].viewport,n=new Po({vertexShader:Yu,fragmentShader:Xu,uniforms:{depthColor:{value:this.texture},depthWidth:{value:t.z},depthHeight:{value:t.w}}});this.mesh=new oi(new So(20,20),n)}return this.mesh}reset(){this.texture=null,this.mesh=null}getDepthTexture(){return this.texture}},Qu=class extends ot{constructor(e,t){super();let n=this,r=null,i=1,a=null,o=`local-floor`,s=1,c=null,u=null,d=null,f=null,p=null,h=null,g=typeof XRWebGLBinding<`u`,_=new Zu,v={},b=t.getContextAttributes(),x=null,S=null,C=[],D=[],O=new I,k=null,A=null,ee=new ys;ee.viewport=new en;let j=new ys;j.viewport=new en;let te=[ee,j],M=new ks,ne=null,N=null;this.cameraAutoUpdate=!0,this.enabled=!1,this.isPresenting=!1,this.getController=function(e){let t=C[e];return t===void 0&&(t=new In,C[e]=t),t.getTargetRaySpace()},this.getControllerGrip=function(e){let t=C[e];return t===void 0&&(t=new In,C[e]=t),t.getGripSpace()},this.getHand=function(e){let t=C[e];return t===void 0&&(t=new In,C[e]=t),t.getHandSpace()};function re(e){let t=D.indexOf(e.inputSource);if(t===-1)return;let n=C[t];n!==void 0&&(n.update(e.inputSource,e.frame,c||a),n.dispatchEvent({type:e.type,data:e.inputSource}))}function ie(){r.removeEventListener(`select`,re),r.removeEventListener(`selectstart`,re),r.removeEventListener(`selectend`,re),r.removeEventListener(`squeeze`,re),r.removeEventListener(`squeezestart`,re),r.removeEventListener(`squeezeend`,re),r.removeEventListener(`end`,ie),r.removeEventListener(`inputsourceschange`,ae);for(let e=0;e<C.length;e++){let t=D[e];t!==null&&(D[e]=null,C[e].disconnect(t))}ne=null,N=null,_.reset();for(let e in v)delete v[e];if(e.setRenderTarget(x),p=null,f=null,d=null,r=null,S=null,ue.stop(),n.isPresenting=!1,e.setPixelRatio(k),e.setSize(O.width,O.height,!1),A!==null){let e=A.camera;e.fov=A.fov,e.zoom=A.zoom,e.updateProjectionMatrix(),A=null}n.dispatchEvent({type:`sessionend`})}this.setFramebufferScaleFactor=function(e){i=e,n.isPresenting===!0&&tt(`WebXRManager: Cannot change framebuffer scale while presenting.`)},this.setReferenceSpaceType=function(e){o=e,n.isPresenting===!0&&tt(`WebXRManager: Cannot change reference space type while presenting.`)},this.getReferenceSpace=function(){return c||a},this.setReferenceSpace=function(e){c=e},this.getBaseLayer=function(){return f===null?p:f},this.getBinding=function(){return d===null&&g&&(d=new XRWebGLBinding(r,t)),d},this.getFrame=function(){return h},this.getSession=function(){return r},this.setSession=async function(u){if(r=u,r!==null){if(x=e.getRenderTarget(),r.addEventListener(`select`,re),r.addEventListener(`selectstart`,re),r.addEventListener(`selectend`,re),r.addEventListener(`squeeze`,re),r.addEventListener(`squeezestart`,re),r.addEventListener(`squeezeend`,re),r.addEventListener(`end`,ie),r.addEventListener(`inputsourceschange`,ae),b.xrCompatible!==!0&&await t.makeXRCompatible(),k=e.getPixelRatio(),e.getSize(O),g&&`createProjectionLayer`in XRWebGLBinding.prototype){let n=null,a=null,o=null;b.depth&&(o=b.stencil?t.DEPTH24_STENCIL8:t.DEPTH_COMPONENT24,n=b.stencil?E:T,a=b.stencil?y:m);let s={colorFormat:t.RGBA8,depthFormat:o,scaleFactor:i};d=this.getBinding(),f=d.createProjectionLayer(s),r.updateRenderState({layers:[f]}),e.setPixelRatio(1),e.setSize(f.textureWidth,f.textureHeight,!1),S=new nn(f.textureWidth,f.textureHeight,{format:w,type:l,depthTexture:new qi(f.textureWidth,f.textureHeight,a,void 0,void 0,void 0,void 0,void 0,void 0,n),stencilBuffer:b.stencil,colorSpace:e.outputColorSpace,samples:b.antialias?4:0,resolveDepthBuffer:f.ignoreDepthValues===!1,resolveStencilBuffer:f.ignoreDepthValues===!1,storeMultisampledDepthBuffer:f.ignoreDepthValues===!1,storeMultisampledStencilBuffer:f.ignoreDepthValues===!1})}else{let n={antialias:b.antialias,alpha:!0,depth:b.depth,stencil:b.stencil,framebufferScaleFactor:i};p=new XRWebGLLayer(r,t,n),r.updateRenderState({baseLayer:p}),e.setPixelRatio(1),e.setSize(p.framebufferWidth,p.framebufferHeight,!1),S=new nn(p.framebufferWidth,p.framebufferHeight,{format:w,type:l,colorSpace:e.outputColorSpace,stencilBuffer:b.stencil,resolveDepthBuffer:p.ignoreDepthValues===!1,resolveStencilBuffer:p.ignoreDepthValues===!1,storeMultisampledDepthBuffer:p.ignoreDepthValues===!1,storeMultisampledStencilBuffer:p.ignoreDepthValues===!1})}S.isXRRenderTarget=!0,this.setFoveation(s),c=null,a=await r.requestReferenceSpace(o),ue.setContext(r),ue.start(),n.isPresenting=!0,n.dispatchEvent({type:`sessionstart`})}},this.getEnvironmentBlendMode=function(){if(r!==null)return r.environmentBlendMode},this.getDepthTexture=function(){return _.getDepthTexture()};function ae(e){for(let t=0;t<e.removed.length;t++){let n=e.removed[t],r=D.indexOf(n);r>=0&&(D[r]=null,C[r].disconnect(n))}for(let t=0;t<e.added.length;t++){let n=e.added[t],r=D.indexOf(n);if(r===-1){for(let e=0;e<C.length;e++)if(e>=D.length){D.push(n),r=e;break}else if(D[e]===null){D[e]=n,r=e;break}if(r===-1)break}let i=C[r];i&&i.connect(n)}}function oe(e,t){t===null?e.matrixWorld.copy(e.matrix):e.matrixWorld.multiplyMatrices(t.matrixWorld,e.matrix),e.matrixWorldInverse.copy(e.matrixWorld).invert()}this.updateCamera=function(e){if(r===null)return;let t=e.near,n=e.far;_.texture!==null&&(_.depthNear>0&&(t=_.depthNear),_.depthFar>0&&(n=_.depthFar)),M.near=j.near=ee.near=t,M.far=j.far=ee.far=n,(ne!==M.near||N!==M.far)&&(r.updateRenderState({depthNear:M.near,depthFar:M.far}),ne=M.near,N=M.far),M.layers.mask=e.layers.mask|6,ee.layers.mask=M.layers.mask&-5,j.layers.mask=M.layers.mask&-3;let i=e.parent,a=M.cameras;oe(M,i);for(let e=0;e<a.length;e++)oe(a[e],i);M.projectionMatrix.copy(ee.projectionMatrix),M.projectionMatrixInverse.copy(ee.projectionMatrixInverse),A===null&&e.isPerspectiveCamera&&(A={camera:e,fov:e.fov,zoom:e.zoom}),se(e,M,i)};function se(e,t,n){n===null?e.matrix.copy(t.matrixWorld):(e.matrix.copy(n.matrixWorld),e.matrix.invert(),e.matrix.multiply(t.matrixWorld)),e.matrix.decompose(e.position,e.quaternion,e.scale),e.updateMatrixWorld(!0),e.projectionMatrix.copy(t.projectionMatrix),e.projectionMatrixInverse.copy(t.projectionMatrixInverse),e.isPerspectiveCamera&&(e.fov=ut*2*Math.atan(1/e.projectionMatrix.elements[5]),e.zoom=1)}this.getCamera=function(){return M},this.getFoveation=function(){if(f!==null||p!==null)return s},this.setFoveation=function(e){s=e,f!==null&&(f.fixedFoveation=e),p!==null&&p.fixedFoveation!==void 0&&(p.fixedFoveation=e)},this.hasDepthSensing=function(){return _.texture!==null},this.getDepthSensingMesh=function(){return _.getMesh(M)},this.getCameraTexture=function(e){return v[e]};let ce=null;function le(t,i){if(u=i.getViewerPose(c||a),h=i,u!==null){let t=u.views;p!==null&&(e.setRenderTargetFramebuffer(S,p.framebuffer),e.setRenderTarget(S));let i=!1;t.length!==M.cameras.length&&(M.cameras.length=0,i=!0);for(let n=0;n<t.length;n++){let r=t[n],a=null;if(p!==null)a=p.getViewport(r);else{let t=d.getViewSubImage(f,r);a=t.viewport,n===0&&(e.setRenderTargetTextures(S,t.colorTexture,t.depthStencilTexture),e.setRenderTarget(S))}let o=te[n];o===void 0&&(o=new ys,o.layers.enable(n),o.viewport=new en,te[n]=o),o.matrix.fromArray(r.transform.matrix),o.matrix.decompose(o.position,o.quaternion,o.scale),o.projectionMatrix.fromArray(r.projectionMatrix),o.projectionMatrixInverse.copy(o.projectionMatrix).invert(),o.viewport.set(a.x,a.y,a.width,a.height),n===0&&(M.matrix.copy(o.matrix),M.matrix.decompose(M.position,M.quaternion,M.scale)),i===!0&&M.cameras.push(o)}let a=r.enabledFeatures;if(a&&a.includes(`depth-sensing`)&&r.depthUsage==`gpu-optimized`&&g){d=n.getBinding();let e=d.getDepthInformation(t[0]);e&&e.isValid&&e.texture&&_.init(e,r.renderState)}if(a&&a.includes(`camera-access`)&&g){e.state.unbindTexture(),d=n.getBinding();for(let e=0;e<t.length;e++){let n=t[e].camera;if(n){let e=v[n];e||(e=new Yi,v[n]=e);let t=d.getCameraImage(n);e.sourceTexture=t}}}}for(let e=0;e<C.length;e++){let t=D[e],n=C[e];t!==null&&n!==void 0&&n.update(t,i,c||a)}ce&&ce(t,i),i.detectedPlanes&&n.dispatchEvent({type:`planesdetected`,data:i}),h=null}let ue=new Xs;ue.setAnimationLoop(le),this.setAnimationLoop=function(e){ce=e},this.dispose=function(){}}},$u=new on,ed=new Rt;ed.set(-1,0,0,0,1,0,0,0,1);function td(e,t){function n(e,t){e.matrixAutoUpdate===!0&&e.updateMatrix(),t.value.copy(e.matrix)}function r(t,n){n.color.getRGB(t.fogColor.value,Ao(e)),n.isFog?(t.fogNear.value=n.near,t.fogFar.value=n.far):n.isFogExp2&&(t.fogDensity.value=n.density)}function i(e,t,n,r,i){t.isNodeMaterial?t.uniformsNeedUpdate=!1:t.isMeshBasicMaterial?a(e,t):t.isMeshLambertMaterial?(a(e,t),t.envMap&&(e.envMapIntensity.value=t.envMapIntensity)):t.isMeshToonMaterial?(a(e,t),d(e,t)):t.isMeshPhongMaterial?(a(e,t),u(e,t),t.envMap&&(e.envMapIntensity.value=t.envMapIntensity)):t.isMeshStandardMaterial?(a(e,t),f(e,t),t.isMeshPhysicalMaterial&&p(e,t,i)):t.isMeshMatcapMaterial?(a(e,t),m(e,t)):t.isMeshDepthMaterial?a(e,t):t.isMeshDistanceMaterial?(a(e,t),h(e,t)):t.isMeshNormalMaterial?a(e,t):t.isLineBasicMaterial?(o(e,t),t.isLineDashedMaterial&&s(e,t)):t.isPointsMaterial?c(e,t,n,r):t.isSpriteMaterial?l(e,t):t.isShadowMaterial?(e.color.value.copy(t.color),e.opacity.value=t.opacity):t.isShaderMaterial&&(t.uniformsNeedUpdate=!1)}function a(e,r){e.opacity.value=r.opacity,r.color&&e.diffuse.value.copy(r.color),r.emissive&&e.emissive.value.copy(r.emissive).multiplyScalar(r.emissiveIntensity),r.map&&(e.map.value=r.map,n(r.map,e.mapTransform)),r.alphaMap&&(e.alphaMap.value=r.alphaMap,n(r.alphaMap,e.alphaMapTransform)),r.bumpMap&&(e.bumpMap.value=r.bumpMap,n(r.bumpMap,e.bumpMapTransform),e.bumpScale.value=r.bumpScale,r.side===1&&(e.bumpScale.value*=-1)),r.normalMap&&(e.normalMap.value=r.normalMap,n(r.normalMap,e.normalMapTransform),e.normalScale.value.copy(r.normalScale),r.side===1&&e.normalScale.value.negate()),r.displacementMap&&(e.displacementMap.value=r.displacementMap,n(r.displacementMap,e.displacementMapTransform),e.displacementScale.value=r.displacementScale,e.displacementBias.value=r.displacementBias),r.emissiveMap&&(e.emissiveMap.value=r.emissiveMap,n(r.emissiveMap,e.emissiveMapTransform)),r.specularMap&&(e.specularMap.value=r.specularMap,n(r.specularMap,e.specularMapTransform)),r.alphaTest>0&&(e.alphaTest.value=r.alphaTest);let i=t.get(r),a=i.envMap,o=i.envMapRotation;a&&(e.envMap.value=a,e.envMapRotation.value.setFromMatrix4($u.makeRotationFromEuler(o)).transpose(),a.isCubeTexture&&a.isRenderTargetTexture===!1&&e.envMapRotation.value.premultiply(ed),e.reflectivity.value=r.reflectivity,e.ior.value=r.ior,e.refractionRatio.value=r.refractionRatio),r.lightMap&&(e.lightMap.value=r.lightMap,e.lightMapIntensity.value=r.lightMapIntensity,n(r.lightMap,e.lightMapTransform)),r.aoMap&&(e.aoMap.value=r.aoMap,e.aoMapIntensity.value=r.aoMapIntensity,n(r.aoMap,e.aoMapTransform))}function o(e,t){e.diffuse.value.copy(t.color),e.opacity.value=t.opacity,t.map&&(e.map.value=t.map,n(t.map,e.mapTransform))}function s(e,t){e.dashSize.value=t.dashSize,e.totalSize.value=t.dashSize+t.gapSize,e.scale.value=t.scale}function c(e,t,r,i){e.diffuse.value.copy(t.color),e.opacity.value=t.opacity,e.size.value=t.size*r,e.scale.value=i*.5,t.map&&(e.map.value=t.map,n(t.map,e.uvTransform)),t.alphaMap&&(e.alphaMap.value=t.alphaMap,n(t.alphaMap,e.alphaMapTransform)),t.alphaTest>0&&(e.alphaTest.value=t.alphaTest)}function l(e,t){e.diffuse.value.copy(t.color),e.opacity.value=t.opacity,e.rotation.value=t.rotation,t.map&&(e.map.value=t.map,n(t.map,e.mapTransform)),t.alphaMap&&(e.alphaMap.value=t.alphaMap,n(t.alphaMap,e.alphaMapTransform)),t.alphaTest>0&&(e.alphaTest.value=t.alphaTest)}function u(e,t){e.specular.value.copy(t.specular),e.shininess.value=Math.max(t.shininess,1e-4)}function d(e,t){t.gradientMap&&(e.gradientMap.value=t.gradientMap)}function f(e,t){e.metalness.value=t.metalness,t.metalnessMap&&(e.metalnessMap.value=t.metalnessMap,n(t.metalnessMap,e.metalnessMapTransform)),e.roughness.value=t.roughness,t.roughnessMap&&(e.roughnessMap.value=t.roughnessMap,n(t.roughnessMap,e.roughnessMapTransform)),t.envMap&&(e.envMapIntensity.value=t.envMapIntensity)}function p(e,t,r){e.ior.value=t.ior,t.diffuseRoughness>0&&(e.diffuseRoughness.value=t.diffuseRoughness,t.diffuseRoughnessMap&&(e.diffuseRoughnessMap.value=t.diffuseRoughnessMap,n(t.diffuseRoughnessMap,e.diffuseRoughnessMapTransform))),t.sheen>0&&(e.sheenColor.value.copy(t.sheenColor).multiplyScalar(t.sheen),e.sheenRoughness.value=t.sheenRoughness,t.sheenColorMap&&(e.sheenColorMap.value=t.sheenColorMap,n(t.sheenColorMap,e.sheenColorMapTransform)),t.sheenRoughnessMap&&(e.sheenRoughnessMap.value=t.sheenRoughnessMap,n(t.sheenRoughnessMap,e.sheenRoughnessMapTransform))),t.clearcoat>0&&(e.clearcoat.value=t.clearcoat,e.clearcoatRoughness.value=t.clearcoatRoughness,t.clearcoatMap&&(e.clearcoatMap.value=t.clearcoatMap,n(t.clearcoatMap,e.clearcoatMapTransform)),t.clearcoatRoughnessMap&&(e.clearcoatRoughnessMap.value=t.clearcoatRoughnessMap,n(t.clearcoatRoughnessMap,e.clearcoatRoughnessMapTransform)),t.clearcoatNormalMap&&(e.clearcoatNormalMap.value=t.clearcoatNormalMap,n(t.clearcoatNormalMap,e.clearcoatNormalMapTransform),e.clearcoatNormalScale.value.copy(t.clearcoatNormalScale),t.side===1&&e.clearcoatNormalScale.value.negate())),t.dispersion>0&&(e.dispersion.value=t.dispersion),t.retroreflectivity>0&&(e.retroreflectivity.value=t.retroreflectivity),t.iridescence>0&&(e.iridescence.value=t.iridescence,e.iridescenceIOR.value=t.iridescenceIOR,e.iridescenceThicknessMinimum.value=t.iridescenceThicknessMinimum,e.iridescenceThicknessMaximum.value=t.iridescenceThicknessMaximum,t.iridescenceMap&&(e.iridescenceMap.value=t.iridescenceMap,n(t.iridescenceMap,e.iridescenceMapTransform)),t.iridescenceThicknessMap&&(e.iridescenceThicknessMap.value=t.iridescenceThicknessMap,n(t.iridescenceThicknessMap,e.iridescenceThicknessMapTransform))),t.transmission>0&&(e.transmission.value=t.transmission,e.transmissionSamplerMap.value=r.texture,e.transmissionSamplerSize.value.set(r.width,r.height),t.transmissionMap&&(e.transmissionMap.value=t.transmissionMap,n(t.transmissionMap,e.transmissionMapTransform)),e.thickness.value=t.thickness,t.thicknessMap&&(e.thicknessMap.value=t.thicknessMap,n(t.thicknessMap,e.thicknessMapTransform)),e.attenuationDistance.value=t.attenuationDistance,e.attenuationColor.value.copy(t.attenuationColor)),t.anisotropy>0&&(e.anisotropyVector.value.set(t.anisotropy*Math.cos(t.anisotropyRotation),t.anisotropy*Math.sin(t.anisotropyRotation)),t.anisotropyMap&&(e.anisotropyMap.value=t.anisotropyMap,n(t.anisotropyMap,e.anisotropyMapTransform))),e.specularIntensity.value=t.specularIntensity,e.specularColor.value.copy(t.specularColor),t.specularColorMap&&(e.specularColorMap.value=t.specularColorMap,n(t.specularColorMap,e.specularColorMapTransform)),t.specularIntensityMap&&(e.specularIntensityMap.value=t.specularIntensityMap,n(t.specularIntensityMap,e.specularIntensityMapTransform))}function m(e,t){t.matcap&&(e.matcap.value=t.matcap)}function h(e,n){let r=t.get(n).light;e.referencePosition.value.setFromMatrixPosition(r.matrixWorld),e.nearDistance.value=r.shadow.camera.near,e.farDistance.value=r.shadow.camera.far}return{refreshFogUniforms:r,refreshMaterialUniforms:i}}function nd(e,t,n,r){let i={},a={};function o(e,t){let n=t.program;r.uniformBlockBinding(e,n,i[e.id])}function s(e,n){let o=i[e.id];o===void 0&&(m(e),o=c(e),i[e.id]=o,e.addEventListener(`dispose`,g));let s=n.program;r.updateUBOMapping(e,s);let u=t.render.frame;a[e.id]!==u&&(l(e),a[e.id]=u)}function c(t){let n=e.createBuffer(),r=t.__size,i=t.usage;return e.bindBuffer(e.UNIFORM_BUFFER,n),e.bufferData(e.UNIFORM_BUFFER,r,i),e.bindBuffer(e.UNIFORM_BUFFER,null),n}function l(t){let n=i[t.id],r=t.uniforms,a=t.__cache;e.bindBuffer(e.UNIFORM_BUFFER,n);for(let e=0,t=r.length;e<t;e++){let t=r[e];if(Array.isArray(t))for(let n=0,r=t.length;n<r;n++)u(t[n],e,n,a);else u(t,e,0,a)}e.bindBuffer(e.UNIFORM_BUFFER,null)}function u(t,n,r,i){if(f(t,n,r,i)===!0){let n=t.__offset,r=t.value;if(Array.isArray(r)){let e=0;for(let n=0;n<r.length;n++){let i=r[n],a=h(i,!0);d(i,t.__data,e),e+=a.storage/Float32Array.BYTES_PER_ELEMENT}}else d(r,t.__data,0);e.bufferSubData(e.UNIFORM_BUFFER,n,t.__data)}}function d(e,t,n){typeof e==`number`||typeof e==`boolean`?t[n]=e:e.isMatrix3?(t[n]=e.elements[0],t[n+1]=e.elements[1],t[n+2]=e.elements[2],t[n+3]=0,t[n+4]=e.elements[3],t[n+5]=e.elements[4],t[n+6]=e.elements[5],t[n+7]=0,t[n+8]=e.elements[6],t[n+9]=e.elements[7],t[n+10]=e.elements[8],t[n+11]=0):ArrayBuffer.isView(e)?t.set(e.subarray(0,t.length-n),n):e.toArray(t,n)}function f(e,t,n,r){let i=e.value,a=t+`_`+n;if(Array.isArray(i)){r[a]===void 0&&(r[a]=[]);let e=r[a],t=!1;for(let n=0;n<i.length;n++)p(i[n],e,n)===!0&&(t=!0);return t}return p(i,r,a)}function p(e,t,n){if(t[n]===void 0)return t[n]=typeof e==`number`||typeof e==`boolean`?e:ArrayBuffer.isView(e)?e.slice():e.clone(),!0;{let r=t[n];if(typeof e==`number`||typeof e==`boolean`){if(r!==e)return t[n]=e,!0}else if(ArrayBuffer.isView(e))return!0;else if(r.equals(e)===!1)return r.copy(e),!0}return!1}function m(e){let t=e.uniforms,n=0;for(let e=0,r=t.length;e<r;e++){let r=Array.isArray(t[e])?t[e]:[t[e]];for(let i=0,a=r.length;i<a;i++){let a=r[i],o=Array.isArray(a.value)?a.value:[a.value],s=Array.isArray(t[e])||Array.isArray(a.value),c=n;for(let e=0,t=o.length;e<t;e++){let t=o[e],r=h(t,s),i=n%16,a=i%r.boundary,l=i+a;n+=a,l!==0&&16-l<r.storage&&(n+=16-l),e===0&&(c=n),n+=r.storage}a.__data=new(a.type===`int`?Int32Array:a.type===`uint`?Uint32Array:Float32Array)((n-c)/Float32Array.BYTES_PER_ELEMENT),a.__offset=c}}let r=n%16;return r>0&&(n+=16-r),e.__size=n,e.__cache={},this}function h(e,t){let n={boundary:0,storage:0};return typeof e==`number`||typeof e==`boolean`?(n.boundary=4,n.storage=4):e.isVector2?(n.boundary=8,n.storage=8):e.isVector3||e.isColor?(n.boundary=16,n.storage=12):e.isVector4?(n.boundary=16,n.storage=16):e.isMatrix3?(n.boundary=16,n.storage=48):e.isMatrix4?(n.boundary=16,n.storage=64):e.isTexture?tt(`WebGLRenderer: Texture samplers can not be part of an uniforms group.`):ArrayBuffer.isView(e)?(n.boundary=16,n.storage=e.byteLength):tt(`WebGLRenderer: Unsupported uniform value type.`,e),t===!0&&(n.boundary=16,n.storage=Math.ceil(n.storage/16)*16),n}function g(t){let n=t.target;n.removeEventListener(`dispose`,g),e.deleteBuffer(i[n.id]),delete i[n.id],delete a[n.id]}function _(){for(let t in i)e.deleteBuffer(i[t]);i={},a={}}return{bind:o,update:s,dispose:_}}var rd=new Uint16Array([12469,15057,12620,14925,13266,14620,13807,14376,14323,13990,14545,13625,14713,13328,14840,12882,14931,12528,14996,12233,15039,11829,15066,11525,15080,11295,15085,10976,15082,10705,15073,10495,13880,14564,13898,14542,13977,14430,14158,14124,14393,13732,14556,13410,14702,12996,14814,12596,14891,12291,14937,11834,14957,11489,14958,11194,14943,10803,14921,10506,14893,10278,14858,9960,14484,14039,14487,14025,14499,13941,14524,13740,14574,13468,14654,13106,14743,12678,14818,12344,14867,11893,14889,11509,14893,11180,14881,10751,14852,10428,14812,10128,14765,9754,14712,9466,14764,13480,14764,13475,14766,13440,14766,13347,14769,13070,14786,12713,14816,12387,14844,11957,14860,11549,14868,11215,14855,10751,14825,10403,14782,10044,14729,9651,14666,9352,14599,9029,14967,12835,14966,12831,14963,12804,14954,12723,14936,12564,14917,12347,14900,11958,14886,11569,14878,11247,14859,10765,14828,10401,14784,10011,14727,9600,14660,9289,14586,8893,14508,8533,15111,12234,15110,12234,15104,12216,15092,12156,15067,12010,15028,11776,14981,11500,14942,11205,14902,10752,14861,10393,14812,9991,14752,9570,14682,9252,14603,8808,14519,8445,14431,8145,15209,11449,15208,11451,15202,11451,15190,11438,15163,11384,15117,11274,15055,10979,14994,10648,14932,10343,14871,9936,14803,9532,14729,9218,14645,8742,14556,8381,14461,8020,14365,7603,15273,10603,15272,10607,15267,10619,15256,10631,15231,10614,15182,10535,15118,10389,15042,10167,14963,9787,14883,9447,14800,9115,14710,8665,14615,8318,14514,7911,14411,7507,14279,7198,15314,9675,15313,9683,15309,9712,15298,9759,15277,9797,15229,9773,15166,9668,15084,9487,14995,9274,14898,8910,14800,8539,14697,8234,14590,7790,14479,7409,14367,7067,14178,6621,15337,8619,15337,8631,15333,8677,15325,8769,15305,8871,15264,8940,15202,8909,15119,8775,15022,8565,14916,8328,14804,8009,14688,7614,14569,7287,14448,6888,14321,6483,14088,6171,15350,7402,15350,7419,15347,7480,15340,7613,15322,7804,15287,7973,15229,8057,15148,8012,15046,7846,14933,7611,14810,7357,14682,7069,14552,6656,14421,6316,14251,5948,14007,5528,15356,5942,15356,5977,15353,6119,15348,6294,15332,6551,15302,6824,15249,7044,15171,7122,15070,7050,14949,6861,14818,6611,14679,6349,14538,6067,14398,5651,14189,5311,13935,4958,15359,4123,15359,4153,15356,4296,15353,4646,15338,5160,15311,5508,15263,5829,15188,6042,15088,6094,14966,6001,14826,5796,14678,5543,14527,5287,14377,4985,14133,4586,13869,4257,15360,1563,15360,1642,15358,2076,15354,2636,15341,3350,15317,4019,15273,4429,15203,4732,15105,4911,14981,4932,14836,4818,14679,4621,14517,4386,14359,4156,14083,3795,13808,3437,15360,122,15360,137,15358,285,15355,636,15344,1274,15322,2177,15281,2765,15215,3223,15120,3451,14995,3569,14846,3567,14681,3466,14511,3305,14344,3121,14037,2800,13753,2467,15360,0,15360,1,15359,21,15355,89,15346,253,15325,479,15287,796,15225,1148,15133,1492,15008,1749,14856,1882,14685,1886,14506,1783,14324,1608,13996,1398,13702,1183]),id=null;function ad(){return id===null&&(id=new li(rd,16,16,k,g),id.name=`DFG_LUT`,id.minFilter=o,id.magFilter=o,id.wrapS=t,id.wrapT=t,id.generateMipmaps=!1,id.needsUpdate=!0),id}var od=class{constructor(e={}){let{canvas:t=Ze(),context:n=null,depth:r=!0,stencil:i=!1,alpha:a=!1,antialias:o=!1,premultipliedAlpha:s=!0,preserveDrawingBuffer:u=!1,powerPreference:d=`default`,failIfMajorPerformanceCaveat:p=!1,reversedDepthBuffer:h=!1,outputBufferType:b=l}=e;this.isWebGLRenderer=!0;let x;if(n!==null){if(typeof WebGLRenderingContext<`u`&&n instanceof WebGLRenderingContext)throw Error(`THREE.WebGLRenderer: WebGL 1 is not supported since r163.`);x=n.getContextAttributes().alpha}else x=a;let S=b,C=new Set([ee,A,O]),w=new Set([l,m,f,y,_,v]),T=new Uint32Array(4),E=new Int32Array(4),D={textures:[],min:[],max:[],resolution:[]},k=null,j=null,te=[],M=[],ne=null;this.domElement=t,this.debug={checkShaderErrors:!0,diagnostics:{keywords:!1},onShaderError:null},this.autoClear=!0,this.autoClearColor=!0,this.autoClearDepth=!0,this.autoClearStencil=!0,this.sortObjects=!0,this.clippingPlanes=[],this.localClippingEnabled=!1,this.toneMapping=0,this.toneMappingExposure=1,this.transmissionResolutionScale=1;let N=this,re=!1,ie=null,ae=null,oe=null,se=null;this._outputColorSpace=Be;let ce=0,le=0,ue=null,de=-1,fe=null,pe=new en,me=new en,he=null,ge=new R(0),_e=0,ve=t.width,ye=t.height,be=1,xe=null,Se=null,Ce=new en(0,0,ve,ye),we=new en(0,0,ve,ye),Te=!1,Ee=new Si,De=new wi,Oe=!1,ke=!1,Ae=new on,je=new L,Me=new en,Ne={background:null,fog:null,environment:null,overrideMaterial:null,isScene:!0},Pe=!1;function Fe(){return ue===null?be:1}let P=n;function Ie(e,n){return t.getContext(e,n)}let Le,Re,F,ze,Ve,He,Ue,We,Ge,Ke,Je,Ye,Xe,Qe,et,rt,at,ot,st,ct,lt,ut,dt;try{let e={alpha:!0,depth:r,stencil:i,antialias:o,premultipliedAlpha:s,preserveDrawingBuffer:u,powerPreference:d,failIfMajorPerformanceCaveat:p};if(`setAttribute`in t&&t.setAttribute(`data-engine`,`three.js r187`),t.addEventListener(`webglcontextlost`,mt,!1),t.addEventListener(`webglcontextrestored`,ht,!1),t.addEventListener(`webglcontextcreationerror`,gt,!1),P===null){let t=`webgl2`;if(P=Ie(t,e),P===null)throw Ie(t)?Error(`THREE.WebGLRenderer: Error creating WebGL context with your selected attributes.`):Error(`THREE.WebGLRenderer: Error creating WebGL context.`)}ft()}catch(e){throw t.removeEventListener(`webglcontextlost`,mt,!1),t.removeEventListener(`webglcontextrestored`,ht,!1),t.removeEventListener(`webglcontextcreationerror`,gt,!1),nt(`WebGLRenderer: `+e.message),e}function ft(){Le=new Ec(P),Le.init(),lt=new Ju(P,Le),Re=new oc(P,Le,e,lt),F=new Ku(P,Le),Re.reversedDepthBuffer&&h&&F.buffers.depth.setReversed(!0),ae=P.createFramebuffer(),oe=P.createFramebuffer(),se=P.createFramebuffer(),ze=new kc(P),Ve=new Eu,He=new qu(P,Le,F,Ve,Re,lt,ze),Ue=new Tc(N),We=new Zs(P),ut=new ic(P,We),Ge=new Dc(P,We,ze,ut),Ke=new jc(P,Ge,We,ut,ze),ot=new Ac(P,Re,He),et=new sc(Ve),Je=new Tu(N,Ue,Le,Re,ut,et),Ye=new td(N,Ve),Xe=new Au,Qe=new Lu(Le),at=new rc(N,Ue,F,Ke,x,s),rt=new Gu(N,Ke,Re),dt=new nd(P,ze,Re,F),st=new ac(P,Le,ze),ct=new Oc(P,Le,ze),ze.programs=Je.programs,N.capabilities=Re,N.extensions=Le,N.properties=Ve,N.renderLists=Xe,N.shadowMap=rt,N.state=F,N.info=ze}S!==1009&&(ne=new Nc(S,t.width,t.height,o,r,i));let pt=new Qu(N,P);this.xr=pt,this.getContext=function(){return P},this.getContextAttributes=function(){return P.getContextAttributes()},this.forceContextLoss=function(){let e=Le.get(`WEBGL_lose_context`);e&&e.loseContext()},this.forceContextRestore=function(){let e=Le.get(`WEBGL_lose_context`);e&&e.restoreContext()},this.getPixelRatio=function(){return be},this.setPixelRatio=function(e){e!==void 0&&(be=e,this.setSize(ve,ye,!1))},this.getSize=function(e){return e.set(ve,ye)},this.setSize=function(e,n,r=!0){pt.isPresenting?tt(`WebGLRenderer: Can't change size while VR device is presenting.`):(ve=e,ye=n,t.width=Math.floor(e*be),t.height=Math.floor(n*be),r===!0&&(t.style.width=e+`px`,t.style.height=n+`px`),ne!==null&&ne.setSize(t.width,t.height),this.setViewport(0,0,e,n))},this.getDrawingBufferSize=function(e){return e.set(ve*be,ye*be).floor()},this.setDrawingBufferSize=function(e,n,r){ve=e,ye=n,be=r,t.width=Math.floor(e*r),t.height=Math.floor(n*r),this.setViewport(0,0,e,n)},this.setEffects=function(e){if(S===1009)nt(`WebGLRenderer: setEffects() requires outputBufferType set to HalfFloatType or FloatType.`);else{if(e){for(let t=0;t<e.length;t++)if(e[t].isOutputPass===!0){tt(`WebGLRenderer: OutputPass is not needed in setEffects(). Tone mapping and color space conversion are applied automatically.`);break}}ne.setEffects(e||[])}},this.getCurrentViewport=function(e){return e.copy(pe)},this.getViewport=function(e){return e.copy(Ce)},this.setViewport=function(e,t,n,r){e.isVector4?Ce.set(e.x,e.y,e.z,e.w):Ce.set(e,t,n,r),F.viewport(pe.copy(Ce).multiplyScalar(Fe()).round())},this.getScissor=function(e){return e.copy(we)},this.setScissor=function(e,t,n,r){e.isVector4?we.set(e.x,e.y,e.z,e.w):we.set(e,t,n,r),F.scissor(me.copy(we).multiplyScalar(Fe()).round())},this.getScissorTest=function(){return Te},this.setScissorTest=function(e){F.setScissorTest(Te=e)},this.setOpaqueSort=function(e){xe=e},this.setTransparentSort=function(e){Se=e},this.getClearColor=function(e){return e.copy(at.getClearColor())},this.setClearColor=function(){at.setClearColor(...arguments)},this.getClearAlpha=function(){return at.getClearAlpha()},this.setClearAlpha=function(){at.setClearAlpha(...arguments)},this.clear=function(e=!0,t=!0,n=!0){let r=0;if(e){let e=!1;if(ue!==null){let t=ue.texture.format;e=C.has(t)}if(e){let e=ue.texture.type,t=w.has(e),n=at.getClearColor(),r=at.getClearAlpha(),i=n.r,a=n.g,o=n.b;t?(T[0]=i,T[1]=a,T[2]=o,T[3]=r,P.clearBufferuiv(P.COLOR,0,T)):(E[0]=i,E[1]=a,E[2]=o,E[3]=r,P.clearBufferiv(P.COLOR,0,E))}else r|=P.COLOR_BUFFER_BIT}t&&(r|=P.DEPTH_BUFFER_BIT,this.state.buffers.depth.setMask(!0)),n&&(r|=P.STENCIL_BUFFER_BIT,this.state.buffers.stencil.setMask(4294967295)),r!==0&&P.clear(r)},this.clearColor=function(){this.clear(!0,!1,!1)},this.clearDepth=function(){this.clear(!1,!0,!1)},this.clearStencil=function(){this.clear(!1,!1,!0)},this.setNodesHandler=function(e){e.setRenderer(this),ie=e},this.dispose=function(){t.removeEventListener(`webglcontextlost`,mt,!1),t.removeEventListener(`webglcontextrestored`,ht,!1),t.removeEventListener(`webglcontextcreationerror`,gt,!1),at.dispose(),Xe.dispose(),Qe.dispose(),He.dispose(),Ve.dispose(),Ue.dispose(),Ke.dispose(),Ge.dispose(),ut.dispose(),dt.dispose(),Je.dispose(),pt.dispose(),pt.removeEventListener(`sessionstart`,Ct),pt.removeEventListener(`sessionend`,wt),Tt.stop()};function mt(e){e.preventDefault(),$e(`WebGLRenderer: Context Lost.`),re=!0}function ht(){$e(`WebGLRenderer: Context Restored.`),re=!1;let e=ze.autoReset,t=rt.enabled,n=rt.autoUpdate,r=rt.needsUpdate,i=rt.type;ft(),ze.autoReset=e,rt.enabled=t,rt.autoUpdate=n,rt.needsUpdate=r,rt.type=i}function gt(e){nt(`WebGLRenderer: A WebGL context could not be created. Reason: `,e.statusMessage)}function _t(e){let t=e.target;t.removeEventListener(`dispose`,_t),vt(t)}function vt(e){yt(e),Ve.remove(e)}function yt(e){let t=Ve.get(e).programs;t!==void 0&&(t.forEach(function(e){Je.releaseProgram(e)}),e.isShaderMaterial&&Je.releaseShaderCache(e))}this.renderBufferDirect=function(e,t,n,r,i,a){t===null&&(t=Ne);let o=i.isMesh&&i.matrixWorld.determinantAffine()<0,s=Ft(e,t,n,r,i);F.setMaterial(r,o);let c=n.index,l=1;if(r.wireframe===!0){if(c=Ge.getWireframeAttribute(n),c===void 0)return;l=2}let u=n.drawRange,d=n.attributes.position,f=u.start*l,p=(u.start+u.count)*l;a!==null&&(f=Math.max(f,a.start*l),p=Math.min(p,(a.start+a.count)*l)),c===null?d!=null&&(f=Math.max(f,0),p=Math.min(p,d.count)):(f=Math.max(f,0),p=Math.min(p,c.count));let m=p-f;if(m<0||m===1/0)return;ut.setup(i,r,s,n,c);let h,g=st;if(c!==null&&(h=We.get(c),g=ct,g.setIndex(h)),i.isMesh)r.wireframe===!0?(F.setLineWidth(r.wireframeLinewidth*Fe()),g.setMode(P.LINES)):g.setMode(P.TRIANGLES);else if(i.isLine){let e=r.linewidth;e===void 0&&(e=1),F.setLineWidth(e*Fe()),i.isLineSegments?g.setMode(P.LINES):i.isLineLoop?g.setMode(P.LINE_LOOP):g.setMode(P.LINE_STRIP)}else i.isPoints?g.setMode(P.POINTS):i.isSprite&&g.setMode(P.TRIANGLES);if(i.isBatchedMesh){if(Le.get(`WEBGL_multi_draw`))g.renderMultiDraw(i._multiDrawStarts,i._multiDrawCounts,i._multiDrawCount);else{let e=i._multiDrawStarts,t=i._multiDrawCounts,n=i._multiDrawCount,a=c?We.get(c).bytesPerElement:1,o=Ve.get(r).currentProgram.getUniforms();for(let r=0;r<n;r++)o.setValue(P,`_gl_DrawID`,r),g.render(e[r]/a,t[r])}}else if(i.isInstancedMesh)g.renderInstances(f,m,i.count);else if(n.isInstancedBufferGeometry){let e=n._maxInstanceCount===void 0?1/0:n._maxInstanceCount,t=Math.min(n.instanceCount,e);g.renderInstances(f,m,t)}else g.render(f,m)};function bt(e,t,n,r){ie!==null&&e.isNodeMaterial&&ie.setObject(r,e),Oe===!0&&et.setState(e,n,!1),e.transparent===!0&&e.side===2&&e.forceSinglePass===!1?(e.side=1,e.needsUpdate=!0,Mt(e,t,r),e.side=0,e.needsUpdate=!0,Mt(e,t,r),e.side=2):Mt(e,t,r)}this.compile=function(e,t,n=null){n===null&&(n=e),ie!==null&&ie.renderStart(e,t,n),j=Qe.get(n),j.init(t),M.push(j),n.traverseVisible(function(e){e.isLight&&e.layers.test(t.layers)&&(j.pushLight(e),e.castShadow&&j.pushShadow(e))}),e!==n&&e.traverseVisible(function(e){e.isLight&&e.layers.test(t.layers)&&(j.pushLight(e),e.castShadow&&j.pushShadow(e))}),j.setupLights(),ie!==null&&ie.updateLights(j.state.lightsArray),ke=this.localClippingEnabled,Oe=et.init(this.clippingPlanes,ke),Oe===!0&&et.setGlobalState(this.clippingPlanes,t),ie!==null&&rt.render(j.state.shadowsArray,n,t);let r=new Set;return e.traverse(function(e){if(!(e.isMesh||e.isPoints||e.isLine||e.isSprite))return;let i=e.material;if(i){if(Array.isArray(i))for(let a=0;a<i.length;a++){let o=i[a];bt(o,n,t,e),r.add(o)}else bt(i,n,t,e),r.add(i)}}),j=M.pop(),ie!==null&&ie.renderEnd(),r},this.compileAsync=function(e,t,n=null){let r=this.compile(e,t,n);return new Promise(t=>{function n(){r.forEach(function(e){let t=Ve.get(e).currentProgram;(t===void 0||t.isReady())&&r.delete(e)}),r.size===0?t(e):setTimeout(n,10)}Le.get(`KHR_parallel_shader_compile`)===null?setTimeout(n,10):n()})};let xt=null;function St(e){xt&&xt(e)}function Ct(){Tt.stop()}function wt(){Tt.start()}let Tt=new Xs;Tt.setAnimationLoop(St),typeof self<`u`&&Tt.setContext(self),this.setAnimationLoop=function(e){xt=e,pt.setAnimationLoop(e),e===null?Tt.stop():Tt.start()},pt.addEventListener(`sessionstart`,Ct),pt.addEventListener(`sessionend`,wt),this.render=function(e,t){if(t!==void 0&&t.isCamera!==!0){nt(`WebGLRenderer.render: camera is not an instance of THREE.Camera.`);return}if(re===!0)return;ie!==null&&ie.renderStart(e,t);let n=pt.enabled===!0&&pt.isPresenting===!0,r=ne!==null&&(ue===null||n)&&ne.begin(N,ue);if(e.matrixWorldAutoUpdate===!0&&e.updateMatrixWorld(),t.parent===null&&t.matrixWorldAutoUpdate===!0&&t.updateMatrixWorld(),pt.enabled===!0&&pt.isPresenting===!0&&(ne===null||ne.isCompositing()===!1)&&(pt.cameraAutoUpdate===!0&&pt.updateCamera(t),t=pt.getCamera()),e.isScene===!0&&e.onBeforeRender(N,e,t,ue),j=Qe.get(e,M.length),j.init(t),j.state.textureUnits=He.getTextureUnits(),M.push(j),Ae.multiplyMatrices(t.projectionMatrix,t.matrixWorldInverse),t.isArrayCamera?De.setFromArrayCamera(t):Ee.setFromProjectionMatrix(Ae,qe,t.reversedDepth),ke=this.localClippingEnabled,Oe=et.init(this.clippingPlanes,ke),k=Xe.get(e,te.length),k.init(),te.push(k),this.info.render.frame++,pt.enabled===!0&&pt.isPresenting===!0){let e=N.xr.getDepthSensingMesh();e!==null&&Et(e,t,-1/0,N.sortObjects)}Et(e,t,0,N.sortObjects),k.finish(),ie!==null&&ie.updateLights(j.state.lightsArray),N.sortObjects===!0&&k.sort(xe,Se),Pe=pt.enabled===!1||pt.isPresenting===!1||pt.hasDepthSensing()===!1,Pe&&at.addToRenderList(k,e),this.info.autoReset===!0&&this.info.reset(),Oe===!0&&et.beginShadows();let i=j.state.shadowsArray;if(rt.render(i,e,t),Oe===!0&&et.endShadows(),(r&&ne.hasRenderPass())===!1){let n=k.opaque,r=k.transmissive;if(j.setupLights(),t.isArrayCamera){let i=t.cameras;if(r.length>0)for(let t=0,a=i.length;t<a;t++){let a=i[t];Ot(n,r,e,a)}Pe&&at.render(e);for(let t=0,n=i.length;t<n;t++){let n=i[t];Dt(k,e,n,n.viewport)}}else r.length>0&&Ot(n,r,e,t),Pe&&at.render(e),Dt(k,e,t)}ue!==null&&le===0&&(He.updateMultisampleRenderTarget(ue),He.updateRenderTargetMipmap(ue)),r&&ne.end(N),e.isScene===!0&&e.onAfterRender(N,e,t),ut.resetDefaultState(),de=-1,fe=null,M.pop(),M.length>0?(j=M[M.length-1],He.setTextureUnits(j.state.textureUnits),Oe===!0&&et.setGlobalState(N.clippingPlanes,j.state.camera)):j=null,te.pop(),k=te.length>0?te[te.length-1]:null,ie!==null&&ie.renderEnd()};function Et(e,t,n,r){if(e.visible===!1)return;if(e.layers.test(t.layers)){if(e.isGroup)n=e.renderOrder;else if(e.isLOD)e.autoUpdate===!0&&e.update(t);else if(e.isLight)j.pushLight(e),e.castShadow&&j.pushShadow(e);else if(e.isSprite){let i=t.isArrayCamera?De:Ee;if(!e.frustumCulled||e.intersectsFrustum(i)){r&&Me.setFromMatrixPosition(e.matrixWorld).applyMatrix4(Ae);let i=Ke.update(e),a=e.material;a.visible&&k.push(e,i,a,n,Me.z,null,t)}}else if(e.isMesh||e.isLine||e.isPoints){let i=t.isArrayCamera?De:Ee;if(!e.frustumCulled||e.intersectsFrustum(i)){let i=Ke.update(e),a=e.material;if(r&&(e.boundingSphere===void 0?(i.boundingSphere===null&&i.computeBoundingSphere(),Me.copy(i.boundingSphere.center)):(e.boundingSphere===null&&e.computeBoundingSphere(),Me.copy(e.boundingSphere.center)),Me.applyMatrix4(e.matrixWorld).applyMatrix4(Ae)),Array.isArray(a)){let r=i.groups;for(let o=0,s=r.length;o<s;o++){let s=r[o],c=a[s.materialIndex];c&&c.visible&&k.push(e,i,c,n,Me.z,s,t)}}else a.visible&&k.push(e,i,a,n,Me.z,null,t)}}}let i=e.children;for(let e=0,a=i.length;e<a;e++)Et(i[e],t,n,r)}function Dt(e,t,n,r){let{opaque:i,transmissive:a,transparent:o}=e;j.setupLightsView(n),Oe===!0&&et.setGlobalState(N.clippingPlanes,n),r&&F.viewport(pe.copy(r)),i.length>0&&kt(i,t,n),a.length>0&&kt(a,t,n),o.length>0&&kt(o,t,n),F.buffers.depth.setTest(!0),F.buffers.depth.setMask(!0),F.buffers.color.setMask(!0),F.setPolygonOffset(!1)}function Ot(e,t,n,r){if((n.isScene===!0?n.overrideMaterial:null)!==null)return;if(j.state.transmissionRenderTarget[r.id]===void 0){let e=Le.has(`EXT_color_buffer_half_float`)||Le.has(`EXT_color_buffer_float`);j.state.transmissionRenderTarget[r.id]=new nn(1,1,{generateMipmaps:!0,type:e?g:l,minFilter:c,samples:Math.max(4,Re.samples),stencilBuffer:i,resolveDepthBuffer:!1,resolveStencilBuffer:!1,storeMultisampledDepthBuffer:!1,storeMultisampledStencilBuffer:!1,colorSpace:Ut.workingColorSpace})}let a=j.state.transmissionRenderTarget[r.id],o=r.viewport||pe;a.setSize(o.z*N.transmissionResolutionScale,o.w*N.transmissionResolutionScale);let s=N.getRenderTarget(),u=N.getActiveCubeFace(),d=N.getActiveMipmapLevel();N.setRenderTarget(a),N.getClearColor(ge),_e=N.getClearAlpha(),_e<1&&N.setClearColor(16777215,.5),N.clear(),Pe&&at.render(n);let f=N.toneMapping;N.toneMapping=0;let p=r.viewport;if(r.viewport!==void 0&&(r.viewport=void 0),j.setupLightsView(r),Oe===!0&&et.setGlobalState(N.clippingPlanes,r),kt(e,n,r),He.updateMultisampleRenderTarget(a),He.updateRenderTargetMipmap(a),Le.has(`WEBGL_multisampled_render_to_texture`)===!1){let e=!1;for(let i=0,a=t.length;i<a;i++){let{object:a,geometry:o,material:s,group:c}=t[i];if(s.side===2&&a.layers.test(r.layers)){let t=s.side;s.side=1,s.needsUpdate=!0,At(a,n,r,o,s,c),s.side=t,s.needsUpdate=!0,e=!0}}e===!0&&(He.updateMultisampleRenderTarget(a),He.updateRenderTargetMipmap(a))}N.setRenderTarget(s,u,d),N.setClearColor(ge,_e),p!==void 0&&(r.viewport=p),N.toneMapping=f}function kt(e,t,n){let r=t.isScene===!0?t.overrideMaterial:null;for(let i=0,a=e.length;i<a;i++){let a=e[i],{object:o,geometry:s,group:c}=a,l=a.material;l.allowOverride===!0&&r!==null&&(l=r),o.layers.test(n.layers)&&At(o,t,n,s,l,c)}}function At(e,t,n,r,i,a){ie!==null&&i.isNodeMaterial&&ie.setObject(e,i),e.onBeforeRender(N,t,n,r,i,a),e.modelViewMatrix.multiplyMatrices(n.matrixWorldInverse,e.matrixWorld),e.normalMatrix.getNormalMatrix(e.modelViewMatrix),i.onBeforeRender(N,t,n,r,e,a),i.transparent===!0&&i.side===2&&i.forceSinglePass===!1?(i.side=1,i.needsUpdate=!0,N.renderBufferDirect(n,t,r,i,e,a),i.side=0,i.needsUpdate=!0,N.renderBufferDirect(n,t,r,i,e,a),i.side=2):N.renderBufferDirect(n,t,r,i,e,a),e.onAfterRender(N,t,n,r,i,a)}function jt(e){let t=0;for(let n of e)n.texture!==null&&t++;return t}function Mt(e,t,n){t.isScene!==!0&&(t=Ne);let r=Ve.get(e),i=j.state.lights,a=j.state.shadowsArray,o=i.state.version,s=Je.getParameters(e,i.state,a,t,n,j.state.lightProbeGridArray),c=Je.getProgramCacheKey(s),l=r.programs;r.environment=e.isMeshStandardMaterial||e.isMeshLambertMaterial||e.isMeshPhongMaterial?t.environment:null,r.fog=t.fog;let u=e.isMeshStandardMaterial||e.isMeshLambertMaterial&&!e.envMap||e.isMeshPhongMaterial&&!e.envMap;r.envMap=Ue.get(e.envMap||r.environment,u),r.envMapRotation=r.environment!==null&&e.envMap===null?t.environmentRotation:e.envMapRotation,l===void 0&&(e.addEventListener(`dispose`,_t),l=new Map,r.programs=l,r.programVariants=new Map);let d=l.get(c);if(d!==void 0){if(r.currentProgram===d&&r.lightsStateVersion===o)return I(e,s),d}else s.uniforms=Je.getUniforms(e),ie!==null&&e.isNodeMaterial&&ie.build(e,n,s),e.onBeforeCompile(s,N),d=Je.acquireProgram(s,c),l.set(c,d),r.uniforms=s.uniforms;let f=r.uniforms;return(!e.isShaderMaterial&&!e.isRawShaderMaterial||e.clipping===!0)&&(f.clippingPlanes=et.uniform),I(e,s),r.needsLights=Lt(e),r.lightsStateVersion=o,r.needsLights&&(f.ambientLightColor.value=i.state.ambient,f.lightProbe.value=i.state.probe,f.sunLights.value=i.state.sun,f.sunLightShadows.value=i.state.sunShadow,f.directionalLights.value=i.state.directional,f.directionalLightShadows.value=i.state.directionalShadow,f.spotLights.value=i.state.spot,f.spotLightShadows.value=i.state.spotShadow,f.rectAreaLights.value=i.state.rectArea,f.ltc_1.value=i.state.rectAreaLTC1,f.ltc_2.value=i.state.rectAreaLTC2,f.pointLights.value=i.state.point,f.pointLightShadows.value=i.state.pointShadow,f.hemisphereLights.value=i.state.hemi,f.sunShadowMatrix.value=i.state.sunShadowMatrix,f.sunShadowCascade.value=i.state.sunShadowCascade,f.directionalShadowMatrix.value=i.state.directionalShadowMatrix,f.spotLightMatrix.value=i.state.spotLightMatrix,f.spotLightMap.value=i.state.spotLightMap,f.pointShadowMatrix.value=i.state.pointShadowMatrix),r.numLightProbeGrids=jt(j.state.lightProbeGridArray),r.currentProgram=d,r.uniformsList=null,d}function Nt(e,t,n,r,i){let a=Ve.get(e),o=a.currentProgram.id+`,`+r+`,`+i,s=a.programVariants.get(o);return s===void 0?(s=Mt(e,t,n),a.programVariants.set(o,s)):(a.currentProgram=s,a.uniformsList=null,a.outputColorSpace=r,a.toneMapping=i),s}function Pt(e){if(e.uniformsList===null){let t=e.currentProgram.getUniforms();e.uniformsList=Hl.seqWithValue(t.seq,e.uniforms)}return e.uniformsList}function I(e,t){let n=Ve.get(e);n.outputColorSpace=t.outputColorSpace,n.batching=t.batching,n.batchingColor=t.batchingColor,n.instancing=t.instancing,n.instancingColor=t.instancingColor,n.instancingMorph=t.instancingMorph,n.skinning=t.skinning,n.morphTargets=t.morphTargets,n.morphNormals=t.morphNormals,n.morphColors=t.morphColors,n.morphTargetsCount=t.morphTargetsCount,n.numClippingPlanes=t.numClippingPlanes,n.numIntersection=t.numClipIntersection,n.vertexAlphas=t.vertexAlphas,n.vertexTangents=t.vertexTangents,n.toneMapping=t.toneMapping}function Ft(e,t,n,r,i){t.isScene!==!0&&(t=Ne),He.resetTextureUnits();let a=t.fog,o=r.isMeshStandardMaterial||r.isMeshLambertMaterial||r.isMeshPhongMaterial?t.environment:null,s=ue===null?N.outputColorSpace:ue.isXRRenderTarget===!0?ue.texture.colorSpace:Ut.workingColorSpace,c=r.isMeshStandardMaterial||r.isMeshLambertMaterial&&!r.envMap||r.isMeshPhongMaterial&&!r.envMap,l=Ue.get(r.envMap||o,c),u=r.vertexColors===!0&&!!n.attributes.color&&n.attributes.color.itemSize===4,d=!!n.attributes.tangent&&(!!r.normalMap||r.anisotropy>0),f=!!n.morphAttributes.position,p=!!n.morphAttributes.normal,m=!!n.morphAttributes.color,h=0;r.toneMapped&&(ue===null||ue.isXRRenderTarget===!0)&&(h=N.toneMapping);let g=n.morphAttributes.position||n.morphAttributes.normal||n.morphAttributes.color,_=g===void 0?0:g.length,v=Ve.get(r),y=j.state.lights;if(Oe===!0&&(ke===!0||e!==fe)){let t=e===fe&&r.id===de;et.setState(r,e,t)}let b=!1,x=!1;r.version===v.__version?v.needsLights&&v.lightsStateVersion!==y.state.version||i.isBatchedMesh&&v.batching===!1||!i.isBatchedMesh&&v.batching===!0||i.isBatchedMesh&&v.batchingColor===!0&&i._colorsTexture===null||i.isBatchedMesh&&v.batchingColor===!1&&i._colorsTexture!==null||i.isInstancedMesh&&v.instancing===!1||!i.isInstancedMesh&&v.instancing===!0||i.isSkinnedMesh&&v.skinning===!1||!i.isSkinnedMesh&&v.skinning===!0||i.isInstancedMesh&&v.instancingColor===!0&&i.instanceColor===null||i.isInstancedMesh&&v.instancingColor===!1&&i.instanceColor!==null||i.isInstancedMesh&&v.instancingMorph===!0&&i.morphTexture===null||i.isInstancedMesh&&v.instancingMorph===!1&&i.morphTexture!==null?b=!0:v.envMap===l?r.fog===!0&&v.fog!==a||v.numClippingPlanes!==void 0&&(v.numClippingPlanes!==et.numPlanes||v.numIntersection!==et.numIntersection)?b=!0:v.vertexAlphas===u&&v.vertexTangents===d&&v.morphTargets===f&&v.morphNormals===p&&v.morphColors===m&&v.morphTargetsCount===_&&v.numLightProbeGrids===jt(j.state.lightProbeGridArray)?(v.outputColorSpace!==s||v.toneMapping!==h)&&(x=!0):b=!0:b=!0:(b=!0,v.__version=r.version);let S=v.currentProgram;(b===!0||x===!0)&&(S=x===!0?Nt(r,t,i,s,h):Mt(r,t,i),ie&&r.isNodeMaterial&&ie.onUpdateProgram(r,S,v));let C=!1,w=!1,T=!1,E=S.getUniforms(),O=v.uniforms;if(F.useProgram(S.program)&&(C=!0,w=!0,T=!0),r.id!==de&&(de=r.id,w=!0),C||fe!==e){F.buffers.depth.getReversed()&&e.reversedDepth!==!0&&(e._reversedDepth=!0,e.updateProjectionMatrix()),E.setValue(P,`projectionMatrix`,e.projectionMatrix),E.setValue(P,`viewMatrix`,e.matrixWorldInverse);let t=E.map.cameraPosition;t!==void 0&&t.setValue(P,je.setFromMatrixPosition(e.matrixWorld)),Re.logarithmicDepthBuffer&&E.setValue(P,`logDepthBufFC`,2/(Math.log(e.far+1)/Math.LN2)),(r.isMeshPhongMaterial||r.isMeshToonMaterial||r.isMeshLambertMaterial||r.isMeshBasicMaterial||r.isMeshStandardMaterial||r.isShaderMaterial)&&E.setValue(P,`isOrthographic`,e.isOrthographicCamera===!0),fe!==e&&(fe=e,w=!0,T=!0)}if(v.needsLights&&(y.state.sunShadowMap.length>0&&E.setValue(P,`sunShadowMap`,y.state.sunShadowMap,He),y.state.directionalShadowMap.length>0&&E.setValue(P,`directionalShadowMap`,y.state.directionalShadowMap,He),y.state.spotShadowMap.length>0&&E.setValue(P,`spotShadowMap`,y.state.spotShadowMap,He),y.state.pointShadowMap.length>0&&E.setValue(P,`pointShadowMap`,y.state.pointShadowMap,He)),i.isSkinnedMesh){E.setOptional(P,i,`bindMatrix`),E.setOptional(P,i,`bindMatrixInverse`);let e=i.skeleton;e&&(e.boneTexture===null&&e.computeBoneTexture(),E.setValue(P,`boneTexture`,e.boneTexture,He))}i.isBatchedMesh&&(E.setOptional(P,i,`batchingTexture`),E.setValue(P,`batchingTexture`,i._matricesTexture,He),E.setOptional(P,i,`batchingIdTexture`),E.setValue(P,`batchingIdTexture`,i._indirectTexture,He),E.setOptional(P,i,`batchingColorTexture`),i._colorsTexture!==null&&E.setValue(P,`batchingColorTexture`,i._colorsTexture,He));let k=n.morphAttributes;if((k.position!==void 0||k.normal!==void 0||k.color!==void 0)&&ot.update(i,n,S),(w||v.receiveShadow!==i.receiveShadow)&&(v.receiveShadow=i.receiveShadow,E.setValue(P,`receiveShadow`,i.receiveShadow)),(r.isMeshStandardMaterial||r.isMeshLambertMaterial||r.isMeshPhongMaterial)&&r.envMap===null&&t.environment!==null&&(O.envMapIntensity.value=t.environmentIntensity),O.dfgLUT!==void 0&&(O.dfgLUT.value=ad()),w){if(E.setValue(P,`toneMappingExposure`,N.toneMappingExposure),v.needsLights&&It(O,T),a&&r.fog===!0&&Ye.refreshFogUniforms(O,a),Ye.refreshMaterialUniforms(O,r,be,ye,j.state.transmissionRenderTarget[e.id]),v.needsLights&&v.numLightProbeGrids>0){let e=D,t=0;for(let n of j.state.lightProbeGridArray)n.texture!==null&&(e.textures[t]=n.texture,e.min[t]=n.boundingBox.min,e.max[t]=n.boundingBox.max,e.resolution[t]=n.resolution,t++);for(let n in e)e[n].length=t;O.probesSH.value=e.textures,O.probesMin.value=e.min,O.probesMax.value=e.max,O.probesResolution.value=e.resolution}Hl.upload(P,Pt(v),O,He)}if(r.isShaderMaterial&&r.uniformsNeedUpdate===!0&&(Hl.upload(P,Pt(v),O,He),r.uniformsNeedUpdate=!1),r.isSpriteMaterial&&E.setValue(P,`center`,i.center),E.setValue(P,`modelViewMatrix`,i.modelViewMatrix),E.setValue(P,`normalMatrix`,i.normalMatrix),E.setValue(P,`modelMatrix`,i.matrixWorld),r.uniformsGroups!==void 0){let e=r.uniformsGroups;for(let t=0,n=e.length;t<n;t++){let n=e[t];dt.update(n,S),dt.bind(n,S)}}return S}function It(e,t){e.ambientLightColor.needsUpdate=t,e.lightProbe.needsUpdate=t,e.sunLights.needsUpdate=t,e.sunLightShadows.needsUpdate=t,e.directionalLights.needsUpdate=t,e.directionalLightShadows.needsUpdate=t,e.pointLights.needsUpdate=t,e.pointLightShadows.needsUpdate=t,e.spotLights.needsUpdate=t,e.spotLightShadows.needsUpdate=t,e.rectAreaLights.needsUpdate=t,e.hemisphereLights.needsUpdate=t}function Lt(e){return e.isMeshLambertMaterial||e.isMeshToonMaterial||e.isMeshPhongMaterial||e.isMeshStandardMaterial||e.isShadowMaterial||e.isShaderMaterial&&e.lights===!0}this.getActiveCubeFace=function(){return ce},this.getActiveMipmapLevel=function(){return le},this.getRenderTarget=function(){return ue},this.setRenderTargetTextures=function(e,t,n){let r=Ve.get(e);r.__autoAllocateDepthBuffer=e.resolveDepthBuffer===!1,r.__autoAllocateDepthBuffer===!1&&(r.__useRenderToTexture=!1),Ve.get(e.texture).__webglTexture=t,Ve.get(e.depthTexture).__webglTexture=r.__autoAllocateDepthBuffer?void 0:n,r.__hasExternalTextures=!0},this.setRenderTargetFramebuffer=function(e,t){let n=Ve.get(e);n.__webglFramebuffer=t,n.__useDefaultFramebuffer=t===void 0},this.setRenderTarget=function(e,t=0,n=0){ue=e,ce=t,le=n;let r=null,i=!1,a=!1;if(e){let o=Ve.get(e);if(o.__useDefaultFramebuffer!==void 0){F.bindFramebuffer(P.FRAMEBUFFER,o.__webglFramebuffer),pe.copy(e.viewport),me.copy(e.scissor),he=e.scissorTest,F.viewport(pe),F.scissor(me),F.setScissorTest(he),de=-1;return}if(o.__webglFramebuffer===void 0)He.setupRenderTarget(e);else if(o.__hasExternalTextures)He.rebindTextures(e,Ve.get(e.texture).__webglTexture,Ve.get(e.depthTexture).__webglTexture);else if(e.depthBuffer){let t=e.depthTexture;if(o.__boundDepthTexture!==t){if(t!==null&&Ve.has(t)&&(e.width!==t.image.width||e.height!==t.image.height))throw Error(`THREE.WebGLRenderer: Attached DepthTexture is initialized to the incorrect size.`);He.setupDepthRenderbuffer(e)}}let s=e.texture;(s.isData3DTexture||s.isDataArrayTexture||s.isCompressedArrayTexture)&&(a=!0);let c=Ve.get(e).__webglFramebuffer;e.isWebGLCubeRenderTarget?(r=Array.isArray(c[t])?c[t][n]:c[t],i=!0):r=e.samples>0&&He.useMultisampledRTT(e)===!1?Ve.get(e).__webglMultisampledFramebuffer:Array.isArray(c)?c[n]:c,pe.copy(e.viewport),me.copy(e.scissor),he=e.scissorTest}else pe.copy(Ce).multiplyScalar(be).floor(),me.copy(we).multiplyScalar(be).floor(),he=Te;if(n!==0&&(r=ae),F.bindFramebuffer(P.FRAMEBUFFER,r)&&F.drawBuffers(e,r),F.viewport(pe),F.scissor(me),F.setScissorTest(he),i){let r=Ve.get(e.texture);P.framebufferTexture2D(P.FRAMEBUFFER,P.COLOR_ATTACHMENT0,P.TEXTURE_CUBE_MAP_POSITIVE_X+t,r.__webglTexture,n)}else if(a){let r=t;for(let t=0;t<e.textures.length;t++){let i=Ve.get(e.textures[t]);P.framebufferTextureLayer(P.FRAMEBUFFER,P.COLOR_ATTACHMENT0+t,i.__webglTexture,n,r)}}else if(e!==null&&n!==0){let t=Ve.get(e.texture);P.framebufferTexture2D(P.FRAMEBUFFER,P.COLOR_ATTACHMENT0,P.TEXTURE_2D,t.__webglTexture,n)}de=-1};function Rt(e){let t=Ve.get(e);return(t.__readFormat!==e.format||t.__readType!==e.type)&&(t.__readFormat=e.format,t.__readType=e.type,t.__formatReadable=Re.textureFormatReadable(e.format),t.__typeReadable=Re.textureTypeReadable(e.type)),t}this.readRenderTargetPixels=function(e,t,n,r,i,a,o,s=0){if(!(e&&e.isWebGLRenderTarget)){nt(`WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.`);return}let c=Ve.get(e).__webglFramebuffer;if(e.isWebGLCubeRenderTarget&&o!==void 0&&(c=c[o],Array.isArray(c)&&(c=c[0])),c){F.bindFramebuffer(P.FRAMEBUFFER,c);try{let o=e.textures[s],c=o.format,l=o.type;e.textures.length>1&&P.readBuffer(P.COLOR_ATTACHMENT0+s);let u=Rt(o);if(u.__formatReadable===!1){nt(`WebGLRenderer.readRenderTargetPixels: renderTarget is not in RGBA or implementation defined format.`);return}if(u.__typeReadable===!1){nt(`WebGLRenderer.readRenderTargetPixels: renderTarget is not in UnsignedByteType or implementation defined type.`);return}t>=0&&t<=e.width-r&&n>=0&&n<=e.height-i&&P.readPixels(t,n,r,i,lt.convert(c),lt.convert(l),a)}finally{let e=ue===null?null:Ve.get(ue).__webglFramebuffer;F.bindFramebuffer(P.FRAMEBUFFER,e)}}},this.readRenderTargetPixelsAsync=async function(e,t,n,r,i,a,o,s=0){if(!(e&&e.isWebGLRenderTarget))throw Error(`THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.`);let c=Ve.get(e).__webglFramebuffer;if(e.isWebGLCubeRenderTarget&&o!==void 0&&(c=c[o],Array.isArray(c)&&(c=c[0])),c){if(t>=0&&t<=e.width-r&&n>=0&&n<=e.height-i){F.bindFramebuffer(P.FRAMEBUFFER,c);let o=e.textures[s],l=o.format,u=o.type;e.textures.length>1&&P.readBuffer(P.COLOR_ATTACHMENT0+s);let d=Rt(o);if(d.__formatReadable===!1)throw Error(`THREE.WebGLRenderer.readRenderTargetPixelsAsync: renderTarget is not in RGBA or implementation defined format.`);if(d.__typeReadable===!1)throw Error(`THREE.WebGLRenderer.readRenderTargetPixelsAsync: renderTarget is not in UnsignedByteType or implementation defined type.`);let f=P.createBuffer();P.bindBuffer(P.PIXEL_PACK_BUFFER,f),P.bufferData(P.PIXEL_PACK_BUFFER,a.byteLength,P.STREAM_READ),P.readPixels(t,n,r,i,lt.convert(l),lt.convert(u),0),P.bindBuffer(P.PIXEL_PACK_BUFFER,null);let p=ue===null?null:Ve.get(ue).__webglFramebuffer;F.bindFramebuffer(P.FRAMEBUFFER,p);let m=P.fenceSync(P.SYNC_GPU_COMMANDS_COMPLETE,0);return P.flush(),await it(P,m,4),P.bindBuffer(P.PIXEL_PACK_BUFFER,f),P.getBufferSubData(P.PIXEL_PACK_BUFFER,0,a),P.bindBuffer(P.PIXEL_PACK_BUFFER,null),P.deleteBuffer(f),P.deleteSync(m),a}throw Error(`THREE.WebGLRenderer.readRenderTargetPixelsAsync: requested read bounds are out of range.`)}},this.copyFramebufferToTexture=function(e,t=null,n=0){let r=2**-n,i=Math.floor(e.image.width*r),a=Math.floor(e.image.height*r),o=t===null?0:t.x,s=t===null?0:t.y;He.setTexture2D(e,0),P.copyTexSubImage2D(P.TEXTURE_2D,n,0,0,o,s,i,a),F.unbindTexture()},this.copyTextureToTexture=function(e,t,n=null,r=null,i=0,a=0){let o,s,c,l,u,d,f,p,m,h=e.isCompressedTexture?e.mipmaps[a]:e.image;if(n!==null)o=n.max.x-n.min.x,s=n.max.y-n.min.y,c=n.isBox3?n.max.z-n.min.z:1,l=n.min.x,u=n.min.y,d=n.isBox3?n.min.z:0;else{let t=2**-i;o=Math.floor(h.width*t),s=Math.floor(h.height*t),c=e.isDataArrayTexture?h.depth:e.isData3DTexture?Math.floor(h.depth*t):1,l=0,u=0,d=0}r===null?(f=0,p=0,m=0):(f=r.x,p=r.y,m=r.z);let g=lt.convert(t.format),_=lt.convert(t.type),v;t.isData3DTexture?(He.setTexture3D(t,0),v=P.TEXTURE_3D):t.isDataArrayTexture||t.isCompressedArrayTexture?(He.setTexture2DArray(t,0),v=P.TEXTURE_2D_ARRAY):(He.setTexture2D(t,0),v=P.TEXTURE_2D),F.activeTexture(P.TEXTURE0),F.pixelStorei(P.UNPACK_FLIP_Y_WEBGL,t.flipY),F.pixelStorei(P.UNPACK_PREMULTIPLY_ALPHA_WEBGL,t.premultiplyAlpha),F.pixelStorei(P.UNPACK_ALIGNMENT,t.unpackAlignment);let y=F.getParameter(P.UNPACK_ROW_LENGTH),b=F.getParameter(P.UNPACK_IMAGE_HEIGHT),x=F.getParameter(P.UNPACK_SKIP_PIXELS),S=F.getParameter(P.UNPACK_SKIP_ROWS),C=F.getParameter(P.UNPACK_SKIP_IMAGES);F.pixelStorei(P.UNPACK_ROW_LENGTH,h.width),F.pixelStorei(P.UNPACK_IMAGE_HEIGHT,h.height),F.pixelStorei(P.UNPACK_SKIP_PIXELS,l),F.pixelStorei(P.UNPACK_SKIP_ROWS,u),F.pixelStorei(P.UNPACK_SKIP_IMAGES,d);let w=e.isDataArrayTexture||e.isData3DTexture,T=t.isDataArrayTexture||t.isData3DTexture;if(e.isDepthTexture){let n=Ve.get(e),r=Ve.get(t),h=Ve.get(n.__renderTarget),g=Ve.get(r.__renderTarget);F.bindFramebuffer(P.READ_FRAMEBUFFER,h.__webglFramebuffer),F.bindFramebuffer(P.DRAW_FRAMEBUFFER,g.__webglFramebuffer);for(let n=0;n<c;n++)w&&(P.framebufferTextureLayer(P.READ_FRAMEBUFFER,P.COLOR_ATTACHMENT0,Ve.get(e).__webglTexture,i,d+n),P.framebufferTextureLayer(P.DRAW_FRAMEBUFFER,P.COLOR_ATTACHMENT0,Ve.get(t).__webglTexture,a,m+n)),P.blitFramebuffer(l,u,l+o,u+s,f,p,f+o,p+s,P.DEPTH_BUFFER_BIT,P.NEAREST);F.bindFramebuffer(P.READ_FRAMEBUFFER,null),F.bindFramebuffer(P.DRAW_FRAMEBUFFER,null)}else if(i!==0||e.isRenderTargetTexture||Ve.has(e)){let n=Ve.get(e),r=Ve.get(t);F.bindFramebuffer(P.READ_FRAMEBUFFER,oe),F.bindFramebuffer(P.DRAW_FRAMEBUFFER,se);for(let e=0;e<c;e++)w?P.framebufferTextureLayer(P.READ_FRAMEBUFFER,P.COLOR_ATTACHMENT0,n.__webglTexture,i,d+e):P.framebufferTexture2D(P.READ_FRAMEBUFFER,P.COLOR_ATTACHMENT0,P.TEXTURE_2D,n.__webglTexture,i),T?P.framebufferTextureLayer(P.DRAW_FRAMEBUFFER,P.COLOR_ATTACHMENT0,r.__webglTexture,a,m+e):P.framebufferTexture2D(P.DRAW_FRAMEBUFFER,P.COLOR_ATTACHMENT0,P.TEXTURE_2D,r.__webglTexture,a),i===0?T?P.copyTexSubImage3D(v,a,f,p,m+e,l,u,o,s):P.copyTexSubImage2D(v,a,f,p,l,u,o,s):P.blitFramebuffer(l,u,l+o,u+s,f,p,f+o,p+s,P.COLOR_BUFFER_BIT,P.NEAREST);F.bindFramebuffer(P.READ_FRAMEBUFFER,null),F.bindFramebuffer(P.DRAW_FRAMEBUFFER,null)}else T?e.isDataTexture||e.isData3DTexture?P.texSubImage3D(v,a,f,p,m,o,s,c,g,_,h.data):t.isCompressedArrayTexture?P.compressedTexSubImage3D(v,a,f,p,m,o,s,c,g,h.data):P.texSubImage3D(v,a,f,p,m,o,s,c,g,_,h):e.isDataTexture?P.texSubImage2D(P.TEXTURE_2D,a,f,p,o,s,g,_,h.data):e.isCompressedTexture?P.compressedTexSubImage2D(P.TEXTURE_2D,a,f,p,h.width,h.height,g,h.data):P.texSubImage2D(P.TEXTURE_2D,a,f,p,o,s,g,_,h);F.pixelStorei(P.UNPACK_ROW_LENGTH,y),F.pixelStorei(P.UNPACK_IMAGE_HEIGHT,b),F.pixelStorei(P.UNPACK_SKIP_PIXELS,x),F.pixelStorei(P.UNPACK_SKIP_ROWS,S),F.pixelStorei(P.UNPACK_SKIP_IMAGES,C),a===0&&t.generateMipmaps===!0&&t.mipmapsAutoUpdate===!0&&P.generateMipmap(v),F.unbindTexture()},this.initRenderTarget=function(e){Ve.get(e).__webglFramebuffer===void 0&&He.setupRenderTarget(e)},this.initTexture=function(e){e.isCubeTexture?He.setTextureCube(e,0):e.isData3DTexture?He.setTexture3D(e,0):e.isDataArrayTexture||e.isCompressedArrayTexture?He.setTexture2DArray(e,0):He.setTexture2D(e,0),F.unbindTexture()},this.resetState=function(){ce=0,le=0,ue=null,F.reset(),ut.reset()},typeof __THREE_DEVTOOLS__<`u`&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent(`observe`,{detail:this}))}get coordinateSystem(){return qe}get outputColorSpace(){return this._outputColorSpace}set outputColorSpace(e){this._outputColorSpace=e;let t=this.getContext();t.drawingBufferColorSpace=Ut._getDrawingBufferColorSpace(e),t.unpackColorSpace=Ut._getUnpackColorSpace()}},sd=class{s;constructor(e){this.s=e>>>0}next(){let e=this.s=this.s+1831565813>>>0;return e=Math.imul(e^e>>>15,e|1),e^=e+Math.imul(e^e>>>7,e|61),((e^e>>>14)>>>0)/4294967296}range(e,t){return e+(t-e)*this.next()}int(e){return Math.floor(this.next()*e)}dir(){for(;;){let e=this.next()*2-1,t=this.next()*2-1,n=this.next()*2-1,r=e*e+t*t+n*n;if(r>.01&&r<=1){let i=Math.sqrt(r);return[e/i,t/i,n/i]}}}};function cd(e,t,n,r){let i=Math.imul(e,374761393)^Math.imul(t,668265263)^Math.imul(n,2147483647)^Math.imul(r,1274126177);return i=Math.imul(i^i>>>13,1274126177),i^=i>>>16,(i>>>0)/4294967296}function ld(e,t,n,r){let i=Math.floor(e),a=Math.floor(t),o=Math.floor(n),s=e-i,c=t-a,l=n-o,u=s*s*(3-2*s),d=c*c*(3-2*c),f=l*l*(3-2*l),p=cd(i,a,o,r),m=cd(i+1,a,o,r),h=cd(i,a+1,o,r),g=cd(i+1,a+1,o,r),_=cd(i,a,o+1,r),v=cd(i+1,a,o+1,r),y=cd(i,a+1,o+1,r),b=cd(i+1,a+1,o+1,r),x=p+(m-p)*u,S=h+(g-h)*u,C=_+(v-_)*u,w=y+(b-y)*u,T=x+(S-x)*d;return T+(C+(w-C)*d-T)*f}function ud(e,t,n,r,i=4){let a=.5,o=1,s=0,c=0;for(let l=0;l<i;l++)s+=a*ld(e*o,t*o,n*o,r+l*101),c+=a,a*=.5,o*=2.03;return s/c}var dd={seed:1337,radius:1e3,gridN:128,large:3,medium:8,small:30},fd=[[[1,0,0],[0,0,-1],[0,1,0]],[[-1,0,0],[0,0,1],[0,1,0]],[[0,1,0],[1,0,0],[0,0,-1]],[[0,-1,0],[1,0,0],[0,0,1]],[[0,0,1],[1,0,0],[0,1,0]],[[0,0,-1],[-1,0,0],[0,1,0]]],pd=.0144,md=3.5,hd=.17,gd=class{params;N;cellCount;radius;blobs=[];cx;cy;cz;height;land;adjStart;adj;adjCost;edgeLand;edgeSea;constructor(e={}){this.params={...dd,...e},this.N=this.params.gridN,this.radius=this.params.radius,this.cellCount=6*this.N*this.N,this.placeIslands();let t=this.cellCount;this.cx=new Float64Array(t),this.cy=new Float64Array(t),this.cz=new Float64Array(t),this.height=new Float32Array(t),this.land=new Uint8Array(t);let n=this.N;for(let e=0;e<6;e++){let[t,r,i]=fd[e];for(let a=0;a<n;a++)for(let o=0;o<n;o++){let s=(o+.5)/n*2-1,c=(a+.5)/n*2-1,l=t[0]+s*r[0]+c*i[0],u=t[1]+s*r[1]+c*i[1],d=t[2]+s*r[2]+c*i[2],f=Math.sqrt(l*l+u*u+d*d);l/=f,u/=f,d/=f;let p=e*n*n+a*n+o;this.cx[p]=l,this.cy[p]=u,this.cz[p]=d;let m=this.heightAt(l,u,d);this.height[p]=m,this.land[p]=+(m>0)}}let r=Array(t);for(let e=0;e<t;e++)r[e]=[];for(let e=0;e<t;e++){let t=this.cx[e],i=this.cy[e],a=this.cz[e],o,s,c;Math.abs(i)<.9?(o=a,s=0,c=-t):(o=0,s=-a,c=i);let l=Math.sqrt(o*o+s*s+c*c);o/=l,s/=l,c/=l;let u=i*c-a*s,d=a*o-t*c,f=t*s-i*o,p=e%n<n-1?e+1:e-1,m=this.cx[p]-t,h=this.cy[p]-i,g=this.cz[p]-a,_=Math.sqrt(m*m+h*h+g*g);for(let n=0;n<16;n++){let l=_d[n*2]*_,p=_d[n*2+1]*_,m=t+l*o+p*u,h=i+l*s+p*d,g=a+l*c+p*f,v=this.cellOf(m,h,g);v!==e&&!r[e].includes(v)&&(r[e].push(v),r[v].includes(e)||r[v].push(e))}}let i=0;for(let e=0;e<t;e++)i+=r[e].length;this.adjStart=new Int32Array(t+1),this.adj=new Int32Array(i),this.adjCost=new Float32Array(i);let a=0;for(let e=0;e<t;e++){this.adjStart[e]=a;let t=r[e].sort((e,t)=>e-t);for(let n of t){this.adj[a]=n;let t=this.cx[n]-this.cx[e],r=this.cy[n]-this.cy[e],i=this.cz[n]-this.cz[e];this.adjCost[a]=Math.sqrt(t*t+r*r+i*i)*this.radius,a++}}this.adjStart[t]=a,this.edgeLand=new Uint8Array(i),this.edgeSea=new Uint8Array(i);for(let e=0;e<t;e++)for(let t=this.adjStart[e];t<this.adjStart[e+1];t++){let n=this.adj[t],r=this.land[e]===1&&this.land[n]===1,i=this.land[e]===0&&this.land[n]===0;for(let t=1;t<8&&(r||i);t++){let a=t/8,o=this.cellOf(this.cx[e]+(this.cx[n]-this.cx[e])*a,this.cy[e]+(this.cy[n]-this.cy[e])*a,this.cz[e]+(this.cz[n]-this.cz[e])*a);this.land[o]===1?i=!1:r=!1}this.edgeLand[t]=+!!r,this.edgeSea[t]=+!!i}}placeIslands(){let e=new sd(this.params.seed),t=[[`large`,this.params.large,.2,.27],[`medium`,this.params.medium,.1,.14],[`small`,this.params.small,.035,.065]];for(let[n,r,i,a]of t){let t=0,o=0;for(;t<r&&o<5e3;){o++;let r=e.dir(),s=e.range(i,a),c=!0;for(let e of this.blobs){let t=e.c[0]-r[0],n=e.c[1]-r[1],i=e.c[2]-r[2];if(Math.sqrt(t*t+n*n+i*i)<(e.r+s)*1.35+.03){c=!1;break}}if(!c)continue;let l=n===`large`?e.range(.8,1):n===`medium`?e.range(.5,.75):e.range(.25,.45);this.blobs.push({c:r,r:s,h:l,kind:n}),t++}}}heightAt(e,t,n){let r=this.params.seed,i=ud(e*6+11,t*6,n*6,r+7,3)-.5,a=-.55+(ud(e*3,t*3,n*3,r+3,3)-.5)*.4;for(let o of this.blobs){let s=o.c[0]-e,c=o.c[1]-t,l=o.c[2]-n,u=s*s+c*c+l*l,d=o.r*1.6+hd;if(u>d*d)continue;let f=1-Math.sqrt(u)*(1+i*.9)/o.r,p;if(f>.0144){let i=ud(e*25,t*25,n*25,r+19,3)-.5,a=Math.min(1,(f-pd)/.06);p=(Math.sqrt(f)-.12)*o.h+i*.25*o.h*a}else p=(f-pd)*o.r*md;p>a&&(a=p)}return a}cellOf(e,t,n){let r=Math.abs(e),i=Math.abs(t),a=Math.abs(n),o;o=r>=i&&r>=a?e>0?0:1:i>=a?t>0?2:3:n>0?4:5;let[s,c,l]=fd[o],u=e*s[0]+t*s[1]+n*s[2],d=(e*c[0]+t*c[1]+n*c[2])/u,f=(e*l[0]+t*l[1]+n*l[2])/u,p=this.N,m=Math.floor((d+1)/2*p),h=Math.floor((f+1)/2*p);return m<0?m=0:m>=p&&(m=p-1),h<0?h=0:h>=p&&(h=p-1),o*p*p+h*p+m}nearestCell(e,t,n=2e5){if(t(e))return e;let r=new Uint8Array(this.cellCount),i=[e];r[e]=1;for(let e=0;e<i.length&&e<n;e++){let n=i[e];for(let e=this.adjStart[n];e<this.adjStart[n+1];e++){let n=this.adj[e];if(!r[n]){if(t(n))return n;r[n]=1,i.push(n)}}}return-1}},_d=new Float64Array(32);{let e=[1,.9238795325112867,.7071067811865476,.3826834323650898,0,-.3826834323650898,-.7071067811865476,-.9238795325112867,-1,-.9238795325112867,-.7071067811865476,-.3826834323650898,0,.3826834323650898,.7071067811865476,.9238795325112867];for(let t=0;t<16;t++){let n=e[(t+12)%16],r=t%4==2?1.414:1;_d[t*2]=e[t]*r,_d[t*2+1]=n*r}}var B=function(e){return e[e.Land=0]=`Land`,e[e.Sea=1]=`Sea`,e[e.Air=2]=`Air`,e}({});function vd(e,t,n){return t===2?!0:t===0?e.land[n]===1:e.land[n]===0}var yd=class{planet;layer;goal;dist;constructor(e,t,n,r,i=1/0){this.planet=e,this.layer=t,this.goal=n;let a=e.cellCount,o=this.dist=new Float32Array(a).fill(1/0),s=new Int32Array(e.adj.length+1),c=new Float32Array(e.adj.length+1),l=0,u=(e,t)=>{let n=l++;for(;n>0;){let e=n-1>>1;if(c[e]<=t)break;s[n]=s[e],c[n]=c[e],n=e}s[n]=e,c[n]=t},d=()=>{let e=s[0],t=s[--l],n=c[l],r=0;for(;;){let e=2*r+1;if(e>=l||(e+1<l&&c[e+1]<c[e]&&e++,c[e]>=n))break;s[r]=s[e],c[r]=c[e],r=e}return s[r]=t,c[r]=n,e};o[n]=0,u(n,0);let{adjStart:f,adj:p,adjCost:m}=e,h=t===0?e.edgeLand:t===1?e.edgeSea:null;for(;l>0;){let e=c[0],n=d();if(!(e>o[n])){if(e>i)break;for(let i=f[n];i<f[n+1];i++){let n=p[i];if(h&&!h[i]||r&&t===0&&r[n])continue;let a=e+m[i];a<o[n]&&(o[n]=a,u(n,a))}}}}nextCell(e){let{adjStart:t,adj:n}=this.planet,r=-1,i=this.dist[e];for(let a=t[e];a<t[e+1];a++){let e=n[a];this.dist[e]<i&&(i=this.dist[e],r=e)}return r}},V=function(e){return e[e.Solar=0]=`Solar`,e[e.Wind=1]=`Wind`,e[e.MetalMine=2]=`MetalMine`,e[e.Storage=3]=`Storage`,e[e.Horizon=4]=`Horizon`,e[e.PracticeTarget=5]=`PracticeTarget`,e[e.Radar=6]=`Radar`,e[e.VehiclePlant=7]=`VehiclePlant`,e[e.Shipyard=8]=`Shipyard`,e[e.DronePad=9]=`DronePad`,e[e.AaGun=10]=`AaGun`,e[e.Tidal=11]=`Tidal`,e[e.Converter=12]=`Converter`,e[e.SonarBuoy=13]=`SonarBuoy`,e[e.AdvVehiclePlant=14]=`AdvVehiclePlant`,e[e.AdvShipyard=15]=`AdvShipyard`,e[e.AdvDronePad=16]=`AdvDronePad`,e[e.Fission=17]=`Fission`,e[e.AdvMine=18]=`AdvMine`,e[e.HeavyTower=19]=`HeavyTower`,e[e.Anvil=20]=`Anvil`,e[e.Fusion=21]=`Fusion`,e[e.LaunchComplex=22]=`LaunchComplex`,e[e.PointDefence=23]=`PointDefence`,e}({}),H=[{name:`Solar collector`,metal:145,energy:0,buildTime:2600,hp:300,radius:9,sight:60,energyOut:20,buildable:!0},{name:`Wind turbine`,metal:40,energy:175,buildTime:1600,hp:200,radius:5,sight:60,energyOut:30,buildable:!0},{name:`Metal mine`,metal:50,energy:520,buildTime:1800,hp:300,radius:7,sight:60,metalOut:1,energyUpkeep:3,buildable:!0},{name:`Storage`,metal:220,energy:600,buildTime:3e3,hp:500,radius:9,sight:60,metalStore:1500,energyStore:3e3,buildable:!0},{name:`Horizon`,metal:2500,energy:25e3,buildTime:45e3,hp:3e3,radius:15,sight:90,buildable:!0,faction:`agi`},{name:`Practice target`,metal:0,energy:0,buildTime:1,hp:1500,radius:8,sight:0,buildable:!1},{name:`Radar tower`,metal:60,energy:600,buildTime:1500,hp:250,radius:5,sight:80,radar:325,energyUpkeep:3,buildable:!0},{name:`Vehicle plant`,metal:450,energy:1500,buildTime:6e3,hp:2e3,radius:14,sight:90,buildable:!0},{name:`Shipyard`,metal:500,energy:1500,buildTime:7e3,hp:2200,radius:13,sight:110,buildable:!0},{name:`Drone pad`,metal:400,energy:2500,buildTime:6e3,hp:1500,radius:11,sight:90,buildable:!0},{name:`Anti-air MG`,metal:75,energy:700,buildTime:1800,hp:450,radius:4,sight:110,buildable:!0,weapon:{name:`AA machine gun`,range:110,damage:10,reload:.15,kind:`instant`,speed:0,splash:0,land:!1,sea:!1,air:!0}},{name:`Tidal generator`,metal:70,energy:500,buildTime:1700,hp:300,radius:6,sight:60,energyOut:18,buildable:!0},{name:`Metal Converter`,metal:80,energy:1500,buildTime:2600,hp:400,radius:7,sight:60,buildable:!0},{name:`Sonar buoy`,metal:40,energy:400,buildTime:900,hp:150,radius:3,sight:40,sonar:250,buildable:!0},{name:`Advanced vehicle plant`,metal:1500,energy:9e3,buildTime:18e3,hp:4e3,radius:17,sight:100,buildable:!0,tier:2,t1Builds:!0,factoryPower:180},{name:`Advanced shipyard`,metal:1600,energy:9e3,buildTime:2e4,hp:4200,radius:15,sight:120,buildable:!0,tier:2,t1Builds:!0,factoryPower:180},{name:`Advanced drone pad`,metal:1400,energy:12e3,buildTime:18e3,hp:3e3,radius:13,sight:100,buildable:!0,tier:2,t1Builds:!0,factoryPower:180},{name:`Fission reactor`,metal:900,energy:8e3,buildTime:16e3,hp:1500,radius:12,sight:60,energyOut:300,buildable:!0,tier:2},{name:`Advanced metal mine`,metal:450,energy:6e3,buildTime:9e3,hp:800,radius:8,sight:60,metalOut:3,energyUpkeep:25,buildable:!0,tier:2},{name:`Heavy defence tower`,metal:500,energy:5e3,buildTime:9e3,hp:2500,radius:6,sight:240,buildable:!0,tier:2,weapon:{name:`Heavy cannon`,range:230,damage:220,reload:3.5,kind:`shell`,speed:220,splash:10,land:!0,sea:!0,air:!1}},{name:`Anvil`,metal:2500,energy:25e3,buildTime:45e3,hp:3e3,radius:12,sight:90,buildable:!0,faction:`man`},{name:`Fusion reactor`,metal:3e3,energy:3e4,buildTime:4e4,hp:4e3,radius:16,sight:60,energyOut:1e3,buildable:!0,tier:2},{name:`Launch complex`,metal:2e3,energy:4e4,buildTime:3e4,hp:3e3,radius:12,sight:80,buildable:!0,tier:2,factoryPower:180},{name:`Point defence`,metal:600,energy:6e3,buildTime:6e3,hp:1500,radius:5,sight:120,buildable:!0,tier:2}],bd={shotEnergy:3e3,reload:90,fall:3,radius:45,damage:3500,scatter:8},xd={radius:200,damage:4e3},Sd={radius:220,damage:6e3,flightMin:6,flightPerRad:25,stopChance:.45,defenceReach:260},Cd={radius:90,seconds:12,commanderSlow:.75},wd={radius:120,damage:2500},Td={energyIn:60,metalOut:1,minStore:.3},Ed={shoreReach:14},Dd={buildPower:90,queueMax:30,shipyardWater:14},Od={team:1,builders:2,reserve:150,mineRange:320,lane:18,rallyOffset:45,homeRadius:260,reserveFrac:.3,homeGuard:4,maxFactories:3,t2Metal:600,reactorClear:60,plotRing:85,ferryMin:4,ferryWait:40,noSpotWait:10,energyPause:.1,searchesPerTurn:2,nukeEvery:240,upkeepSpare:20},kd={metalFraction:.6,sizeFraction:.85},Ad={workPerMetal:20},jd={team:1,tanks:5,destroyers:3,drones:3,leash:150,home:25,checkEvery:10},Md={grace:5,perSecond:1/30},Nd={buildPower:300,buildReach:10,metalOut:1.5,energyOut:25},Pd={startMetal:600,startEnergy:1e3,baseMetalCap:1e3,baseEnergyCap:2e3},Fd={showerCount:6,showerSpread:150,showerFirstDelay:4,showerInterval:1.8,warning:6,randomMin:90,randomMax:150,damageRadius:28,damageFraction:.05,richnessMin:2,richnessMax:4},Id={shotEnergy:1500,reload:60,turnCos:.9996573249755573,turnSin:.02617694830787315,aimTolerance:.9993908270190958,damage:650,radius:32,scatter:14,flightMin:6,flightPerRad:4.5,apex:.45},Ld=[`Player 1 (blue)`,`Player 2 (red)`,`Player 3 (green)`,`Player 4 (yellow)`],Rd={metal:3e3,energy:12e3,metalCap:2500,energyCap:1e4},zd={agi:{name:`AGI`,speed:1.15,hp:.85},man:{name:`MAN`,speed:.85,hp:1.15}},Bd=e=>e===`agi`?`man`:`agi`,Vd={easy:{thinkEvery:30,firstWave:600,waveEvery:300,waveSize:4,waveGrow:2,income:1,aaEarly:1,aaMax:2,t2At:0,t2Builders:0,reactors:0,towers:0,nukes:!1},normal:{thinkEvery:10,firstWave:360,waveEvery:240,waveSize:8,waveGrow:4,income:1,aaEarly:2,aaMax:4,t2At:840,t2Builders:1,reactors:2,towers:2,nukes:!1},hard:{thinkEvery:5,firstWave:360,waveEvery:180,waveSize:10,waveGrow:5,income:1.5,aaEarly:2,aaMax:6,t2At:540,t2Builders:2,reactors:3,towers:4,nukes:!0}},Hd={dayTicks:14400,cos:.9999999048070578,sin:.0004363322991533301,y:.2,startX:.9248,startZ:.3237,solarPeak:2.2,solarRamp:2.5},Ud=1/20,U=4096,W=function(e){return e[e.Commander=0]=`Commander`,e[e.Tank=1]=`Tank`,e[e.Boat=2]=`Boat`,e[e.Drone=3]=`Drone`,e[e.Builder=4]=`Builder`,e[e.ConShip=5]=`ConShip`,e[e.ConDrone=6]=`ConDrone`,e[e.Sub=7]=`Sub`,e[e.Transport=8]=`Transport`,e[e.AdvBuilder=9]=`AdvBuilder`,e[e.AdvConShip=10]=`AdvConShip`,e[e.AdvConDrone=11]=`AdvConDrone`,e[e.HeavyTank=12]=`HeavyTank`,e[e.Artillery=13]=`Artillery`,e[e.Gunship=14]=`Gunship`,e[e.Bomber=15]=`Bomber`,e[e.HeavyTransport=16]=`HeavyTransport`,e[e.RadarDrone=17]=`RadarDrone`,e[e.Cruiser=18]=`Cruiser`,e[e.SubHunter=19]=`SubHunter`,e[e.Interceptor=20]=`Interceptor`,e[e.EmpDrone=21]=`EmpDrone`,e[e.Satellite=22]=`Satellite`,e[e.NukeMissile=23]=`NukeMissile`,e}({}),Wd={name:`Cannon`,range:70,damage:60,reload:1.5,kind:`shell`,speed:180,splash:4,land:!0,sea:!0,air:!1},Gd={name:`Naval gun`,range:110,damage:120,reload:2.5,kind:`shell`,speed:160,splash:6,land:!0,sea:!0,air:!1},Kd={name:`AA gun`,range:90,damage:18,reload:.4,kind:`instant`,speed:0,splash:0,land:!1,sea:!1,air:!0},G=[{name:`Commander`,layer:B.Land,speed:16,radius:5,altitude:0,hp:3e3,sight:130,radar:200,metal:2500,energy:0,buildTime:0,buildPower:300,weapons:[]},{name:`Light tank`,layer:B.Land,speed:24,radius:3.2,altitude:0,hp:400,sight:80,radar:0,metal:150,energy:900,buildTime:2e3,buildPower:0,weapons:[Wd]},{name:`Destroyer`,layer:B.Sea,speed:22,radius:5,altitude:0,hp:1e3,sight:120,radar:0,metal:300,energy:2e3,buildTime:5e3,buildPower:0,weapons:[Gd,Kd,{name:`Depth charges`,range:50,damage:90,reload:2,kind:`instant`,speed:0,splash:0,land:!1,sea:!1,air:!1,sub:!0}],sonar:120},{name:`Attack drone`,layer:B.Air,speed:45,radius:2.5,altitude:35,hp:150,sight:160,radar:0,metal:60,energy:900,buildTime:1500,buildPower:0,weapons:[{name:`Guns`,range:45,damage:8,reload:.25,kind:`instant`,speed:0,splash:0,land:!0,sea:!0,air:!0}]},{name:`Construction vehicle`,layer:B.Land,speed:22,radius:3.6,altitude:0,hp:600,sight:100,radar:0,metal:120,energy:1200,buildTime:2400,buildPower:90,weapons:[]},{name:`Construction ship`,layer:B.Sea,speed:20,radius:5,altitude:0,hp:900,sight:110,radar:0,metal:200,energy:1500,buildTime:4500,buildPower:90,weapons:[]},{name:`Construction drone`,layer:B.Air,speed:38,radius:2.5,altitude:35,hp:180,sight:140,radar:0,metal:110,energy:1600,buildTime:3200,buildPower:45,weapons:[]},{name:`Submarine`,layer:B.Sea,speed:18,radius:4,altitude:0,hp:700,sight:90,radar:0,metal:250,energy:1800,buildTime:5500,buildPower:0,weapons:[{name:`Torpedoes`,range:80,damage:150,reload:3,kind:`instant`,speed:0,splash:0,land:!1,sea:!0,air:!1,sub:!0}],sonar:90,submerged:!0},{name:`Light transport`,layer:B.Air,speed:35,radius:4,altitude:30,hp:400,sight:110,radar:0,metal:120,energy:1500,buildTime:2600,buildPower:0,weapons:[],capacity:4},{name:`Advanced construction vehicle`,layer:B.Land,speed:20,radius:4.2,altitude:0,hp:1200,sight:110,radar:0,metal:400,energy:5e3,buildTime:9e3,buildPower:200,weapons:[],tier:2},{name:`Advanced construction ship`,layer:B.Sea,speed:18,radius:6,altitude:0,hp:2e3,sight:120,radar:0,metal:500,energy:6e3,buildTime:11e3,buildPower:200,weapons:[],tier:2},{name:`Advanced construction drone`,layer:B.Air,speed:34,radius:3,altitude:35,hp:400,sight:150,radar:0,metal:350,energy:7e3,buildTime:1e4,buildPower:120,weapons:[],tier:2},{name:`Heavy tank`,layer:B.Land,speed:16,radius:4.4,altitude:0,hp:1800,sight:100,radar:0,metal:450,energy:4500,buildTime:7e3,buildPower:0,weapons:[{name:`Heavy cannon`,range:90,damage:160,reload:2,kind:`shell`,speed:190,splash:6,land:!0,sea:!0,air:!1}]},{name:`Mobile artillery`,layer:B.Land,speed:14,radius:4,altitude:0,hp:500,sight:90,radar:0,metal:350,energy:4e3,buildTime:6500,buildPower:0,weapons:[{name:`Artillery`,range:220,damage:180,reload:5,kind:`shell`,speed:120,splash:14,land:!0,sea:!0,air:!1}]},{name:`Gunship`,layer:B.Air,speed:32,radius:3.6,altitude:30,hp:900,sight:130,radar:0,metal:300,energy:5e3,buildTime:6e3,buildPower:0,weapons:[{name:`Rockets`,range:70,damage:40,reload:.8,kind:`shell`,speed:260,splash:3,land:!0,sea:!0,air:!1}]},{name:`Heavy bomber`,layer:B.Air,speed:40,radius:5,altitude:45,hp:1200,sight:120,radar:0,metal:450,energy:8e3,buildTime:8e3,buildPower:0,weapons:[{name:`Bombs`,range:14,damage:300,reload:6,kind:`shell`,speed:60,splash:20,land:!0,sea:!0,air:!1,orderOnly:!0,salvo:4}],flyover:!0},{name:`Heavy transport`,layer:B.Air,speed:30,radius:6,altitude:32,hp:1500,sight:110,radar:0,metal:400,energy:6e3,buildTime:7e3,buildPower:0,weapons:[],capacity:8,carriesCommander:!0},{name:`Radar drone`,layer:B.Air,speed:42,radius:2.8,altitude:40,hp:250,sight:140,radar:600,metal:150,energy:3e3,buildTime:3500,buildPower:0,weapons:[]},{name:`Cruiser`,layer:B.Sea,speed:18,radius:8,altitude:0,hp:3500,sight:160,radar:0,metal:900,energy:9e3,buildTime:14e3,buildPower:0,weapons:[{name:`Heavy naval guns`,range:180,damage:200,reload:3,kind:`shell`,speed:170,splash:10,land:!0,sea:!0,air:!1},Kd]},{name:`Sub hunter`,layer:B.Sea,speed:26,radius:5.5,altitude:0,hp:1400,sight:120,radar:0,metal:400,energy:4e3,buildTime:6500,buildPower:0,weapons:[{name:`Heavy depth charges`,range:70,damage:160,reload:2,kind:`instant`,speed:0,splash:0,land:!1,sea:!1,air:!1,sub:!0},{name:`Torpedoes`,range:110,damage:150,reload:3,kind:`instant`,speed:0,splash:0,land:!1,sea:!0,air:!1,sub:!0}],sonar:250},{name:`Interceptor`,layer:B.Air,speed:62,radius:2.6,altitude:40,hp:300,sight:160,radar:0,metal:140,energy:2500,buildTime:2800,buildPower:0,weapons:[{name:`Air-to-air guns`,range:70,damage:22,reload:.3,kind:`instant`,speed:0,splash:0,land:!1,sea:!1,air:!0}],faction:`agi`},{name:`EMP drone`,layer:B.Air,speed:50,radius:2.8,altitude:38,hp:250,sight:120,radar:0,metal:350,energy:6e3,buildTime:6e3,buildPower:0,weapons:[{name:`EMP charge`,range:12,damage:0,reload:1,kind:`instant`,speed:0,splash:0,land:!0,sea:!0,air:!0,orderOnly:!0,emp:!0}],faction:`man`},{name:`Satellite`,layer:B.Air,speed:90,radius:3,altitude:260,hp:500,sight:0,radar:900,metal:800,energy:15e3,buildTime:9e3,buildPower:0,weapons:[],orbital:!0},{name:`Nuclear missile`,layer:B.Air,speed:0,radius:1,altitude:0,hp:1,sight:0,radar:0,metal:1500,energy:3e4,buildTime:2e4,buildPower:0,weapons:[],stock:!0}],qd=e=>G[e].buildPower>0,Jd={[V.VehiclePlant]:[1,4],[V.Shipyard]:[2,5,7],[V.DronePad]:[3,6,8],[V.AdvVehiclePlant]:[9,12,13],[V.LaunchComplex]:[22,23],[V.AdvShipyard]:[10,18,19],[V.AdvDronePad]:[11,14,15,16,17,20,21]};function Yd(e,t){if(!G[e].buildPower)return!1;let n=H[t];return n.tier===2?n.t1Builds?e!==0:G[e].tier===2:!0}function Xd(e,t){return!t.faction||!e.faction||t.faction===e.faction}function Zd(e){let t=-e[0]*e[1],n=1-e[1]*e[1],r=-e[2]*e[1],i=Math.sqrt(t*t+n*n+r*r);i<1e-6&&(t=0,n=0,r=1,i=1),t/=i,n/=i,r/=i;let a=n*e[2]-r*e[1],o=r*e[0]-t*e[2],s=t*e[1]-n*e[0];return{north:[t,n,r],east:[a,o,s]}}function Qd(e,t,n,r){let i=Zd(e),a=e[0]+(t*i.east[0]+n*i.north[0])/r,o=e[1]+(t*i.east[1]+n*i.north[1])/r,s=e[2]+(t*i.east[2]+n*i.north[2])/r,c=Math.sqrt(a*a+o*o+s*s);return a/=c,o/=c,s/=c,[a,o,s]}var $d=e=>Jd[e]!==void 0;function ef(e){let t=[0,0,0,0];for(let n=0;n<e.count;n++)e.alive[n]&&t[e.team[n]]++;return t}function tf(e,t,n,r=0){if(!t.alive||!t.complete||!$d(t.type)||t.prod.length===0)return null;if(n[t.team]>=300&&!G[t.prod[0]].stock)return t.capWarned||(t.capWarned=!0,e.message(t.team,`Unit cap reached (300) — factories wait`)),null;t.capWarned=!1;let i=t.prod[0];return{type:i,rate:((H[t.type].factoryPower??Dd.buildPower)+r)/G[i].buildTime}}function nf(e,t,n,r){if(!t.alive||!(Jd[t.type]??[]).includes(n)||!Xd(e.teams[t.team],G[n]))return;if(r>0){t.prod.length<Dd.queueMax&&t.prod.push(n);return}let i=t.prod.lastIndexOf(n);if(!(i<0)){if(i===0&&t.prodProgress>0){let r=G[n],i=e.teams[t.team];i.metal=Math.min(i.metalCap,i.metal+r.metal*t.prodProgress),i.energy=Math.min(i.energyCap,i.energy+r.energy*t.prodProgress),t.prodProgress=0}t.prod.splice(i,1)}}function rf(e,t,n){let r=e.planet,i=r.radius,a=H[t.type].radius,o=G[n].layer;if(o===B.Air)return[t.x,t.y,t.z];if(o===B.Sea){let e=r.nearestCell(t.cell,e=>{if(r.land[e])return!1;for(let t=r.adjStart[e];t<r.adjStart[e+1];t++)if(r.land[r.adj[t]])return!1;return!0},3e3);return e>=0?hm(r,e):[t.x,t.y,t.z]}let s=Qd([t.x,t.y,t.z],0,a+5,i),c=r.cellOf(...s);if(vd(r,B.Land,c)&&!e.blocked[c])return s;let l=r.nearestCell(c,t=>vd(r,B.Land,t)&&!e.blocked[t],3e3);return l>=0?hm(r,l):s}function af(e,t){let n=t.prod.shift();if(t.prodProgress=0,G[n].stock){t.stock=(t.stock??0)+1,e.message(t.team,`${G[n].name} ready (${t.stock} in stock)`);return}let r=rf(e,t,n),i=e.spawn(n,t.team,r);if(i<0)return;e.teams[t.team].stats.unitsBuilt++,e.events.push({kind:`unit-built`,tick:e.tick,unit:i,struct:t.id});let a=e.planet.radius,o=t.rally??r;t.rally||(o=G[n].layer===B.Land?Qd([t.x,t.y,t.z],0,H[t.type].radius+18,a):G[n].layer===B.Air?Qd([t.x,t.y,t.z],0,25,a):r),K(...o,...r)*a>2&&e.applyMove({ids:[i],target:o})}function of(e,t,n=V.Shipyard){let r=e.planet,i=r.radius,a=(H[n].radius+Dd.shipyardWater)/i,o=r.cellOf(...t);return r.nearestCell(o,e=>!r.land[e]&&K(r.cx[e],r.cy[e],r.cz[e],...t)<=a,400)>=0}var sf=(e,t=W.Transport)=>G[e].layer===B.Land&&(e!==W.Commander||!!G[t].carriesCommander);function cf(e,t){return e.cargo[t]??(e.cargo[t]=[])}function lf(e,t,n){if(!(n<0||n>=e.count||!e.alive[n]||!G[e.type[n]].capacity)){e.hasOrder[n]=0,e.releaseField(n),e.unloading[n]=0;for(let r of t)r<0||r>=e.count||!e.alive[r]||e.team[r]!==e.team[n]||!sf(e.type[r],e.type[n])||e.carriedBy[r]>=0||(e.boarding[r]=n,e.buildTask[r]=-1,e.buildQueue[r]=[],e.attack[r]=-1,e.driving[r]=0,e.applyMove({ids:[r],target:[e.x[n],e.y[n],e.z[n]]}))}}function uf(e,t,n){t<0||t>=e.count||!e.alive[t]||!cf(e,t).length||e.planet.land[e.planet.cellOf(n[0],n[1],n[2])]&&(e.unloading[t]=1,e.unloadX[t]=n[0],e.unloadY[t]=n[1],e.unloadZ[t]=n[2],e.applyMove({ids:[t],target:n}))}function df(e){let t=e.planet.radius;for(let n=0;n<e.count;n++){let r=e.boarding[n];if(r<0)continue;let i=G[e.type[r]]?.capacity??0;!e.alive[n]||!e.alive[r]||e.team[r]!==e.team[n]||cf(e,r).length>=i?e.boarding[n]=-1:K(e.x[n],e.y[n],e.z[n],e.x[r],e.y[r],e.z[r])*t<=12?(e.boarding[n]=-1,e.carriedBy[n]=r,cf(e,r).push(n),e.hasOrder[n]=0,e.releaseField(n)):e.hasOrder[n]||e.applyMove({ids:[n],target:[e.x[r],e.y[r],e.z[r]]})}for(let n=0;n<e.count;n++){if(!e.unloading[n])continue;if(!e.alive[n]){e.unloading[n]=0;continue}let r=K(e.x[n],e.y[n],e.z[n],e.unloadX[n],e.unloadY[n],e.unloadZ[n])*t;if(e.hasOrder[n]&&r>6)continue;e.unloading[n]=0;let i=cf(e,n),a=[e.x[n],e.y[n],e.z[n]];for(let n=0;n<i.length;n++){let r=i[n];if(!e.alive[r])continue;let o=[[6,0],[-6,0],[0,6],[0,-6],[6,6],[-6,-6],[6,-6],[-6,6]][n%8],s=Qd(a,o[0],o[1],t),c=e.planet.cellOf(s[0],s[1],s[2]),l=e.planet.land[c]?s:a;e.x[r]=l[0],e.y[r]=l[1],e.z[r]=l[2],e.px[r]=l[0],e.py[r]=l[1],e.pz[r]=l[2],e.cell[r]=e.planet.cellOf(l[0],l[1],l[2]),e.elev[r]=e.elevationFor(r),e.prevElev[r]=e.elev[r],e.carriedBy[r]=-1}i.length=0}}function ff(e,t){for(let n=0;n<e.count;n++){let r=e.cargo[n];if(r&&r.length){if(e.alive[n])for(let t of r)e.x[t]=e.x[n],e.y[t]=e.y[n],e.z[t]=e.z[n],e.cell[t]=e.cell[n];else{for(let n of r)e.carriedBy[n]=-1,t(n);r.length=0}}}}var pf=()=>({n:0,sx:[],sy:[],sz:[],sr:[],m:0,rx:[],ry:[],rz:[],rr:[],o:0,ox:[],oy:[],oz:[],or:[]});function mf(e){let t=e.planet.radius,n=e.sensors;for(let e=0;e<n.length;e++)n[e].n=0,n[e].m=0,n[e].o=0;let r=(e,n,r,i,a,o,s)=>{if(a>0){let o=e.n++;e.sx[o]=n,e.sy[o]=r,e.sz[o]=i,e.sr[o]=a/t}if(o>0){let a=e.m++;e.rx[a]=n,e.ry[a]=r,e.rz[a]=i,e.rr[a]=o/t}if(s>0){let a=e.o++;e.ox[a]=n,e.oy[a]=r,e.oz[a]=i,e.or[a]=s/t}};for(let t=0;t<e.count;t++){if(!e.alive[t]||e.carriedBy[t]>=0)continue;let i=n[e.team[t]];if(!i)continue;let a=G[e.type[t]];r(i,e.x[t],e.y[t],e.z[t],a.sight,a.radar,a.sonar??0)}for(let t of e.structures){if(!t.alive||!t.complete)continue;let i=H[t.type],a=t.type===V.Radar&&e.teams[t.team].radarPowered?i.radar??0:0;r(n[t.team],t.x,t.y,t.z,i.sight,a,i.sonar??0)}e.sensorsTick=e.tick}function hf(e,t){gf(e);let n=e.sensors[t];if(!n)return[];let r=[];for(let t=0;t<n.m;t++)r.push({dir:[n.rx[t],n.ry[t],n.rz[t]],radius:n.rr[t]*e.planet.radius});return r}function gf(e){e.sensorsTick!==e.tick&&mf(e)}function _f(e,t,n,r,i,a,o,s){for(let c=0;c<e;c++){let e=t[c]-a,l=n[c]-o,u=r[c]-s,d=i[c];if(e*e+l*l+u*u<=d*d)return!0}return!1}function vf(e,t,n){gf(e);let r=e.sensors[t];return _f(r.n,r.sx,r.sy,r.sz,r.sr,n[0],n[1],n[2])}function yf(e,t,n,r){return n<0||n===t||e.viewFiltered||vf(e,t,r)}function bf(e,t,n){gf(e);let r=e.sensors[t];return _f(r.n,r.sx,r.sy,r.sz,r.sr,n[0],n[1],n[2])||_f(r.m,r.rx,r.ry,r.rz,r.rr,n[0],n[1],n[2])}function xf(e,t,n){gf(e);let r=e.sensors[t];return _f(r.o,r.ox,r.oy,r.oz,r.or,e.x[n],e.y[n],e.z[n])}function Sf(e,t,n){if(e.carriedBy[n]>=0)return e.team[n]===t?2:0;if(e.team[n]===t)return 2;if(G[e.type[n]].submerged)return xf(e,t,n)?2:0;gf(e);let r=e.sensors[t],i=e.x[n],a=e.y[n],o=e.z[n];return _f(r.n,r.sx,r.sy,r.sz,r.sr,i,a,o)?2:+!!_f(r.m,r.rx,r.ry,r.rz,r.rr,i,a,o)}function Cf(){return[0,1,2,3].map(pf)}G[W.Commander].radar;function wf(e,t,n,r){let i=e.planet.radius;for(let a=0;a<e.count;a++){if(!e.alive[a]||G[e.type[a]].submerged||e.carriedBy[a]>=0)continue;let o=K(e.x[a],e.y[a],e.z[a],t[0],t[1],t[2])*i;o>n||Hf(e,a,r(e.maxHp(a))*(1-.5*o/n))}for(let a of e.structures){if(!a.alive)continue;let o=K(a.x,a.y,a.z,t[0],t[1],t[2])*i,s=n+H[a.type].radius*.5;o>s||Wf(e,a,r(H[a.type].hp)*(1-.5*Math.min(1,o/s)))}}function Tf(e,t,n){let r=K(t[0],t[1],t[2],n[0],n[1],n[2]),i=r+r*r*r/24;return Math.round((Id.flightMin+Id.flightPerRad*i)*20)}function Ef(e,t){let{north:n,east:r}=Zd([e.x,e.y,e.z]),i=t[0]-e.x,a=t[1]-e.y,o=t[2]-e.z,s=i*r[0]+a*r[1]+o*r[2],c=i*n[0]+a*n[1]+o*n[2],l=Math.sqrt(s*s+c*c);if(l<1e-9)return!0;if(s/=l,c/=l,e.aimE*s+e.aimN*c>=Id.turnCos)return e.aimE=s,e.aimN=c,!0;let u=e.aimE*c-e.aimN*s,d=Id.turnCos,f=u>=0?Id.turnSin:-Id.turnSin,p=e.aimE*d-e.aimN*f,m=e.aimE*f+e.aimN*d,h=Math.sqrt(p*p+m*m);return p/=h,m/=h,e.aimE=p,e.aimN=m,p*s+m*c>=Id.aimTolerance}function Df(e,t){let n=K(e[0],e[1],e[2],t[0],t[1],t[2]),r=n+n*n*n/24;return Math.round((Sd.flightMin+Sd.flightPerRad*r)*20)}function Of(e){for(let t of e.structures){if(!t.alive||!t.complete||t.type!==V.LaunchComplex||!t.target)continue;if(!(t.stock??0)){t.warned||=(e.message(t.team,`Launch complex: no nuclear missile in stock — build one first`),!0);continue}if(!bf(e,t.team,t.target)){t.warned||=(e.message(t.team,`Launch complex: target not in sight or on radar — a satellite or radar must cover it`),!0);continue}t.warned=!1,t.stock=(t.stock??0)-1;let n=[t.x,t.y,t.z],r=[...t.target];e.shells.push({id:e.nextId++,team:t.team,from:n,to:r,launchTick:e.tick,impactTick:e.tick+Df(n,r),nuke:!0}),e.events.push({kind:`nuke-launch`,tick:e.tick,struct:t.id,to:r});for(let n=0;n<e.teams.length;n++)n!==t.team&&e.teams[n].started&&e.message(n,`Nuclear launch detected!`);t.target=null}}function kf(e){Of(e);let t=e.planet.radius;for(let n of e.structures){let r=n.type===V.Anvil;if(!n.alive||!n.complete||n.type!==V.Horizon&&!r)continue;let i=H[n.type].name,a=n.target?r?!0:Ef(n,n.target):!1;if(n.reload>0){n.reload--;continue}if(!n.target)continue;let o=e.teams[n.team];if(!bf(e,n.team,n.target)){n.warned||=(e.message(n.team,`${i}: target not in sight or on radar — send a unit, drone or radar to spot it`),!0);continue}let s=r?bd.shotEnergy:Id.shotEnergy;if(o.energy<s){n.warned||=(e.message(n.team,`${i}: not enough energy to fire`),!0);continue}if(!a)continue;n.warned=!1,o.energy-=s;let[c,l,u]=n.target,d=-u,f=c,p=Math.sqrt(d*d+f*f)||1;d/=p,f/=p;let m=l*f-u*0,h=u*d-c*f,g=c*0-l*d,_,v;do _=e.rng.next()*2-1,v=e.rng.next()*2-1;while(_*_+v*v>1);let y=(r?bd.scatter:Id.scatter)/t,b=c+(_*d+v*m)*y,x=l+(_*0+v*h)*y,S=u+(_*f+v*g)*y;p=Math.sqrt(b*b+x*x+S*S),b/=p,x/=p,S/=p;let C=[n.x,n.y,n.z],w=[b,x,S],T=r?{id:e.nextId++,team:n.team,from:C,to:w,launchTick:e.tick,impactTick:e.tick+bd.fall*20,rod:!0}:{id:e.nextId++,team:n.team,from:C,to:w,launchTick:e.tick,impactTick:e.tick+Tf(e,C,w)};e.shells.push(T),n.reload=(r?bd.reload:Id.reload)*20,n.target=null,e.events.push({kind:`horizon-launch`,tick:e.tick,struct:n.id,shell:T.id})}}function Af(e){for(let t=e.shells.length-1;t>=0;t--){let n=e.shells[t];if(!(n.impactTick>e.tick)){if(e.shells.splice(t,1),n.nuke){let t=-1;for(let r of e.structures)if(r.alive&&r.complete&&r.type===V.PointDefence&&r.team!==n.team&&!(K(r.x,r.y,r.z,...n.to)*e.planet.radius>Sd.defenceReach)&&e.rng.next()<Sd.stopChance){t=r.id;break}if(t>=0){e.events.push({kind:`nuke-stopped`,tick:e.tick,dir:n.to,by:t});continue}wf(e,n.to,Sd.radius,()=>Sd.damage),e.events.push({kind:`shell-impact`,tick:e.tick,dir:n.to,nuke:!0})}else n.rod?wf(e,n.to,bd.radius,()=>bd.damage):wf(e,n.to,Id.radius,()=>Id.damage),e.events.push({kind:`shell-impact`,tick:e.tick,dir:n.to,...n.rod?{rod:!0}:{}})}}}function jf(e,t,n,r,i,a,o,s,c){let l={id:e.nextId++,x:r,y:i,z:a,cell:e.planet.cellOf(r,i,a),radius:o,metal:s,metal0:s,alive:!0,from:t,type:n,hx:c[0],hy:c[1],hz:c[2],tick:e.tick};return e.wrecks.push(l),l}function Mf(e,t){let n=G[e.type[t]];return n.layer===B.Sea||!e.planet.land[e.planet.cellOf(e.x[t],e.y[t],e.z[t])]?!1:(jf(e,`unit`,e.type[t],e.x[t],e.y[t],e.z[t],n.radius*kd.sizeFraction,n.metal*kd.metalFraction,[e.hx[t],e.hy[t],e.hz[t]]),!0)}function Nf(e,t){let n=H[t.type],r=n.metal*t.progress*kd.metalFraction;r<=0||jf(e,`structure`,t.type,t.x,t.y,t.z,n.radius*kd.sizeFraction,r,[1,0,0])}function Pf(e,t){let n=e.wrecks,r=0,i=n.length-1;for(;r<=i;){let e=r+i>>1,a=n[e].id;if(a===t)return n[e];a<t?r=e+1:i=e-1}}function Ff(e){return e.radius+Nd.buildReach}function If(e){let t=e.planet.radius,n=[0,0,0,0];for(let r=0;r<e.count;r++){let i=e.buildTask[r];if(i<0||!e.alive[r]||e.hasOrder[r])continue;let a=Pf(e,i);if(!a||!a.alive||K(a.x,a.y,a.z,e.x[r],e.y[r],e.z[r])*t>Ff(a))continue;let o=e.teams[e.team[r]],s=Math.max(0,o.metalCap-o.metal),c=Math.min(a.metal,e.buildPowerOf(r)/Ad.workPerMetal*Ud,s);a.metal-=c,o.metal+=c,n[e.team[r]]+=c/Ud,a.metal<=1e-6&&(a.alive=!1,a.metal=0,e.events.push({kind:`reclaimed`,tick:e.tick,wreck:a.id}))}return n}var Lf=e=>-2-e,Rf=e=>e<=-2,zf=e=>-2-e;function Bf(e,t){if(!e.alive[t])return;let n=G[e.type[t]],r=n.layer===B.Sea||n.layer===B.Air&&!e.planet.land[e.planet.cellOf(e.x[t],e.y[t],e.z[t])];Mf(e,t),e.alive[t]=0,e.hasOrder[t]=0,e.releaseField(t),e.buildTask[t]=-1,e.buildQueue[t]=[],e.attack[t]=-1,e.guard[t]=0,e.teams[e.team[t]].stats.unitsLost++,e.events.push({kind:`destroyed`,tick:e.tick,dir:[e.x[t],e.y[t],e.z[t]],what:`unit`,big:e.type[t]===W.Commander,team:e.team[t],unitType:e.type[t],sink:r,elev:e.elev[t],heading:[e.hx[t],e.hy[t],e.hz[t]]}),e.type[t]===W.Commander&&(e.winRule===`commander`?Vf(e,e.team[t],`Commander destroyed`):e.message(e.team[t],`Commander destroyed — your side fights on`))}function Vf(e,t,n){if(!e.teams[t].lost){e.teams[t].lost=!0,e.message(t,`${n} — match lost`);for(let r=0;r<e.teams.length;r++)r!==t&&e.teams[r].started&&!e.teams[r].lost&&e.teams[t].started&&e.message(r,e.matchResult(r)===`victory`?`${n===`Commander destroyed`?`Enemy Commander destroyed`:`Last enemy destroyed`} — victory!`:`${Ld[t]}: ${n.toLowerCase()}`)}}function Hf(e,t,n){e.alive[t]&&(e.hp[t]-=n,e.hp[t]<=0&&Bf(e,t))}function Uf(e,t){if(!t.alive)return;t.alive=!1,t.site>=0&&e.sites[t.site].mine===t.id&&(e.sites[t.site].mine=-1),Nf(e,t),t.type!==V.PracticeTarget&&e.teams[t.team].stats.structsLost++;let n=t.complete?t.type===V.Fission?wd:t.type===V.Fusion?xd:null:null;e.events.push({kind:`destroyed`,tick:e.tick,dir:[t.x,t.y,t.z],what:`structure`,big:t.type===V.Horizon||t.type===V.Anvil||!!n,team:t.team,...n?{blast:n.radius}:{}}),n&&wf(e,[t.x,t.y,t.z],n.radius,()=>n.damage)}function Wf(e,t,n){t.alive&&(t.hp-=n,t.hp<=0&&Uf(e,t))}function Gf(e,t){return t===B.Land?e.land:t===B.Sea?e.sea:e.air}function Kf(e,t,n,r){if(e.carriedBy[r]>=0)return!1;let i=G[e.type[r]];return i.orbital?!1:i.submerged?!!n.sub&&xf(e,t,r):Gf(n,i.layer)}function qf(e,t,n,r){if(r===-1)return!1;if(Rf(r)){let i=e.structById(zf(r));return!!i&&i.alive&&i.team!==e.team[t]&&n.land}return r<e.count&&e.alive[r]===1&&e.team[r]!==e.team[t]&&Kf(e,e.team[t],n,r)}function Jf(e,t,n){let r=e.planet.radius;if(Rf(n)){let i=e.structById(zf(n));return Math.max(0,K(i.x,i.y,i.z,e.x[t],e.y[t],e.z[t])*r-H[i.type].radius)}return K(e.x[n],e.y[n],e.z[n],e.x[t],e.y[t],e.z[t])*r}function Yf(e,t){if(Rf(t)){let n=e.structById(zf(t));return n&&n.alive?[n.x,n.y,n.z]:null}return t>=0&&t<e.count&&e.alive[t]?[e.x[t],e.y[t],e.z[t]]:null}function Xf(e,t,n){let r=0;for(let i of G[e.type[t]].weapons)qf(e,t,i,n)&&(r=Math.max(r,i.range));return r}function Zf(e,t,n,r,i){let a=e.planet.radius,o=e.team[t],s=e.x[t],c=e.y[t],l=e.z[t],u=r/a,d=r>G[e.type[t]].sight,f=t=>vf(e,o,t)||bf(e,o,t),p=-1,m=u*u;for(let t=0;t<i.length;t++){if(t===o)continue;let r=i[t];for(let t=0;t<r.length;t++){let i=r[t];if(!e.alive[i]||!Kf(e,o,n,i))continue;let a=e.x[i]-s,u=e.y[i]-c,h=e.z[i]-l,g=a*a+u*u+h*h;g<m&&(!d||f([e.x[i],e.y[i],e.z[i]]))&&(m=g,p=i)}}if(p!==-1||!n.land)return p;let h=1/0;for(let t of e.structures){if(!t.alive||t.team===o)continue;let e=K(t.x,t.y,t.z,s,c,l)*a-H[t.type].radius;e<=r&&e<h&&(!d||f([t.x,t.y,t.z]))&&(h=e,p=Lf(t.id))}return p}function Qf(e){let t=[[],[],[],[]];for(let n=0;n<e.count;n++)e.alive[n]&&t[e.team[n]].push(n);return t}function $f(e){let t=Qf(e),n=e.count;for(let r=0;r<n;r++){if(!e.alive[r]||e.carriedBy[r]>=0||e.disabledUntil[r]>e.tick)continue;let n=G[e.type[r]].weapons;for(let i=0;i<n.length&&i<3;i++){let a=e.reload[i];if(a[r]>0&&(a[r]--,a[r]>0))continue;if(!e.alive[r])break;let o=n[i],s=e.aim[i],c=-1,l=e.attack[r];if(qf(e,r,o,l)&&Jf(e,r,l)<=o.range)c=l;else if(e.holdFire[r]||o.orderOnly){s[r]=-1;continue}else qf(e,r,o,s[r])&&Jf(e,r,s[r])<=o.range?c=s[r]:(e.tick+r)%4==0&&(c=Zf(e,r,o,o.range,t));s[r]=c,c!==-1&&(tp(e,r,i,o,c),a[r]=Math.max(1,Math.round(o.reload*20)))}}}function ep(e){let t=null,n=e.planet.radius;for(let r of e.structures){let i=H[r.type].weapon;if(!i||!r.alive||!r.complete||r.reload>0&&(r.reload--,r.reload>0))continue;let a=i.range/n,o=r.aimTarget;if(o>=0&&!(o<e.count&&e.alive[o]&&e.team[o]!==r.team&&Kf(e,r.team,i,o)&&K(e.x[o],e.y[o],e.z[o],r.x,r.y,r.z)<=a)&&(o=-1),o<0){t??=Qf(e);let n=a*a;for(let a=0;a<t.length;a++)if(a!==r.team)for(let s of t[a]){if(!e.alive[s]||!Kf(e,r.team,i,s))continue;let t=e.x[s]-r.x,a=e.y[s]-r.y,c=e.z[s]-r.z,l=t*t+a*a+c*c;l<n&&(n=l,o=s)}}if(r.aimTarget=o,!(o<0)){if(e.events.push({kind:`struct-shot`,tick:e.tick,struct:r.id,to:[e.x[o],e.y[o],e.z[o]],toElev:e.elev[o]}),i.kind===`shell`){let t=K(e.x[o],e.y[o],e.z[o],r.x,r.y,r.z)*n,a=Math.max(1,Math.round(t/i.speed*20));e.projectiles.push({id:e.nextProjectile++,team:r.team,from:[r.x,r.y,r.z],fromElev:12,to:[e.x[o],e.y[o],e.z[o]],toElev:e.elev[o],launchTick:e.tick,impactTick:e.tick+a,damage:i.damage,splash:i.splash,land:i.land,sea:i.sea})}else Hf(e,o,i.damage);r.reload=Math.max(1,Math.round(i.reload*20))}}}function tp(e,t,n,r,i){let a=Yf(e,i),o=Rf(i)?4:e.elev[i];if(r.salvo){rp(e,t,r,a,o);return}if(r.emp){np(e,t);return}if(e.events.push({kind:`shot`,tick:e.tick,unit:t,weapon:n,to:a,toElev:o,instant:r.kind===`instant`}),r.kind===`instant`){Rf(i)?Wf(e,e.structById(zf(i)),r.damage):Hf(e,i,r.damage);return}let s=Jf(e,t,i)+(Rf(i)?H[e.structById(zf(i)).type].radius:0),c=Math.max(1,Math.round(s/r.speed*20));e.projectiles.push({id:e.nextProjectile++,team:e.team[t],from:[e.x[t],e.y[t],e.z[t]],fromElev:e.elev[t]+2,to:a,toElev:o,launchTick:e.tick,impactTick:e.tick+c,damage:r.damage,splash:r.splash,land:r.land,sea:r.sea})}function np(e,t){let n=e.planet.radius,r=e.tick+Cd.seconds*20,i=[e.x[t],e.y[t],e.z[t]];e.events.push({kind:`emp`,tick:e.tick,dir:i,radius:Cd.radius});for(let a=0;a<e.count;a++)if(!(!e.alive[a]||a===t||e.carriedBy[a]>=0)&&!(K(e.x[a],e.y[a],e.z[a],...i)*n>Cd.radius)){if(e.type[a]===W.Commander)e.slowUntil[a]=Math.max(e.slowUntil[a],r);else if(G[e.type[a]].orbital)continue;else G[e.type[a]].layer===B.Air?Bf(e,a):e.disabledUntil[a]=Math.max(e.disabledUntil[a],r)}Bf(e,t)}function rp(e,t,n,r,i){let a=e.planet.radius,o=r[0]-e.x[t],s=r[1]-e.y[t],c=r[2]-e.z[t],l=o*r[0]+s*r[1]+c*r[2];o-=l*r[0],s-=l*r[1],c-=l*r[2];let u=Math.sqrt(o*o+s*s+c*c);u<1e-9&&(o=1,s=0,c=0,u=1),o/=u,s/=u,c/=u;let d=n.salvo;e.events.push({kind:`shot`,tick:e.tick,unit:t,weapon:0,to:r,toElev:i,instant:!1});for(let i=0;i<d;i++){let l=(i-(d-1)/2)*9/a,u=r[0]+o*l,f=r[1]+s*l,p=r[2]+c*l,m=Math.sqrt(u*u+f*f+p*p);u/=m,f/=m,p/=m,e.projectiles.push({id:e.nextProjectile++,team:e.team[t],from:[e.x[t],e.y[t],e.z[t]],fromElev:e.elev[t],to:[u,f,p],toElev:0,launchTick:e.tick,impactTick:e.tick+i*2+Math.max(1,Math.round(e.elev[t]/n.speed*20)),damage:n.damage,splash:n.splash,land:n.land,sea:n.sea})}let f=r[0]+80/a*o,p=r[1]+80/a*s,m=r[2]+80/a*c,h=Math.sqrt(f*f+p*p+m*m);f/=h,p/=h,m/=h,e.applyMove({ids:[t],target:[f,p,m]},!0)}function ip(e){let t=e.planet.radius;for(let n=0;n<e.projectiles.length;){let r=e.projectiles[n];if(r.impactTick>e.tick){n++;continue}e.projectiles.splice(n,1);let[i,a,o]=r.to;for(let n=0;n<e.count;n++){if(!e.alive[n]||e.team[n]===r.team)continue;let s=G[e.type[n]];if(s.layer===B.Air||s.submerged||e.carriedBy[n]>=0||s.layer===B.Land&&!r.land||s.layer===B.Sea&&!r.sea)continue;let c=K(e.x[n],e.y[n],e.z[n],i,a,o)*t-s.radius;c>r.splash||Hf(e,n,r.damage*(1-.5*Math.max(0,c)/r.splash))}if(r.land)for(let n of e.structures){if(!n.alive||n.team===r.team)continue;let s=K(n.x,n.y,n.z,i,a,o)*t-H[n.type].radius;s<=r.splash&&Wf(e,n,r.damage*(1-.5*Math.max(0,s)/r.splash))}e.events.push({kind:`proj-impact`,tick:e.tick,dir:r.to,splash:r.splash,water:!e.planet.land[e.planet.cellOf(i,a,o)]})}}function ap(e){let t=e.planet.radius,n=[];for(let r=0;r<e.count;r++){let i=e.attack[r];if(i===-1||!e.alive[r])continue;let a=Yf(e,i),o=a?Xf(e,r,i):0,s=Rf(i)||bf(e,e.team[r],a??[0,0,1])||G[e.type[i]].submerged===!0&&xf(e,e.team[r],i);if(!a||o===0||!s){e.attack[r]=-1,e.guard[r]||(e.hasOrder[r]=0,e.releaseField(r));continue}let c=G[e.type[r]].flyover;if(c){if(e.reload[0][r]>0)continue}else if(Jf(e,r,i)<=o*.9){e.hasOrder[r]&&(e.hasOrder[r]=0,e.releaseField(r));continue}let l=!e.hasOrder[r];if(!l&&(c||(e.tick+r)%40==0)&&(l=K(e.tx[r],e.ty[r],e.tz[r],a[0],a[1],a[2])*t>20),!l)continue;let u=n.find(e=>e.enc===i);u||(u={enc:i,ids:[]},n.push(u)),u.ids.push(r)}for(let r of n){e.applyMove({ids:r.ids,target:Yf(e,r.enc)},!0);for(let n of r.ids)e.hasOrder[n]&&K(e.tx[n],e.ty[n],e.tz[n],e.x[n],e.y[n],e.z[n])*t>8||G[e.type[n]].flyover&&Jf(e,n,r.enc)<=Xf(e,n,r.enc)||(e.attack[n]=-1,e.hasOrder[n]=0,e.releaseField(n),e.guard[n]?e.guardWait[n]=e.tick+100:e.message(e.team[n],`${G[e.type[n]].name} can't reach its target`))}}function op(e){let t=e.planet.radius,n=null;for(let r=0;r<e.count;r++){if(!e.guard[r]||!e.alive[r]||(e.tick+r)%jd.checkEvery!==0)continue;let i=e.gpx[r],a=e.gpy[r],o=e.gpz[r],s=K(i,a,o,e.x[r],e.y[r],e.z[r])*t;if(e.attack[r]!==-1){s>jd.leash&&(e.attack[r]=-1,e.applyMove({ids:[r],target:[i,a,o]},!0));continue}if(e.guardWait[r]>e.tick)continue;n??=Qf(e);let c=G[e.type[r]],l=-1,u=1/0;for(let s=0;s<n.length;s++)if(s!==e.team[r])for(let d of n[s]){if(!e.alive[d]||Xf(e,r,d)===0)continue;let n=K(e.x[d],e.y[d],e.z[d],e.x[r],e.y[r],e.z[r])*t;n>c.sight||n>=u||K(e.x[d],e.y[d],e.z[d],i,a,o)*t>jd.leash-10||(u=n,l=d)}l===-1?s>jd.home&&!e.hasOrder[r]&&e.applyMove({ids:[r],target:[i,a,o]},!0):e.attack[r]=l}}var sp=-1,cp=new Set([`move`,`stop`,`build`,`assist`,`reclaim`,`reclaim-struct`,`attack`,`load`]);function lp(e,t){if(t.kind===`drive`)t.dir&&t.id>=0&&t.id<e.count&&(e.patrol[t.id]=null);else if(cp.has(t.kind)&&`ids`in t)for(let n of t.ids)n>=0&&n<e.count&&(e.patrol[n]=null)}function up(e,t,n=-1){for(let r of t){let t=e.structById(r);!t||!t.alive||n>=0&&t.team!==n||Uf(e,t)}}function dp(e,t,n){let r=e.structById(n);if(r&&r.alive)for(let n of t)n<0||n>=e.count||!e.alive[n]||!qd(e.type[n])||e.team[n]!==r.team||(e.buildQueue[n]=[],e.buildTask[n]=r.id,e.unbuildOf[n]=r.id,e.assistOf[n]=-1,e.attack[n]=sp,e.hasOrder[n]=0,e.releaseField(n))}function fp(e,t,n){for(let r of t)r<0||r>=e.count||!e.alive[r]||(e.holdFire[r]=+(n===1),e.aggressive[r]=+(n===2))}function pp(e,t,n,r){if(n.length)for(let i of t)i<0||i>=e.count||!e.alive[i]||!G[e.type[i]].weapons.length||(e.buildTask[i]=-1,e.buildQueue[i]=[],e.attack[i]=sp,e.patrol[i]=[[e.x[i],e.y[i],e.z[i]],...n.map(e=>[e[0],e[1],e[2]])],e.patrolIdx[i]=1,e.patrolDir[i]=1,e.patrolLoop[i]=+!!r,e.applyMove({ids:[i],target:e.patrol[i][1]}))}function mp(e){let t=e.planet.radius;for(let n=0;n<e.count;n++){if(!e.alive[n]||e.carriedBy[n]>=0)continue;if(e.aggressive[n]&&e.attack[n]===sp&&(n+e.tick)%10==0){let r=G[e.type[n]],i=-1,a=r.sight/t*(r.sight/t);for(let t=0;t<e.count;t++){if(!e.alive[t]||e.team[t]===e.team[n]||e.unitSeenBy(e.team[n],t)!==2||!r.weapons.some(r=>Kf(e,e.team[n],r,t)))continue;let o=e.x[t]-e.x[n],s=e.y[t]-e.y[n],c=e.z[t]-e.z[n],l=o*o+s*s+c*c;l<a&&(a=l,i=t)}i>=0&&(e.attack[n]=i,e.hasOrder[n]=0,e.releaseField(n))}let r=e.patrol[n];if(!r||e.hasOrder[n]||e.attack[n]!==sp)continue;let i=r[e.patrolIdx[n]],a=K(e.x[n],e.y[n],e.z[n],i[0],i[1],i[2])*t<25;(a||(n+e.tick)%40==0)&&(a&&(e.patrolLoop[n]?e.patrolIdx[n]=(e.patrolIdx[n]+1)%r.length:((e.patrolIdx[n]+e.patrolDir[n]<0||e.patrolIdx[n]+e.patrolDir[n]>=r.length)&&(e.patrolDir[n]=-e.patrolDir[n]),e.patrolIdx[n]+=e.patrolDir[n])),e.applyMove({ids:[n],target:r[e.patrolIdx[n]]}))}}function hp(e,t){let n=Vd[t.level];return e.techLimit>=2?n:{...n,t2At:0,nukes:!1,reactors:0,towers:0,t2Builders:0}}var gp=[V.Wind,V.Wind,V.Solar,V.MetalMine,V.MetalMine,V.VehiclePlant,V.Solar,V.Wind,V.MetalMine,V.DronePad,V.Storage,V.Solar,V.Radar,V.Shipyard,V.Solar];function _p(e){return e.metal>e.metalCap*2*Od.reserveFrac&&e.energy>e.energyCap*2*Od.reserveFrac}function vp(e,t,n){let r=hp(e,t),i=e.teams[t.team],a=n=>{let r=0;for(let i of e.structures)i.alive&&i.team===t.team&&i.type===n&&r++;return r},o=0,s=0;for(let n of e.structures){if(!n.alive||!n.complete||n.team!==t.team||n.type!==V.Solar)continue;let r=H[V.Solar].energyOut??0;o+=r*Hd.solarPeak*e.sunlight(n.x,n.y,n.z),s+=r*.5}let c=i.energyIn-o+s;if(G[n].tier===2){if(i.energy>i.energyCap*.4&&c-i.energyOut>(H[V.AdvMine].energyUpkeep??0)+Od.upkeepSpare&&jp(e,t,V.AdvMine))return V.AdvMine;if(a(V.Fission)<r.reactors&&(a(V.Fission)===0||i.energy<i.energyCap*.5)&&wp(e,t,V.Fission))return V.Fission;let n=i.faction===`man`?V.Anvil:i.faction===`agi`?V.Horizon:null;if(n!==null&&a(n)===0&&jp(e,t,n))return n;if(a(V.AdvVehiclePlant)>0&&a(V.AdvDronePad)===0&&jp(e,t,V.AdvDronePad))return V.AdvDronePad;if(a(V.AdvVehiclePlant)>0&&a(V.AdvShipyard)===0&&jp(e,t,V.AdvShipyard))return V.AdvShipyard;if(r.nukes&&a(V.LaunchComplex)===0&&jp(e,t,V.LaunchComplex))return V.LaunchComplex;if(a(V.HeavyTower)<r.towers&&jp(e,t,V.HeavyTower))return V.HeavyTower;if(r.nukes&&a(V.LaunchComplex)>0&&a(V.PointDefence)<2&&jp(e,t,V.PointDefence))return V.PointDefence;if(a(V.Fission)>0&&a(V.Fusion)===0&&i.energy<i.energyCap*.5&&wp(e,t,V.Fusion))return V.Fusion}if(r.t2At>0&&Yd(n,V.AdvVehiclePlant)&&e.tick>=t.startTick+r.t2At*20&&a(V.AdvVehiclePlant)===0&&i.metal>=Od.t2Metal)return V.AdvVehiclePlant;let l=e.sunlight(t.base[0],t.base[1],t.base[2])<.2;if(t.step<gp.length){let e=gp[t.step++];return e===V.Solar&&l?V.Wind:e}let u=e.teams[t.team],d=n=>{let r=0;for(let i of e.structures)i.alive&&i.team===t.team&&i.type===n&&r++;return r};if(d(V.Radar)===0)return V.Radar;let f=hp(e,t),p=d(V.AaGun);if(p<f.aaEarly||p<f.aaMax&&yp(e,t))return V.AaGun;if(u.energy<u.energyCap*.25||c-u.energyOut<15&&u.energy<u.energyCap*.9){let n=t.step++%3;return n===2&&jp(e,t,V.Tidal)?V.Tidal:n===0||l?V.Wind:V.Solar}if(jp(e,t,V.MetalMine))return V.MetalMine;if(d(V.Shipyard)===0)return V.Shipyard;if(d(V.DronePad)<2&&u.metal>300)return V.DronePad;if(d(V.Storage)<2&&u.energy>=u.energyCap*.95)return V.Storage;if(d(V.Converter)<6&&u.energy>=u.energyCap*.9&&c-u.energyOut>Td.energyIn)return V.Converter;if(_p(u)){if(d(V.DronePad)<Od.maxFactories)return V.DronePad;if(d(V.Shipyard)<Od.maxFactories&&jp(e,t,V.Shipyard))return V.Shipyard;if(d(V.VehiclePlant)<Od.maxFactories)return V.VehiclePlant}return null}function yp(e,t){let n=300/e.planet.radius;for(let r=0;r<e.count;r++)if(e.alive[r]&&e.team[r]!==t.team&&e.type[r]===W.Drone&&K(e.x[r],e.y[r],e.z[r],t.base[0],t.base[1],t.base[2])<n)return!0;return!1}function bp(e,t=`easy`){return{team:e,started:!1,base:[1,0,0],step:0,wave:0,nextWave:0,warned:!1,level:t,made:0,startTick:0,plots:[],t2made:0,ferry:null,noSpot:[],searches:0,lastNuke:-1e9,target:-1}}function xp(e,t){let n=e.ai;n&&!n.started&&(n.level=t,e.teams[n.team].incomeMul=Vd[t].income)}function Sp(e){for(let t of e.ais)!t.started&&!e.teams[t.team].started&&Cp(e,t)}function Cp(e,t){let n=e.planet,r=[];for(let t of e.teams)t.started&&t.home&&r.push(t.home);let i=-1,a=-1;n.blobs.forEach((e,t)=>{if(e.kind===`small`)return;let n=1/0;for(let t of r)n=Math.min(n,K(e.c[0],e.c[1],e.c[2],t[0],t[1],t[2]));n>a&&(a=n,i=t)});let o=hm(n,n.nearestCell(n.cellOf(...n.blobs[Math.max(0,i)].c),e=>n.land[e]===1));e.setupStart(t.team,o),t.started=!0,t.base=o,t.startTick=e.tick,Op(e,t),e.teams[t.team].incomeMul=Vd[t.level].income,t.nextWave=e.tick+Vd[t.level].firstWave*20;for(let n=0;n<e.teams.length;n++)n!==t.team&&e.teams[n].started&&e.message(n,`An enemy Commander has landed on a distant island`)}function wp(e,t,n){let r=jp(e,t,n);if(r||!Tp(n))return r;let i=e.teams[t.team];return i.energy<i.energyCap*.3?jp(e,t,n,Od.lane):null}var Tp=e=>e===V.Fission||e===V.Fusion,Ep=new WeakMap;function Dp(e,t){let n=Ep.get(e);n||Ep.set(e,n=[]);let r=n[t.team];if(r)return r;let i=e.planet;r=new Uint8Array(i.cellCount);let a=i.cellOf(...t.base),o=[a];r[a]=1;for(let e=0;e<o.length;e++){let t=o[e];for(let e=i.adjStart[t];e<i.adjStart[t+1];e++){let t=i.adj[e];!r[t]&&vd(i,B.Land,t)&&(r[t]=1,o.push(t))}}return n[t.team]=r,r}function Op(e,t){if(t.plots=[],!hp(e,t).t2At)return;let n=e.planet,r=n.radius,i=Dp(e,t),a=null,o=1/0;for(let s=0;s<n.cellCount;s++){if(!i[s])continue;let c=hm(n,s),l=Math.abs(K(...c,...t.base)*r-Od.plotRing);if(l>=o)continue;let u=e.canPlace(V.AdvVehiclePlant,c,t.team);u&&(a=u.dir,o=l)}a&&t.plots.push({type:V.AdvVehiclePlant,at:a});let s=H[V.Fission].radius+H[V.AdvVehiclePlant].radius+Od.lane,c=null,l=-1;for(let o=0;o<n.cellCount;o++){if(!i[o])continue;let u=hm(n,o),d=K(...u,...t.base);if(d<=l||d*r>Od.mineRange||a&&K(...u,...a)*r<s)continue;let f=e.canPlace(V.Fission,u,t.team);f&&(c=f.dir,l=d)}c&&t.plots.push({type:V.Fission,at:c});let u=null,d=1/0,f=H[V.AdvShipyard].radius+Od.lane;for(let o=0;o<n.cellCount;o++){if(!i[o])continue;let s=hm(n,o),c=a??t.base,l=K(...s,...c);if(l>=d||l*r>Od.mineRange)continue;let p=!0;for(let e of t.plots)K(...s,...e.at)*r<f+H[e.type].radius&&(p=!1);if(!p)continue;let m=e.canPlace(V.AdvShipyard,s,t.team);m&&(u=m.dir,d=l)}u&&t.plots.push({type:V.AdvShipyard,at:u});let p=a=>{let o=null,s=1/0,c=H[a].radius+Od.lane;for(let l=0;l<n.cellCount;l++){if(!i[l])continue;let u=hm(n,l),d=Math.abs(K(...u,...t.base)*r-Od.plotRing);if(d>=s)continue;let f=!0;for(let e of t.plots)K(...u,...e.at)*r<c+H[e.type].radius+(e.type===V.Fission?Od.reactorClear:0)&&(f=!1);if(!f)continue;let p=e.canPlace(a,u,t.team);p&&(o=p.dir,s=d)}o&&t.plots.push({type:a,at:o})};p(V.AdvDronePad);let m=e.teams[t.team].faction;if(m&&p(m===`man`?V.Anvil:V.Horizon),hp(e,t).nukes){let a=null,o=-1,s=H[V.LaunchComplex].radius+Od.lane;for(let c=0;c<n.cellCount;c++){if(!i[c])continue;let l=hm(n,c),u=K(...l,...t.base);if(u<=o||u*r>Od.mineRange)continue;let d=!0;for(let e of t.plots)K(...l,...e.at)*r<s+H[e.type].radius+(e.type===V.Fission?Od.reactorClear:0)&&(d=!1);if(!d)continue;let f=e.canPlace(V.LaunchComplex,l,t.team);f&&(a=f.dir,o=u)}a&&t.plots.push({type:V.LaunchComplex,at:a})}}var kp=new WeakMap;function Ap(e,t){let n=kp.get(e);n||kp.set(e,n=[]);let r=n[t.team];if(r&&r.tick===e.tick)return r.m;let i=e.planet,a=r?.m??new Uint8Array(i.cellCount);a.fill(0);let o=[];for(let n=0;n<e.count;n++){if(!e.alive[n]||e.team[n]!==t.team||!G[e.type[n]].buildPower||G[e.type[n]].layer!==B.Land)continue;let r=e.cell[n];a[r]||(a[r]=1,o.push(r))}for(let t=0;t<o.length;t++){let n=o[t];for(let t=i.adjStart[n];t<i.adjStart[n+1];t++){let n=i.adj[t];!a[n]&&!e.blocked[n]&&vd(i,B.Land,n)&&(a[n]=1,o.push(n))}}return n[t.team]={tick:e.tick,m:a},a}function jp(e,t,n,r=Od.reactorClear){let i=r===Od.reactorClear?n:n+100;if((t.noSpot[i]??0)>e.tick||t.searches<=0&&t.started&&e.tick>t.startTick)return null;t.searches--;let a=Mp(e,t,n,r);return a||(t.noSpot[i]=e.tick+Od.noSpotWait*20),a}function Mp(e,t,n,r){let i=e.planet,a=i.radius,o=Dp(e,t),s=H[n];if(n===V.MetalMine||n===V.AdvMine){let r=-1,s=Od.mineRange/a*(Od.mineRange/a);for(let a of e.sites){if(a.mine>=0&&!(n===V.AdvMine&&e.canPlace(n,[a.x,a.y,a.z],t.team)))continue;let c=a.x-t.base[0],l=a.y-t.base[1],u=a.z-t.base[2],d=c*c+l*l+u*u;d<s&&o[i.cellOf(a.x,a.y,a.z)]&&e.canPlace(n,[a.x,a.y,a.z],t.team)&&(s=d,r=a.id)}return r>=0?[e.sites[r].x,e.sites[r].y,e.sites[r].z]:null}for(let n=t.plots.length-1;n>=0;n--){let r=t.plots[n],i=0;for(let n of e.structures)!n.alive&&n.team===t.team&&n.type===r.type&&n.progress<.01&&K(n.x,n.y,n.z,...r.at)*a<2&&i++;i>=2&&t.plots.splice(n,1)}for(let r of t.plots)if(r.type===n&&e.canPlace(n,r.at,t.team))return r.at;let c=H[n].tier===2||n===V.Horizon||n===V.Anvil,l=Ap(e,t),u=c?45:$d(n)||n===V.Fission?32:22;for(let d=2;d<=u;d++)for(let u=-d;u<=d;u++)for(let f=-d;f<=d;f++){if(Math.max(Math.abs(u),Math.abs(f))!==d)continue;let p=Qd(t.base,u*10,f*10,a),m=i.cellOf(...p);if(i.land[m]&&(!o[m]||!l[m])||(n===V.Shipyard||n===V.AdvShipyard)&&!Ip(e,p,s.radius+Dd.shipyardWater))continue;let h=e.canPlace(n,p);if(!h)continue;let g=i.cellOf(...h.dir);if(i.land[g]?!o[g]||!l[g]:!Wp(e,h.dir,Ed.shoreReach))continue;let _=!0;for(let t of e.structures){if(!t.alive)continue;let e=Tp(n)||Tp(t.type)?r:c?Od.lane/2:Od.lane;if(K(t.x,t.y,t.z,...h.dir)*a<s.radius+H[t.type].radius+e){_=!1;break}}for(let e of t.plots)_&&K(...e.at,...h.dir)*a<s.radius+H[e.type].radius+Od.lane&&(_=!1);let v=s.radius+H[V.AdvMine].radius+2;for(let t of e.sites)_&&t.mine<0&&K(t.x,t.y,t.z,...h.dir)*a<v&&(_=!1);if(_)return h.dir}return null}function Np(e,t){let n=[];for(let r=0;r<e.count;r++)e.alive[r]&&e.team[r]===t&&n.push(r);return n}function Pp(e,t){let n=t.target>=0?e.teams[t.target]:null;if(n&&n.started&&!n.lost)return t.target;let r=e.teams.map(e=>e.started&&!e.lost?e.home??null:null);for(let t=0;t<e.count;t++)e.alive[t]&&e.type[t]===W.Commander&&r[e.team[t]]&&(r[e.team[t]]=[e.x[t],e.y[t],e.z[t]]);let i=-1,a=1/0;for(let e=0;e<r.length;e++){let n=r[e];if(e===t.team||!n)continue;let o=K(n[0],n[1],n[2],...t.base);o<a&&(a=o,i=e)}return t.target=i}function Fp(e,t){let n=t.target;if(n<0)return null;for(let t=0;t<e.count;t++)if(e.alive[t]&&e.team[t]===n&&e.type[t]===W.Commander)return[e.x[t],e.y[t],e.z[t]];let r=null,i=1/0;for(let a of e.structures){if(!a.alive||a.team!==n)continue;let e=K(a.x,a.y,a.z,...t.base);e<i&&(i=e,r=a)}return r?[r.x,r.y,r.z]:null}function Ip(e,t,n){let r=e.planet,i=r.radius;for(let e of[.5,1])for(let a=0;a<8;a++){let o=Lp[a],s=Qd(t,o[0]*n*e,o[1]*n*e,i);if(!r.land[r.cellOf(...s)])return!0}return!1}var Lp=[[1,0],[-1,0],[0,1],[0,-1],[.7,.7],[-.7,.7],[.7,-.7],[-.7,-.7]];function Rp(e){for(let t of e.ais)zp(e,t)}function zp(e,t){if(!t.started)return;let n=t.team,r=e.teams[n],i=hp(e,t),a=(n-Od.team+e.teams.length)%e.teams.length;if(r.lost||(e.tick+i.thinkEvery*e.teams.length-a)%i.thinkEvery!==0)return;Pp(e,t);let o=e.planet.radius,s=Np(e,n);if(t.searches=Od.searchesPerTurn,i.t2At>0&&e.tick>=t.startTick+i.t2At*20&&r.metal>=Od.t2Metal&&!e.structures.some(e=>e.alive&&e.team===n&&e.type===V.AdvVehiclePlant)){let n=s.find(t=>Yd(e.type[t],V.AdvVehiclePlant)&&G[e.type[t]].layer===B.Land),r=n===void 0?null:jp(e,t,V.AdvVehiclePlant);n!==void 0&&r&&Xp(e,{kind:`build`,ids:[n],structType:V.AdvVehiclePlant,target:r})}for(let i of s){let a=e.buildTask[i]>=0&&e.assistOf[i]===e.buildTask[i];if(!G[e.type[i]].buildPower||e.buildTask[i]>=0&&!a||e.hasOrder[i]||(e.buildQueue[i]?.length??0)>0)continue;let s=!1;for(let n=0;n<4&&!s;n++){let n=vp(e,t,e.type[i]);if(n===null)break;let r=wp(e,t,n);r&&(Xp(e,{kind:`build`,ids:[i],structType:n,target:r}),s=!0)}if(s)continue;if(_p(r)){let t=-1,r=1/0;for(let a of e.structures){if(!a.alive||a.team!==n||!a.complete||!$d(a.type))continue;let o=K(a.x,a.y,a.z,e.x[i],e.y[i],e.z[i]);o<r&&(r=o,t=a.id)}if(t>=0&&(e.assistOf[i]!==t||e.buildTask[i]!==t)){Xp(e,{kind:`assist`,ids:[i],structId:t});continue}if(t>=0)continue}let c=-1,l=Od.mineRange/o;for(let n of e.wrecks){if(!n.alive)continue;let e=K(n.x,n.y,n.z,...t.base);e<l&&(l=e,c=n.id)}c>=0&&Xp(e,{kind:`reclaim`,ids:[i],wreckId:c})}let c=r.metal<r.metalCap*Od.reserveFrac||r.energy<r.energyCap*Od.reserveFrac,l=!1;for(let t of e.structures)t.alive&&t.team===n&&t.type===V.AdvVehiclePlant&&(l=!0);let u=i.t2At>0&&e.tick>=t.startTick+i.t2At*20&&!l&&r.metal<Od.t2Metal,d=0,f=0;for(let t of s)e.type[t]===W.Builder?d++:e.type[t]===W.AdvBuilder&&f++;for(let a of e.structures){if(!a.alive||a.team!==n||!a.complete||!$d(a.type))continue;a.rally||Xp(e,{kind:`rally`,structIds:[a.id],target:Qd(t.base,0,-Od.rallyOffset,o)});let l=c?r.stall&&r.metal<Od.reserve||r.energy<r.energyCap*Od.energyPause?0:1:_p(r)?3:2;if(a.type===V.LaunchComplex){if(s.filter(t=>e.type[t]===W.Satellite).length+a.prod.filter(e=>e===W.Satellite).length===0){Xp(e,{kind:`factory-queue`,structId:a.id,unitType:W.Satellite,delta:1});continue}(a.stock??0)+a.prod.filter(e=>e===W.NukeMissile).length<2&&Xp(e,{kind:`factory-queue`,structId:a.id,unitType:W.NukeMissile,delta:1})}else if(a.type===V.AdvVehiclePlant||a.type===V.AdvDronePad||a.type===V.AdvShipyard){for(let e of a.prod)e===W.AdvBuilder&&f++;if(a.type===V.AdvVehiclePlant&&f<i.t2Builders){Xp(e,{kind:`factory-queue`,structId:a.id,unitType:W.AdvBuilder,delta:1});continue}for(;a.prod.length<l;){let n=a.prod.length;if(Xp(e,{kind:`factory-queue`,structId:a.id,unitType:Bp(e,t,a.type,s),delta:1}),a.prod.length===n)break}}else for(;a.prod.length<l&&(!u||a.type===V.VehiclePlant&&d<Od.builders);){let n=t.level!==`easy`&&t.made++%3==2,r=a.type===V.Shipyard?n?W.Sub:W.Boat:a.type===V.DronePad?W.Drone:W.Tank;a.type===V.VehiclePlant&&d<Od.builders&&(r=W.Builder,d++);let i=a.prod.length;if(Xp(e,{kind:`factory-queue`,structId:a.id,unitType:r,delta:1}),a.prod.length===i)break}}for(let t of s)e.guard[t]||G[e.type[t]].weapons.length===0||e.hasOrder[t]||e.attack[t]!==-1||(e.guard[t]=1,e.gpx[t]=e.x[t],e.gpy[t]=e.y[t],e.gpz[t]=e.z[t]);if(e.tick>=t.nextWave){let n=[];for(let r of s){let i=G[e.type[r]].layer;(i===B.Air||i===B.Sea)&&G[e.type[r]].weapons.length&&K(e.gpx[r],e.gpy[r],e.gpz[r],...t.base)*o<Od.homeRadius&&n.push(r)}let r=i.waveSize+t.wave*i.waveGrow,a=0;for(let n of s)G[e.type[n]].weapons.length&&K(e.x[n],e.y[n],e.z[n],...t.base)*o<Od.homeRadius&&a++;let c=Math.min(n.length,a-Od.homeGuard,r*2),l=Fp(e,t);if(l&&c>=r){n.length=c;for(let t of n)e.guard[t]=1,e.gpx[t]=l[0],e.gpy[t]=l[1],e.gpz[t]=l[2],e.attack[t]=-1;e.applyMove({ids:n,target:l});let r=n.filter(t=>G[e.type[t]].weapons.some(e=>e.orderOnly)),a=r.length?Vp(e,t.target,l):null;if(a){for(let t of r)e.guard[t]=0;Xp(e,{kind:`attack`,ids:r,structId:a.id})}t.wave++,t.nextWave=e.tick+i.waveEvery*20,e.message(t.target,`Enemy attack wave ${t.wave} (${n.length} units) is on its way`)}else l||(t.nextWave=e.tick+600)}if(Hp(e,t,s),e.tick%600==0){let n=Fp(e,t),r=s.filter(t=>e.type[t]===W.Satellite);n&&r.length&&e.applyMove({ids:r,target:n})}for(let r of e.structures){if(!r.alive||!r.complete||r.team!==n||r.target||r.reload>0)continue;let i=r.type===V.LaunchComplex;if(r.type!==V.Horizon&&r.type!==V.Anvil&&!(i&&(r.stock??0)>0)||i&&e.tick-t.lastNuke<Od.nukeEvery*20)continue;let a=null,o=Fp(e,t)??t.base,s=1/0;for(let r of e.structures){if(!r.alive||r.team!==t.target||!bf(e,n,[r.x,r.y,r.z]))continue;let i=K(r.x,r.y,r.z,...o);i<s&&(s=i,a=[r.x,r.y,r.z])}a&&(Xp(e,{kind:`fire`,structIds:[r.id],target:a}),i&&(t.lastNuke=e.tick))}}function Bp(e,t,n,r){let i=n=>r.some(t=>e.type[t]===n)||e.structures.some(e=>e.alive&&e.team===t.team&&e.prod.includes(n)),a=t.t2made++;if(n===V.AdvVehiclePlant)return a%3==2?W.Artillery:W.HeavyTank;if(n===V.AdvShipyard)return a%2?W.SubHunter:W.Cruiser;if(!i(W.RadarDrone))return W.RadarDrone;if(!i(W.HeavyTransport))return W.HeavyTransport;let o=e.teams[t.team].faction;return o===`agi`&&a%4==3?W.Interceptor:o===`man`&&a%6==5?W.EmpDrone:a%3==2?W.Bomber:W.Gunship}function Vp(e,t,n){let r=null,i=1/0;for(let a of e.structures){if(!a.alive||a.team!==t)continue;let e=K(a.x,a.y,a.z,...n);e<i&&(i=e,r=a)}return r}function Hp(e,t,n){let r=e.planet.radius,i=t.ferry;if(i&&(!e.alive[i.tr]||e.team[i.tr]!==t.team)&&(i=t.ferry=null),!i){let r=n.find(t=>e.type[t]===W.HeavyTransport&&!e.hasOrder[t]&&cf(e,t).length===0);if(r===void 0)return;i=t.ferry={tr:r,since:e.tick,flying:!1}}let a=i.tr,o=cf(e,a);if(i.flying){o.length===0&&!e.unloading[a]&&(t.ferry=null,e.applyMove({ids:[a],target:t.base}));return}let s=n.filter(n=>G[e.type[n]].weapons.length&&sf(e.type[n],W.HeavyTransport)&&e.type[n]!==W.Commander&&e.carriedBy[n]<0&&e.boarding[n]<0&&!e.hasOrder[n]&&e.attack[n]===-1&&K(e.x[n],e.y[n],e.z[n],...t.base)*r<Od.homeRadius).slice(Od.homeGuard),c=(G[W.HeavyTransport].capacity??0)-o.length;if(s.length&&c>0&&e.tick%100==0){let t=s.slice(0,c);for(let n of t)e.guard[n]=0;lf(e,t,a)}let l=(e.tick-i.since)/20;if(o.length>=Od.ferryMin||o.length>0&&l>Od.ferryWait){let r=Fp(e,t),s=r?Up(e,r):null;if(!s)return;for(let t of o)e.guard[t]=1,e.gpx[t]=s[0],e.gpy[t]=s[1],e.gpz[t]=s[2];for(let t of n)e.boarding[t]===a&&(e.boarding[t]=-1,e.hasOrder[t]=0,e.releaseField(t),e.guard[t]=1,e.gpx[t]=e.x[t],e.gpy[t]=e.y[t],e.gpz[t]=e.z[t]);uf(e,a,s),i.flying=!0,e.message(t.target,`Enemy heavy transport is bringing ${o.length} units`)}}function Up(e,t){let n=e.planet,r=n.cellOf(...t),i=n.nearestCell(r,t=>n.land[t]===1&&!e.blocked[t]&&vd(n,B.Land,t),4e3);return i>=0?hm(n,i):null}function Wp(e,t,n){let r=e.planet,i=n/r.radius,[a,o,s]=t,c=-s,l=a,u=Math.sqrt(c*c+l*l);u<1e-9?(c=1,l=0):(c/=u,l/=u);let d=o*l,f=s*c-a*l,p=-o*c;for(let[e,t]of[[1,0],[-1,0],[0,1],[0,-1],[.7,.7],[-.7,.7],[.7,-.7],[-.7,-.7]])if(r.land[r.cellOf(a+(e*c+t*d)*i,o+t*f*i,s+(e*l+t*p)*i)])return!0;return!1}function Gp(e){return H[e].radius+Nd.buildReach}function Kp(e,t){let n=e.structById(t);if(n)return n.alive&&!n.complete;let r=Pf(e,t);return!!r&&r.alive}function qp(e,t,n){if(e.unbuildOf[t]===n){let r=e.structById(n);return!!r&&r.alive&&r.team===e.team[t]}if(Kp(e,n))return!0;if(e.assistOf[t]!==n)return!1;let r=e.structById(n);return!!r&&r.alive&&r.complete&&$d(r.type)&&r.team===e.team[t]}function Jp(e,t){let n=e.structById(t);if(n)return{x:n.x,y:n.y,z:n.z,range:Gp(n.type)};let r=Pf(e,t);return r?{x:r.x,y:r.y,z:r.z,range:Ff(r)}:null}function Yp(e,t,n,r){let i=e.buildQueue[t]??=[],a=e.buildTask[t],o=a>=0&&a!==n&&Kp(e,a);for(let t=i.length-1;t>=0;t--)i[t]!==n&&Kp(e,i[t])||i.splice(t,1);for(r&&o?i.push(n):(o&&i.unshift(a),e.buildTask[t]=n,e.attack[t]=-1,e.hasOrder[t]=0,e.releaseField(t));i.length>2;)i.pop()}function Xp(e,t){switch(lp(e,t),t.kind){case`self-destruct`:up(e,t.structIds);break;case`reclaim-struct`:dp(e,t.ids,t.structId);break;case`stance`:fp(e,t.ids,t.stance);break;case`patrol`:pp(e,t.ids,t.points,t.loop);break;case`move`:for(let n of t.ids)n>=0&&n<e.count&&(e.buildTask[n]=-1,e.buildQueue[n]=[],e.attack[n]=-1);e.applyMove(t);break;case`load`:lf(e,t.ids,t.transport);break;case`unload`:uf(e,t.id,t.target);break;case`drive`:{let n=t.id;if(n<0||n>=e.count||!e.alive[n])break;if(!t.dir){e.driving[n]=0;break}e.driving[n]||(e.buildTask[n]=-1,e.buildQueue[n]=[],e.attack[n]=-1,e.hasOrder[n]=0,e.releaseField(n)),e.driving[n]=1,e.driveX[n]=t.dir[0],e.driveY[n]=t.dir[1],e.driveZ[n]=t.dir[2];break}case`place-start`:{let n=e.teams[t.team];if(n.started)break;let r=e.planet.cellOf(...t.target);if(!e.planet.land[r])break;if(t.faction&&(n.faction=t.faction),e.setupStart(t.team,t.target),t.opponents&&e.autoLandAi&&!e.ais.some(e=>e.started)){e.ais.length=0;let n=e.teams.map((e,t)=>t).filter(e=>e!==t.team);t.opponents.slice(0,n.length).forEach((t,r)=>{e.enableAi(t.level,n[r]),e.teams[n[r]].faction=t.faction}),Sp(e)}else e.autoLandAi&&e.ai&&!e.ai.started&&t.team!==e.ai.team&&(t.difficulty&&xp(e,t.difficulty),t.faction&&(e.teams[e.ai.team].faction=Bd(t.faction)),Sp(e));break}case`build`:{let n=t.ids.filter(t=>t>=0&&t<e.count&&e.alive[t]&&qd(e.type[t]));if(!n.length)break;let r=e.team[n[0]];if(e.techLimit<2&&H[t.structType].tier===2){e.message(r,`T2 is off in this game`);break}if(!Xd(e.teams[r],H[t.structType])){e.message(r,`${H[t.structType].name}: ${zd[H[t.structType].faction].name} only`);break}let i=n.filter(n=>Yd(e.type[n],t.structType));if(!i.length){let n=H[t.structType];e.message(r,n.t1Builds?`${n.name}: needs a construction vehicle, ship or drone`:`${n.name}: needs an advanced (T2) builder`);break}let a=Qp(e,t.structType,t.target,r);if(!a){e.message(r,`Can't build ${H[t.structType].name} there`);break}let o=Zp(e,t.structType,r,a.dir,0);o.site=a.site,a.site>=0&&e.sites[a.site].mine<0&&(e.sites[a.site].mine=o.id);for(let n of i)Yp(e,n,o.id,t.queue===!0);break}case`fire`:for(let n of t.structIds){let r=e.structById(n);r&&r.alive&&(r.type===V.Horizon||r.type===V.Anvil||r.type===V.LaunchComplex)&&(r.target=[...t.target],r.warned=!1)}break;case`assist`:{let n=e.structById(t.structId);if(!n||!n.alive)break;let r=n.complete&&$d(n.type);if(n.complete&&!r)break;for(let i of t.ids)i<0||i>=e.count||!e.alive[i]||!qd(e.type[i])||e.team[i]!==n.team||(r?(e.buildQueue[i]=[],e.buildTask[i]=n.id,e.assistOf[i]=n.id,e.attack[i]=-1,e.hasOrder[i]=0,e.releaseField(i)):Yp(e,i,n.id,!1));break}case`attack`:{let n=t.unit===void 0?t.structId===void 0?-1:Lf(t.structId):t.unit;if(n===-1)break;for(let r of t.ids)r<0||r>=e.count||!e.alive[r]||Xf(e,r,n)!==0&&(e.buildTask[r]=-1,e.buildQueue[r]=[],e.attack[r]=n,e.hasOrder[r]=0,e.releaseField(r));break}case`reclaim`:{let n=Pf(e,t.wreckId);if(!n||!n.alive)break;for(let r of t.ids)r<0||r>=e.count||!e.alive[r]||!qd(e.type[r])||Yp(e,r,n.id,t.queue===!0);break}case`dev-spawn-enemy`:{let n=e.planet.cellOf(...t.target),r=e.planet.land[n]===1;e.spawnSquad(t.team,t.target,r?3:0,r?0:2,2,211);break}case`stop`:for(let n of t.ids)n<0||n>=e.count||!e.alive[n]||(e.hasOrder[n]=0,e.releaseField(n),e.attack[n]=-1,e.buildTask[n]=-1,e.buildQueue[n]=[]);for(let n of t.structIds??[]){let t=e.structById(n);t&&t.alive&&(t.type===V.Horizon||t.type===V.Anvil||t.type===V.LaunchComplex)&&(t.target=null)}break;case`hold-fire`:for(let n of t.ids)n>=0&&n<e.count&&e.alive[n]&&(e.holdFire[n]=+!!t.hold);break;case`factory-queue`:{let n=e.structById(t.structId);n&&nf(e,n,t.unitType,t.delta);break}case`rally`:for(let n of t.structIds){let r=e.structById(n);r&&r.alive&&$d(r.type)&&(r.rally=[...t.target])}break;case`dev-resources`:{let n=e.teams[t.team];n.bonusMetalCap=5e3,n.bonusEnergyCap=4e4,n.metalCap+=5e3,n.energyCap+=4e4,n.metal=n.metalCap,n.energy=n.energyCap;break}}}function Zp(e,t,n,r,i){let a=H[t],o=Math.sqrt(r[0]*r[0]+r[1]*r[1]+r[2]*r[2]),s={id:e.nextId++,type:t,team:n,x:r[0]/o,y:r[1]/o,z:r[2]/o,cell:e.planet.cellOf(r[0],r[1],r[2]),progress:i,hp:a.hp*Math.max(.1,i),alive:!0,complete:i>=1,site:-1,reload:0,aimTarget:-1,target:null,aimE:0,aimN:1,warned:!1,idleTicks:0,prod:[],prodProgress:0,rally:null,capWarned:!1};return e.structures.push(s),s}function Qp(e,t,n,r=-1){let i=e.planet,a=i.radius,o=H[t],[s,c,l]=n,u=Math.sqrt(s*s+c*c+l*l);s/=u,c/=u,l/=u;let d=-1,f=-1,p=t===V.MetalMine||t===V.AdvMine,m=n=>{if(t!==V.AdvMine||n<0)return!1;let i=e.structById(n);return!!i&&i.alive&&i.complete&&i.type===V.MetalMine&&(r<0||i.team===r)};if(p){let t=14/a;for(let n of e.sites){if(n.mine>=0&&!m(n.mine))continue;let e=K(n.x,n.y,n.z,s,c,l);e<t&&(t=e,d=n.id)}if(d<0)return null;let n=e.sites[d];s=n.x,c=n.y,l=n.z,n.mine>=0&&(f=n.mine)}let h=-l,g=0,_=s;h*h+_*_<1e-9&&(h=1,_=0),u=Math.sqrt(h*h+g*g+_*_),h/=u,g/=u,_/=u;let v=c*_-l*g,y=l*h-s*_,b=s*g-c*h,x=o.radius/a,S=[[0,0],[1,0],[-1,0],[0,1],[0,-1],[.7,.7],[-.7,.7],[.7,-.7],[-.7,-.7]],C=i.land[i.cellOf(s,c,l)]===1,w=t===V.Tidal||t===V.SonarBuoy||t===V.Storage&&!C;for(let[e,t]of S){let n=s+(e*h+t*v)*x,r=c+(e*g+t*y)*x,a=l+(e*_+t*b)*x;if(i.land[i.cellOf(n,r,a)]===1===w)return null}if((t===V.Shipyard||t===V.AdvShipyard)&&!of(e,[s,c,l],t))return null;for(let t of e.structures)if(t.alive&&t.id!==f&&K(t.x,t.y,t.z,s,c,l)*a<o.radius+H[t.type].radius+2)return null;for(let t of e.wrecks)if(t.alive&&K(t.x,t.y,t.z,s,c,l)*a<o.radius+t.radius+1)return null;return{dir:[s,c,l],site:d}}var $p=100;function em(e){let t=e.planet.radius;for(let n=0;n<e.count;n++){let r=e.buildTask[n];if(r<0&&!e.buildQueue[n]?.length)continue;if(!e.alive[n]){e.buildTask[n]=-1,e.buildQueue[n]=[];continue}let i=r>=0?Jp(e,r):null;if(r<0||!qp(e,n,r)){let t=e.buildQueue[n]??[];for(r=-1;t.length&&r<0;){let n=t.shift();Kp(e,n)&&(r=n)}if(e.buildTask[n]=r,r<0)continue;i=Jp(e,r)}if(!i){e.buildTask[n]=-1;continue}let a=K(i.x,i.y,i.z,e.x[n],e.y[n],e.z[n])*t,o=e.hasOrder[n]&&e.field[n]>=0?e.fieldOf(n):null,s=o&&o.dist[e.cell[n]]<1/0?o.dist[e.cell[n]]:a;if(e.jobOf[n]===r?s<e.jobBest[n]-.5&&(e.jobBest[n]=s,e.jobSince[n]=e.tick):(e.jobOf[n]=r,e.jobBest[n]=s,e.jobSince[n]=e.tick),a>i.range&&e.tick-e.jobSince[n]>$p)e.buildTask[n]=-1,e.jobOf[n]=-1,e.hasOrder[n]=0,e.releaseField(n),e.message(e.team[n],`Build site unreachable`);else if(a<=i.range)e.jobSince[n]=e.tick,e.hasOrder[n]&&(e.hasOrder[n]=0,e.releaseField(n));else if(!e.hasOrder[n]){if(e.applyMove({ids:[n],target:[i.x,i.y,i.z]},!1,!0),!e.hasOrder[n]&&a<=i.range+30&&(e.hasOrder[n]=1,e.tx[n]=i.x,e.ty[n]=i.y,e.tz[n]=i.z),!e.hasOrder[n]){let t=tm(e,n,i);t>=0&&e.applyMove({ids:[n],target:hm(e.planet,t)},!1,!0)}e.hasOrder[n]||(e.buildTask[n]=-1,e.message(e.team[n],`Build site unreachable`))}}}function tm(e,t,n){let r=e.planet,i=r.radius,a=e.cell[t];if(!vd(r,B.Land,a))return-1;let o=new Uint8Array(r.cellCount),s=[a];o[a]=1;let c=-1,l=(n.range-1)/i;for(let t=0;t<s.length&&t<4e4;t++){let i=s[t],a=K(r.cx[i],r.cy[i],r.cz[i],n.x,n.y,n.z);a<l&&(l=a,c=i);for(let t=r.adjStart[i];t<r.adjStart[i+1];t++){let n=r.adj[t];!o[n]&&!e.blocked[n]&&vd(r,B.Land,n)&&(o[n]=1,s.push(n))}}return c}function nm(e,t=3){let n=e.planet,r=0;for(let i of n.blobs){if(r>=t)break;if(i.kind!==`medium`)continue;let a=n.nearestCell(n.cellOf(...i.c),e=>n.land[e]===1);a<0||(Zp(e,V.PracticeTarget,1,hm(n,a),1),r++)}}function rm(e){return .15+.85*ld(e.tick/800,.5,.5,e.planet.params.seed+77)}function im(e){let t=rm(e),n=e.planet.radius,r=new Map,i=new Map;for(let t=0;t<e.count;t++){let a=e.buildTask[t];if(a<0||!e.alive[t]||e.hasOrder[t])continue;let o=e.structById(a);if(!o||K(o.x,o.y,o.z,e.x[t],e.y[t],e.z[t])*n>Gp(o.type))continue;let s=e.unbuildOf[t]===a?i:r;s.set(a,(s.get(a)??0)+e.buildPowerOf(t))}am(e,i);let a=If(e),o=ef(e),s=[];for(let n=0;n<e.teams.length;n++){let i=e.teams[n];if(!i.started)continue;let c=0,l=0,u=0,d=0,f=Pd.baseMetalCap,p=Pd.baseEnergyCap;for(let t=0;t<e.count;t++)e.alive[t]&&e.team[t]===n&&e.type[t]===W.Commander&&(c+=Nd.metalOut,l+=Nd.energyOut);let m=0,h=0,g=0;c+=a[n];for(let r of e.structures){if(!r.alive||!r.complete||r.team!==n)continue;let i=H[r.type];r.type===V.Wind?l+=(i.energyOut??0)*t:r.type===V.Solar?l+=(i.energyOut??0)*Hd.solarPeak*e.sunlight(r.x,r.y,r.z):i.energyOut&&(l+=i.energyOut),(r.type===V.MetalMine||r.type===V.AdvMine)&&r.site>=0&&e.sites[r.site].mine===r.id&&(h+=(i.metalOut??0)*e.sites[r.site].richness,m+=i.energyUpkeep??0),r.type===V.Radar&&(g+=i.energyUpkeep??0),f+=i.metalStore??0,p+=i.energyStore??0}if(c*=i.incomeMul,l*=i.incomeMul,h*=i.incomeMul,i.metalCap=f+i.bonusMetalCap,i.energyCap=p+i.bonusEnergyCap,i.metal+=c*Ud,i.energy+=l*Ud,m>0){let e=m*Ud,t=Math.min(1,i.energy/e);i.energy-=e*t,d+=m*t,i.metal+=h*t*Ud,c+=h*t}if(g>0){let e=g*Ud;i.radarPowered=i.energy>=e,i.radarPowered&&(i.energy-=e,d+=g)}else i.radarPowered=!0;let _=0,v=0,y=[];for(let t of e.structures){if(!t.alive||t.complete||t.team!==n)continue;let e=r.get(t.id);if(!e)continue;let i=H[t.type],a=e/i.buildTime;y.push([t,a]),_+=i.metal*a*Ud,v+=i.energy*a*Ud}let b=[];for(let t of e.structures){if(t.team!==n)continue;let i=tf(e,t,o,r.get(t.id)??0);if(!i)continue;b.push([t,i.rate,i.type]);let a=G[i.type];_+=a.metal*i.rate*Ud,v+=a.energy*i.rate*Ud}let x=1;i.short=null,_>0&&i.metal/_<x&&(x=i.metal/_,i.short=`metal`),v>0&&i.energy/v<x&&(x=i.energy/v,i.short=`energy`),x=Math.max(0,Math.min(1,x)),i.stall=y.length+b.length>0&&x<.999,i.stall||(i.short=null);for(let[t,n]of y){let r=H[t.type],a=Math.min(n*Ud*x,1-t.progress);t.progress+=a,t.hp=Math.min(r.hp,t.hp+r.hp*a),i.metal-=r.metal*a,i.energy-=r.energy*a,u+=r.metal*a/Ud,d+=r.energy*a/Ud,t.progress>=1-1e-9&&(t.progress=1,t.complete=!0,i.stats.structsBuilt++,t.type===V.AdvMine&&t.site>=0&&sm(e,t),e.events.push({kind:`built`,tick:e.tick,struct:t.id}))}for(let[e,t,r]of b){let a=G[r],c=Math.min(t*Ud*x,1-e.prodProgress);e.prodProgress+=c,i.metal-=a.metal*c,i.energy-=a.energy*c,u+=a.metal*c/Ud,d+=a.energy*c/Ud,e.prodProgress>=1-1e-9&&(s.push(e),o[n]++)}let S=0;for(let t of e.structures)t.alive&&t.complete&&t.team===n&&t.type===V.Converter&&S++;if(S>0){let e=S*Td.energyIn*Ud,t=S*Td.metalOut*Ud,n=Math.max(0,i.energy-i.energyCap*Td.minStore),r=Math.max(0,i.metalCap-i.metal),a=Math.max(0,Math.min(1,n/e,r/t));i.energy-=e*a,d+=e*a/Ud,i.metal+=t*a,c+=t*a/Ud}i.metal=Math.max(0,Math.min(i.metal,i.metalCap)),i.energy=Math.max(0,Math.min(i.energy,i.energyCap)),i.metalIn=c,i.energyIn=l,i.metalOut=u,i.energyOut=d,i.stats.metalMade+=c*Ud,i.stats.energyMade+=l*Ud}for(let t of s)af(e,t);om(e)}function am(e,t){for(let n of e.structures){let r=t.get(n.id);if(!r||!n.alive)continue;let i=H[n.type];n.complete=!1,n.idleTicks=0;let a=Math.min(n.progress,r/i.buildTime*Ud);n.progress-=a,n.hp=Math.max(1,Math.min(n.hp,i.hp*Math.max(n.progress,.05)));let o=e.teams[n.team];o.metal=Math.min(o.metalCap,o.metal+i.metal*a),o.metalIn+=i.metal*a/Ud,n.progress<=1e-9&&(n.progress=0,n.alive=!1,n.site>=0&&e.sites[n.site].mine===n.id&&(e.sites[n.site].mine=-1),e.events.push({kind:`reclaimed-struct`,tick:e.tick,dir:[n.x,n.y,n.z],team:n.team}))}}function om(e){let t=new Set,n=new Set;for(let r=0;r<e.count;r++)if(e.alive[r]){e.buildTask[r]>=0&&t.add(e.buildTask[r]);for(let t of e.buildQueue[r]??[])n.add(t)}for(let r of e.structures){if(!r.alive||r.complete)continue;let i=n.has(r.id);if(t.has(r.id)||i&&r.progress<=1e-9){r.idleTicks=0;continue}if(r.idleTicks++,r.idleTicks<=Md.grace*20)continue;let a=H[r.type],o=Math.min(r.progress,Md.perSecond*Ud);r.progress-=o,r.hp=Math.max(1,r.hp-a.hp*o);let s=e.teams[r.team];if(s.metal=Math.min(s.metalCap,s.metal+a.metal*o),s.energy=Math.min(s.energyCap,s.energy+a.energy*o),s.metalIn+=a.metal*o/Ud,s.energyIn+=a.energy*o/Ud,r.progress<=1e-9){if(r.progress=0,i)continue;r.alive=!1,r.site>=0&&e.sites[r.site].mine===r.id&&(e.sites[r.site].mine=-1),e.message(r.team,`Abandoned ${a.name} has decayed away (resources returned)`)}}}function sm(e,t){let n=e.sites[t.site];if(n.mine!==t.id){let r=n.mine>=0?e.structById(n.mine):void 0;r&&r.alive&&(r.alive=!1,r.hp=0),n.mine=t.id}}function cm(e,t,n,r,i=-1){let a=e.planet.cellOf(...t);e.impacts.push({id:e.nextId++,x:t[0],y:t[1],z:t[2],land:e.planet.land[a]===1,impactTick:e.tick+n,warnTick:e.tick+n-Fd.warning*20,shower:r,team:i})}function lm(e,t,n){let r=e.planet,i=r.radius,a=r.cellOf(...t),o=[],s=new Uint8Array(r.cellCount),c=[a];s[a]=1;for(let e=0;e<c.length;e++){let n=c[e],a=K(r.cx[n],r.cy[n],r.cz[n],t[0],t[1],t[2])*i;if(!(a>Fd.showerSpread)){a>45&&o.push(n);for(let e=r.adjStart[n];e<r.adjStart[n+1];e++){let t=r.adj[e];!s[t]&&r.land[t]&&(s[t]=1,c.push(t))}}}let l=[];for(let t=0;t<Fd.showerCount*8&&l.length<Fd.showerCount&&o.length;t++){let t=o[e.rng.int(o.length)];l.some(e=>K(r.cx[e],r.cy[e],r.cz[e],r.cx[t],r.cy[t],r.cz[t])*i<30)||l.push(t)}l.forEach((t,i)=>{let a=(Fd.showerFirstDelay+Fd.warning+i*Fd.showerInterval)*20;cm(e,hm(r,t),Math.round(a),!0,n)}),e.nextRandomImpact<0&&(e.nextRandomImpact=e.tick+Math.round(e.rng.range(Fd.randomMin,Fd.randomMax)*20))}function um(e){e.nextRandomImpact>=0&&e.tick>=e.nextRandomImpact&&(cm(e,e.rng.dir(),Fd.warning*20,!1),e.nextRandomImpact=e.tick+Math.round(e.rng.range(Fd.randomMin,Fd.randomMax)*20));for(let t=e.impacts.length-1;t>=0;t--){let n=e.impacts[t];if(n.impactTick>e.tick)continue;e.impacts.splice(t,1);let r=[n.x,n.y,n.z],i=-1;if(n.land){let t=e.planet.radius;if(!e.sites.some(e=>K(e.x,e.y,e.z,n.x,n.y,n.z)*t<20)){i=e.sites.length;let t=Math.round(e.rng.range(Fd.richnessMin,Fd.richnessMax)*10)/10;e.sites.push({id:i,x:n.x,y:n.y,z:n.z,richness:t,mine:-1,tick:e.tick,team:n.team})}}wf(e,r,Fd.damageRadius,e=>e*Fd.damageFraction),e.events.push({kind:`meteor-impact`,tick:e.tick,dir:r,land:n.land,site:i,team:n.team})}}var dm=4,fm={speed:1,hp:1},pm=20,mm=class{planet;tick=0;count=0;type=new Uint8Array(U);team=new Uint8Array(U);x=new Float64Array(U);y=new Float64Array(U);z=new Float64Array(U);px=new Float64Array(U);py=new Float64Array(U);pz=new Float64Array(U);hx=new Float64Array(U);hy=new Float64Array(U);hz=new Float64Array(U);elev=new Float32Array(U);prevElev=new Float32Array(U);cell=new Int32Array(U);hasOrder=new Uint8Array(U);tx=new Float64Array(U);ty=new Float64Array(U);tz=new Float64Array(U);field=new Int32Array(U).fill(-1);fields=[];queue=[];log=[];lastStepMs=0;lastFieldMs=0;alive=new Uint8Array(U);hp=new Float32Array(U);buildTask=new Int32Array(U).fill(-1);buildQueue=[];attack=new Int32Array(U).fill(-1);reload=Array.from({length:3},()=>new Int16Array(U));aim=Array.from({length:3},()=>new Int32Array(U).fill(-1));guard=new Uint8Array(U);holdFire=new Uint8Array(U);assistOf=new Int32Array(U).fill(-1);driving=new Uint8Array(U);stuck=new Uint16Array(U);disabledUntil=new Int32Array(U);slowUntil=new Int32Array(U);jobOf=new Int32Array(U).fill(-1);jobBest=new Float32Array(U);jobSince=new Int32Array(U);driveX=new Float32Array(U);driveY=new Float32Array(U);driveZ=new Float32Array(U);carriedBy=new Int32Array(U).fill(-1);boarding=new Int32Array(U).fill(-1);cargo=[];unbuildOf=new Int32Array(U).fill(-1);sunX=Hd.startX;sunY=Hd.y;sunZ=Hd.startZ;aggressive=new Uint8Array(U);patrol=[];patrolIdx=new Int16Array(U);patrolDir=new Int8Array(U);patrolLoop=new Uint8Array(U);unloading=new Uint8Array(U);unloadX=new Float64Array(U);unloadY=new Float64Array(U);unloadZ=new Float64Array(U);guardWait=new Int32Array(U);gpx=new Float64Array(U);gpy=new Float64Array(U);gpz=new Float64Array(U);projectiles=[];nextProjectile=1;wrecks=[];ais=[];autoLandAi=!0;winRule=`commander`;techLimit=2;startRich=!1;get ai(){return this.ais[0]??null}sensors=Cf();sensorsTick=-1;blocked;blockedSig=-1;structures=[];sites=[];teams=[0,1,2,3].map(()=>({started:!1,metal:Pd.startMetal,energy:Pd.startEnergy,metalCap:Pd.baseMetalCap,energyCap:Pd.baseEnergyCap,metalIn:0,metalOut:0,energyIn:0,energyOut:0,stall:!1,short:null,lost:!1,bonusMetalCap:0,bonusEnergyCap:0,radarPowered:!0,incomeMul:1,stats:{unitsBuilt:0,unitsLost:0,structsBuilt:0,structsLost:0,metalMade:0,energyMade:0}}));impacts=[];viewFiltered=!1;shells=[];nextRandomImpact=-1;nextId=1;rng;events=[];head;next=new Int32Array(U);constructor(e){this.planet=e,this.head=new Int32Array(e.cellCount),this.blocked=new Uint8Array(e.cellCount),this.rng=new sd((e.params.seed^10558693)>>>0)}spawn(e,t,n){if(this.count>=4096)return-1;let r=this.count++,i=Math.sqrt(n[0]*n[0]+n[1]*n[1]+n[2]*n[2]),a=n[0]/i,o=n[1]/i,s=n[2]/i;this.type[r]=e,this.team[r]=t,this.alive[r]=1,this.hp[r]=G[e].hp*this.factionMul(t).hp,this.buildTask[r]=-1,this.assistOf[r]=-1,this.driving[r]=0,this.stuck[r]=0,this.jobOf[r]=-1,this.disabledUntil[r]=0,this.slowUntil[r]=0,this.carriedBy[r]=-1,this.boarding[r]=-1,this.unloading[r]=0,this.cargo[r]=[],this.unbuildOf[r]=-1,this.aggressive[r]=0,this.patrol[r]=null,this.attack[r]=-1,this.guard[r]=0,this.holdFire[r]=0,this.guardWait[r]=0;for(let e=0;e<3;e++)this.reload[e][r]=0,this.aim[e][r]=-1;this.x[r]=this.px[r]=a,this.y[r]=this.py[r]=o,this.z[r]=this.pz[r]=s;let c=-s,l=0,u=a;c*c+u*u<1e-6&&(c=1,l=0,u=0);let d=Math.sqrt(c*c+l*l+u*u);return this.hx[r]=c/d,this.hy[r]=l/d,this.hz[r]=u/d,this.cell[r]=this.planet.cellOf(a,o,s),this.elev[r]=this.prevElev[r]=this.elevationFor(r),r}enqueue(e){this.queue.push(e)}turnSun(){let e=this.sunX*Hd.cos-this.sunZ*Hd.sin,t=this.sunX*Hd.sin+this.sunZ*Hd.cos,n=Math.sqrt((1-Hd.y*Hd.y)/(e*e+t*t));this.sunX=e*n,this.sunZ=t*n}sunlight(e,t,n){let r=e*this.sunX+t*this.sunY+n*this.sunZ;return Math.max(0,Math.min(1,r*Hd.solarRamp))}elevationFor(e){let t=G[this.type[e]],n=this.planet.heightAt(this.x[e],this.y[e],this.z[e]);if(t.layer===B.Sea)return 0;let r=Math.max(0,n)*45;return t.layer===B.Air?r+t.altitude:r}factionMul(e){let t=this.teams[e]?.faction;return t?zd[t]:fm}maxHp(e){return G[this.type[e]].hp*this.factionMul(this.team[e]).hp}speedOf(e){return G[this.type[e]].speed*this.factionMul(this.team[e]).speed*(this.slowUntil[e]>this.tick?Cd.commanderSlow:1)}disabled(e){return this.disabledUntil[e]>this.tick}buildPowerOf(e){return this.disabled(e)?0:G[this.type[e]].buildPower*(this.slowUntil[e]>this.tick?Cd.commanderSlow:1)}fieldOf(e){let t=this.field[e];return t>=0?this.fields[t]?.field??null:null}releaseField(e){let t=this.field[e];if(t<0)return;let n=this.fields[t];--n.refs<=0&&(this.fields[t]=null),this.field[e]=-1}applyMove(e,t=!1,n=!1){let r=this.planet,i=r.radius,[a,o,s]=e.target,c=Math.sqrt(a*a+o*o+s*s);a/=c,o/=c,s/=c;let l=[...new Set(e.ids)].filter(e=>e>=0&&e<this.count&&this.alive[e]).sort((e,t)=>e-t),u=-s,d=0,f=a;u*u+f*f<1e-6&&(u=1,d=0,f=0);let p=Math.sqrt(u*u+d*d+f*f);u/=p,d/=p,f/=p;let m=o*f-s*d,h=s*u-a*f,g=a*d-o*u;for(let c of[B.Land,B.Sea,B.Air]){let p=l.filter(e=>G[this.type[e]].layer===c);if(p.length===0)continue;let _=-1,v=null;if(c!==B.Air){let e=r.cellOf(a,o,s),n=r.nearestCell(e,e=>vd(r,c,e)&&!(c===B.Land&&this.blocked[e]));if(n<0)continue;let l=performance.now(),u=1/0;if(t){u=0;for(let e of p)u=Math.max(u,K(this.x[e],this.y[e],this.z[e],r.cx[n],r.cy[n],r.cz[n])*i);u=u*2.5+120}v=new yd(r,c,n,this.blocked,u),this.lastFieldMs=performance.now()-l,_=this.fields.indexOf(null),_<0&&(_=this.fields.length,this.fields.push(null)),this.fields[_]={field:v,refs:0}}let y=0;for(let e of p)y=Math.max(y,G[this.type[e]].radius);let b=y*2.6,x=Math.ceil(Math.sqrt(p.length));p.forEach((t,l)=>{let y=(l%x-(x-1)/2)*b/i,S=(Math.floor(l/x)-(x-1)/2)*b/i,C=a+y*u+S*m,w=o+y*d+S*h,T=s+y*f+S*g,E=Math.sqrt(C*C+w*w+T*T);if(C/=E,w/=E,T/=E,v){let i=r.cellOf(C,w,T);vd(r,c,i)&&v.dist[i]<1/0||(n&&p.length===1?(C=e.target[0],w=e.target[1],T=e.target[2]):(C=r.cx[v.goal],w=r.cy[v.goal],T=r.cz[v.goal]));let a=this.cell[t];if(!(v.dist[a]<1/0)&&v.nextCell(a)<0)return}this.releaseField(t),this.hasOrder[t]=1,this.tx[t]=C,this.ty[t]=w,this.tz[t]=T,_>=0&&(this.field[t]=_,this.fields[_].refs++)}),_>=0&&this.fields[_].refs===0&&(this.fields[_]=null)}}step(){let e=performance.now();for(let e of this.queue)this.log.push({tick:this.tick,cmd:e}),Xp(this,e);this.queue.length=0,um(this),Af(this),ip(this),this.updateBlocked(),em(this),Rp(this),op(this),ap(this),df(this),mp(this);let t=this.planet,n=t.radius,r=this.count,{x:i,y:a,z:o,px:s,py:c,pz:l,hx:u,hy:d,hz:f}=this;s.set(i.subarray(0,r)),c.set(a.subarray(0,r)),l.set(o.subarray(0,r)),this.prevElev.set(this.elev.subarray(0,r));let p=this.head;for(let e=0;e<r;e++)p[this.cell[e]]=-1;for(let e=0;e<r;e++){if(!this.alive[e]||this.carriedBy[e]>=0)continue;let t=this.cell[e];this.next[e]=p[t],p[t]=e}for(let e=0;e<r;e++){if(!this.alive[e]||this.carriedBy[e]>=0||this.disabledUntil[e]>this.tick)continue;let r=G[this.type[e]],m=s[e],h=c[e],g=l[e],_=0,v=0,y=0,b=!1,x=-1;if(this.driving[e]){let t=this.driveX[e],r=this.driveY[e],i=this.driveZ[e],a=t*m+r*h+i*g;t-=m*a,r-=h*a,i-=g*a;let o=Math.sqrt(t*t+r*r+i*i);if(o>1e-9){t/=o,r/=o,i/=o,u[e]=t,d[e]=r,f[e]=i;let a=this.speedOf(e)*Ud/n;_=t*a,v=r*a,y=i*a,b=!0}}else if(this.hasOrder[e]){let r,i,a,o=this.tx[e]-m,s=this.ty[e]-h,c=this.tz[e]-g,l=Math.sqrt(o*o+s*s+c*c)*n,p=this.field[e],S=p>=0?this.fields[p]:null;if(!S||l<30)r=this.tx[e],i=this.ty[e],a=this.tz[e];else{let n=S.field,o=n.nextCell(this.cell[e]);if(o<0&&this.stuck[e]>pm&&!(n.dist[this.cell[e]]<1/0)&&(o=t.nearestCell(this.cell[e],e=>n.dist[e]<1/0,60)),o<0)r=this.tx[e],i=this.ty[e],a=this.tz[e];else{let e=n.nextCell(o),s=e>=0?e:o;x=o,r=t.cx[s],i=t.cy[s],a=t.cz[s]}}let C=r-m,w=i-h,T=a-g,E=C*m+w*h+T*g;C-=m*E,w-=h*E,T-=g*E;let D=Math.sqrt(C*C+w*w+T*T),O=this.speedOf(e)*Ud/n;if(l/n<=O)_=this.tx[e]-m,v=this.ty[e]-h,y=this.tz[e]-g,this.hasOrder[e]=0,this.releaseField(e);else if(D>1e-12){C/=D,w/=D,T/=D;let t=u[e]*.55+C*.45,n=d[e]*.55+w*.45,r=f[e]*.55+T*.45,i=Math.sqrt(t*t+n*n+r*r);i>1e-9?(t/=i,n/=i,r/=i):(t=C,n=w,r=T),u[e]=t,d[e]=n,f[e]=r;let a=Math.max(.25,t*C+n*w+r*T);_=t*O*a,v=n*O*a,y=r*O*a,b=!0}}let S=r.radius,C=this.cell[e];for(let i=t.adjStart[C]-1;i<t.adjStart[C+1];i++){let a=i<t.adjStart[C]?C:t.adj[i];for(let t=p[a];t>=0;t=this.next[t]){if(t===e)continue;let i=G[this.type[t]];if(i.layer!==r.layer)continue;let a=m-s[t],o=h-c[t],u=g-l[t],d=Math.sqrt(a*a+o*o+u*u)*n,f=S+i.radius;if(d<f){if(d<1e-6){let r=(e-t)/n*.05;_+=r,v+=r*.5}else{let e=(f-d)*.5/(d*n);_+=a*e,v+=o*e,y+=u*e}}}}let w=!1,T=this.stuck[e]>pm&&this.blocked[this.cell[e]]===1;if(r.layer===B.Land&&!T){for(let t of this.structures){if(!t.alive)continue;let r=m+_-t.x,i=h+v-t.y,a=g+y-t.z,o=Math.sqrt(r*r+i*i+a*a)*n,s=H[t.type].radius+S;if(o>=s)continue;if(w=!0,o<1e-6){_+=u[e]*(s/n),v+=d[e]*(s/n),y+=f[e]*(s/n);continue}let c=(s-o)/o;_+=r*c,v+=i*c,y+=a*c}for(let t of this.wrecks){if(!t.alive)continue;let r=m+_-t.x,i=h+v-t.y,a=g+y-t.z,o=Math.sqrt(r*r+i*i+a*a)*n,s=t.radius+S;if(o>=s)continue;if(w=!0,o<1e-6){_+=u[e]*(s/n),v+=d[e]*(s/n),y+=f[e]*(s/n);continue}let c=(s-o)/o;_+=r*c,v+=i*c,y+=a*c}}else if(r.layer===B.Sea)for(let r of this.structures){if(!r.alive||t.land[r.cell])continue;let i=m+_-r.x,a=h+v-r.y,o=g+y-r.z,s=Math.sqrt(i*i+a*a+o*o)*n,c=H[r.type].radius+S;if(s>=c)continue;if(w=!0,s<1e-6){_+=u[e]*(c/n),v+=d[e]*(c/n),y+=f[e]*(c/n);continue}let l=(c-s)/s;_+=i*l,v+=a*l,y+=o*l}if(_===0&&v===0&&y===0&&!w)continue;let E=m+_,D=h+v,O=g+y,k=Math.sqrt(E*E+D*D+O*O);E/=k,D/=k,O/=k;let A=t.cellOf(E,D,O);if(r.layer!==B.Air&&!vd(t,r.layer,A)){let i=!1;for(let a of[x,this.cell[e]]){if(a<0)continue;let o=t.cx[a]-m,s=t.cy[a]-h,c=t.cz[a]-g,l=Math.sqrt(o*o+s*s+c*c);if(l<1e-12)continue;let u=Math.min(l,this.speedOf(e)*Ud/n);if(E=m+o/l*u,D=h+s/l*u,O=g+c/l*u,k=Math.sqrt(E*E+D*D+O*O),E/=k,D/=k,O/=k,A=t.cellOf(E,D,O),vd(t,r.layer,A)){i=!0;break}}if(!i)continue}i[e]=E,a[e]=D,o[e]=O,this.cell[e]=A;let ee=u[e]*E+d[e]*D+f[e]*O,j=u[e]-E*ee,te=d[e]-D*ee,M=f[e]-O*ee,ne=Math.sqrt(j*j+te*te+M*M);ne>1e-9&&(u[e]=j/ne,d[e]=te/ne,f[e]=M/ne),(b||r.layer!==B.Sea)&&(this.elev[e]=this.elevationFor(e))}for(let e=0;e<r;e++){if(!this.alive[e]||G[this.type[e]].layer!==B.Land||!this.hasOrder[e]){this.stuck[e]=0;continue}let t=K(i[e],a[e],o[e],s[e],c[e],l[e])*n;this.stuck[e]=t<.05?Math.min(6e4,this.stuck[e]+1):this.stuck[e]>pm&&this.blocked[this.cell[e]]?this.stuck[e]:0}mf(this),$f(this),ep(this),im(this),kf(this),this.turnSun(),ff(this,e=>Bf(this,e)),this.winRule===`everything`&&this.tick%20==0&&this.checkEverything(),this.tick++,this.lastStepMs=performance.now()-e}updateBlocked(){let e=0,t=0;for(let t of this.structures)t.alive&&e++;for(let e of this.wrecks)e.alive&&t++;let n=this.nextId*1e8+e*1e4+t;if(n===this.blockedSig)return;this.blockedSig=n;let r=this.planet,i=r.radius;this.blocked.fill(0);let a=[];for(let e of this.structures)e.alive&&a.push({cell:e.cell,x:e.x,y:e.y,z:e.z,r:H[e.type].radius+dm});for(let e of this.wrecks)e.alive&&a.push({cell:e.cell,x:e.x,y:e.y,z:e.z,r:e.radius+dm});for(let e of a){let t=e.r,n=[e.cell],a=new Set(n);for(let o=0;o<n.length;o++){let s=n[o],c=K(r.cx[s],r.cy[s],r.cz[s],e.x,e.y,e.z)*i;if(c<=t&&(this.blocked[s]=1),!(c>t+14))for(let e=r.adjStart[s];e<r.adjStart[s+1];e++){let t=r.adj[e];a.has(t)||(a.add(t),n.push(t))}}}}hash(){let e=2166136261,t=t=>{e^=t|0,e=Math.imul(e,16777619)>>>0};t(this.tick),t(this.count);for(let e=0;e<this.count;e++){t(Math.round(this.x[e]*1e9)),t(Math.round(this.y[e]*1e9)),t(Math.round(this.z[e]*1e9)),t(this.hasOrder[e]),t(this.buildTask[e]);for(let n of this.buildQueue[e]??[])t(n);t(this.alive[e]),t(Math.round(this.hp[e]*100)),t(this.attack[e]),this.holdFire[e]&&t(7919),this.assistOf[e]>=0&&this.buildTask[e]===this.assistOf[e]&&t(104729+this.assistOf[e]),this.unbuildOf[e]>=0&&this.unbuildOf[e]===this.buildTask[e]&&t(49979687+this.unbuildOf[e]),this.aggressive[e]&&t(67867967),this.patrol[e]&&(t(86028121+this.patrolIdx[e]),t(this.patrolDir[e]+2)),this.carriedBy[e]>=0&&t(15485863+this.carriedBy[e]),this.boarding[e]>=0&&t(32452843+this.boarding[e]),this.driving[e]&&(t(1299709),t(Math.round(this.driveX[e]*1e6)),t(Math.round(this.driveY[e]*1e6)),t(Math.round(this.driveZ[e]*1e6)));for(let n=0;n<3;n++)t(this.reload[n][e])}for(let e of this.wrecks)t(+!!e.alive),t(Math.round(e.metal*1e3));t(this.projectiles.length);for(let e of this.structures)t(e.type),t(+!!e.alive),t(Math.round(e.progress*1e6)),t(Math.round(e.hp*100)),e.prod.length&&(t(e.prod.length),t(e.prod[0]),t(Math.round(e.prodProgress*1e6))),e.type===V.Horizon&&(t(Math.round(e.aimE*1e6)),t(Math.round(e.aimN*1e6)));for(let e of this.sites)t(Math.round(e.x*1e9)),t(e.mine);for(let e of this.teams)t(Math.round(e.metal*1e3)),t(Math.round(e.energy*1e3));t(this.impacts.length),t(this.shells.length);for(let e of this.ais)t(e.step),t(e.wave),t(e.nextWave);return e>>>0}canPlace(e,t,n=-1){return Qp(this,e,t,n)}visible(e,t){return vf(this,e,t)}detected(e,t){return bf(this,e,t)}unitSeenBy(e,t){return Sf(this,e,t)}wreckById(e){return Pf(this,e)}wind(){return rm(this)}setupPracticeTargets(e=3){nm(this,e)}static shellFlightTicks(e,t){return Tf(null,e,t)}structById(e){let t=0,n=this.structures.length-1;for(;t<=n;){let r=t+n>>1,i=this.structures[r].id;if(i===e)return this.structures[r];i<e?t=r+1:n=r-1}}message(e,t){this.events.push({kind:`message`,tick:this.tick,team:e,text:t})}setupStart(e=0,t){let n=this.planet,r;if(t)r=n.nearestCell(n.cellOf(...t),e=>n.land[e]===1);else{let e=n.blobs.find(e=>e.kind===`large`)??n.blobs[0];r=n.nearestCell(n.cellOf(...e.c),e=>n.land[e]===1)}let i=t&&n.land[n.cellOf(...t)]?t:hm(n,r),a=this.spawn(W.Commander,e,i),o=new sd(n.params.seed^24301^e);for(let t=0;t<6;t++)this.spawnNear(W.Tank,e,i,40,o);let s=n.nearestCell(r,e=>n.land[e]===0);if(s>=0){let t=hm(n,s);for(let n=0;n<4;n++)this.spawnNear(W.Boat,e,t,40,o)}for(let t=0;t<4;t++)this.spawnNear(W.Drone,e,i,40,o);if(this.teams[e].started=!0,this.teams[e].home=i,this.startRich){let t=this.teams[e];t.bonusMetalCap=Rd.metalCap,t.bonusEnergyCap=Rd.energyCap,t.metal=Rd.metal,t.energy=Rd.energy}return lm(this,i,e),a}enableAi(e=`easy`,t=Od.team){let n=this.ais.findIndex(e=>e.team===t);n>=0&&this.ais.splice(n,1),this.ais.push(bp(t,e)),this.ais.sort((e,t)=>e.team-t.team)}checkEverything(){let e=this.teams.map(()=>!1);for(let t=0;t<this.count;t++)this.alive[t]&&(e[this.team[t]]=!0);for(let t of this.structures)t.alive&&(e[t.team]=!0);this.teams.forEach((t,n)=>{t.started&&!t.lost&&!e[n]&&Vf(this,n,`Everything destroyed`)})}matchResult(e=0){let t=this.teams[e];if(!t.started)return null;if(t.lost)return`defeat`;let n=0;for(let t=0;t<this.teams.length;t++)if(t!==e&&this.teams[t].started){if(!this.teams[t].lost)return null;n++}return n>0?`victory`:null}setupGarrison(){let e=this.planet,t=e.blobs.find(e=>e.kind===`large`)??e.blobs[0],n=-1,r=1/0;if(e.blobs.forEach((e,i)=>{if(e.kind!==`medium`)return;let a=K(e.c[0],e.c[1],e.c[2],t.c[0],t.c[1],t.c[2]);a<r&&(r=a,n=i)}),n<0)return;let i=e.nearestCell(e.cellOf(...e.blobs[n].c),t=>e.land[t]===1);i>=0&&this.spawnSquad(jd.team,hm(e,i),jd.tanks,jd.destroyers,jd.drones,27255)}spawnSquad(e,t,n,r,i,a){let o=this.planet,s=new sd((o.params.seed^a^this.nextId*7919)>>>0),c=[],l=o.cellOf(...t);if(o.land[l])for(let r=0;r<n;r++)c.push(this.spawnNear(W.Tank,e,t,35,s));let u=o.nearestCell(l,e=>o.land[e]===0);if(u>=0&&r>0){let t=o.nearestCell(u,e=>{if(o.land[e])return!1;for(let t=o.adjStart[e];t<o.adjStart[e+1];t++)if(o.land[o.adj[t]])return!1;return K(o.cx[e],o.cy[e],o.cz[e],o.cx[u],o.cy[u],o.cz[u])*o.radius>25},4e3),n=hm(o,t>=0?t:u);for(let t=0;t<r;t++)c.push(this.spawnNear(W.Boat,e,n,30,s))}for(let n=0;n<i;n++)c.push(this.spawnNear(W.Drone,e,t,35,s));let d=c.filter(e=>e>=0);for(let e of d)this.guard[e]=1,this.gpx[e]=this.x[e],this.gpy[e]=this.y[e],this.gpz[e]=this.z[e];return d}spawnNear(e,t,n,r,i){let a=this.planet,o=G[e].layer;for(let s=0;s<60;s++){let s=i.dir(),c=r*i.next()/a.radius,l=[n[0]+s[0]*c,n[1]+s[1]*c,n[2]+s[2]*c];if(vd(a,o,a.cellOf(...l)))return this.spawn(e,t,l)}return-1}spawnStress(e,t,n){let r=new sd(n),i=this.planet;for(let n=0;n<e&&this.count<4096;n++){let e=r.next(),n=e<.5?W.Tank:e<.85?W.Boat:W.Drone,a=G[n].layer;for(let e=0;e<200;e++){let e=r.dir();if(vd(i,a,i.cellOf(...e))){this.spawn(n,t,e);break}}}}};function K(e,t,n,r,i,a){let o=e-r,s=t-i,c=n-a;return Math.sqrt(o*o+s*s+c*c)}function hm(e,t){return[e.cx[t],e.cy[t],e.cz[t]]}function gm(e,t=`#e2f4f6`,n=`#3ff0d8`){return`<svg class="emblem" viewBox="0 0 100 100" width="${e}" height="${e}" role="img" aria-label="Atoll Rising"><path d="M50 4 L90 27 V73 L50 96 L10 73 V27 Z" fill="none" stroke="${t}" stroke-width="3"/><path d="M50 12 L83 31 V69 L50 88 L17 69 V31 Z" fill="none" stroke="${t}" stroke-opacity="0.35" stroke-width="1.2"/><path d="M30.5 62 A22 14 0 1 1 69.5 62" fill="none" stroke="${n}" stroke-width="5"/><path d="M36 70 H64" stroke="${n}" stroke-width="3" stroke-opacity="0.55"/><path d="M50 22 L60 36 H54 V58 H46 V36 H40 Z" fill="${t}"/></svg>`}var _m=`<svg class="lock" viewBox="0 0 24 24" fill="none" stroke="#3ff0d8" stroke-width="2.2" role="img" aria-label="Password"><rect x="5" y="11" width="14" height="10"/><path d="M8 11V7a4 4 0 0 1 8 0v4"/></svg>`,vm=`https://atollrising.eu/`,ym=[`www`,`test`];function bm(e=location.hostname,t=location.search){return new URLSearchParams(t).has(`server`)?!0:e.endsWith(`.atollrising.eu`)?!ym.includes(e.slice(0,-15)):!1}function xm(){return new URLSearchParams(location.search).get(`server`)??`wss://${location.host}/ws`}function Sm(){return new URLSearchParams(location.search).get(`directory`)??`https://atollrising.eu/api/?a=list`}var Cm=class{on;ws=null;constructor(e){this.on=e}open(){if(this.ws)return;this.on.status(`Connecting to the game server…`,!1);let e=this.ws=new WebSocket(xm());e.onopen=()=>{this.on.status(`Connected`,!0),this.send({t:`list`});for(let e of this.queued.splice(0))this.send(e)},e.onmessage=e=>{let t=JSON.parse(String(e.data));switch(t.t){case`hello`:this.on.session(t.session??null);break;case`games`:this.on.games(t.list);break;case`room`:this.on.room(t.room);break;case`started`:this.on.started(t.match);break;case`error`:t.text&&this.on.error(t.text)}},e.onclose=()=>{this.ws=null,this.on.status(`Can't reach the game server`,!1)}}close(){this.ws?.close(),this.ws=null}queued=[];send(e){this.ws?.readyState===WebSocket.OPEN?this.ws.send(JSON.stringify(e)):this.ws&&this.queued.push(e)}create(e){this.send({t:`create`,opts:e})}join(e,t){this.send({t:`join`,match:e,password:t})}faction(e){this.send({t:`faction`,faction:e})}start(){this.send({t:`start`})}leave(){this.send({t:`leave`}),this.on.room(null)}};function wm(e=xm()){return new Promise((t,n)=>{let r=new WebSocket(e),i=[],a=null,o=null,s=`connecting`,c=0,l=e=>{r.readyState===WebSocket.OPEN&&r.send(JSON.stringify(e))};r.onopen=()=>{s=`joining`,l({t:`play`})},r.onmessage=e=>{c+=String(e.data).length;let r=JSON.parse(String(e.data));r.t===`joined`?(s=`in game`,t(o={joined:r,send:l,status:()=>s,bytes:()=>c,onEnded:()=>{},attach:e=>{a=e,e.send=e=>l({t:`cmd`,c:e}),e.winRule=r.win,e.techLimit=r.tech,e.startRich=r.rich;for(let t of i.splice(0))t.t===`u`&&e.apply(t,performance.now())}})):r.t===`ended`?(s=`ended`,o?.onEnded(r.text)):r.t===`error`&&r.text?s===`joining`?n(Error(r.text)):console.warn(`server:`,r.text):r.t===`u`&&(a?a.apply(r,performance.now()):i.push(r))},r.onclose=()=>{s!==`in game`&&n(Error(`Can't reach the game server`)),s=`disconnected`}})}var q={me:0},Tm=`blue.difficulty`,Em=[`easy`,`normal`,`hard`],Dm={easy:`Easy`,normal:`Normal`,hard:`Hard`},Om=`blue.faction`,km={agi:`AGI: machine intelligence. Units 15% faster, 15% less health. Specials: Horizon cannon, interceptor drone.`,man:`MAN: humans. Units 15% tougher, 15% slower. Specials: Anvil orbital strike, EMP drone.`};function Am(){try{let e=localStorage.getItem(Om);if(e===`agi`||e===`man`)return e}catch{}return`agi`}var jm=`blue.sides`,Mm=[`#3d8bff`,`#ff5a3d`,`#3dff8b`,`#ffd23d`],Nm=()=>[0,1,2,3].filter(e=>e!==q.me);function Pm(e,t){let n=[{level:e,faction:Bd(t)},{level:`off`,faction:t},{level:`off`,faction:Bd(t)}];try{let e=JSON.parse(localStorage.getItem(jm)??`null`);if(Array.isArray(e)&&e.length===3)return e.map((e,t)=>({level:e&&(Em.includes(e.level)||e.level===`off`&&t>0)?e.level:n[t].level,faction:e&&(e.faction===`agi`||e.faction===`man`)?e.faction:n[t].faction}))}catch{}return n}function Fm(){try{let e=localStorage.getItem(Tm);if(e&&Em.includes(e))return e}catch{}return`normal`}var Im=class{world;seed;difficulty=Fm();faction=Am();slots=Pm(this.difficulty,this.faction);paused=!1;shown=!1;end=document.getElementById(`endscreen`);multiplayer=!1;constructor(e,t){this.world=e,this.seed=t}startHtml(e=!1){let t=e=>`<button data-faction="${e}" class="${e===this.faction?`on`:``}">${zd[e].name}</button>`,n=`<div class="diff"><span class="head">YOUR SIDE</span>${t(`agi`)}${t(`man`)}<br><small id="fac-note">${km[this.faction]}</small></div>`;return e?n:(n+=`<div class="diff"><span class="head">OPPONENTS · EVERYONE AGAINST EVERYONE</span>`,this.slots.forEach((e,t)=>{let r=n=>`<button data-slot="${t}" data-slevel="${n}" class="${e.level===n?`on`:``}">${n===`off`?`Off`:Dm[n]}</button>`,i=n=>`<button data-slot="${t}" data-sfaction="${n}" class="${e.faction===n?`on`:``}"${e.level===`off`?` disabled`:``}>${zd[n].name}</button>`,a=Nm()[t];n+=`${t?`<br>`:``}<span class="side" style="color:${Mm[a]}">${Ld[a]}</span> ${t===0?`<button class="spacer" disabled>Off</button>`:``}${(t===0?Em:[`off`,...Em]).map(r).join(``)} · ${i(`agi`)}${i(`man`)}`}),n+`<br><small id="diff-note">${this.note()}</small></div>`)}onChange=()=>{};summary(){let e=this.opponents(),t=[...new Set(e.map(e=>Dm[e.level]))].join(`/`);return`${zd[this.faction].name} · vs ${e.length} computer${e.length===1?``:`s`}${t?` · ${t}`:``}`}opponents(){return this.slots.filter(e=>e.level!==`off`).map(e=>({level:e.level,faction:e.faction}))}bindStart(e){let t=()=>{try{localStorage.setItem(jm,JSON.stringify(this.slots)),localStorage.setItem(Tm,this.difficulty)}catch{}};e.querySelectorAll(`.diff button[data-faction]`).forEach(t=>{t.addEventListener(`click`,n=>{n.stopPropagation(),this.faction=t.dataset.faction;try{localStorage.setItem(Om,this.faction)}catch{}e.querySelectorAll(`.diff button[data-faction]`).forEach(e=>e.classList.toggle(`on`,e===t));let r=e.querySelector(`#fac-note`);r&&(r.textContent=km[this.faction]),this.onChange()})}),e.querySelectorAll(`.diff button[data-slot]`).forEach(n=>{n.addEventListener(`click`,r=>{r.stopPropagation();let i=Number(n.dataset.slot),a=this.slots[i];n.dataset.slevel?(a.level=n.dataset.slevel,i===0&&a.level!==`off`&&(this.difficulty=a.level)):a.faction=n.dataset.sfaction,t(),e.querySelectorAll(`.diff button[data-slot="${i}"]`).forEach(e=>{e.classList.toggle(`on`,e.dataset.slevel?e.dataset.slevel===a.level:e.dataset.sfaction===a.faction),e.dataset.sfaction&&(e.disabled=a.level===`off`)});let o=e.querySelector(`#diff-note`);o&&(o.textContent=this.note()),this.onChange()})})}note(){let e=this.slots.filter(e=>e.level!==`off`),t=Vd[e.length?e[0].level:this.difficulty],n=e.length>1?` · ${e.length} computer sides: the last side standing wins`:``;return`${Ld[Nm()[0]].split(` (`)[0]}: first attack after ${t.firstWave/60} min, then every ${t.waveEvery/60} min, starting with ${t.waveSize} units`+(t.income===1?``:`, +${Math.round((t.income-1)*100)}% income`)+n}get over(){return this.shown}update(){if(this.shown)return;let e=this.world.matchResult(q.me);e&&(this.shown=!0,this.paused=!0,this.show(e))}show(e){let t=this.world,n=t.teams.map((e,t)=>({t:e,k:t})).filter(({t:e})=>e.started),r=Math.floor(t.tick/20),i=`${Math.floor(r/60)}:${String(r%60).padStart(2,`0`)}`,a=e=>e>=1e4?`${(e/1e3).toFixed(0)}k`:String(Math.round(e)),o=n.map(({k:e})=>`<th style="color:${Mm[e]}">${e===q.me?`You`:Ld[e].split(` (`)[0]}</th>`).join(``),s=(e,t)=>`<tr><td>${e}</td>${n.map(({t:e})=>`<td>${a(t(e.stats))}</td>`).join(``)}</tr>`,c=t.ais.map(e=>`${Ld[e.team].split(` (`)[0]} ${Dm[e.level]}`).join(`, `),l=this.end.querySelector(`.box`);l.innerHTML=gm(60,`#e2f4f6`,e===`victory`?`#3ff0d8`:`#ff6a5a`)+`<h1 class="${e}">${e===`victory`?`Victory`:`Defeat`}</h1><div>${e===`victory`?n.length>2?`You are the last side standing.`:`The enemy Commander is destroyed.`:`Your Commander was destroyed.`} Match time ${i}${c?` · ${c}`:``}</div><table><tr><th></th>${o}</tr>`+s(`Units built`,e=>e.unitsBuilt)+s(`Units lost`,e=>e.unitsLost)+s(`Buildings built`,e=>e.structsBuilt)+s(`Buildings lost`,e=>e.structsLost)+s(`Metal produced`,e=>e.metalMade)+s(`Energy produced`,e=>e.energyMade)+(this.multiplayer?`</table><div class="btns"><button id="end-home" class="primary">Back to Atoll Rising</button><button id="end-list">This server's games</button><button id="end-keep">Keep watching</button></div>`:`</table><div class="btns"><button id="end-new" class="primary">New match</button><button id="end-planet">New planet</button><button id="end-keep">Keep playing</button></div>`),this.end.style.display=`flex`,document.pointerLockElement&&document.exitPointerLock();let u=e=>{let t=new URLSearchParams(location.search);t.set(`seed`,String(e)),t.delete(`autostart`),location.search=t.toString()},d=(e,t)=>{let n=l.querySelector(e);n&&(n.onclick=t)};d(`#end-new`,()=>u(this.seed)),d(`#end-planet`,()=>u(Math.random()*1e9>>>0)),d(`#end-home`,()=>{location.href=`${vm}#mp`}),d(`#end-list`,()=>{let e=new URLSearchParams(location.search);e.delete(`mp`),location.href=`${location.pathname}?${e.toString()}#mp`}),l.querySelector(`#end-keep`).onclick=()=>{this.end.style.display=`none`,this.paused=!1}}},Lm=`0.5.5`,Rm=class{running;allowed=!1;constructor(e,t=window){this.running=e,t.addEventListener(`beforeunload`,e=>this.onBeforeUnload(e))}allow(){this.allowed=!0}get warns(){return!this.allowed&&this.running()}onBeforeUnload(e){this.warns&&(e.preventDefault(),e.returnValue=``)}},zm=`
float hash3u(ivec3 p, uint seed) {
  uint h = (uint(p.x) * 374761393u) ^ (uint(p.y) * 668265263u) ^ (uint(p.z) * 2147483647u) ^ (seed * 1274126177u);
  h = (h ^ (h >> 13u)) * 1274126177u;
  h ^= h >> 16u;
  return float(h) / 4294967296.0;
}
float vnoise3(vec3 p, uint seed) {
  vec3 i = floor(p); vec3 f = p - i;
  vec3 u = f * f * (3.0 - 2.0 * f);
  ivec3 b = ivec3(i);
  float c000 = hash3u(b, seed), c100 = hash3u(b + ivec3(1,0,0), seed);
  float c010 = hash3u(b + ivec3(0,1,0), seed), c110 = hash3u(b + ivec3(1,1,0), seed);
  float c001 = hash3u(b + ivec3(0,0,1), seed), c101 = hash3u(b + ivec3(1,0,1), seed);
  float c011 = hash3u(b + ivec3(0,1,1), seed), c111 = hash3u(b + ivec3(1,1,1), seed);
  float x00 = mix(c000, c100, u.x), x10 = mix(c010, c110, u.x);
  float x01 = mix(c001, c101, u.x), x11 = mix(c011, c111, u.x);
  return mix(mix(x00, x10, u.y), mix(x01, x11, u.y), u.z);
}
float fbm3(vec3 p, uint seed, int oct) {
  float a = 0.5, f = 1.0, s = 0.0, n = 0.0;
  for (int i = 0; i < 6; i++) {
    if (i >= oct) break;
    s += a * vnoise3(p * f, seed + uint(i) * 101u);
    n += a; a *= 0.5; f *= 2.03;
  }
  return s / n;
}
`,Bm=`
uniform vec4 uBlobs[64]; // xyz centre, w radius
uniform float uBlobH[64];
uniform int uBlobCount;
uniform uint uSeed;
float heightAt(vec3 d) {
  float warp = fbm3(d * 6.0 + vec3(11.0, 0.0, 0.0), uSeed + 7u, 3) - 0.5;
  float best = -0.55 + (fbm3(d * 3.0, uSeed + 3u, 3) - 0.5) * 0.4;
  for (int i = 0; i < 64; i++) {
    if (i >= uBlobCount) break;
    vec3 c = uBlobs[i].xyz; float r = uBlobs[i].w;
    vec3 dd = c - d;
    float d2 = dot(dd, dd);
    float lim = r * 1.6 + ${hd.toFixed(6)};
    if (d2 > lim * lim) continue;
    float dist = sqrt(d2) * (1.0 + warp * 0.9);
    float t = 1.0 - dist / r;
    float hh;
    if (t > ${pd.toFixed(6)}) {
      float detail = fbm3(d * 25.0, uSeed + 19u, 3) - 0.5;
      float w = min(1.0, (t - ${pd.toFixed(6)}) / 0.06);
      hh = (sqrt(t) - 0.12) * uBlobH[i] + detail * 0.25 * uBlobH[i] * w;
    } else {
      hh = (t - ${pd.toFixed(6)}) * r * ${md.toFixed(6)};
    }
    best = max(best, hh);
  }
  return best;
}
`;function Vm(e){let t=Array(64).fill(0).map(()=>new en),n=Array(64).fill(0);return e.blobs.slice(0,64).forEach((e,r)=>{t[r].set(e.c[0],e.c[1],e.c[2],e.r),n[r]=e.h}),{uBlobs:{value:t},uBlobH:{value:n},uBlobCount:{value:Math.min(e.blobs.length,64)},uSeed:{value:e.params.seed>>>0}}}var Hm=`
uniform samplerCube uHeightCube;
uniform float uHeightOffset;
float bakedHeight(vec3 dir) { return textureLod(uHeightCube, dir, 0.0).r - uHeightOffset; }
`,Um=`
uniform float uTime;
uniform uint uCloudSeed;
vec3 rotY(vec3 p, float a) { float c = cos(a), s = sin(a); return vec3(c * p.x + s * p.z, p.y, -s * p.x + c * p.z); }
float weatherCoverage(vec3 dir) {
  vec3 p = rotY(dir, uTime * 0.0035);
  float w = fbm3(p * 1.25 + vec3(3.1, 0.0, 0.0), uCloudSeed, 3);
  return smoothstep(0.54, 0.72, w);           // mostly clear, some cloudy regions, few overcast
}
vec2 cloudDensity(vec3 dir) {
  float cov = weatherCoverage(dir);
  vec3 p = rotY(dir, uTime * (0.006 + 0.004 * dir.y * dir.y));
  vec3 q = p * 5.0;
  vec3 warp = vec3(fbm3(q + vec3(1.7, 9.2, 0.0), uCloudSeed + 11u, 2), fbm3(q + vec3(8.3, 2.8, 0.0), uCloudSeed + 23u, 2), 0.0);
  float detail = fbm3(p * 7.0 + warp * 1.4 + vec3(0.0, uTime * 0.002, 0.0), uCloudSeed + 31u, 5);
  float thr = 0.74 - cov * 0.38;
  float dense = smoothstep(thr - 0.05, thr + 0.1, detail);
  float mist = smoothstep(0.42, 0.7, detail) * smoothstep(0.15, 0.5, cov) * 0.22;
  float sheet = smoothstep(0.8, 1.0, cov) * (0.35 + 0.35 * detail);
  float d = clamp(max(dense * (0.4 + 0.6 * cov), max(mist, sheet)), 0.0, 1.0);
  return vec2(d, cov);
}
`,Wm=`
uniform samplerCube uCloudCube;
vec3 cloudTex(vec3 dir) { return textureLod(uCloudCube, dir, 0.0).rgb; }
float cloudShadow(vec3 dir, vec3 sunDir) {
  vec3 tang = sunDir - dir * dot(sunDir, dir);
  float d = cloudTex(normalize(dir + tang * 0.09)).r;
  return 1.0 - d * 0.32;
}
`;function Gm(e,t,n=1024){let r=e.extensions.has(`EXT_color_buffer_float`),i=r?0:.5,a=new cc(n,{type:r?g:l,format:w,generateMipmaps:!1,minFilter:o,magFilter:o}),s=new Hn,c=new Po({uniforms:{...Vm(t),uOffset:{value:i}},side:1,depthTest:!1,depthWrite:!1,vertexShader:`
      varying vec3 vDir;
      void main() { vDir = position; gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0); }`,fragmentShader:`
      precision highp float; precision highp int;
      ${zm}
      ${Bm}
      uniform float uOffset;
      varying vec3 vDir;
      void main() {
        float h = heightAt(normalize(vDir));
        gl_FragColor = vec4(clamp(h + uOffset, -1.0, 1.0), 0.0, 0.0, 1.0);
      }`});s.add(new oi(new Xi(10,10,10),c));let u=new Os(.1,100,a),d=e.toneMapping;return e.toneMapping=0,u.update(e,s),e.toneMapping=d,c.dispose(),{rt:a,offset:i}}function Km(e,t,n,r,i=256){let a=new Float32Array(i*4),o=[],s=12345,c=()=>(s=Math.imul(s,1664525)+1013904223>>>0)/4294967296;for(let e=0;e<i;e++){let n,r,i,s;if(e%2==0&&t.blobs.length){let a=t.blobs[e%t.blobs.length];n=a.c[0]+(c()-.5)*a.r*2.4,r=a.c[1]+(c()-.5)*a.r*2.4,i=a.c[2]+(c()-.5)*a.r*2.4}else n=c()*2-1,r=c()*2-1,i=c()*2-1;s=Math.hypot(n,r,i),n/=s,r/=s,i/=s,a.set([n,r,i,1],e*4),o.push(Math.max(-.5,Math.min(.5,t.heightAt(n,r,i))))}let u=new li(a,i,1,w,h);u.needsUpdate=!0;let d=new nn(i,1,{type:l}),f=new Po({uniforms:{uDirs:{value:u},uHeightCube:{value:n.texture},uHeightOffset:{value:r},uN:{value:i}},vertexShader:`void main() { gl_Position = vec4(position.xy * 2.0, 0.0, 1.0); }`,fragmentShader:`
      precision highp float;
      uniform sampler2D uDirs; uniform float uN;
      ${Hm}
      void main() {
        vec3 d = texelFetch(uDirs, ivec2(int(gl_FragCoord.x), 0), 0).xyz;
        gl_FragColor = vec4(bakedHeight(d) + 0.5, 0.0, 0.0, 1.0);
      }`}),p=new Hn;p.add(new oi(new So(1,1),f));let m=new hs,g=e.toneMapping;e.toneMapping=0,e.setRenderTarget(d),e.render(p,m);let _=new Uint8Array(i*4);e.readRenderTargetPixels(d,0,0,i,1,_),e.setRenderTarget(null),e.toneMapping=g;let v=0,y=0;for(let e=0;e<i;e++){let t=_[e*4]/255-.5,n=Math.abs(t-o[e]);v=Math.max(v,n),y+=n}return d.dispose(),f.dispose(),u.dispose(),{max:v,mean:y/i,n:i}}function qm(e,t=!1){let n=e[0].index!==null,r=new Set(Object.keys(e[0].attributes)),i=new Set(Object.keys(e[0].morphAttributes)),a={},o={},s=e[0].morphTargetsRelative,c=new Ir;c.morphTargetsRelative=s;let l=0;for(let u=0;u<e.length;++u){let d=e[u],f=0,p=0;if(n!==(d.index!==null))return console.error(`THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index `+u+`. All geometries must have compatible attributes; make sure index attribute exists among all geometries, or in none of them.`),null;for(let e in d.attributes){if(!r.has(e))return console.error(`THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index `+u+`. All geometries must have compatible attributes; make sure "`+e+`" attribute exists among all geometries, or in none of them.`),null;a[e]===void 0&&(a[e]=[]),a[e].push(d.attributes[e]),f++}if(f!==r.size)return console.error(`THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index `+u+`. Make sure all geometries have the same number of attributes.`),null;if(s!==d.morphTargetsRelative)return console.error(`THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index `+u+`. .morphTargetsRelative must be consistent throughout all geometries.`),null;for(let t in d.morphAttributes){if(!i.has(t))return console.error(`THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index `+u+`.  .morphAttributes must be consistent throughout all geometries.`),null;if(d.morphAttributes[t].length!==e[0].morphAttributes[t].length)return console.error(`THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index `+u+`. All geometries must have the same number of morph targets for the "`+t+`" morph attribute.`),null;o[t]===void 0&&(o[t]=[]),o[t].push(d.morphAttributes[t]),p++}if(p!==i.size)return console.error(`THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index `+u+`. Make sure all geometries have the same number of morph attributes.`),null;if(t){let e;if(n)e=d.index.count;else if(d.attributes.position!==void 0)e=d.attributes.position.count;else return console.error(`THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index `+u+`. The geometry must have either an index or a position attribute`),null;c.addGroup(l,e,u),l+=e}}if(n){let t=0,n=[];for(let r=0;r<e.length;++r){let i=e[r].index;for(let e=0;e<i.count;++e)n.push(i.getX(e)+t);t+=e[r].attributes.position.count}c.setIndex(n)}for(let e in a){let t=Jm(a[e]);if(!t)return console.error(`THREE.BufferGeometryUtils: .mergeGeometries() failed while trying to merge the `+e+` attribute.`),null;c.setAttribute(e,t)}for(let e in o){let t=o[e][0].length;if(t!==0){c.morphAttributes=c.morphAttributes||{},c.morphAttributes[e]=[];for(let n=0;n<t;++n){let t=[];for(let r=0;r<o[e].length;++r)t.push(o[e][r][n]);let r=Jm(t);if(!r)return console.error(`THREE.BufferGeometryUtils: .mergeGeometries() failed while trying to merge the `+e+` morphAttribute.`),null;c.morphAttributes[e].push(r)}}}return c}function Jm(e){let t,n,r,i=-1,a=0;for(let o=0;o<e.length;++o){let s=e[o];if(t===void 0&&(t=s.array.constructor),t!==s.array.constructor)return console.error(`THREE.BufferGeometryUtils: .mergeAttributes() failed. BufferAttribute.array must be of consistent array types across matching attributes.`),null;if(n===void 0&&(n=s.itemSize),n!==s.itemSize)return console.error(`THREE.BufferGeometryUtils: .mergeAttributes() failed. BufferAttribute.itemSize must be consistent across matching attributes.`),null;if(r===void 0&&(r=s.normalized),r!==s.normalized)return console.error(`THREE.BufferGeometryUtils: .mergeAttributes() failed. BufferAttribute.normalized must be consistent across matching attributes.`),null;if(i===-1&&(i=s.gpuType),i!==s.gpuType)return console.error(`THREE.BufferGeometryUtils: .mergeAttributes() failed. BufferAttribute.gpuType must be consistent across matching attributes.`),null;a+=s.count*n}let o=new t(a),s=new xr(o,n,r),c=0;for(let t=0;t<e.length;++t){let r=e[t];if(r.isInterleavedBufferAttribute){let e=c/n;for(let t=0,i=r.count;t<i;t++)for(let i=0;i<n;i++){let n=r.getComponent(t,i);s.setComponent(t+e,i,n)}}else o.set(r.array,c);c+=r.count*n}return i!==void 0&&(s.gpuType=i),s}function Ym(e,t=1e-4){t=Math.max(t,2**-52);let n={},r=e.getIndex(),i=e.getAttribute(`position`),a=r?r.count:i.count,o=0,s=Object.keys(e.attributes),c=[],l=new Map,u=[],d=[`getX`,`getY`,`getZ`,`getW`],f=t*.5,p=10**Math.log10(1/t),m=f*p;for(let t=0;t<a;t++){let i=r?r.getX(t):t,a=``;for(let t=0,n=s.length;t<n;t++){let n=s[t],r=e.getAttribute(n),o=r.itemSize;for(let e=0;e<o;e++)a+=`${Math.trunc(r[d[e]](i)*p+m)},`}a in n?u.push(n[a]):(c.push(i),n[a]=o,u.push(o),o++)}let h=e.clone();for(let t in e.attributes)h.setAttribute(t,Xm(e.attributes[t],c,l));for(let t in e.morphAttributes)h.morphAttributes[t]=e.morphAttributes[t].map(e=>Xm(e,c,l));return h.setIndex(u),h}function Xm(e,t,n=new Map){let r=e.isInterleavedBufferAttribute,i=r?e.data:e,a=r?i.stride:e.itemSize,o=r?n.get(i):void 0;if(o===void 0){let s=new i.array.constructor(t.length*a);for(let e=0;e<t.length;e++)for(let n=0;n<a;n++)s[e*a+n]=i.array[t[e]*a+n];o=r?new i.constructor(s,a,i.meshPerAttribute):new e.constructor(s,e.itemSize,e.normalized,e.meshPerAttribute),o.setUsage(i.usage),r&&n.set(i,o)}let s=r?new e.constructor(o,e.itemSize,e.offset,e.normalized):o;return s.name=e.name,r||(s.gpuType=e.gpuType),s}var Zm=[[[1,0,0],[0,0,-1],[0,1,0]],[[-1,0,0],[0,0,1],[0,1,0]],[[0,1,0],[1,0,0],[0,0,-1]],[[0,-1,0],[1,0,0],[0,0,1]],[[0,0,1],[1,0,0],[0,1,0]],[[0,0,-1],[-1,0,0],[0,1,0]]];function Qm(e,t){return e.radius+(t>0?t*45:t*70)}function $m(e,t,n,r,i,a){let o=ud(t*40,n*40,r*40,i+51,2);if(e<-.25)a.setRGB(.05,.12,.2);else if(e<0){let t=(e+.25)/.25;a.setRGB(.05+.55*t*t,.12+.5*t*t,.2+.3*t*t)}else if(e<.025)a.setRGB(.84,.78,.58);else if(e<.45){let e=.36+o*.22;a.setRGB(.18+o*.12,e,.12+o*.05)}else if(e<.7){let t=(e-.45)/.25;a.setRGB(.3+t*.15+o*.1,.36-t*.02+o*.08,.22+t*.1)}else a.setRGB(.5+o*.12,.48+o*.1,.45+o*.1)}function eh(e,t=160){let n=[],r=[],i=[],a=new R;for(let[o,s,c]of Zm){let l=n.length/3;for(let i=0;i<=t;i++)for(let l=0;l<=t;l++){let u=l/t*2-1,d=i/t*2-1,f=o[0]+u*s[0]+d*c[0],p=o[1]+u*s[1]+d*c[1],m=o[2]+u*s[2]+d*c[2],h=Math.hypot(f,p,m);f/=h,p/=h,m/=h;let g=e.heightAt(f,p,m),_=Qm(e,g);n.push(f*_,p*_,m*_),$m(g,f,p,m,e.params.seed,a),r.push(a.r,a.g,a.b)}for(let e=0;e<t;e++)for(let n=0;n<t;n++){let r=l+e*(t+1)+n;i.push(r,r+1,r+t+1,r+1,r+t+2,r+t+1)}}let o=new Ir;o.setAttribute(`position`,new wr(n,3)),o.setAttribute(`color`,new wr(r,3)),o.setIndex(i),o=Ym(o,.001),o.computeVertexNormals();let s=new Io({vertexColors:!0,roughness:.95,metalness:0});return new oi(o,s)}function th(e,t){return new oi(new wo(e.radius*1.08,96,64),new Po({uniforms:{uSunDir:{value:t}},side:1,transparent:!0,blending:2,depthWrite:!1,vertexShader:`
      #include <common>
      #include <logdepthbuf_pars_vertex>
      varying vec3 vN; varying vec3 vW;
      void main() {
        vN = normalize(normalMatrix * normal);
        vW = (modelMatrix * vec4(position, 1.0)).xyz;
        gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
        #include <logdepthbuf_vertex>
      }`,fragmentShader:`
      #include <common>
      #include <logdepthbuf_pars_fragment>
      uniform vec3 uSunDir; varying vec3 vN; varying vec3 vW;
      void main() {
        #include <logdepthbuf_fragment>
        float rim = pow(0.72 - dot(vN, vec3(0.0, 0.0, 1.0)), 4.0);
        float s = dot(normalize(vW), normalize(uSunDir));
        float day = smoothstep(-0.4, 0.4, s);
        float dusk = 1.0 - smoothstep(0.0, 0.3, abs(s)); // the line between day and night glows warm
        vec3 col = mix(vec3(0.3, 0.55, 1.0), vec3(1.0, 0.55, 0.3), dusk * 0.7);
        gl_FragColor = vec4(col * rim * (0.35 + day + dusk * 0.4), 1.0);
      }`}))}function nh(){let e=6e3,t=new Float32Array(e*3),n=new Float32Array(e*3);for(let r=0;r<e;r++){let e=new L().randomDirection().multiplyScalar(6e4);t.set([e.x,e.y,e.z],r*3);let i=.4+Math.random()*.6,a=Math.random();n.set([i,i*(.85+a*.15),i*(.8+(1-a)*.2)],r*3)}let r=new Ir;return r.setAttribute(`position`,new xr(t,3)),r.setAttribute(`color`,new xr(n,3)),new Wi(r,new zi({size:1.6,sizeAttenuation:!1,vertexColors:!0}))}var rh=`
uniform sampler2D uFogTex; uniform float uFogOn; uniform float uFogN;
float fogAt(vec3 d) {
  if (uFogOn < 0.5) return 1.0;
  vec3 a = abs(d); float f; vec3 n; vec3 t1; vec3 t2;
  if (a.x >= a.y && a.x >= a.z) {
    if (d.x > 0.0) { f = 0.0; n = vec3(1, 0, 0); t1 = vec3(0, 0, -1); t2 = vec3(0, 1, 0); }
    else { f = 1.0; n = vec3(-1, 0, 0); t1 = vec3(0, 0, 1); t2 = vec3(0, 1, 0); }
  } else if (a.y >= a.z) {
    if (d.y > 0.0) { f = 2.0; n = vec3(0, 1, 0); t1 = vec3(1, 0, 0); t2 = vec3(0, 0, -1); }
    else { f = 3.0; n = vec3(0, -1, 0); t1 = vec3(1, 0, 0); t2 = vec3(0, 0, 1); }
  } else {
    if (d.z > 0.0) { f = 4.0; n = vec3(0, 0, 1); t1 = vec3(1, 0, 0); t2 = vec3(0, 1, 0); }
    else { f = 5.0; n = vec3(0, 0, -1); t1 = vec3(-1, 0, 0); t2 = vec3(0, 1, 0); }
  }
  float dn = dot(d, n);
  vec2 uv = clamp((vec2(dot(d, t1), dot(d, t2)) / dn + 1.0) * 0.5, 0.5 / uFogN, 1.0 - 0.5 / uFogN);
  return texture2D(uFogTex, vec2(uv.x, (f + uv.y) / 6.0)).r;
}
// 0 never seen: the dark shroud; 0.5 seen before: greyed and about 20% bright; 1 in sight: as is
vec3 fogShade(vec3 c, float f) {
  vec3 grey = vec3(dot(c, vec3(0.3, 0.55, 0.15)));
  vec3 seen = mix(grey, c, 0.45) * 0.22;
  vec3 shroud = vec3(0.010, 0.018, 0.030);
  return f < 0.5 ? mix(shroud, seen, f * 2.0) : mix(seen, c, (f - 0.5) * 2.0);
}
`,ih=class{world;texture;data;target;stamp;queue;explored;gen=0;timer=0;landed=!1;enabled=!0;constructor(e){this.world=e;let t=e.planet;this.data=new Uint8Array(t.cellCount).fill(255),this.target=new Uint8Array(t.cellCount),this.stamp=new Int32Array(t.cellCount),this.queue=new Int32Array(t.cellCount),this.explored=new Uint8Array(t.cellCount),this.texture=new li(this.data,t.N,t.N*6,D,l),this.texture.magFilter=o,this.texture.minFilter=o,this.texture.needsUpdate=!0}get active(){return this.enabled&&this.world.teams[q.me].started}seen(e){return!this.active||this.explored[this.world.planet.cellOf(e[0],e[1],e[2])]===1}level(e){return this.data[e]}paint(){let e=this.world,t=e.planet;this.target.fill(0);let n=e.sensors[q.me];e.visible(q.me,[1,0,0]);let r=new Set;for(let e=0;e<n.n;e++){let i=t.cellOf(n.sx[e],n.sy[e],n.sz[e]),a=i*4096+Math.min(4095,Math.round(n.sr[e]*1e3));r.has(a)||(r.add(a),this.circle(i,n.sx[e],n.sy[e],n.sz[e],n.sr[e]))}let i=this.target,a=this.explored;for(let e=0;e<i.length;e++)i[e]===255?a[e]=1:a[e]&&(i[e]=128)}circle(e,t,n,r,i){let a=this.world.planet,o=++this.gen,s=this.queue,c=0,l=0;s[l++]=e,this.stamp[e]=o;let u=i*i;for(;c<l;){let e=s[c++],i=a.cx[e]-t,d=a.cy[e]-n,f=a.cz[e]-r;if(!(i*i+d*d+f*f>u)){this.target[e]=255;for(let t=a.adjStart[e];t<a.adjStart[e+1];t++){let e=a.adj[t];this.stamp[e]!==o&&(this.stamp[e]=o,s[l++]=e)}}}}update(e){if(!this.active||(this.landed||(this.landed=!0,this.data.fill(0)),this.timer-=e,this.timer>0))return;this.timer=.15,this.paint();let t=this.data,n=this.target;for(let e=0;e<t.length;e++){let r=t[e],i=n[e];r!==i&&(t[e]=r<i?Math.min(i,r+77):Math.max(i,r-77))}this.texture.needsUpdate=!0}};function ah(e,t){return new oi(new bo(e.radius,160),new Po({uniforms:{...t,uRadius:{value:e.radius},uDebug:{value:Number(new URLSearchParams(location.search).get(`dbg`)??0)}},transparent:!0,vertexShader:`
      #include <common>
      #include <logdepthbuf_pars_vertex>
      uniform float uTime; uniform float uRadius;
      varying vec3 vWorld; varying vec3 vSwellN;
      void main() {
        vec3 n = normalize(position);
        vec3 p = n * uRadius;
        // long swell (wavelengths 90–220 units, < 0.5 units high)
        const vec3 K0 = normalize(vec3(0.8, 0.1, 0.59)), K1 = normalize(vec3(-0.3, 0.9, 0.31)), K2 = normalize(vec3(0.2, -0.4, 0.89));
        float h = 0.0; vec3 g = vec3(0.0);
        vec3 K[3] = vec3[](K0, K1, K2);
        float L[3] = float[](220.0, 140.0, 90.0);
        float A[3] = float[](0.45, 0.3, 0.16);
        for (int i = 0; i < 3; i++) {
          float f = 6.2832 / L[i];
          float ph = dot(p, K[i]) * f - uTime * sqrt(9.8 * f);
          h += A[i] * sin(ph);
          g += A[i] * f * cos(ph) * K[i];
        }
        g -= n * dot(g, n);
        vSwellN = normalize(n - g);
        vec3 wp = n * (uRadius + h);
        vWorld = (modelMatrix * vec4(wp, 1.0)).xyz;
        gl_Position = projectionMatrix * viewMatrix * vec4(vWorld, 1.0);
        #include <logdepthbuf_vertex>
      }`,fragmentShader:`
      precision highp float; precision highp int;
      #include <common>
      #include <logdepthbuf_pars_fragment>
      ${zm}
      ${Hm}
      ${Wm}
      ${rh}
      uniform float uTime;
      uniform vec3 uSunDir; uniform float uPixelAngle; uniform float uCloudShadows; uniform float uDebug;
      varying vec3 vWorld; varying vec3 vSwellN;

      // 12 directional waves, 1.1–30 units long (owner: bigger waves, 2026-11-21); each fades out once smaller than a few pixels.
      // Crests are bent by low-frequency noise and wave groups rise and fall across the sea,
      // so the sum never forms the regular criss-cross lattice of pure plane waves.
      vec3 detailNormal(vec3 p, vec3 n, float strength, float footprint, out float lost) {
        const int NW = 12;
        vec3 w = vec3(vnoise3(p * 0.006, 41u), vnoise3(p * 0.006 + vec3(17.0), 42u), vnoise3(p * 0.006 + vec3(-9.0, 4.0, 23.0), 43u)) - 0.5;
        vec3 pw = p + w * 120.0;
        float grpA = vnoise3(p * 0.012, 44u), grpB = vnoise3(p * 0.012 + vec3(5.0, 11.0, 2.0), 45u);
        vec3 g = vec3(0.0);
        float total = 0.0, kept = 0.0;
        for (int i = 0; i < NW; i++) {
          float fi = float(i);
          vec3 k = normalize(vec3(sin(fi * 2.399 + 0.3), cos(fi * 1.713 + 1.1), sin(fi * 0.917 + 2.0)));
          float lambda = 30.0 * pow(0.74, fi);
          float f = 6.2832 / lambda;
          float grp = mod(fi, 2.0) < 0.5 ? grpA : grpB;
          float steep = 0.12 * strength * (0.6 + 0.4 * fract(fi * 0.618)) * (0.25 + 1.5 * grp);
          float ph = dot(pw, k) * f - uTime * sqrt(9.8 * f) * 0.9 + fi * 1.7;
          float fade = smoothstep(4.0 * footprint, 12.0 * footprint, lambda);
          g += steep * cos(ph) * k * fade;
          total += steep; kept += steep * fade;
        }
        lost = 1.0 - kept / max(total, 1e-4);
        g -= n * dot(g, n);
        return normalize(n - g);
      }

      void main() {
        #include <logdepthbuf_fragment>
        vec3 dir = normalize(vWorld);
        vec3 V = normalize(cameraPosition - vWorld);
        vec3 L = normalize(uSunDir);
        float camDist = length(cameraPosition - vWorld);
        float footprint = camDist * uPixelAngle / max(dot(V, dir), 0.15);
        float day = smoothstep(-0.2, 0.25, dot(dir, L));

        float h = bakedHeight(dir);            // < 0 under water
        float depth = max(-h, 0.0);
        vec3 ct = cloudTex(dir);
        float cov = ct.g;
        float strength = 0.7 + 0.9 * cov;       // rougher sea under heavy weather
        float lost;
        vec3 N = detailNormal(vWorld, vSwellN, strength * mix(0.4, 1.0, smoothstep(0.0, 0.05, depth)), footprint, lost);

        vec3 deep = vec3(0.004, 0.035, 0.1), mid = vec3(0.01, 0.12, 0.24), shallow = vec3(0.07, 0.46, 0.5);
        vec3 water = mix(deep, mid, smoothstep(0.4, 0.12, depth));
        water = mix(water, shallow, smoothstep(0.08, 0.0, depth));
        float shade = uCloudShadows > 0.5 ? cloudShadow(dir, L) : 1.0;
        // night: a full moon opposite the sun lights the water in cool blue (owner: bright moonlit nights)
        vec3 M = -L;
        float night = 1.0 - day;
        float dusk = 1.0 - smoothstep(0.0, 0.28, abs(dot(dir, L) - 0.03)); // sun on the horizon here
        vec3 lightCol = mix(vec3(0.42, 0.52, 0.8), mix(vec3(1.0), vec3(1.15, 0.78, 0.5), dusk), day);
        float lit = mix(max(dot(N, M), 0.0), max(dot(N, L), 0.0), day);
        water *= lightCol * (0.6 + 0.4 * lit) * mix(1.0, shade, day);

        float fres = 0.02 + 0.5 * pow(1.0 - max(dot(N, V), 0.0), 5.0);
        vec3 sky = mix(vec3(0.05, 0.075, 0.14), mix(vec3(0.25, 0.4, 0.6), vec3(0.42, 0.45, 0.5), cov), day);
        sky = mix(sky, vec3(0.75, 0.45, 0.28), dusk * 0.6 * (1.0 - cov)); // golden sky at dawn and dusk
        vec3 H = normalize(L + V);
        // distant water is rougher at sub-pixel scale → broader, dimmer glint
        float shin = mix(260.0, 24.0, lost);
        float spec = pow(max(dot(N, H), 0.0), shin) * mix(0.8, 0.22, lost) * day * shade * (1.0 - 0.7 * cov) / (1.0 + footprint * 0.6);
        // the moon's glint at night
        vec3 Hm = normalize(M + V);
        float mspec = pow(max(dot(N, Hm), 0.0), shin) * mix(0.5, 0.15, lost) * night * (1.0 - 0.7 * cov) / (1.0 + footprint * 0.6);
        vec3 col = mix(water, sky, fres) + mix(vec3(1.0, 0.95, 0.85), vec3(1.1, 0.7, 0.4), dusk) * spec + vec3(0.7, 0.8, 1.0) * mspec;

        // --- surf: broken foam lines rolling in, and the swash edge running up and down the sand
        float n1 = vnoise3(vWorld * 0.05 + vec3(0.0, uTime * 0.04, 0.0), 7u);   // along-shore variation
        float n2 = vnoise3(vWorld * 0.35 + vec3(uTime * 0.15, 0.0, 0.0), 9u);  // foam texture
        float n3 = vnoise3(vWorld * 1.6 - vec3(0.0, 0.0, uTime * 0.3), 13u);   // fine bubbles
        float zone = smoothstep(0.045, 0.004, depth);
        // crest position moves shoreward over time; spacing and phase vary along the shore
        float phase = depth * (300.0 + 120.0 * n1) + uTime * 1.1 + n1 * 9.0;
        float crest = pow(max(sin(phase), 0.0), 6.0);
        float broken = smoothstep(0.35, 0.75, n2 * 0.7 + n3 * 0.3 + 0.25 * zone);
        float surf = crest * zone * broken;
        float swash = 0.006 + 0.005 * sin(uTime * 0.65 + n1 * 6.0);
        float edge = smoothstep(swash, swash * 0.25, depth) * smoothstep(0.2, 0.6, n2 * 0.6 + n3 * 0.4 + 0.15);
        float foam = clamp(surf * 0.85 + edge, 0.0, 1.0);
        float near = 1.0 - smoothstep(1.2, 4.0, footprint);
        foam *= mix(0.3, 1.0, near);
        col = mix(col, vec3(0.9, 0.94, 0.96) * (0.35 + 0.65 * day) * mix(1.0, shade, day), foam);

        float alpha = mix(0.45, 0.93, smoothstep(0.0, 0.06, depth));
        alpha = max(max(alpha, fres), foam);
        col = fogShade(col, fogAt(normalize(vWorld))); // fog of war (fogView.ts)
        if (uDebug == 1.0) col = vec3(spec);
        if (uDebug == 2.0) col = N * 0.5 + 0.5;
        if (uDebug == 3.0) col = vec3(fract(footprint));
        if (uDebug == 4.0) col = vec3(shade);
        gl_FragColor = vec4(col, uDebug > 0.0 ? 1.0 : alpha);
        #include <colorspace_fragment>
      }`}))}function oh(e,t){let n=new oi(new bo(e.radius+90,48),new Po({uniforms:{...t},transparent:!0,depthWrite:!1,side:2,vertexShader:`
      #include <common>
      #include <logdepthbuf_pars_vertex>
      varying vec3 vWorld;
      void main() {
        vWorld = (modelMatrix * vec4(position, 1.0)).xyz;
        gl_Position = projectionMatrix * viewMatrix * vec4(vWorld, 1.0);
        #include <logdepthbuf_vertex>
      }`,fragmentShader:`
      precision highp float; precision highp int;
      #include <common>
      #include <logdepthbuf_pars_fragment>
      ${zm}
      ${Wm}
      uniform float uTime;
      uniform vec3 uSunDir; uniform float uCamHeight;
      varying vec3 vWorld;
      void main() {
        #include <logdepthbuf_fragment>
        vec3 dir = normalize(vWorld);
        vec3 ct = cloudTex(dir);
        float fine = vnoise3(vWorld * 0.08 + vec3(uTime * 0.03, 0.0, 0.0), 21u) * 0.6 + vnoise3(vWorld * 0.25, 22u) * 0.4;
        float d = clamp(ct.r * (0.75 + 0.5 * fine) - 0.04, 0.0, 1.0);
        if (d < 0.01) discard;
        float cov = ct.g;
        vec3 L = normalize(uSunDir);
        float sunDot = dot(dir, L);
        float day = smoothstep(-0.25, 0.3, sunDot);
        vec3 bright = vec3(1.0, 0.98, 0.95), grey = vec3(0.5, 0.53, 0.58);
        vec3 col = mix(bright, grey, smoothstep(0.4, 1.0, cov) * d) * ct.b;
        col *= mix(vec3(1.0), vec3(1.0, 0.7, 0.5), smoothstep(0.35, 0.0, sunDot) * day);
        col *= mix(vec3(0.2, 0.25, 0.36), vec3(1.0), day); // moonlit at night
        // fade out as the camera comes down, so clouds never hide the battlefield up close
        float fade = smoothstep(380.0, 1500.0, uCamHeight);
        float a = d * fade * 0.9;
        if (a < 0.005) discard;
        gl_FragColor = vec4(col, a);
        #include <colorspace_fragment>
      }`}));return n.renderOrder=2,n}function sh(e,t,n,r){return{uTime:{value:0},uSunDir:{value:r},uHeightCube:{value:e},uHeightOffset:{value:t},uCloudCube:{value:n},uPixelAngle:{value:.001},uCamHeight:{value:1e3},uCloudShadows:{value:1},uFogTex:{value:null},uFogOn:{value:0},uFogN:{value:128},uWind:{value:.3}}}function ch(e,t){let n=e.material;n.onBeforeCompile=e=>{Object.assign(e.uniforms,t),e.vertexShader=e.vertexShader.replace(`#include <common>`,`#include <common>
varying vec3 vWorldPosT;`).replace(`#include <begin_vertex>`,`#include <begin_vertex>
vWorldPosT = (modelMatrix * vec4(position, 1.0)).xyz;
vNormalT = normalize(mat3(modelMatrix) * objectNormal);`).replace(`#include <common>`,`#include <common>
varying vec3 vNormalT;`),e.fragmentShader=e.fragmentShader.replace(`#include <common>`,`#include <common>
        precision highp int;
        varying vec3 vWorldPosT; varying vec3 vNormalT;
        uniform vec3 uSunDir; uniform float uCloudShadows; uniform float uTime;
        ${zm}
        ${Hm}
        ${Wm}
        ${rh}`).replace(`#include <color_fragment>`,`#include <color_fragment>
        {
          vec3 dirT = normalize(vWorldPosT);
          float hT = bakedHeight(dirT);
          // ground layers above the beach: meadow and dry grass, dirt patches, highland scrub,
          // rock on steep slopes and high up (with strata), snow on the peaks, fine grain up close
          if (hT > 0.0) {
            float macro = vnoise3(vWorldPosT * 0.018, 11u);
            float meso = vnoise3(vWorldPosT * 0.085, 12u);
            float micro = vnoise3(vWorldPosT * 0.55, 13u);
            float slopeT = 1.0 - dot(normalize(vNormalT), dirT);
            vec3 meadow = mix(vec3(0.19, 0.36, 0.11), vec3(0.33, 0.43, 0.16), smoothstep(0.3, 0.8, macro));
            meadow = mix(meadow, vec3(0.13, 0.25, 0.09), smoothstep(0.62, 0.85, meso) * 0.7);
            vec3 ground = mix(meadow, vec3(0.38, 0.31, 0.21), smoothstep(0.72, 0.9, meso * 0.7 + macro * 0.3) * 0.8);
            ground = mix(ground, vec3(0.36, 0.36, 0.24), smoothstep(0.38, 0.6, hT + (macro - 0.5) * 0.12));
            float strata = 0.93 + 0.07 * sin(hT * 420.0 + meso * 9.0 + micro * 2.0);
            vec3 rock = vec3(0.44, 0.41, 0.37) * strata * (0.82 + 0.3 * micro);
            float rocky = max(smoothstep(0.06, 0.16, slopeT + (meso - 0.5) * 0.05), smoothstep(0.62, 0.74, hT + (meso - 0.5) * 0.08));
            ground = mix(ground, rock, rocky);
            float snow = smoothstep(0.78, 0.86, hT + (meso - 0.5) * 0.06) * smoothstep(0.2, 0.08, slopeT);
            ground = mix(ground, vec3(0.9, 0.92, 0.96), snow);
            ground *= 0.86 + 0.28 * micro;
            diffuseColor.rgb = mix(diffuseColor.rgb, ground, smoothstep(0.0, 0.03, hT));
          }
          // per-pixel beach: sand near the waterline (finer than the mesh), sand under the shallows
          float nS = vnoise3(vWorldPosT * 0.12, 5u);
          float sand = smoothstep(0.03 + 0.012 * nS, 0.012, hT);
          diffuseColor.rgb = mix(diffuseColor.rgb, vec3(0.8, 0.74, 0.55), sand);
          // wet sand just above the waterline, following the ocean's swash rhythm
          float nT = vnoise3(vWorldPosT * 0.05 + vec3(0.0, uTime * 0.04, 0.0), 7u);
          float wetLine = 0.013 + 0.005 * sin(uTime * 0.65 + nT * 6.0);
          float wet = smoothstep(wetLine, wetLine * 0.4, hT);
          diffuseColor.rgb *= mix(1.0, 0.62, wet);
          if (uCloudShadows > 0.5) diffuseColor.rgb *= cloudShadow(dirT, normalize(uSunDir));
          // fog of war: never seen covered, seen before darker, in sight clear (fogView.ts)
          diffuseColor.rgb = fogShade(diffuseColor.rgb, fogAt(dirT));
        }`)},n.needsUpdate=!0}function lh(e,t,n){e.onBeforeCompile=e=>{Object.assign(e.uniforms,t),e.vertexShader=e.vertexShader.replace(`#include <common>`,`#include <common>
varying vec3 vWorldPosV;
uniform float uTime; uniform float uWind;`).replace(`#include <begin_vertex>`,`#include <begin_vertex>
        #ifdef USE_INSTANCING
          vec3 basePos = (modelMatrix * instanceMatrix * vec4(0.0, 0.0, 0.0, 1.0)).xyz;
        #else
          vec3 basePos = (modelMatrix * vec4(0.0, 0.0, 0.0, 1.0)).xyz;
        #endif
        float bend = ${n.toFixed(2)} * transformed.y * transformed.y * (0.03 + 0.09 * uWind);
        float ph = dot(basePos, vec3(0.031, 0.027, 0.023));
        transformed.x += bend * sin(uTime * (1.3 + uWind) + ph);
        transformed.z += bend * 0.6 * cos(uTime * (1.1 + uWind) + ph * 1.3);`).replace(`#include <worldpos_vertex>`,`#include <worldpos_vertex>
        #ifdef USE_INSTANCING
          vWorldPosV = (modelMatrix * instanceMatrix * vec4(transformed, 1.0)).xyz;
        #else
          vWorldPosV = (modelMatrix * vec4(transformed, 1.0)).xyz;
        #endif`),e.fragmentShader=e.fragmentShader.replace(`#include <common>`,`#include <common>
        precision highp int;
        varying vec3 vWorldPosV;
        uniform vec3 uSunDir; uniform float uCloudShadows;
        ${zm}
        ${Wm}
        ${rh}`).replace(`#include <color_fragment>`,`#include <color_fragment>
        {
          vec3 dirV = normalize(vWorldPosV);
          if (uCloudShadows > 0.5) diffuseColor.rgb *= cloudShadow(dirV, normalize(uSunDir));
          diffuseColor.rgb = fogShade(diffuseColor.rgb, fogAt(dirV));
        }`)},e.needsUpdate=!0}var uh=class{rt;scene=new Hn;cubeCam;face=0;uniforms;constructor(e,t,n,r=512){this.rt=new cc(r,{type:l,generateMipmaps:!1,minFilter:o,magFilter:o}),this.uniforms={uTime:{value:0},uCloudSeed:{value:t>>>0},uSunDir:{value:n}};let i=new Po({uniforms:this.uniforms,side:1,depthTest:!1,depthWrite:!1,vertexShader:`varying vec3 vDir; void main() { vDir = position; gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0); }`,fragmentShader:`
        precision highp float; precision highp int;
        ${zm}
        ${Um}
        uniform vec3 uSunDir;
        varying vec3 vDir;
        void main() {
          vec3 dir = normalize(vDir);
          vec2 dc = cloudDensity(dir);
          vec3 L = normalize(uSunDir);
          vec3 tang = L - dir * dot(L, dir);
          float toward = cloudDensity(normalize(dir + tang * 0.02)).x;
          float lit = clamp(1.0 - (toward - dc.x) * 1.5, 0.35, 1.0);
          gl_FragColor = vec4(dc.x, dc.y, lit, 1.0);
        }`});this.scene.add(new oi(new Xi(10,10,10),i)),this.cubeCam=new Os(.1,100,this.rt),this.full(e,0)}full(e,t){this.uniforms.uTime.value=t;let n=e.toneMapping;e.toneMapping=0,this.cubeCam.update(e,this.scene),e.toneMapping=n}step(e,t){this.uniforms.uTime.value=t;let n=this.cubeCam.children[this.face],r=e.getRenderTarget(),i=e.toneMapping,a=e.xr.enabled;e.toneMapping=0,e.xr.enabled=!1,e.setRenderTarget(this.rt,this.face),e.render(this.scene,n),e.setRenderTarget(r),e.toneMapping=i,e.xr.enabled=a,this.face=(this.face+1)%6}},dh={name:`CopyShader`,uniforms:{tDiffuse:{value:null},opacity:{value:1}},vertexShader:`

		varying vec2 vUv;

		void main() {

			vUv = uv;
			gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );

		}`,fragmentShader:`

		uniform float opacity;

		uniform sampler2D tDiffuse;

		varying vec2 vUv;

		void main() {

			vec4 texel = texture2D( tDiffuse, vUv );
			gl_FragColor = opacity * texel;


		}`},fh=class{constructor(){this.isPass=!0,this.enabled=!0,this.needsSwap=!0,this.clear=!1,this.renderToScreen=!1}setSize(){}render(){console.error(`THREE.Pass: .render() must be implemented in derived pass.`)}dispose(){}},ph=new Ss(-1,1,1,-1,0,1),mh=new class extends Ir{constructor(){super(),this.setAttribute(`position`,new wr([-1,3,0,-1,-1,0,3,-1,0],3)),this.setAttribute(`uv`,new wr([0,2,0,0,2,0],2))}},hh=class{constructor(e){this._mesh=new oi(mh,e)}dispose(){this._mesh.geometry.dispose()}render(e){e.render(this._mesh,ph)}get material(){return this._mesh.material}set material(e){this._mesh.material=e}},gh=class extends fh{constructor(e,t=`tDiffuse`){super(),this.textureID=t,this.uniforms=null,this.material=null,e instanceof Po?(this.uniforms=e.uniforms,this.material=e):e&&(this.uniforms=jo.clone(e.uniforms),this.material=new Po({name:e.name===void 0?`unspecified`:e.name,defines:Object.assign({},e.defines),uniforms:this.uniforms,vertexShader:e.vertexShader,fragmentShader:e.fragmentShader})),this._fsQuad=new hh(this.material)}render(e,t,n){this.uniforms[this.textureID]&&(this.uniforms[this.textureID].value=n.texture),this._fsQuad.material=this.material,this.renderToScreen?(e.setRenderTarget(null),this._fsQuad.render(e)):(e.setRenderTarget(t),this.clear&&e.clear(e.autoClearColor,e.autoClearDepth,e.autoClearStencil),this._fsQuad.render(e))}dispose(){this.material.dispose(),this._fsQuad.dispose()}},_h=class extends fh{constructor(e,t){super(),this.scene=e,this.camera=t,this.clear=!0,this.needsSwap=!1,this.inverse=!1}render(e,t,n){let r=e.getContext(),i=e.state;i.buffers.color.setMask(!1),i.buffers.depth.setMask(!1),i.buffers.color.setLocked(!0),i.buffers.depth.setLocked(!0);let a,o;this.inverse?(a=0,o=1):(a=1,o=0),i.buffers.stencil.setTest(!0),i.buffers.stencil.setOp(r.REPLACE,r.REPLACE,r.REPLACE),i.buffers.stencil.setFunc(r.ALWAYS,a,4294967295),i.buffers.stencil.setClear(o),i.buffers.stencil.setLocked(!0),e.setRenderTarget(n),this.clear&&e.clear(),e.render(this.scene,this.camera),e.setRenderTarget(t),this.clear&&e.clear(),e.render(this.scene,this.camera),i.buffers.color.setLocked(!1),i.buffers.depth.setLocked(!1),i.buffers.color.setMask(!0),i.buffers.depth.setMask(!0),i.buffers.stencil.setLocked(!1),i.buffers.stencil.setFunc(r.EQUAL,1,4294967295),i.buffers.stencil.setOp(r.KEEP,r.KEEP,r.KEEP),i.buffers.stencil.setLocked(!0)}},vh=class extends fh{constructor(){super(),this.needsSwap=!1}render(e){e.state.buffers.stencil.setLocked(!1),e.state.buffers.stencil.setTest(!1)}},yh=class{constructor(e,t){if(this.renderer=e,this._pixelRatio=e.getPixelRatio(),t===void 0){let n=e.getSize(new I);this._width=n.width,this._height=n.height,t=new nn(this._width*this._pixelRatio,this._height*this._pixelRatio,{type:g}),t.texture.name=`EffectComposer.rt1`}else this._width=t.width,this._height=t.height;this.renderTarget1=t,this.renderTarget2=t.clone(),this.renderTarget2.texture.name=`EffectComposer.rt2`,this.writeBuffer=this.renderTarget1,this.readBuffer=this.renderTarget2,this.renderToScreen=!0,this.passes=[],this.copyPass=new gh(dh),this.copyPass.material.blending=0,this.timer=new As}swapBuffers(){let e=this.readBuffer;this.readBuffer=this.writeBuffer,this.writeBuffer=e}addPass(e){this.passes.push(e),e.setSize(this._width*this._pixelRatio,this._height*this._pixelRatio)}insertPass(e,t){this.passes.splice(t,0,e),e.setSize(this._width*this._pixelRatio,this._height*this._pixelRatio)}removePass(e){let t=this.passes.indexOf(e);t!==-1&&this.passes.splice(t,1)}isLastEnabledPass(e){for(let t=e+1;t<this.passes.length;t++)if(this.passes[t].enabled)return!1;return!0}render(e){this.timer.update(),e===void 0&&(e=this.timer.getDelta());let t=this.renderer.getRenderTarget(),n=!1;for(let t=0,r=this.passes.length;t<r;t++){let r=this.passes[t];if(r.enabled!==!1){if(r.renderToScreen=this.renderToScreen&&this.isLastEnabledPass(t),r.render(this.renderer,this.writeBuffer,this.readBuffer,e,n),r.needsSwap){if(n){let t=this.renderer.getContext(),n=this.renderer.state.buffers.stencil;n.setFunc(t.NOTEQUAL,1,4294967295),this.copyPass.render(this.renderer,this.writeBuffer,this.readBuffer,e),n.setFunc(t.EQUAL,1,4294967295)}this.swapBuffers()}_h!==void 0&&(r instanceof _h?n=!0:r instanceof vh&&(n=!1))}}this.renderer.setRenderTarget(t)}reset(e){if(e===void 0){let t=this.renderer.getSize(new I);this._pixelRatio=this.renderer.getPixelRatio(),this._width=t.width,this._height=t.height,e=this.renderTarget1.clone(),e.setSize(this._width*this._pixelRatio,this._height*this._pixelRatio)}this.renderTarget1.dispose(),this.renderTarget2.dispose(),this.renderTarget1=e,this.renderTarget2=e.clone(),this.writeBuffer=this.renderTarget1,this.readBuffer=this.renderTarget2}setSize(e,t){this._width=e,this._height=t;let n=this._width*this._pixelRatio,r=this._height*this._pixelRatio;this.renderTarget1.setSize(n,r),this.renderTarget2.setSize(n,r);for(let e=0;e<this.passes.length;e++)this.passes[e].setSize(n,r)}setPixelRatio(e){this._pixelRatio=e,this.setSize(this._width,this._height)}dispose(){this.renderTarget1.dispose(),this.renderTarget2.dispose(),this.copyPass.dispose()}},bh=class extends fh{constructor(e,t,n=null,r=null,i=null){super(),this.scene=e,this.camera=t,this.overrideMaterial=n,this.clearColor=r,this.clearAlpha=i,this.clear=!0,this.clearDepth=!1,this.needsSwap=!1,this.isRenderPass=!0,this._oldClearColor=new R}render(e,t,n){let r=e.autoClear;e.autoClear=!1;let i,a;this.overrideMaterial!==null&&(a=this.scene.overrideMaterial,this.scene.overrideMaterial=this.overrideMaterial),this.clearColor!==null&&(e.getClearColor(this._oldClearColor),e.setClearColor(this.clearColor,e.getClearAlpha())),this.clearAlpha!==null&&(i=e.getClearAlpha(),e.setClearAlpha(this.clearAlpha)),this.clearDepth==1&&e.clearDepth(),e.setRenderTarget(this.renderToScreen?null:n),this.clear===!0&&e.clear(e.autoClearColor,e.autoClearDepth,e.autoClearStencil),e.render(this.scene,this.camera),this.clearColor!==null&&e.setClearColor(this._oldClearColor),this.clearAlpha!==null&&e.setClearAlpha(i),this.overrideMaterial!==null&&(this.scene.overrideMaterial=a),e.autoClear=r}},xh={name:`LuminosityHighPassShader`,uniforms:{tDiffuse:{value:null},luminosityThreshold:{value:1},smoothWidth:{value:1},defaultColor:{value:new R(0)},defaultOpacity:{value:0}},vertexShader:`

		varying vec2 vUv;

		void main() {

			vUv = uv;

			gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );

		}`,fragmentShader:`

		uniform sampler2D tDiffuse;
		uniform vec3 defaultColor;
		uniform float defaultOpacity;
		uniform float luminosityThreshold;
		uniform float smoothWidth;

		varying vec2 vUv;

		void main() {

			vec4 texel = texture2D( tDiffuse, vUv );

			float v = luminance( texel.xyz );

			vec4 outputColor = vec4( defaultColor.rgb, defaultOpacity );

			float alpha = smoothstep( luminosityThreshold, luminosityThreshold + smoothWidth, v );

			gl_FragColor = mix( outputColor, texel, alpha );

		}`},Sh=class e extends fh{constructor(e,t=1,n,r){super(),this.strength=t,this.radius=n,this.threshold=r,this.resolution=e===void 0?new I(256,256):new I(e.x,e.y),this.clearColor=new R(0,0,0),this.needsSwap=!1,this.renderTargetsHorizontal=[],this.renderTargetsVertical=[],this.nMips=5;let i=Math.round(this.resolution.x/2),a=Math.round(this.resolution.y/2);this.renderTargetBright=new nn(i,a,{type:g,depthBuffer:!1}),this.renderTargetBright.texture.name=`UnrealBloomPass.bright`,this.renderTargetBright.texture.generateMipmaps=!1;for(let e=0;e<this.nMips;e++){let t=new nn(i,a,{type:g,depthBuffer:!1});t.texture.name=`UnrealBloomPass.h`+e,t.texture.generateMipmaps=!1,this.renderTargetsHorizontal.push(t);let n=new nn(i,a,{type:g,depthBuffer:!1});n.texture.name=`UnrealBloomPass.v`+e,n.texture.generateMipmaps=!1,this.renderTargetsVertical.push(n),i=Math.round(i/2),a=Math.round(a/2)}let o=xh;this.highPassUniforms=jo.clone(o.uniforms),this.highPassUniforms.luminosityThreshold.value=r,this.highPassUniforms.smoothWidth.value=.01,this.materialHighPassFilter=new Po({uniforms:this.highPassUniforms,vertexShader:o.vertexShader,fragmentShader:o.fragmentShader}),this.separableBlurMaterials=[];let s=[6,10,14,18,22];i=Math.round(this.resolution.x/2),a=Math.round(this.resolution.y/2);for(let e=0;e<this.nMips;e++)this.separableBlurMaterials.push(this._getSeparableBlurMaterial(s[e])),this.separableBlurMaterials[e].uniforms.invSize.value=new I(1/i,1/a),i=Math.round(i/2),a=Math.round(a/2);this.compositeMaterial=this._getCompositeMaterial(this.nMips),this.compositeMaterial.uniforms.blurTexture1.value=this.renderTargetsVertical[0].texture,this.compositeMaterial.uniforms.blurTexture2.value=this.renderTargetsVertical[1].texture,this.compositeMaterial.uniforms.blurTexture3.value=this.renderTargetsVertical[2].texture,this.compositeMaterial.uniforms.blurTexture4.value=this.renderTargetsVertical[3].texture,this.compositeMaterial.uniforms.blurTexture5.value=this.renderTargetsVertical[4].texture,this.compositeMaterial.uniforms.bloomStrength.value=t,this.compositeMaterial.uniforms.bloomRadius.value=.1;let c=[1,.8,.6,.4,.2];this.compositeMaterial.uniforms.bloomFactors.value=c,this.bloomTintColors=[new L(1,1,1),new L(1,1,1),new L(1,1,1),new L(1,1,1),new L(1,1,1)],this.compositeMaterial.uniforms.bloomTintColors.value=this.bloomTintColors,this.copyUniforms=jo.clone(dh.uniforms),this.blendMaterial=new Po({uniforms:this.copyUniforms,vertexShader:dh.vertexShader,fragmentShader:dh.fragmentShader,premultipliedAlpha:!0,blending:2,depthTest:!1,depthWrite:!1,transparent:!0}),this._oldClearColor=new R,this._oldClearAlpha=1,this._basic=new Jr,this._fsQuad=new hh(null)}dispose(){for(let e=0;e<this.renderTargetsHorizontal.length;e++)this.renderTargetsHorizontal[e].dispose();for(let e=0;e<this.renderTargetsVertical.length;e++)this.renderTargetsVertical[e].dispose();this.renderTargetBright.dispose();for(let e=0;e<this.separableBlurMaterials.length;e++)this.separableBlurMaterials[e].dispose();this.compositeMaterial.dispose(),this.blendMaterial.dispose(),this._basic.dispose(),this._fsQuad.dispose()}setSize(e,t){let n=Math.round(e/2),r=Math.round(t/2);this.renderTargetBright.setSize(n,r);for(let e=0;e<this.nMips;e++)this.renderTargetsHorizontal[e].setSize(n,r),this.renderTargetsVertical[e].setSize(n,r),this.separableBlurMaterials[e].uniforms.invSize.value=new I(1/n,1/r),n=Math.round(n/2),r=Math.round(r/2)}render(t,n,r,i,a){t.getClearColor(this._oldClearColor),this._oldClearAlpha=t.getClearAlpha();let o=t.autoClear;t.autoClear=!1,t.setClearColor(this.clearColor,0),a&&t.state.buffers.stencil.setTest(!1),this.renderToScreen&&(this._fsQuad.material=this._basic,this._basic.map=r.texture,t.setRenderTarget(null),t.clear(),this._fsQuad.render(t)),this.highPassUniforms.tDiffuse.value=r.texture,this.highPassUniforms.luminosityThreshold.value=this.threshold,this._fsQuad.material=this.materialHighPassFilter,t.setRenderTarget(this.renderTargetBright),t.clear(),this._fsQuad.render(t);let s=this.renderTargetBright;for(let n=0;n<this.nMips;n++)this._fsQuad.material=this.separableBlurMaterials[n],this.separableBlurMaterials[n].uniforms.colorTexture.value=s.texture,this.separableBlurMaterials[n].uniforms.direction.value=e.BlurDirectionX,t.setRenderTarget(this.renderTargetsHorizontal[n]),t.clear(),this._fsQuad.render(t),this.separableBlurMaterials[n].uniforms.colorTexture.value=this.renderTargetsHorizontal[n].texture,this.separableBlurMaterials[n].uniforms.direction.value=e.BlurDirectionY,t.setRenderTarget(this.renderTargetsVertical[n]),t.clear(),this._fsQuad.render(t),s=this.renderTargetsVertical[n];this._fsQuad.material=this.compositeMaterial,this.compositeMaterial.uniforms.bloomStrength.value=this.strength,this.compositeMaterial.uniforms.bloomRadius.value=this.radius,this.compositeMaterial.uniforms.bloomTintColors.value=this.bloomTintColors,t.setRenderTarget(this.renderTargetsHorizontal[0]),t.clear(),this._fsQuad.render(t),this._fsQuad.material=this.blendMaterial,this.copyUniforms.tDiffuse.value=this.renderTargetsHorizontal[0].texture,a&&t.state.buffers.stencil.setTest(!0),this.renderToScreen?(t.setRenderTarget(null),this._fsQuad.render(t)):(t.setRenderTarget(r),this._fsQuad.render(t)),t.setClearColor(this._oldClearColor,this._oldClearAlpha),t.autoClear=o}_getSeparableBlurMaterial(e){let t=[],n=e/3;for(let r=0;r<e;r++)t.push(.39894*Math.exp(-.5*r*r/(n*n))/n);let r=[],i=[];for(let n=1;n<e;n+=2){let a=t[n],o=n+1<e?t[n+1]:0,s=a+o;r.push((n*a+(n+1)*o)/s),i.push(s)}return new Po({defines:{KERNEL_PAIRS:r.length},uniforms:{colorTexture:{value:null},invSize:{value:new I(.5,.5)},direction:{value:new I(.5,.5)},centerWeight:{value:t[0]},gaussianOffsets:{value:r},gaussianWeights:{value:i}},vertexShader:`

				varying vec2 vUv;

				void main() {

					vUv = uv;
					gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );

				}`,fragmentShader:`

				#include <common>

				varying vec2 vUv;

				uniform sampler2D colorTexture;
				uniform vec2 invSize;
				uniform vec2 direction;
				uniform float centerWeight;
				uniform float gaussianOffsets[KERNEL_PAIRS];
				uniform float gaussianWeights[KERNEL_PAIRS];

				void main() {

					vec3 diffuseSum = texture2D( colorTexture, vUv ).rgb * centerWeight;

					for ( int i = 0; i < KERNEL_PAIRS; i ++ ) {

						vec2 uvOffset = direction * invSize * gaussianOffsets[ i ];
						vec3 sample1 = texture2D( colorTexture, vUv + uvOffset ).rgb;
						vec3 sample2 = texture2D( colorTexture, vUv - uvOffset ).rgb;
						diffuseSum += ( sample1 + sample2 ) * gaussianWeights[ i ];

					}

					gl_FragColor = vec4( diffuseSum, 1.0 );

				}`})}_getCompositeMaterial(e){return new Po({defines:{NUM_MIPS:e},uniforms:{blurTexture1:{value:null},blurTexture2:{value:null},blurTexture3:{value:null},blurTexture4:{value:null},blurTexture5:{value:null},bloomStrength:{value:1},bloomFactors:{value:null},bloomTintColors:{value:null},bloomRadius:{value:0}},vertexShader:`

				varying vec2 vUv;

				void main() {

					vUv = uv;
					gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );

				}`,fragmentShader:`

				varying vec2 vUv;

				uniform sampler2D blurTexture1;
				uniform sampler2D blurTexture2;
				uniform sampler2D blurTexture3;
				uniform sampler2D blurTexture4;
				uniform sampler2D blurTexture5;
				uniform float bloomStrength;
				uniform float bloomRadius;
				uniform float bloomFactors[NUM_MIPS];
				uniform vec3 bloomTintColors[NUM_MIPS];

				float lerpBloomFactor( const in float factor ) {

					float mirrorFactor = 1.2 - factor;
					return mix( factor, mirrorFactor, bloomRadius );

				}

				void main() {

					// 3.0 for backwards compatibility with previous alpha-based intensity
					vec3 bloom = 3.0 * bloomStrength * (
						lerpBloomFactor( bloomFactors[ 0 ] ) * bloomTintColors[ 0 ] * texture2D( blurTexture1, vUv ).rgb +
						lerpBloomFactor( bloomFactors[ 1 ] ) * bloomTintColors[ 1 ] * texture2D( blurTexture2, vUv ).rgb +
						lerpBloomFactor( bloomFactors[ 2 ] ) * bloomTintColors[ 2 ] * texture2D( blurTexture3, vUv ).rgb +
						lerpBloomFactor( bloomFactors[ 3 ] ) * bloomTintColors[ 3 ] * texture2D( blurTexture4, vUv ).rgb +
						lerpBloomFactor( bloomFactors[ 4 ] ) * bloomTintColors[ 4 ] * texture2D( blurTexture5, vUv ).rgb
					);

					float bloomAlpha = max( bloom.r, max( bloom.g, bloom.b ) );
					gl_FragColor = vec4( bloom, bloomAlpha );

				}`})}};Sh.BlurDirectionX=new I(1,0),Sh.BlurDirectionY=new I(0,1);var Ch={name:`OutputShader`,uniforms:{tDiffuse:{value:null},toneMappingExposure:{value:1}},vertexShader:`
		precision highp float;

		uniform mat4 modelViewMatrix;
		uniform mat4 projectionMatrix;

		attribute vec3 position;
		attribute vec2 uv;

		varying vec2 vUv;

		void main() {

			vUv = uv;
			gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );

		}`,fragmentShader:`

		precision highp float;

		uniform sampler2D tDiffuse;

		#include <tonemapping_pars_fragment>
		#include <colorspace_pars_fragment>

		varying vec2 vUv;

		void main() {

			gl_FragColor = texture2D( tDiffuse, vUv );

			// tone mapping

			#ifdef LINEAR_TONE_MAPPING

				gl_FragColor.rgb = LinearToneMapping( gl_FragColor.rgb );

			#elif defined( REINHARD_TONE_MAPPING )

				gl_FragColor.rgb = ReinhardToneMapping( gl_FragColor.rgb );

			#elif defined( CINEON_TONE_MAPPING )

				gl_FragColor.rgb = CineonToneMapping( gl_FragColor.rgb );

			#elif defined( ACES_FILMIC_TONE_MAPPING )

				gl_FragColor.rgb = ACESFilmicToneMapping( gl_FragColor.rgb );

			#elif defined( AGX_TONE_MAPPING )

				gl_FragColor.rgb = AgXToneMapping( gl_FragColor.rgb );

			#elif defined( NEUTRAL_TONE_MAPPING )

				gl_FragColor.rgb = NeutralToneMapping( gl_FragColor.rgb );

			#elif defined( CUSTOM_TONE_MAPPING )

				gl_FragColor.rgb = CustomToneMapping( gl_FragColor.rgb );

			#endif

			// color space

			#ifdef SRGB_TRANSFER

				gl_FragColor = sRGBTransferOETF( gl_FragColor );

			#endif

		}`},wh=class extends fh{constructor(){super(),this.isOutputPass=!0,this.uniforms=jo.clone(Ch.uniforms),this.material=new Fo({name:Ch.name,uniforms:this.uniforms,vertexShader:Ch.vertexShader,fragmentShader:Ch.fragmentShader}),this._fsQuad=new hh(this.material),this._outputColorSpace=null,this._toneMapping=null}render(e,t,n){this.uniforms.tDiffuse.value=n.texture,this.uniforms.toneMappingExposure.value=e.toneMappingExposure,(this._outputColorSpace!==e.outputColorSpace||this._toneMapping!==e.toneMapping)&&(this._outputColorSpace=e.outputColorSpace,this._toneMapping=e.toneMapping,this.material.defines={},Ut.getTransfer(this._outputColorSpace)===`srgb`&&(this.material.defines.SRGB_TRANSFER=``),this._toneMapping===1?this.material.defines.LINEAR_TONE_MAPPING=``:this._toneMapping===2?this.material.defines.REINHARD_TONE_MAPPING=``:this._toneMapping===3?this.material.defines.CINEON_TONE_MAPPING=``:this._toneMapping===4?this.material.defines.ACES_FILMIC_TONE_MAPPING=``:this._toneMapping===6?this.material.defines.AGX_TONE_MAPPING=``:this._toneMapping===7?this.material.defines.NEUTRAL_TONE_MAPPING=``:this._toneMapping===5&&(this.material.defines.CUSTOM_TONE_MAPPING=``),this.material.needsUpdate=!0),this.renderToScreen===!0?(e.setRenderTarget(null),this._fsQuad.render(e)):(e.setRenderTarget(t),this.clear&&e.clear(e.autoClearColor,e.autoClearDepth,e.autoClearStencil),this._fsQuad.render(e))}dispose(){this.material.dispose(),this._fsQuad.dispose()}},Th=new R(16774374),Eh=new R(16753242),Dh=new R(11125503),Oh={uniforms:{tDiffuse:{value:null},uSun:{value:new I(.5,.5)},uStrength:{value:0},uColor:{value:new R(1,.8,.55)}},vertexShader:`
    varying vec2 vUv;
    void main() { vUv = uv; gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0); }`,fragmentShader:`
    uniform sampler2D tDiffuse; uniform vec2 uSun; uniform float uStrength; uniform vec3 uColor;
    varying vec2 vUv;
    void main() {
      vec4 base = texture2D(tDiffuse, vUv);
      if (uStrength <= 0.001) { gl_FragColor = base; return; }
      const int N = 40;
      vec2 step = (vUv - uSun) / float(N) * 0.85;
      vec2 uv = vUv;
      float decay = 1.0, sum = 0.0;
      for (int i = 0; i < N; i++) {
        uv -= step;
        vec3 s = texture2D(tDiffuse, clamp(uv, 0.0, 1.0)).rgb;
        sum += max(dot(s, vec3(0.333)) - 0.55, 0.0) * decay;
        decay *= 0.955;
      }
      gl_FragColor = vec4(base.rgb + uColor * sum * uStrength / float(N) * 6.0, base.a);
    }`},kh=class{renderer;camera;sunDir;sun=new ws(16774374,3.4);moon=new ws(Dh,.85);hemi=new ss(10273535,1712688,.55);ambient=new Ts(16777215,.1);moonDir=new L;moonMesh;sunDisc;composer;bloom;rays;casters=[];castT=0;effects=`high`;constructor(e,t,n,r){this.renderer=e,this.camera=n,this.sunDir=r,e.shadowMap.enabled=!0,e.shadowMap.type=2,e.toneMappingExposure=1.15;for(let e of[this.sun,this.moon])e.shadow.mapSize.set(2048,2048),e.shadow.bias=-4e-4,e.shadow.normalBias=.6,e.shadow.camera.near=1,e.shadow.camera.far=3e3,t.add(e,e.target);t.add(this.hemi,this.ambient),this.moonMesh=new oi(new wo(900,24,16),new Jr({color:14674175})),this.sunDisc=new oi(new wo(1600,24,16),new Jr({color:new R(4,3.6,3)}));for(let e of[this.moonMesh,this.sunDisc])e.userData.noShadow=!0,t.add(e);this.composer=new yh(e),this.composer.addPass(new bh(t,n)),this.bloom=new Sh(new I(window.innerWidth,window.innerHeight),.45,.5,.9),this.composer.addPass(this.bloom),this.rays=new gh(Oh),this.composer.addPass(this.rays),this.composer.addPass(new wh)}addCasters(...e){this.casters.push(...e)}setSize(e,t){this.composer.setPixelRatio(this.renderer.getPixelRatio()),this.composer.setSize(e,t)}update(e,t,n,r,i){this.sunDir.set(t[0],t[1],t[2]).normalize(),this.moonDir.copy(this.sunDir).negate();let a=n.dot(this.sunDir),o=1-Pt.smoothstep(r,500,1600),s=1-Pt.smoothstep(Math.abs(a-.05),.05,.3);this.sun.color.copy(Th).lerp(Eh,s*o),this.sun.intensity=3.4*(1-o*(1-Pt.smoothstep(a,-.12,.05))),this.moon.intensity=.85,this.hemi.intensity=.55-.2*o*(1-Pt.smoothstep(a,-.2,.1)),this.hemi.color.set(10273535);let c=n.clone().multiplyScalar(i),l=a<-.02,u=l?this.moon:this.sun,d=l?this.sun:this.moon;l?this.moonDir:this.sunDir;let f=Pt.clamp(r*1.3,70,600),p=this.effects!==`low`&&r<1400;u.castShadow=p,d.castShadow=!1;for(let e of[this.sun,this.moon]){let t=e===this.sun?this.sunDir:this.moonDir;e.target.position.copy(c),e.position.copy(c).addScaledVector(t,1200),e.target.updateMatrixWorld()}let m=u.shadow.camera;if(m.left=-f,m.right=f,m.top=f,m.bottom=-f,m.updateProjectionMatrix(),u.shadow.mapSize.setScalar(this.effects===`high`?2048:1024),this.castT-=e,this.castT<=0){this.castT=1;for(let e of this.casters)e.traverse(e=>{e.userData.noShadow||e.isMesh&&(e.castShadow=p,e.receiveShadow=p)})}let h=this.camera.position;this.moonMesh.position.copy(h).addScaledVector(this.moonDir,6e4),this.sunDisc.position.copy(h).addScaledVector(this.sunDir,6e4);let g=0;if(this.effects===`high`){let e=this.sunDisc.position.clone().project(this.camera);e.z<1&&Math.abs(e.x)<1.4&&Math.abs(e.y)<1.4&&(this.rays.uniforms.uSun.value.set((e.x+1)/2,(e.y+1)/2),g=(1-Pt.smoothstep(Math.max(Math.abs(e.x),Math.abs(e.y)),.9,1.4))*(.35+.65*s)*(.3+.7*o))}this.rays.uniforms.uStrength.value+=(g-this.rays.uniforms.uStrength.value)*Math.min(1,e*3),this.bloom.enabled=this.effects!==`low`,this.rays.enabled=this.effects===`high`}render(){this.composer.render()}};function Ah(e,t){let n=new od({antialias:!0,logarithmicDepthBuffer:!0,powerPreference:`high-performance`});n.setPixelRatio(Math.min(window.devicePixelRatio||1,3)),n.setSize(window.innerWidth,window.innerHeight),n.toneMapping=4,document.body.appendChild(n.domElement);let r=new Hn;r.background=new R(4);let i=new ys(50,window.innerWidth/window.innerHeight,.5,2e5),a=new L(1,.2,.35).normalize(),o=new kh(n,r,i,a);r.add(nh());let s=performance.now(),c=Gm(n,e),l=new uh(n,(t^2654435769)>>>0,a),u=performance.now()-s,d=sh(c.rt.texture,c.offset,l.rt.texture,a),f=eh(e);ch(f,d);let p=oh(e,d);return f.receiveShadow=!0,r.add(f,ah(e,d),p,th(e,a)),{renderer:n,scene:r,camera:i,sky:d,clouds:p,cloudBake:l,heightBake:c,bakeMs:u,daylight:o}}var jh=class{camera;planet;f=new L(0,0,1);fwd=new L(0,1,0);dist=2600;minDist=14;maxDist=5200;tiltOffset=0;targetDist=2600;constructor(e,t){this.camera=e,this.planet=t}focusOn(e,t){this.f.copy(e).normalize(),this.reorthonormalise(),t!==void 0&&(this.dist=this.targetDist=t)}reorthonormalise(){this.fwd.addScaledVector(this.f,-this.fwd.dot(this.f)),this.fwd.lengthSq()<1e-8&&(this.fwd.set(0,1,0).addScaledVector(this.f,-this.f.y),this.fwd.lengthSq()<1e-8&&this.fwd.set(1,0,0)),this.fwd.normalize()}get right(){return new L().crossVectors(this.fwd,this.f).normalize()}pan(e,t){this.glide=null;let n=this.dist/this.planet.radius*.0012,r=this.right,i=new L().addScaledVector(r,e*n).addScaledVector(this.fwd,t*n),a=this.f.clone();this.f.add(i).normalize();let o=new Ft().setFromUnitVectors(a,this.f);this.fwd.applyQuaternion(o),this.reorthonormalise()}rotateBy(e){this.f.applyQuaternion(e).normalize(),this.fwd.applyQuaternion(e),this.reorthonormalise()}glide=null;get gliding(){return this.glide!==null}glideTo(e,t,n){this.spin.set(0,0,0),this.glide={from:this.f.clone(),to:e.clone().normalize(),d0:this.dist,d1:Pt.clamp(t,this.minDist,this.maxDist),t:0,len:Math.max(.01,n)}}stepGlide(e){let t=this.glide;t.t+=e;let n=Math.min(1,t.t/t.len),r=n*n*(3-2*n),i=new Ft().setFromUnitVectors(t.from,t.to),a=new Ft().slerp(i,r),o=t.from.clone().applyQuaternion(a).normalize();this.fwd.applyQuaternion(new Ft().setFromUnitVectors(this.f,o)),this.f.copy(o),this.reorthonormalise(),this.dist=this.targetDist=Math.exp(Math.log(t.d0)+(Math.log(t.d1)-Math.log(t.d0))*r),n>=1&&(this.glide=null)}spin=new L;held=!1;rotate(e){this.glide=null,this.fwd.applyAxisAngle(this.f,e),this.reorthonormalise()}zoom(e,t){this.glide=null;let n=this.targetDist;if(this.targetDist=Pt.clamp(this.targetDist*e,this.minDist,this.maxDist),t&&e<1){let e=1-this.targetDist/n,r=this.f.clone();this.f.lerp(t,e*.9).normalize(),this.fwd.applyQuaternion(new Ft().setFromUnitVectors(r,this.f)),this.reorthonormalise()}}get tilt(){return Pt.clamp(Pt.lerp(1.31,0,this.zoomT)+this.tiltOffset,0,1.48)}get zoomT(){return Pt.clamp((Math.log(this.dist)-Math.log(this.minDist))/(Math.log(2500)-Math.log(this.minDist)),0,1)}heightAboveSurface(){return this.camera.position.length()-this.planet.radius}update(e){let t=this.spin.length();this.glide?this.stepGlide(e):this.held||(t>.002&&e>0?(this.rotateBy(new Ft().setFromAxisAngle(this.spin.clone().divideScalar(t),t*e)),this.spin.multiplyScalar(Math.exp(-3.5*e))):this.spin.set(0,0,0)),this.dist+=(this.targetDist-this.dist)*Math.min(1,e*10);let n=this.planet.radius,r=Math.max(0,this.planet.heightAt(this.f.x,this.f.y,this.f.z))*45,i=5*Math.max(0,1-this.zoomT*4),a=this.f.clone().multiplyScalar(n+r+i),o=this.tilt,s=new L().copy(this.f).multiplyScalar(Math.cos(o)).addScaledVector(this.fwd,-Math.sin(o)),c=a.clone().addScaledVector(s,this.dist),l=c.length(),u=n+Math.max(0,this.planet.heightAt(c.x/l,c.y/l,c.z/l))*45+8;l<u&&c.multiplyScalar(u/l),this.camera.position.copy(c);let d=new L().copy(this.fwd).multiplyScalar(Math.cos(o)).addScaledVector(this.f,Math.sin(o));this.camera.up.copy(d),this.camera.lookAt(a),this.camera.updateMatrixWorld()}pick(e,t,n=!1){let r=new Gs;r.setFromCamera(new I(e,t),this.camera);let i=r.ray.origin,a=r.ray.direction,o=this.planet.radius,s=null;for(let e=0;e<(n?1:4);e++){let e=i.dot(a),t=i.lengthSq()-o*o,n=e*e-t;if(n<0)return s?s.normalize():null;let r=-e-Math.sqrt(n);if(r<0)return null;s=i.clone().addScaledVector(a,r);let c=s.clone().normalize();o=this.planet.radius+Math.max(0,this.planet.heightAt(c.x,c.y,c.z))*45}return s.normalize()}},J={TEAM:16777215,TEAM_LIGHT:14212322,DARK:2829875,STEEL:8225676,LIGHT:12172998,GLASS:1913671,GLOW:10479359,HAZARD:14856762,CONCRETE:9276036,HULL_RED:7023142};function Y(e,t,n=0){let r=e.index?e.toNonIndexed():e,i=new R(t),a=r.attributes.position.count,o=new Float32Array(a*3),s=new Float32Array(a);for(let e=0;e<a;e++)o[e*3]=i.r,o[e*3+1]=i.g,o[e*3+2]=i.b,s[e]=n;return r.setAttribute(`color`,new xr(o,3)),r.setAttribute(`teamMask`,new xr(s,1)),r.attributes.uv&&r.deleteAttribute(`uv`),r}var X=(e,t=1)=>Y(e,J.TEAM,t),Z=e=>qm(e);function Q(e,t,n,r=0,i=0,a=0,o=0,s=0,c=0){let l=new Xi(e,t,n);return o&&l.rotateX(o),s&&l.rotateY(s),c&&l.rotateZ(c),l.translate(r,i,a),l}function $(e,t,n=0,r=0,i=0,a=12,o=e){let s=new $i(o,e,t,a);return s.translate(n,r+t/2,i),s}function Mh(e,t,n,r,i,a=8){let o=new $i(e,e,t,a);return o.rotateX(Math.PI/2),o.translate(n,r,i+t/2),o}function Nh(e,t,n,r,i,a=10){let o=new $i(e,e,t,a);return o.rotateZ(Math.PI/2),o.translate(n,r,i),o}function Ph(e,t,n,r=0){let i=new Ma,a=e/2,o=t/2;i.moveTo(-a*.8,-o),i.lineTo(a*.8,-o),i.lineTo(a,-o*.2),i.lineTo(a*.75,o*.6),i.lineTo(0,o),i.lineTo(-a*.75,o*.6),i.lineTo(-a,-o*.2),i.closePath();let s=new _o(i,{depth:n,bevelEnabled:!1});return s.rotateX(Math.PI/2),s.translate(0,r+n,0),s}function Fh(e,t,n){e.vertexColors=!0,e.onBeforeCompile=e=>{t&&(e.uniforms.uTeamColor=t),n&&(e.uniforms.uFaction=n);let r=n?`uFaction`:`instFaction`;e.vertexShader=e.vertexShader.replace(`#include <common>`,`#include <common>\nattribute float teamMask;${t?`
uniform vec3 uTeamColor;`:``}${n?`
uniform float uFaction;`:`
attribute float instFaction;`}`).replace(`#include <color_vertex>`,`vColor = vec4( 1.0 );
        #ifdef USE_COLOR
          vColor.rgb *= color.rgb;
        #endif
        ${t?`vColor.rgb *= mix(vec3(1.0), uTeamColor, teamMask);`:`#ifdef USE_INSTANCING_COLOR
 vColor.rgb *= mix(vec3(1.0), instanceColor.rgb, teamMask);
#endif`}
        float agi = max(${r}, 0.0), man = max(-${r}, 0.0);
        vColor.rgb = mix(vColor.rgb, mix(vColor.rgb, vec3(0.9, 0.93, 0.97), 0.6), agi * (1.0 - teamMask));
        vColor.rgb *= 1.0 + 0.25 * agi * teamMask;
        vColor.rgb *= 1.0 - 0.4 * man * (1.0 - teamMask);`)},e.needsUpdate=!0}var Ih=[new R(4033535),new R(16734781),new R(4063115),new R(16765501)],Lh=new R(13158600),Rh=new R(16777215);function zh(e){switch(e){case W.Commander:{let e=[];for(let t of[-2.2,2.2])e.push(Y(Q(1.6,3.2,2.2,t,1.6,0),J.DARK),Y(Q(1.9,.6,3,t,.3,.3),J.STEEL),Y(Q(1.3,1.2,1.3,t,3.6,0),J.STEEL));return Z([...e,X(Q(6,3,5.4,0,5.2,0)),Y(Q(5.2,.6,4.6,0,6.9,-.2),J.TEAM_LIGHT,.65),X(Q(2.6,1.6,2.4,0,7.8,.6)),Y(Q(2.2,.5,.2,0,7.9,1.85),J.GLOW),Y(Q(1.2,1.2,3.6,3.6,5.4,1),J.STEEL),Y(Mh(.35,1.2,3.6,5.4,2.8),J.GLOW),Y(Q(1.6,2.6,1.6,-3.5,5.4,-.4),J.TEAM_LIGHT,.65),Y($(.12,3.2,-1.4,8.6,-1.2,5),J.LIGHT),Y($(.5,.2,-1.4,11.8,-1.2,10),J.LIGHT)])}case W.Tank:{let e=[Y(Q(1.1,1.2,6.2,-1.6,.6,0),J.DARK),Y(Q(1.1,1.2,6.2,1.6,.6,0),J.DARK),Y(Q(1.3,.22,6.4,-1.6,1.3,0),J.STEEL),Y(Q(1.3,.22,6.4,1.6,1.3,0),J.STEEL),X(Q(2.6,1,5,0,1.55,-.2)),X(Q(2.6,.8,1.2,0,1.45,2.6,-.5)),Y($(1.15,.85,0,2.05,-.4,10,1),J.TEAM_LIGHT,.7),Y(Q(.8,.6,.6,0,2.45,.7),J.STEEL),Y(Mh(.17,3.3,0,2.5,.9),J.STEEL),Y(Q(.42,.42,.5,0,2.5,4.3),J.DARK),Y(Q(.6,.35,.6,.55,3.05,-.8),J.DARK),Y($(.04,1.8,-.7,2.9,-1.1,4),J.DARK)];for(let t of[-2.18,2.18])for(let n of[-2.2,-.75,.75,2.2])e.push(Y(Nh(.45,.12,t,.55,n),J.STEEL));return Z(e)}case W.Boat:return Z([Y(Ph(4.2,12,.7,-.4),J.HULL_RED),X(Ph(4.3,12.2,1.3,.3)),Y(Ph(3.6,10.6,.15,1.6),J.LIGHT),Y(Q(2.4,1.8,3.2,0,2.5,-1.2),J.LIGHT),Y(Q(2.6,.25,.5,0,3.5,.3),J.GLASS),Y(Q(1.8,1,1.8,0,3.8,-1.6),J.TEAM_LIGHT,.6),Y($(.45,1.4,0,2.6,-3.3,8),J.DARK),Y($(.08,3.2,0,4.2,-1.4,4),J.DARK),Y(Q(1.4,.12,.12,0,6.6,-1.4),J.DARK),Y($(.75,.6,0,1.75,3.2,10,.6),J.STEEL),Y(Mh(.12,2.2,0,2.1,3.5),J.STEEL),Y($(.6,.5,0,1.75,-4.6,10,.5),J.STEEL),Y(Mh(.09,1.2,.18,2.05,-4.4),J.DARK),Y(Mh(.09,1.2,-.18,2.05,-4.4),J.DARK)]);case W.Drone:{let e=[X(Q(1.3,.6,2.4,0,0,0)),Y(Q(.7,.35,.9,0,.35,.3),J.GLASS),Y(Mh(.12,1.2,0,-.35,.6),J.DARK)];for(let[t,n]of[[-1.6,1.4],[1.6,1.4],[-1.6,-1.4],[1.6,-1.4]]){let r=Q(.2,.18,Math.hypot(t,n),t/2,0,n/2,0,Math.atan2(t,n));e.push(Y(r,J.DARK),Y($(.18,.3,t,-.1,n,6),J.STEEL),Y($(.95,.04,t,.22,n,14),J.LIGHT))}return Z(e)}case W.Builder:{let e=Q(.6,.6,4.6,0,0,2.3,-.5);e.translate(.9,3.3,-1.2);let t=[Y(Q(1.1,1.2,6.4,-1.65,.6,0),J.DARK),Y(Q(1.1,1.2,6.4,1.65,.6,0),J.DARK),X(Q(2.8,1.3,5.4,0,1.75,-.3)),Y(Q(2.2,1.6,2,-.5,3.2,1.6),J.TEAM_LIGHT,.6),Y(Q(2,.8,.12,-.5,3.4,2.62),J.GLASS),Y(Q(1.4,1.1,1.4,.9,2.95,-1.4),J.HAZARD),Y(e,J.HAZARD),Y(Q(1,1,1,.9,5.4,2.8),J.STEEL),Y(Mh(.3,.6,.9,5.4,3.3),J.GLOW)];for(let e of[-2.25,2.25])for(let n of[-2.3,0,2.3])t.push(Y(Nh(.45,.12,e,.55,n),J.STEEL));return Z(t)}case W.ConShip:{let e=Q(.5,.5,5,0,0,2.5,-.45);return e.translate(0,3.2,-.6),Z([Y(Ph(4.4,11,.7,-.4),J.HULL_RED),X(Ph(4.5,11.2,1.3,.3)),Y(Ph(3.8,9.8,.15,1.6),J.LIGHT),Y(Q(3.2,.3,4,0,1.9,1.6),J.HAZARD),Y(Q(2.6,1.8,2.4,0,2.6,-3),J.TEAM_LIGHT,.6),Y(Q(2.6,.25,.4,0,3.2,-1.8),J.GLASS),Y($(.6,1.2,0,2.6,-.6,8),J.HAZARD),Y(e,J.HAZARD),Y(Q(.9,.9,.9,0,5.2,3.9),J.STEEL),Y(Mh(.28,.6,0,5.2,4.4),J.GLOW),Y($(.08,3,0,4.9,-3.4,4),J.DARK)])}case W.ConDrone:{let e=[X(Q(1.8,.7,2.6,0,0,0)),Y(Q(1.9,.12,.5,0,.42,-.6),J.HAZARD),Y(Q(.8,.35,.8,0,.4,.5),J.GLASS),Y(Mh(.22,.7,0,-.55,.4),J.GLOW),Y(Q(.7,.5,.7,0,-.45,.4),J.STEEL)];for(let[t,n]of[[-1.7,1.4],[1.7,1.4],[-1.7,-1.4],[1.7,-1.4]])e.push(Y($(.95,.35,t,.05,n,14,.95),J.HAZARD),Y($(.85,.05,t,.25,n,14),J.LIGHT));return Z(e)}case W.AdvBuilder:{let e=zh(W.Builder).clone();return e.scale(1.25,1.25,1.25),Z([e,Y(Q(4.2,.5,6.6,0,3,-.3),J.DARK),X(Q(.5,.6,3,-1.2,3.4,-1.6),.7),X(Q(.5,.6,3,.2,3.4,-1.6),.7),Y(Q(1.1,1.1,1.1,-1.4,6.6,3.2),J.STEEL),Y(Mh(.35,.7,-1.4,6.6,3.7),J.GLOW)])}case W.AdvConShip:{let e=zh(W.ConShip).clone();return e.scale(1.25,1.25,1.25),Z([e,Y(Q(4.4,.5,3,0,2.7,-1.6),J.DARK),X(Q(.5,.6,2.4,-1,3.1,-1.6),.7),X(Q(.5,.6,2.4,1,3.1,-1.6),.7),Y(Q(1,1,1,-1.6,6.4,4.4),J.STEEL),Y(Mh(.3,.6,-1.6,6.4,4.9),J.GLOW)])}case W.AdvConDrone:{let e=zh(W.ConDrone).clone();return e.scale(1.25,1.25,1.25),Z([e,Y(Q(2.6,.3,3.4,0,.6,0),J.DARK),X(Q(.35,.4,1.8,-.5,.85,-.4),.7),X(Q(.35,.4,1.8,.5,.85,-.4),.7),Y(Mh(.24,.7,-.6,-.7,.5),J.GLOW)])}case W.HeavyTank:{let e=[Y(Q(1.5,1.6,8.2,-2.3,.8,0),J.DARK),Y(Q(1.5,1.6,8.2,2.3,.8,0),J.DARK),Y(Q(1.8,.3,8.4,-2.3,1.7,0),J.STEEL),Y(Q(1.8,.3,8.4,2.3,1.7,0),J.STEEL),X(Q(3.6,1.4,6.8,0,2,-.2)),X(Q(3.6,1,1.6,0,1.9,3.5,-.5)),Y(Q(3.8,.3,.4,0,2.75,-1.5),J.HAZARD),Y($(1.7,1.2,0,2.7,-.6,10,1.45),J.TEAM_LIGHT,.7),Y(Q(2.2,1,1.6,0,3,-2.2),J.DARK),Y(Q(1.1,.9,.8,0,3.3,1),J.STEEL),Y(Mh(.26,5.2,0,3.35,1.3),J.STEEL),Y(Q(.6,.6,.7,0,3.35,6.6),J.DARK),Y(Mh(.08,1.2,.6,3.6,1.2),J.DARK),Y($(.05,2.2,-.9,3.9,-1.6,4),J.DARK)];for(let t of[-3.1,3.1])for(let n of[-3.2,-1.9,-.6,.6,1.9,3.2])e.push(Y(Nh(.55,.14,t,.65,n),J.STEEL));return Z(e)}case W.Artillery:{let e=[Y(Q(1.2,1.3,7,-1.9,.65,0),J.DARK),Y(Q(1.2,1.3,7,1.9,.65,0),J.DARK),X(Q(3,1.2,6.2,0,1.8,-.3)),Y(Q(3.2,.3,.4,0,2.5,2.2),J.HAZARD),Y($(1.4,.6,0,2.4,-.8,12),J.STEEL),X(Q(2,1.4,2.6,0,3,-1),.8)],t=Mh(.3,7.5,0,0,0);t.rotateX(-.6),t.translate(0,3.5,-.2),e.push(Y(t,J.STEEL));let n=Q(.7,.7,.9,0,0,0);n.rotateX(-.6),n.translate(0,3.5+7.3*Math.sin(.6),-.2+7.3*Math.cos(.6)),e.push(Y(n,J.DARK));for(let t of[-2.6,2.6])e.push(Y(Q(.4,.3,2.2,t,.4,-3.6),J.HAZARD));for(let t of[-2.55,2.55])for(let n of[-2.6,-.9,.9,2.6])e.push(Y(Nh(.45,.12,t,.55,n),J.STEEL));return Z(e)}case W.Gunship:{let e=[X(Q(2,1.2,4.8,0,0,0)),Y(Q(1.6,.9,1.4,0,.1,2.6),J.GLASS),Y(Q(.9,.6,2.4,0,.2,-3.4),J.DARK),Y(Q(6.4,.25,1.2,0,-.1,.2),J.DARK)];for(let t of[-3.1,3.1]){let n=new To(1.5,.22,6,18);n.rotateX(Math.PI/2),n.translate(t,.6,-1.4),e.push(Y(n,J.DARK),Y($(1.3,.05,t,.6,-1.4,16),J.LIGHT))}for(let t of[-3.1,3.1])e.push(Y(Mh(.35,2,t,-.55,.4),J.STEEL),Y(Mh(.12,.3,t,-.55,2.4),J.HAZARD));return Z(e)}case W.Bomber:{let e=new Ir,t=new Float32Array([0,.15,5,9,.15,-3,-9,.15,-3,0,-.15,5,-9,-.15,-3,9,-.15,-3]);e.setAttribute(`position`,new xr(t,3)),e.computeVertexNormals();let n=[Y(e,J.DARK),X(Q(3,1.2,7,0,.3,.5)),Y(Q(1.6,.6,1.6,0,.8,3.2),J.GLASS),X(Q(14,.12,.8,0,.08,-1.8),.8),Y(Q(1.8,.5,3,0,-.35,0),J.HAZARD)];for(let e of[-4.5,-1.6,1.6,4.5])n.push(Y($(.45,1.6,e,0,-3.6,8),J.STEEL),Y($(.3,.1,e,0,-4.4,8),J.GLOW));return Z(n)}case W.HeavyTransport:{let e=[X(Q(3.6,2.2,10,0,.4,0)),Y(Q(3,1,1.8,0,1,5.4),J.GLASS),Y(Q(3.8,.4,10.2,0,1.7,0),J.DARK),Y(Q(.3,1.6,8,-1.9,-1.2,0),J.STEEL),Y(Q(.3,1.6,8,1.9,-1.2,0),J.STEEL),Y(Q(3.8,.3,.3,0,-1.9,3.8),J.HAZARD)];for(let t of[-3.6,3.6])for(let n of[-3.6,0,3.6]){let r=new To(1.3,.2,6,16);r.rotateX(Math.PI/2),r.translate(t,1.2,n),e.push(Y(r,J.DARK),Y($(1.1,.05,t,1.2,n,14),J.LIGHT),Y(Q(1.6,.2,.3,t/2*1.2,1.2,n),J.STEEL))}return Z(e)}case W.RadarDrone:{let e=[X(Q(1,.5,2.6,0,0,0)),Y(Q(.6,.3,.7,0,.3,1),J.GLASS),Y($(.12,1.2,0,.25,-.2,6),J.STEEL),Y($(2,.22,0,1.45,-.2,20,2.2),J.LIGHT),X($(2.25,.08,0,1.6,-.2,20),.7)];for(let[t,n]of[[-1.3,1.1],[1.3,1.1],[-1.3,-1.3],[1.3,-1.3]])e.push(Y($(.7,.04,t,.1,n,12),J.LIGHT),Y($(.12,.25,t,-.05,n,6),J.DARK));return Z(e)}case W.Cruiser:{let e=[Y(Ph(6.4,19,1,-.5),J.HULL_RED),X(Ph(6.5,19.2,1.8,.5)),Y(Ph(5.6,17,.2,2.3),J.LIGHT),Y(Q(3.6,2.6,5,0,3.6,-.5),J.LIGHT),Y(Q(3.8,.3,.5,0,4.9,1.6),J.GLASS),Y(Q(2.6,1.6,2.4,0,5.7,-.8),J.TEAM_LIGHT,.6),Y($(.7,2,0,3.4,-3.8,8),J.DARK),Y($(.1,5,0,6.5,-.8,4),J.DARK),Y(Q(2.2,.15,.15,0,10.4,-.8),J.DARK)];for(let[t,n]of[[5.4,1],[-6.4,-1]]){e.push(Y($(1.4,.9,0,2.4,t,12,1.1),J.STEEL),X(Q(2,.8,2.2,0,3.2,t),.8));for(let r of[-.45,.45]){let i=Mh(.16,3.6,r,3.3,t+n*.8);n<0&&i.rotateY(Math.PI).translate(2*r,0,2*t),e.push(Y(i,J.STEEL))}}for(let t of[-2.4,2.4])e.push(Y($(.5,.5,t,2.4,-2.6,8),J.STEEL),Y(Mh(.07,1,t,2.8,-2.4),J.DARK));return Z(e)}case W.SubHunter:return Z([Y(Ph(4,13,.6,-.4),J.HULL_RED),X(Ph(4.1,13.2,1.1,.2)),Y(Ph(3.4,11.4,.15,1.3),J.LIGHT),Y(Q(2.2,1.6,3,0,2.1,.6),J.LIGHT),Y(Q(2.3,.25,.4,0,2.7,2.1),J.GLASS),X(Q(1.6,.6,1.6,0,3.2,.4),.8),Y(new wo(1.1,12,8,0,Math.PI*2,0,Math.PI/2).rotateX(Math.PI).translate(0,-.3,4.6),J.STEEL),Y(Q(2.6,.6,1.6,0,1.7,-5),J.HAZARD),Y($(.35,.8,-.6,1.9,-5,8),J.DARK),Y($(.35,.8,.6,1.9,-5,8),J.DARK),Y(Mh(.2,2,-1.3,1.6,-1.6),J.STEEL),Y(Mh(.2,2,1.3,1.6,-1.6),J.STEEL),Y($(.08,3,0,3.5,.2,4),J.DARK),Y($(.9,.06,0,5.1,.2,12),J.LIGHT)]);case W.Interceptor:{let e=new Ir;return e.setAttribute(`position`,new xr(new Float32Array([0,.1,1.2,3.6,.1,-2.2,-3.6,.1,-2.2,0,-.1,1.2,-3.6,-.1,-2.2,3.6,-.1,-2.2]),3)),e.computeVertexNormals(),Z([Y(e,J.LIGHT),X(Q(.9,.7,5.2,0,.2,0)),Y(Q(.6,.4,1,0,.6,1.4),J.GLASS),X(Q(.2,1.4,1.2,0,.9,-2),.8),Y(Mh(.1,1.4,-.7,0,1),J.DARK),Y(Mh(.1,1.4,.7,0,1),J.DARK),Y($(.45,.3,0,.2,-2.8,10),J.GLOW)])}case W.EmpDrone:{let e=new wo(1.2,14,10),t=[X(Q(1.4,.5,2.4,0,-.6,0)),Y(e,J.DARK),Y(new To(1.45,.16,6,20),J.GLOW),Y(new To(1.45,.16,6,20).rotateY(Math.PI/2),J.GLOW),Y(new To(1.45,.12,6,20).rotateX(Math.PI/2),J.HAZARD)];for(let[e,n]of[[-1.7,1.5],[1.7,1.5],[-1.7,-1.5],[1.7,-1.5]])t.push(Y($(.8,.04,e,.1,n,12),J.LIGHT),Y($(.14,.4,e,-.2,n,6),J.STEEL));return Z(t)}case W.Satellite:return Z([X(Q(1.6,1.6,2.4,0,0,0)),Y(Q(9,.1,2.2,-5.8,0,0),J.GLASS),Y(Q(9,.1,2.2,5.8,0,0),J.GLASS),Y(Q(1.2,.2,.3,-1.4,0,0),J.STEEL),Y(Q(1.2,.2,.3,1.4,0,0),J.STEEL),Y(new wo(1.4,12,6,0,Math.PI*2,0,Math.PI/3).rotateX(Math.PI).translate(0,-1.4,0),J.LIGHT),Y($(.15,1.2,0,-1.2,0,6),J.STEEL)]);case W.NukeMissile:return Z([Y($(.6,6,0,0,0,12,.6),J.LIGHT),Y($(.6,1.4,0,6,0,12,.05),J.HAZARD),X($(.62,.8,0,1,0,12),.9),Y(Q(2.4,1.2,.1,0,.6,0),J.DARK),Y(Q(.1,1.2,2.4,0,.6,0),J.DARK)]);case W.Sub:{let e=new Zi(1.6,9,6,12);return e.rotateX(Math.PI/2),e.translate(0,-1.3,0),Z([Y(e,J.DARK),X(Q(.5,.35,8,0,.2,0)),Y(Q(1.3,1.8,2.4,0,.7,.8),J.STEEL),X(Q(1.35,.4,2.45,0,1.4,.8),.8),Y(Q(2.8,.15,.8,0,1.1,.8),J.STEEL),Y($(.08,1.4,0,2.2,1.3,4),J.DARK),Y(Q(3.2,.15,.7,0,-1.3,-5.2),J.STEEL),Y(Q(.15,1.6,.7,0,-1.3,-5.2),J.STEEL)])}case W.Transport:{let e=[X(Q(3,1.4,6,0,.6,0)),Y(Q(2.2,.6,1.4,0,1.4,2.4),J.GLASS),Y(Q(3.4,.25,5.2,0,-.35,0),J.HAZARD),Y(Q(.3,1.2,5,-1.6,-.9,0),J.DARK),Y(Q(.3,1.2,5,1.6,-.9,0),J.DARK)];for(let[t,n]of[[-2.8,2.2],[2.8,2.2],[-2.8,-2.2],[2.8,-2.2]])e.push(Y(Q(1.6,.25,.4,t/2,.8,n),J.DARK),Y($(1.25,.4,t,.8,n,14,1.25),J.STEEL),Y($(1.1,.05,t,1.05,n,14),J.LIGHT));return Z(e)}}}var Bh=class{hidden=-1;modelHeight=[];modelHalfWidth=[];get modelScale(){return this.scaleV.x}group=new Pn;meshes=[];rings;icons;iconPos;iconCol;blips;blipPos;blipCol;seen=new Uint8Array(U);wx=new Float32Array(U);wy=new Float32Array(U);wz=new Float32Array(U);m=new on;vUp=new L;vFwd=new L;vRight=new L;vPos=new L;scaleV=new L(1,1,1);constructor(){for(let e=0;e<24;e++){let t=new Io({color:16777215,roughness:.55,metalness:.08});Fh(t);let n=zh(e);n.computeBoundingBox();let r=n.boundingBox;this.modelHeight[e]=r.max.y,this.modelHalfWidth[e]=Math.max(r.max.x-r.min.x,r.max.z-r.min.z)*.4;let i=new vi(n,t,U);i.instanceMatrix.setUsage(Ke);let a=new ui(new Float32Array(U),1);a.setUsage(Ke),n.setAttribute(`instFaction`,a),i.setColorAt(0,new R),i.count=0,i.frustumCulled=!1,this.meshes.push(i),this.group.add(i)}let e=new Co(1,1.18,32);e.rotateX(-Math.PI/2),this.rings=new vi(e,new Jr({color:10289052,transparent:!0,opacity:.9,depthWrite:!1}),U),this.rings.count=0,this.rings.frustumCulled=!1,this.group.add(this.rings),this.iconPos=new Float32Array(U*3),this.iconCol=new Float32Array(U*3);let t=new Ir;t.setAttribute(`position`,new xr(this.iconPos,3).setUsage(Ke)),t.setAttribute(`color`,new xr(this.iconCol,3).setUsage(Ke)),t.setDrawRange(0,0),this.icons=new Wi(t,new zi({size:5,sizeAttenuation:!1,vertexColors:!0,transparent:!0,opacity:0})),this.icons.frustumCulled=!1,this.group.add(this.icons),this.blipPos=new Float32Array(U*3),this.blipCol=new Float32Array(U*3);let n=new Ir;n.setAttribute(`position`,new xr(this.blipPos,3).setUsage(Ke)),n.setAttribute(`color`,new xr(this.blipCol,3).setUsage(Ke)),n.setDrawRange(0,0),this.blips=new Wi(n,new zi({size:8,sizeAttenuation:!1,vertexColors:!0,transparent:!0,opacity:.85,depthWrite:!1})),this.blips.frustumCulled=!1,this.blips.renderOrder=4,this.group.add(this.blips)}update(e,t,n,r,i,a,o){let s=0,c=.65+.35*Math.sin(o*5),l=e.planet.radius,u=Array(24).fill(0),d=0,f=Pt.clamp((r-350)/500,0,1),p=Pt.clamp(r/300,1,2.5);this.scaleV.setScalar(p);let m=new R;for(let r=0;r<e.count;r++){let o=!e.alive[r]||r===this.hidden||e.carriedBy[r]>=0?0:i?e.unitSeenBy(q.me,r):2;if(this.seen[r]=o,o<2){if(this.iconPos[r*3]=this.iconPos[r*3+1]=this.iconPos[r*3+2]=0,o===1){let t=l+Math.max(e.elev[r],0)+3;this.blipPos[s*3]=e.x[r]*t,this.blipPos[s*3+1]=e.y[r]*t,this.blipPos[s*3+2]=e.z[r]*t,m.copy(Ih[e.team[r]]??Lh).multiplyScalar(c),this.blipCol[s*3]=m.r,this.blipCol[s*3+1]=m.g,this.blipCol[s*3+2]=m.b,s++}continue}let h=e.px[r]+(e.x[r]-e.px[r])*t,g=e.py[r]+(e.y[r]-e.py[r])*t,_=e.pz[r]+(e.z[r]-e.pz[r])*t,v=Math.hypot(h,g,_);h/=v,g/=v,_/=v;let y=l+(e.prevElev[r]+(e.elev[r]-e.prevElev[r])*t);this.vUp.set(h,g,_),this.vPos.set(h*y,g*y,_*y),this.wx[r]=this.vPos.x,this.wy[r]=this.vPos.y,this.wz[r]=this.vPos.z,this.vFwd.set(e.hx[r],e.hy[r],e.hz[r]),this.vFwd.addScaledVector(this.vUp,-this.vFwd.dot(this.vUp)).normalize(),this.vRight.crossVectors(this.vUp,this.vFwd),this.m.makeBasis(this.vRight,this.vUp,this.vFwd),this.m.scale(this.scaleV),this.m.setPosition(this.vPos);let b=e.type[r],x=this.meshes[b],S=u[b]++;x.setMatrixAt(S,this.m);let C=n.has(r);m.copy(Ih[e.team[r]%4]),C&&m.lerp(Rh,.45),x.setColorAt(S,m);let w=e.teams[e.team[r]]?.faction;x.geometry.getAttribute(`instFaction`).setX(S,w===`agi`?1:w===`man`?-1:0),this.iconPos[r*3]=h*(y+2),this.iconPos[r*3+1]=g*(y+2),this.iconPos[r*3+2]=_*(y+2),this.iconCol[r*3]=m.r,this.iconCol[r*3+1]=m.g,this.iconCol[r*3+2]=m.b;let T=e.maxHp(r);if((C||e.hp[r]<T)&&f<1&&a.add(this.vPos,(b===W.Commander?13:b===W.Boat||b===W.ConShip||b===W.AdvConShip?7:6)*p,(b===W.Commander?10:7)*p,e.hp[r]/T),C){let e=(b===W.Commander||b===W.Boat||b===W.ConShip||b===W.AdvConShip?7:4.5)*p;this.m.makeBasis(this.vRight,this.vUp,this.vFwd),this.m.scale(new L(e,e,e)),this.vPos.set(h*(y+.4),g*(y+.4),_*(y+.4)),this.m.setPosition(this.vPos),this.rings.setMatrixAt(d++,this.m)}}for(let e=0;e<24;e++){let t=this.meshes[e];t.count=u[e],t.instanceMatrix.needsUpdate=!0,t.instanceColor&&(t.instanceColor.needsUpdate=!0),t.geometry.getAttribute(`instFaction`).needsUpdate=!0,t.visible=f<1}this.rings.count=d,this.rings.instanceMatrix.needsUpdate=!0;let h=this.icons.geometry;h.setDrawRange(0,e.count),h.attributes.position.needsUpdate=!0,h.attributes.color.needsUpdate=!0;let g=this.blips.geometry;g.setDrawRange(0,s),g.attributes.position.needsUpdate=!0,g.attributes.color.needsUpdate=!0,this.blips.visible=s>0;let _=this.icons.material;_.opacity=f,this.icons.visible=f>0}},Vh=class{cap;points;n=0;pos;vel;col;col2;age;life;size0;size1;drag;grav;aPos;aCol;aSize;aAlpha;constructor(e,t){this.cap=e,this.pos=new Float32Array(e*3),this.vel=new Float32Array(e*3),this.col=new Float32Array(e*3),this.col2=new Float32Array(e*3),this.age=new Float32Array(e),this.life=new Float32Array(e),this.size0=new Float32Array(e),this.size1=new Float32Array(e),this.drag=new Float32Array(e),this.grav=new Float32Array(e);let n=new Ir;this.aPos=new xr(new Float32Array(e*3),3).setUsage(Ke),this.aCol=new xr(new Float32Array(e*3),3).setUsage(Ke),this.aSize=new xr(new Float32Array(e),1).setUsage(Ke),this.aAlpha=new xr(new Float32Array(e),1).setUsage(Ke),n.setAttribute(`position`,this.aPos),n.setAttribute(`color`,this.aCol),n.setAttribute(`size`,this.aSize),n.setAttribute(`alpha`,this.aAlpha),n.setDrawRange(0,0);let r=new Po({uniforms:{uScale:{value:500}},transparent:!0,depthWrite:!1,blending:t?2:1,vertexShader:`
        #include <common>
        #include <logdepthbuf_pars_vertex>
        attribute float size; attribute float alpha; attribute vec3 color;
        uniform float uScale;
        varying vec3 vCol; varying float vAlpha;
        void main() {
          vCol = color; vAlpha = alpha;
          vec4 mv = modelViewMatrix * vec4(position, 1.0);
          gl_Position = projectionMatrix * mv;
          gl_PointSize = clamp(size * uScale / max(-mv.z, 1.0), 1.0, 256.0);
          #include <logdepthbuf_vertex>
        }`,fragmentShader:`
        #include <common>
        #include <logdepthbuf_pars_fragment>
        varying vec3 vCol; varying float vAlpha;
        void main() {
          #include <logdepthbuf_fragment>
          vec2 c = gl_PointCoord * 2.0 - 1.0;
          float r = dot(c, c);
          if (r > 1.0) discard;
          float soft = (1.0 - r) * (1.0 - r);
          gl_FragColor = vec4(vCol, vAlpha * soft);
        }`});this.points=new Wi(n,r),this.points.frustumCulled=!1,this.points.renderOrder=3}emit(e,t,n,r,i,a,o,s=.5,c=0){let l;l=this.n<this.cap?this.n++:Math.floor(Math.random()*this.cap),this.pos.set([e.x,e.y,e.z],l*3),this.vel.set([t.x,t.y,t.z],l*3),this.col.set([a.r,a.g,a.b],l*3),this.col2.set([o.r,o.g,o.b],l*3),this.age[l]=0,this.life[l]=n,this.size0[l]=r,this.size1[l]=i,this.drag[l]=s,this.grav[l]=c}update(e,t){this.points.material.uniforms.uScale.value=t;let n=0,r=this.aPos.array,i=this.aCol.array,a=this.aSize.array,o=this.aAlpha.array;for(let t=0;t<this.n;t++){let s=this.age[t]+e;if(s>=this.life[t])continue;if(n!==t){for(let e=0;e<3;e++)this.pos[n*3+e]=this.pos[t*3+e],this.vel[n*3+e]=this.vel[t*3+e],this.col[n*3+e]=this.col[t*3+e],this.col2[n*3+e]=this.col2[t*3+e];this.life[n]=this.life[t],this.size0[n]=this.size0[t],this.size1[n]=this.size1[t],this.drag[n]=this.drag[t],this.grav[n]=this.grav[t]}this.age[n]=s;let c=s/this.life[n],l=this.pos[n*3],u=this.pos[n*3+1],d=this.pos[n*3+2],f=Math.hypot(l,u,d)||1,p=this.grav[n]*e/f,m=Math.max(0,1-this.drag[n]*e);this.vel[n*3]=(this.vel[n*3]-l*p)*m,this.vel[n*3+1]=(this.vel[n*3+1]-u*p)*m,this.vel[n*3+2]=(this.vel[n*3+2]-d*p)*m,this.pos[n*3]+=this.vel[n*3]*e,this.pos[n*3+1]+=this.vel[n*3+1]*e,this.pos[n*3+2]+=this.vel[n*3+2]*e,r[n*3]=this.pos[n*3],r[n*3+1]=this.pos[n*3+1],r[n*3+2]=this.pos[n*3+2];for(let e=0;e<3;e++)i[n*3+e]=this.col[n*3+e]+(this.col2[n*3+e]-this.col[n*3+e])*c;a[n]=this.size0[n]+(this.size1[n]-this.size0[n])*c,o[n]=c<.1?c/.1:1-(c-.1)/.9,n++}this.n=n,this.points.geometry.setDrawRange(0,n),this.aPos.needsUpdate=this.aCol.needsUpdate=this.aSize.needsUpdate=this.aAlpha.needsUpdate=!0}},Hh=e=>new R(e),Uh=Hh(16769696),Wh=Hh(16734736),Gh=Hh(5918792),Kh=Hh(15267071),qh=Hh(10471133),Jh=Hh(9075298),Yh=Hh(12576511),Xh=class{radius;group=new Pn;add=new Vh(9e3,!0);blend=new Vh(7e3,!1);rings=[];ringGeo=new Co(.82,1,64).rotateX(-Math.PI/2);flash;flashLeft=0;shake=0;v=new L;t1=new L;t2=new L;constructor(e){this.radius=e,this.group.add(this.add.points,this.blend.points),this.flash=new xs(16760960,0,1200,2),this.group.add(this.flash)}basis(e){this.t1.set(-e.z,0,e.x),this.t1.lengthSq()<1e-6&&this.t1.set(1,0,0),this.t1.normalize(),this.t2.crossVectors(e,this.t1).normalize()}randHemi(e,t,n){let r=Math.random()*Math.PI*2,i=Math.random();return this.basis(e),n.copy(this.t1).multiplyScalar(Math.cos(r)*i).addScaledVector(this.t2,Math.sin(r)*i).addScaledVector(e,t*(.3+Math.random()*.7))}ring(e,t,n,r,i,a,o=.9){let s=new oi(this.ringGeo,new Jr({color:a,transparent:!0,opacity:o,depthWrite:!1,side:2,blending:2}));s.position.copy(e),s.quaternion.setFromUnitVectors(new L(0,1,0),t),s.scale.setScalar(n),s.renderOrder=3,this.group.add(s),this.rings.push({mesh:s,age:0,life:i,r0:n,r1:r,a0:o})}light(e,t,n){this.flash.position.copy(e).addScaledVector(t,30),this.flash.intensity=Math.max(this.flash.intensity,n*4e3),this.flashLeft=.6}meteorTrail(e,t,n,r=1){if(!(r<=0)){n*=r;for(let i=0;i<6;i++)Math.random()>r||(this.v.copy(t).multiplyScalar(-20-Math.random()*30).add(this.t1.randomDirection().multiplyScalar(6)),this.add.emit(e.clone().addScaledVector(t,-i*4),this.v,.5+Math.random()*.6,14*n,30*n,Uh,Wh,1.5));this.add.emit(e,new L,.08,46*n,40*n,Hh(16777215),Uh),Math.random()<.5&&this.blend.emit(e.clone(),this.t1.randomDirection().multiplyScalar(4),1.8+Math.random()*1.2,8*n,30*n,Hh(9076856),Hh(5920336),.6)}}meteorImpact(e,t){let n=e.clone().normalize();if(this.light(e,n,t?9:6),this.add.emit(e.clone().addScaledVector(n,4),new L,.35,120,260,Hh(16777215),Uh,0),this.ring(e.clone().addScaledVector(n,1.5),n,4,95,1.1,t?16763024:14742783,.85),this.shake=Math.max(this.shake,1),t){this.ring(e.clone().addScaledVector(n,1.2),n,3,55,2.2,16740400,.5);for(let t=0;t<140;t++)this.randHemi(n,1.2,this.v).multiplyScalar(20+Math.random()*60),this.add.emit(e.clone().addScaledVector(n,3),this.v,.6+Math.random()*.9,18,40,Uh,Wh,2.5,8);for(let t=0;t<160;t++)this.randHemi(n,2.2,this.v).multiplyScalar(40+Math.random()*110),this.add.emit(e.clone().addScaledVector(n,2),this.v,1.2+Math.random()*1.6,3,1.5,Hh(16765056),Wh,.3,60);for(let t=0;t<60;t++)this.randHemi(n,.9,this.v).multiplyScalar(8+Math.random()*30),this.blend.emit(e.clone().addScaledVector(n,4+Math.random()*8),this.v,2.2+Math.random()*2.2,14,42,Jh,Hh(10129542),.5,-3);for(let t=0;t<24;t++)this.randHemi(n,1.6,this.v).multiplyScalar(25+Math.random()*40),this.add.emit(e.clone().addScaledVector(n,3),this.v,1.5+Math.random(),4,2,Yh,Hh(4892927),.4,50)}else{this.ring(e.clone().addScaledVector(n,.8),n,6,160,4.5,16777215,.45),this.ring(e.clone().addScaledVector(n,.8),n,4,90,3.2,12574975,.4);for(let t=0;t<220;t++)this.randHemi(n,3.5,this.v).multiplyScalar(25+Math.random()*75),this.blend.emit(e.clone().addScaledVector(n,2),this.v,1.8+Math.random()*1.6,8,22,Kh,qh,.2,55);for(let t=0;t<60;t++)this.randHemi(n,.6,this.v).multiplyScalar(10+Math.random()*30),this.blend.emit(e.clone().addScaledVector(n,6),this.v,4+Math.random()*3,25,80,Kh,Hh(9086136),.5,-2);for(let t=0;t<60;t++)this.randHemi(n,1.2,this.v).multiplyScalar(15+Math.random()*30),this.add.emit(e.clone().addScaledVector(n,3),this.v,.5+Math.random()*.5,16,30,Hh(16777215),Hh(6332671),2)}}explosion(e,t=1){let n=e.clone().normalize();this.light(e,n,4*t),this.add.emit(e.clone().addScaledVector(n,3),new L,.25,60*t,120*t,Hh(16777215),Uh,0),this.ring(e.clone().addScaledVector(n,1.2),n,2,45*t,.8,16756848,.8);for(let r=0;r<70*t;r++)this.randHemi(n,1.3,this.v).multiplyScalar((12+Math.random()*40)*t),this.add.emit(e.clone().addScaledVector(n,2),this.v,.5+Math.random()*.7,12*t,28*t,Uh,Wh,2.5,6);for(let r=0;r<40*t;r++)this.randHemi(n,1,this.v).multiplyScalar((6+Math.random()*18)*t),this.blend.emit(e.clone().addScaledVector(n,4),this.v,1.8+Math.random()*2,12*t,34*t,Gh,Hh(6971994),.5,-2);this.shake=Math.max(this.shake,.5*t)}muzzle(e,t){let n=e.clone().normalize();this.light(e,n,3);for(let n=0;n<50;n++)this.v.copy(t).multiplyScalar(40+Math.random()*80).add(this.t1.randomDirection().multiplyScalar(15)),this.add.emit(e,this.v,.3+Math.random()*.3,14,26,Hh(16777215),Hh(8373503),3);for(let t=0;t<40;t++)this.randHemi(n,.5,this.v).multiplyScalar(10+Math.random()*25),this.blend.emit(e.clone(),this.v,2.5+Math.random()*1.5,10,36,Hh(10132122),Hh(6974058),.6,-2)}weld(e){this.add.emit(e,new L,.08,5,2,Hh(16777215),Hh(10473727),0);for(let t=0;t<3;t++)this.v.copy(e).normalize().multiplyScalar(5).add(this.t1.randomDirection().multiplyScalar(9)),this.add.emit(e.clone(),this.v,.25+Math.random()*.3,1.4,.6,Hh(16773824),Wh,1,25)}gunFlash(e,t=1){this.add.emit(e,new L,.07,9*t,4*t,Hh(16777215),Hh(16760928),0),Math.random()<.6&&this.blend.emit(e.clone(),this.t1.randomDirection().multiplyScalar(3),.8,3*t,9*t,Hh(10132122),Hh(5921370),.8,-2)}tracer(e,t,n=16769162){let r=Hh(n);for(let n=0;n<5;n++){let i=(n+Math.random())/5;this.add.emit(e.clone().lerp(t,i),new L,.06,2.2,1.2,r,r,0)}for(let e=0;e<3;e++)this.v.copy(t).normalize().multiplyScalar(6).add(this.t1.randomDirection().multiplyScalar(10)),this.add.emit(t.clone(),this.v,.18+Math.random()*.15,2.5,1,Hh(16770736),Wh,1,20)}bullet(e,t){this.add.emit(e,new L,.05,4.5,3.5,Hh(16777215),Hh(16760944)),this.v.copy(t).multiplyScalar(-.05),this.add.emit(e.clone(),this.v,.25,2.5,1,Hh(16765072),Wh,1)}smallBlast(e,t,n){let r=e.clone().normalize();if(n)for(let n=0;n<26*t;n++)this.randHemi(r,3,this.v).multiplyScalar((8+Math.random()*18)*t),this.blend.emit(e.clone().addScaledVector(r,1),this.v,.9+Math.random()*.6,3*t,8*t,Kh,qh,.3,40);else{this.add.emit(e.clone().addScaledVector(r,1.5),new L,.12,14*t,22*t,Hh(16777215),Uh,0);for(let n=0;n<14*t;n++)this.randHemi(r,1.4,this.v).multiplyScalar((10+Math.random()*22)*t),this.add.emit(e.clone().addScaledVector(r,1),this.v,.3+Math.random()*.3,4*t,7*t,Uh,Wh,2.5,20);for(let n=0;n<8*t;n++)this.randHemi(r,.8,this.v).multiplyScalar((4+Math.random()*8)*t),this.blend.emit(e.clone().addScaledVector(r,2),this.v,1+Math.random(),5*t,12*t,Jh,Hh(6971994),.6,-2)}}wreckSmoke(e,t,n){let r=e.clone().normalize();this.v.copy(r).multiplyScalar(6+Math.random()*5).add(this.t1.randomDirection().multiplyScalar(2)),this.blend.emit(e.clone().addScaledVector(r,2),this.v,3+Math.random()*2,2*n,(6+8*t)*n,Hh(3814962),Hh(6973024),.4,-1.5),Math.random()<.35*t&&this.add.emit(e.clone().addScaledVector(r,1),this.t1.randomDirection().multiplyScalar(2),.4,1.6*n,.8*n,Uh,Wh,1)}reclaimGlint(e,t){this.v.copy(t).sub(e).multiplyScalar(1.8),this.add.emit(e.clone().add(this.t1.randomDirection().multiplyScalar(2)),this.v,.5,2.6,1.2,Yh,Hh(4892927),0)}shellTrail(e,t){this.add.emit(e,new L,.06,34,26,Hh(16777215),Hh(10476799));for(let n=0;n<4;n++)this.v.copy(t).multiplyScalar(-.03).add(this.t1.randomDirection().multiplyScalar(2)),this.add.emit(e.clone(),this.v,2.6+Math.random()*1.2,12,5,Hh(12577023),Hh(2117887),.4)}update(e,t,n){let r=n/(2*Math.tan(Pt.degToRad(t.fov)/2));this.add.update(e,r),this.blend.update(e,r);for(let t=this.rings.length-1;t>=0;t--){let n=this.rings[t];n.age+=e;let r=n.age/n.life;if(r>=1){this.group.remove(n.mesh),n.mesh.material.dispose(),this.rings.splice(t,1);continue}let i=1-(1-r)*(1-r);n.mesh.scale.setScalar(n.r0+(n.r1-n.r0)*i),n.mesh.material.opacity=n.a0*(1-r)}this.flashLeft>0&&(this.flashLeft-=e,this.flash.intensity*=Math.exp(-e*7),this.flashLeft<=0&&(this.flash.intensity=0)),this.shake*=Math.exp(-e*4)}};function Zh(e,t,n,r){if(n===V.MetalMine||n===V.AdvMine)return null;let i=e.planet.radius,a=2*H[n].radius+3,[o,s,c]=r,l=null,u=a*1.6/i;for(let r of e.structures){if(!r.alive||r.team!==t||r.type!==n)continue;let e=Math.hypot(r.x-o,r.y-s,r.z-c);e<u&&(u=e,l=r)}if(!l)return null;let d=[l.x,l.y,l.z],{north:f,east:p}=Zd(d),m=[];for(let e=-2;e<=2;e++)for(let t=-2;t<=2;t++){if(e===0&&t===0)continue;let n=a/i,r=d[0]+(e*p[0]+t*f[0])*n,l=d[1]+(e*p[1]+t*f[1])*n,u=d[2]+(e*p[2]+t*f[2])*n,h=Math.hypot(r,l,u);r/=h,l/=h,u/=h,m.push({dir:[r,l,u],d:Math.hypot(r-o,l-s,u-c)})}m.sort((e,t)=>e.d-t.d);for(let t of m)if(e.canPlace(n,t.dir))return t.dir;return null}function Qh(e,t=new Ft){let n=Math.hypot(e[0],e[1],e[2]),r=[e[0]/n,e[1]/n,e[2]/n],{north:i}=Zd(r),a=new L(...r),o=new L(...i),s=new L().crossVectors(a,o);return t.setFromRotationMatrix(new on().makeBasis(s,a,o))}var $h=[4033535,16734781,4063115,16765501],eg=768;function tg(e){switch(e){case V.Solar:{let e=[Y(Q(17,1,17,0,.5),J.CONCRETE),X(Q(15,.6,15,0,1.2))];for(let t=-1;t<=1;t++)for(let n=-1;n<=1;n++)e.push(Y(Q(4.6,.3,4.6,t*5,3,n*5,-.35),J.GLASS),Y(Q(4.9,.15,4.9,t*5,2.85,n*5,-.35),J.STEEL)),e.push(Y($(.25,1.8,t*5,1.4,n*5,5),J.STEEL));return Z(e)}case V.Wind:return Z([Y($(2.4,1.2,0,0,0,12,2),J.CONCRETE),X($(.9,6,0,1.2,0,10,.75)),Y($(.75,20,0,7.2,0,10,.45),J.LIGHT),X(Q(1.6,1.6,3.2,0,27,0)),Y(Mh(.5,.9,0,27,1.5),J.STEEL)]);case V.MetalMine:return Z([Y($(6.5,1.6,0,0,0,8,6),J.CONCRETE),X($(4.5,3,0,1.6,0,8,4)),Y($(2.2,1.2,0,4.6,0,8),J.STEEL),Y($(1.3,.4,0,5.8,0,8),J.HAZARD),Y(Q(.9,9,.9,2.6,9.4,2.6),J.STEEL),Y(Q(.9,9,.9,-2.6,9.4,-2.6),J.STEEL),Y(Q(.9,9,.9,2.6,9.4,-2.6),J.STEEL),Y(Q(.9,9,.9,-2.6,9.4,2.6),J.STEEL),Y(Q(6.2,.8,6.2,0,13.6,0),J.DARK),Y(Nh(1.1,.5,0,14.6,0),J.HAZARD)]);case V.Storage:return Z([Y(Q(18,1,13,0,.5),J.CONCRETE),X($(4.2,6,-4.2,1,0,16)),X($(4.2,6,4.2,1,0,16)),Y($(4.3,.9,-4.2,7,0,16,3.4),J.LIGHT),Y($(4.3,.9,4.2,7,0,16,3.4),J.LIGHT),Y(Q(1,1,7,0,5,0),J.STEEL),Y(Q(9,.7,.9,0,6.2,0),J.STEEL),Y(Q(17,.3,.5,0,1.15,6.2),J.HAZARD)]);case V.Horizon:return Z([Y($(15,3,0,0,0,24,14),J.CONCRETE),Y($(10,6,0,3,0,20,9),J.STEEL),Y(Q(14,.4,.8,0,3.2,14),J.HAZARD)]);case V.Radar:return Z([Y($(4.5,1.2,0,0,0,10,4.2),J.CONCRETE),X(Q(3.4,2,3.4,0,1.2)),Y($(.4,15,1.3,1,0,6,.6),J.STEEL),Y($(.4,15,-1.3,1,0,6,.6),J.STEEL),Y($(.4,15,0,1,1.3,6,.6),J.STEEL),Y(Q(3.2,.5,3.2,0,16,0),J.DARK)]);case V.VehiclePlant:{let e=[Y(Q(27,1,27,0,.5),J.CONCRETE),X(Q(22,8,16,0,5,-3)),Y(Q(18,7,.4,0,4.5,5.1),J.DARK),Y(Q(2,9,2,-10,5.5,5.5),J.STEEL),Y(Q(2,9,2,10,5.5,5.5),J.STEEL),Y(Q(22,2,2,0,9,5.5),J.STEEL),Y(Q(18,.5,.6,0,1.25,6.8),J.HAZARD),Y(Q(16,.3,7,0,1.1,10),J.CONCRETE)];for(let t=-1;t<=1;t++)e.push(Y(Q(22,.6,5.6,0,9.7,-3+t*5.2,-.16),J.TEAM_LIGHT,.45),Y(Q(22,.9,.3,0,9.9,-.45+t*5.2),J.GLASS));return e.push(Y($(1.2,8,-7,9,-8,10),J.STEEL),Y($(1.2,6,-4,9,-8,10),J.STEEL),Y($(1.3,.5,-7,17,-8,10),J.DARK)),Z(e)}case V.Shipyard:{let e=[Y(Q(22,1.4,24,0,.7),J.CONCRETE),X(Q(3,6,22,-9.5,3.5,0)),X(Q(3,6,22,9.5,3.5,0)),Y(Q(16,.6,20,0,1.6,1),J.DARK)];for(let t of[-6,5])e.push(Y(Q(2,14,2,-9.5,7,t),J.HAZARD),Y(Q(2,14,2,9.5,7,t),J.HAZARD),Y(Q(21,1.6,2,0,14.5,t),J.STEEL),X(Q(2.6,2.2,2.6,3,12.6,t),.7));return Z(e)}case V.DronePad:{let e=new To(7,.5,6,32);e.rotateX(Math.PI/2),e.translate(0,1.6,0);let t=[Y($(11.5,1.2,0,0,0,32,11),J.CONCRETE),Y($(9.5,.3,0,1.2,0,32),J.DARK),Y(e,J.HAZARD),X(Q(3.5,9,3.5,-8.5,4.5,-8.5)),Y(Q(5,2.5,5,-8.5,10,-8.5),J.GLASS),X(Q(5.4,.5,5.4,-8.5,11.5,-8.5),.7),Y($(.3,3,-8.5,11.7,-8.5,6),J.STEEL)];for(let[e,n]of[[9,0],[-9,3],[0,9],[0,-9]])t.push(Y($(.35,3,e,1.2,n,6),J.STEEL),Y(Q(.9,.9,.9,e,4.6,n),J.GLOW));return Z(t)}case V.SonarBuoy:return Z([Y($(2.6,1.6,0,-.6,0,14,2.2),J.HAZARD),Y($(2.8,.4,0,.9,0,14),J.DARK),X($(.9,1.2,0,1.1,0,10)),Y($(.12,4,0,2.3,0,5),J.STEEL),Y(Q(.5,.5,.5,0,6.4,0),J.GLOW),Y(Q(2.2,.15,.15,0,5,0),J.STEEL)]);case V.Converter:{let e=[Y(Q(13,1,13,0,.5),J.CONCRETE),Y(Q(7,6,9,-2,4,0),J.TEAM_LIGHT,.6),Y(Q(7.4,.6,9.4,-2,7.3,0),J.DARK)];return e.push(Y($(2.8,7,3.6,1,0,14),J.STEEL),Y($(1.6,1.2,3.6,4,2.6,10).rotateX(0),J.GLOW),Y($(3,.6,3.6,8,0,14),J.DARK)),e.push(Y($(.9,6,-4.5,7.6,-3,8),J.STEEL),Y($(1.1,.6,-4.5,13.6,-3,8),J.HAZARD),Y(Q(6,1,1,1,6,3.4),J.STEEL),Y(Q(1.2,2.2,.4,-2,3.4,4.6),J.GLOW)),Z(e)}case V.Tidal:{let e=[Y($(6,4.5,0,-3,0,20,5.6),J.CONCRETE),Y($(5.4,.4,0,1.5,0,20),J.DARK),Y(Q(6,3.2,7,0,3.4,0),J.TEAM_LIGHT,.6),Y(Q(6.4,.5,7.4,0,5.2,0),J.STEEL)];for(let t of[-1,1])e.push(Y(Q(.4,2.2,5,t*3.2,3.2,0),J.DARK),Y(Nh(1.6,.7,t*4.2,1.2,0),J.STEEL));return e.push(Y($(.25,4,2,5.4,-2.6,6),J.STEEL),Y(Q(.7,.7,.7,2,9.6,-2.6),J.GLOW),Y(Q(10,.3,1,0,1.6,6.2),J.HAZARD)),Z(e)}case V.AaGun:return Z([Y($(4.4,.6,0,0,0,16),J.CONCRETE),Y($(4.2,1.4,0,.6,0,16,3.9),J.HAZARD),X($(1.1,3,0,.6,0,10,.9))]);case V.AdvVehiclePlant:{let e=[Y(Q(33,1.2,33,0,.6),J.CONCRETE),Y(Q(28,10,20,0,6.2,-4),J.DARK)];for(let t of[-7,7])e.push(X(Q(12.6,9.2,.6,t,5.8,6.2),.85),Y(Q(10,7.6,.4,t,5,6.6),J.GLASS)),e.push(Y(Q(10,.5,.6,t,1.45,8.2),J.HAZARD),Y(Q(11,.3,8,t,1.3,11.5),J.CONCRETE));e.push(X(Q(28.4,1.4,20.4,0,11.6,-4)),Y(Q(29,.6,21,0,12.6,-4),J.STEEL)),e.push(Y(Q(1.6,14,1.6,-14.5,7,7),J.STEEL),Y(Q(1.6,14,1.6,14.5,7,7),J.STEEL),Y(Q(31,1.6,1.6,0,14.2,7),J.HAZARD));for(let t of[-9,9])e.push(Y($(1.6,10,t,12.6,-11,12),J.STEEL),Y($(1.8,.6,t,22.6,-11,12),J.DARK),X($(1.7,1.2,t,18,-11,12),.7));return Z(e)}case V.AdvShipyard:{let e=[Y(Q(28,1.6,30,0,.8),J.CONCRETE),Y(Q(18,.6,26,0,1.9,1),J.DARK)];for(let t of[-1,1])e.push(X(Q(4,9,28,t*12,5.6,0)),Y(Q(4.4,.8,28.4,t*12,10.4,0),J.STEEL));e.push(Y(Q(28,1.2,12,0,13,-8),J.DARK),X(Q(28.4,.6,12.4,0,13.8,-8),.7));for(let t of[4,11])e.push(Y(Q(2,18,2,-12,9,t),J.HAZARD),Y(Q(2,18,2,12,9,t),J.HAZARD),Y(Q(26,1.8,2.2,0,18.4,t),J.STEEL));return e.push(X(Q(3.2,2.6,3.2,-3,16.2,7.5),.8),Y(Q(5,6,5,11,13,-14),J.TEAM_LIGHT,.6),Y(Q(5.2,1.2,.3,11,15,-11.4),J.GLASS)),Z(e)}case V.AdvDronePad:{let e=[Y($(13.5,1.2,0,0,0,32,13),J.CONCRETE),Y(Q(22,3,14,0,2.2,1),J.DARK),X(Q(22.4,.6,14.4,0,3.9,1))];for(let t of[-5.5,5.5]){let n=new To(4.2,.35,6,28);n.rotateX(Math.PI/2),n.translate(t,4.4,1),e.push(Y(n,J.HAZARD),Y($(3.4,.15,t,4.2,1,24),J.STEEL))}e.push(X(Q(4.5,14,4.5,-9,7,-9)),Y(Q(6,3,6,-9,15.5,-9),J.GLASS),X(Q(6.4,.6,6.4,-9,17.3,-9),.7));for(let t of[-10.5,-9,-7.5])e.push(Y($(.18,5,t,17.6,-9,5),J.STEEL));for(let[t,n]of[[11,7],[-11,7],[11,-7]])e.push(Y($(.35,4,t,1.2,n,6),J.STEEL),Y(Q(.9,.9,.9,t,5.6,n),J.GLOW));return Z(e)}case V.Fission:{let e=new xo([new I(7.5,0),new I(6.2,6),new I(5.2,12),new I(5.6,17),new I(6.3,20)],24);e.translate(-3.5,1,-2);let t=new wo(4.2,18,9,0,Math.PI*2,0,Math.PI/2);t.translate(5.5,4,3.5);let n=new To(11.2,.35,6,40);return n.rotateX(Math.PI/2),n.translate(0,1.25,0),Z([Y($(12,1,0,0,0,32),J.CONCRETE),Y(n,J.HAZARD),Y(e,J.LIGHT),X($(6.4,1.2,-3.5,13.2,-2,24,5.4),.8),Y($(6.1,.4,-3.5,19.9,-2,24),J.DARK),Y(new To(6.3,.35,6,24).rotateX(Math.PI/2).translate(-3.5,21,-2),J.LIGHT),Y($(4.4,3,5.5,1,3.5,18),J.STEEL),X($(4.5,.8,5.5,2.6,3.5,18),.9),Y(t,J.LIGHT),Y(Q(.8,1.6,2.6,9.8,2.6,3.5),J.GLOW),Y(Q(2.6,1.6,.8,5.5,2.6,7.9),J.GLOW),Y(Q(7,1.2,1.2,1,3,1),J.STEEL)])}case V.AdvMine:{let e=[Y($(7.6,1.8,0,0,0,10,7),J.CONCRETE),X($(5.8,3.6,0,1.8,0,10,5)),Y($(3,1.6,0,5.4,0,10),J.DARK),Y($(1.8,.6,0,7,0,10),J.GLOW)];for(let[t,n]of[[3.4,3.4],[-3.4,-3.4],[3.4,-3.4],[-3.4,3.4]])e.push(Y(Q(1.1,13,1.1,t,11.6,n),J.STEEL),Y($(.7,3,t*1.5,1.8,n*1.5,8),J.HAZARD));return e.push(Y(Q(8,1,8,0,18.6,0),J.DARK),X(Q(8.4,.6,8.4,0,19.4,0),.8),Y(Nh(1.4,.6,0,20.6,0),J.HAZARD),Y($(.5,4,0,19.7,0,6),J.STEEL)),Z(e)}case V.HeavyTower:return Z([Y($(6.4,1,0,0,0,8),J.CONCRETE),Y($(5.6,4,0,1,0,8,4.6),J.DARK),X($(4.7,1,0,5,0,8),.85),Y(Q(9,.4,.8,0,1.1,5.9),J.HAZARD)]);case V.Anvil:{let e=[Y($(12.5,1.2,0,0,0,24,12),J.CONCRETE),Y($(7.5,5,0,1.2,0,8,6.5),J.DARK),X($(6.6,1.2,0,6.2,0,8),.85)];for(let[t,n]of[[-2.2,0],[2.2,0]])e.push(Y(Q(1.2,22,1.6,t,18,n),J.STEEL));e.push(Y(Q(5.6,1.2,2.4,0,29.4,0),J.HAZARD),Y(Q(2.4,18,.6,0,16,-.6),J.GLOW));for(let[t,n]of[[-8.5,6],[8.5,6],[-8.5,-6],[8.5,-6]])e.push(Y($(1.6,4,t,1.2,n,10),J.STEEL),X($(1.7,.8,t,4.2,n,10),.8),Y($(.5,.4,t,5.2,n,8),J.GLOW));let t=new wo(3.4,16,8,0,Math.PI*2,0,Math.PI/3);return t.rotateX(-Math.PI/2.6),t.translate(6.5,8.5,-6.5),e.push(Y(t,J.LIGHT),Y($(.3,2.4,6.5,6.2,-6.5,6),J.STEEL)),Z(e)}case V.Fusion:{let e=new To(8,2.6,12,36);e.rotateX(Math.PI/2),e.translate(0,5,0);let t=new wo(4,18,12);t.translate(0,6.5,0);let n=[Y($(16,1.2,0,0,0,36,15.5),J.CONCRETE),Y($(10.5,2.4,0,1.2,0,32),J.DARK),Y(e,J.LIGHT),X(new To(8,2.75,6,36,Math.PI/3).rotateX(Math.PI/2).translate(0,5,0),.85),Y(t,J.GLOW),Y(new To(15.2,.35,6,48).rotateX(Math.PI/2).translate(0,1.3,0),J.HAZARD)];for(let[e,t]of[[11,11],[-11,11],[11,-11],[-11,-11]])n.push(Y($(2.2,9,e,1.2,t,12,1.7),J.LIGHT),X($(2,1,e,6,t,12),.7));return Z(n)}case V.LaunchComplex:{let e=[Y(Q(25,1,25,0,.5,0),J.CONCRETE),Y(Q(14,8,10,-4,5,-5),J.DARK),X(Q(14.4,1.2,10.4,-4,9.4,-5)),Y(Q(.5,6,9,3.4,5,-5),J.GLASS)];for(let t=0;t<6;t++)e.push(Y(Q(.4,3,9.6,-10+t*2.2,11.5,-5),J.STEEL));e.push(Y($(4.6,1.6,6,1,6,16),J.STEEL),Y($(3.6,.3,6,2.6,6,16),J.HAZARD),Y(Q(7,.4,.8,6,2.8,6),J.DARK));let t=new wo(4,16,8,0,Math.PI*2,0,Math.PI/3);return t.rotateX(-Math.PI/3),t.translate(-7,14,6),e.push(Y(t,J.LIGHT),Y($(.4,10,-7,1,6,6),J.STEEL),Y($(.5,.5,-7,15.5,7,6),J.GLOW)),Z(e)}case V.PointDefence:return Z([Y($(5.2,1,0,0,0,10),J.CONCRETE),Y($(2.6,6,0,1,0,10,2.2),J.DARK),X($(2.8,1.6,0,7,0,10),.85),Y(Q(3.6,1.4,2.4,0,9.2,0),J.STEEL),Y(Mh(.25,4,-.8,9.6,1),J.GLOW),Y(Mh(.25,4,.8,9.6,1),J.GLOW),Y(Q(.3,2,.3,0,11,-1),J.DARK)]);case V.PracticeTarget:return Z([Y($(8,.8,0,0,0,24),J.LIGHT),Y($(5.5,.9,0,.8,0,24),J.HULL_RED),Y($(3,1,0,1.7,0,24),J.LIGHT),Y($(.6,10,0,2.7,0,8),J.STEEL),Y(Q(6,3,.4,0,12,0),J.HULL_RED)])}}function ng(){let e=[Y(Q(18,2.4,13,0,-.6),J.HULL_RED),Y(Q(18.4,.6,13.4,0,.9),J.CONCRETE)];for(let t of[-4.2,4.2])e.push(X($(4.2,6,t,1.2,0,16)),Y($(4.3,.9,t,7.2,0,16,3.4),J.LIGHT));for(let t of[-6.8,6.8])for(let n of[-6,0,6])e.push(Y($(.7,1.2,n,.2,t,8),J.DARK));return e.push(Y(Q(1,1,7,0,5.2,0),J.STEEL),Y(Q(9,.7,.9,0,6.4,0),J.STEEL),Y(Q(17,.3,.5,0,1.25,6.2),J.HAZARD)),Z(e)}function rg(e,t,n,r){if(e===V.Wind){let e=new oi(Z([Y(Q(.8,11,.3,0,5.5),J.LIGHT),Y(Q(.8,11,.3,0,5.5).rotateZ(2.094),J.LIGHT),Y(Q(.8,11,.3,0,5.5).rotateZ(-2.094),J.LIGHT),Y(Nh(.6,.8,0,0,0).rotateY(Math.PI/2),J.STEEL)]),n);e.position.set(0,27,1.8),t.add(e),r.blades=e}if(e===V.Radar){let e=new wo(4.2,16,8,0,Math.PI*2,0,.9);e.rotateX(-Math.PI/2+.35);let i=new oi(Z([Y(e,J.LIGHT),Y(Q(.4,.4,3,0,0,1.5),J.DARK)]),n);i.position.set(0,18.5,0),t.add(i),r.dish=i}if(e===V.Horizon){let e=new Pn;e.position.set(0,9,0),e.add(new oi(Z([X(Q(11,8,13,0,4,0)),Y(Q(11.4,1,13.4,0,8.5,0),J.DARK)]),n));let i=new $i(1.8,2.6,34,16);i.translate(0,17,0);let a=new $i(3,3,3,16);a.translate(0,3,0);let o=new oi(Z([Y(i,J.LIGHT),Y(a,J.DARK)]),n);o.position.set(0,3,0),o.rotation.x=.85,e.add(o),t.add(e),r.turret=e,r.barrel=o,r.recoil=0}if(e===V.AaGun){let e=new Pn;e.position.set(0,3.6,0),e.add(new oi(Z([X(Q(2.6,1.2,2.2,0,.6,0)),X(Q(.4,2,1.4,-1.5,1.8,0),.8),X(Q(.4,2,1.4,1.5,1.8,0),.8)]),n));let i=new Pn;i.position.set(0,2.2,0),i.add(new oi(Z([Y(Q(2.4,1.2,1.8,0,0,-.2),J.STEEL),Y(Mh(.22,4.2,-.55,.1,.5),J.DARK),Y(Mh(.22,4.2,.55,.1,.5),J.DARK),Y(Q(1.6,.9,1,0,.9,-.6),J.DARK)]),n)),i.rotation.x=-.6,e.add(i),t.add(e),r.aaYaw=e,r.aaPitch=i,r.aaFlash=0,r.muzzleZ=4.8,r.pivotY=5.8}if(e===V.HeavyTower){let e=new Pn;e.position.set(0,6,0),e.add(new oi(Z([X(Q(5.4,3,6.4,0,1.5,-.6)),Y(Q(5.6,.5,6.6,0,3.2,-.6),J.DARK),Y(Q(1.4,1,1.4,-1.6,3.8,-2),J.STEEL)]),n));let i=new Pn;i.position.set(0,1.6,2.4),i.add(new oi(Z([Y(Q(2,1.6,1.6,0,0,0),J.STEEL),Y(Mh(.45,9,0,0,.6,10),J.DARK),Y(Mh(.62,1.4,0,0,8.6,10),J.DARK)]),n)),i.rotation.x=-.12,e.add(i),t.add(e),r.aaYaw=e,r.aaPitch=i,r.aaFlash=0,r.muzzleZ=10,r.pivotY=7.6}}var ig=new Io({color:2828068,roughness:1,metalness:.15,emissive:0}),ag=25,og=(e,t,n,r)=>Math.hypot(e.x-t,e.y-n,e.z-r),sg=class{world;floatGeo;group=new Pn;effects;structs=new Map;siteMeshes=new Map;warnings=new Map;beams;arcs;geoCache=new Map;up=new L(0,1,0);q=new Ft;v=new L;last=new Map;seenStructs=new Map;wreckVis=new Map;seenWrecks=new Map;sinking=[];reclaimBeams;bulletLast=new Map;rallyLine;onMessage=()=>{};onBuilt=()=>{};fog=()=>!1;seen=()=>!0;bars=null;constructor(e){this.world=e,this.effects=new Xh(e.planet.radius),this.group.add(this.effects.group);let t=new Ir;t.setAttribute(`position`,new xr(new Float32Array(384),3).setUsage(Ke)),this.beams=new Li(t,new Ti({color:8257456,transparent:!0,opacity:.85,blending:2,depthWrite:!1})),this.beams.frustumCulled=!1,this.group.add(this.beams);let n=new Ir;n.setAttribute(`position`,new xr(new Float32Array(eg*3),3).setUsage(Ke)),this.arcs=new Li(n,new Ti({color:7321855,transparent:!0,opacity:.35,blending:2,depthWrite:!1})),this.arcs.frustumCulled=!1,this.group.add(this.arcs);let r=new Ir;r.setAttribute(`position`,new xr(new Float32Array(384),3).setUsage(Ke)),this.reclaimBeams=new Li(r,new Ti({color:16757575,transparent:!0,opacity:.85,blending:2,depthWrite:!1})),this.reclaimBeams.frustumCulled=!1,this.group.add(this.reclaimBeams);let i=new Ir;i.setAttribute(`position`,new xr(new Float32Array(75),3)),this.rallyLine=new Ni(i,new zo({color:4895999,dashSize:3,gapSize:2,transparent:!0,opacity:.9})),this.rallyLine.frustumCulled=!1,this.rallyLine.visible=!1,this.group.add(this.rallyLine)}canSee(e){return!this.fog()||this.world.visible(q.me,e)}known(e){if(e.team===q.me||!this.fog())return e.alive?e:null;let t=this.seenStructs.get(e.id);return t&&t.alive?t:null}knownWreck(e){return this.fog()?this.seenWrecks.get(e.id)??-1:e.alive?e.metal/e.metal0:-1}unitPos(e,t=2){let n=this.world,r=n.planet.radius+Math.max(0,n.elev[e])+t;return new L(n.x[e]*r,n.y[e]*r,n.z[e]*r)}heights=new Map;height(e){let t=this.heights.get(e);if(t===void 0){let n=this.geometry(e);n.computeBoundingBox(),t=n.boundingBox.max.y,this.heights.set(e,t)}return t}geometry(e){let t=this.geoCache.get(e);return t||(t=tg(e),this.geoCache.set(e,t)),t}surface(e,t,n,r=0,i=new L){let a=Math.max(0,this.world.planet.heightAt(e,t,n))*45;return i.set(e,t,n).normalize().multiplyScalar(this.world.planet.radius+a+r)}orient(e,t,n,r,i=0){this.surface(t,n,r,i,e.position),this.v.set(t,n,r).normalize(),this.q.setFromUnitVectors(this.up,this.v),e.quaternion.copy(this.q)}update(e,t,n,r,i){let a=this.world,o=a.tick-1+t;for(let e of a.events)if(e.kind===`meteor-impact`)yf(a,q.me,e.team,e.dir)&&this.effects.meteorImpact(this.surface(...e.dir,(e.land,0)),e.land);else if(e.kind===`shell-impact`){let t=this.surface(...e.dir);this.effects.explosion(t,e.rod?2.6:1.4),e.rod&&this.effects.ring(t,t.clone().normalize(),4,bd.radius,.9,16769712,.9),e.nuke&&(this.effects.explosion(t,8),this.effects.ring(t,t.clone().normalize(),10,Sd.radius,2.2,16774872,.95),this.effects.ring(t,t.clone().normalize(),6,Sd.radius*.7,1.6,16742954,.95))}else if(e.kind===`nuke-stopped`){let t=this.surface(...e.dir,180);this.effects.explosion(t,2.2)}else if(e.kind===`emp`){let t=this.surface(...e.dir,6);this.effects.ring(t,t.clone().normalize(),4,e.radius,1.1,8050687,.95),this.effects.ring(t,t.clone().normalize(),2,e.radius*.6,.7,14218495,.8),this.effects.explosion(t,.5)}else if(e.kind===`destroyed`){if(!this.canSee(e.dir)&&e.team!==q.me)continue;let t=e.unitType!==void 0&&G[e.unitType].layer===B.Air,n=t?new L(...e.dir).normalize().multiplyScalar(a.planet.radius+(e.elev??0)):this.surface(...e.dir,2);this.effects.explosion(n,e.big?2:e.what===`structure`?1.2:t?.35:.6),e.blast&&(this.effects.explosion(n,5),this.effects.ring(n,n.clone().normalize(),6,e.blast,1.4,16773572,.85),this.effects.ring(n,n.clone().normalize(),4,e.blast*.6,.9,16747066,.9)),e.sink&&t?this.effects.smallBlast(this.surface(...e.dir),1.4,!0):e.sink&&e.unitType!==void 0&&this.startSinking(e.unitType,e.team,e.dir,e.heading??[1,0,0])}else if(e.kind===`shot`){let t=e.unit,n=[a.x[t],a.y[t],a.z[t]];if(!this.canSee(n)&&!this.canSee(e.to))continue;let r=this.unitPos(t,a.type[t]===W.Drone?0:3),i=a.planet.radius+Math.max(0,e.toElev)+1.5,o=new L(...e.to).normalize().multiplyScalar(i),s=a.type[t]===W.Boat&&e.weapon===0?1.6:1;e.instant?this.effects.tracer(r,o,a.type[t]===W.Sub?8388564:a.type[t]===W.Boat?12575999:16769162):this.effects.gunFlash(r.addScaledVector(o.clone().sub(r).normalize(),3),s)}else if(e.kind===`struct-shot`){let t=a.structById(e.struct),n=t&&this.structs.get(t.id);if(!t||!n?.aaYaw||!this.canSee([t.x,t.y,t.z])&&!this.canSee(e.to))continue;let r=new L(...e.to).normalize().multiplyScalar(a.planet.radius+Math.max(0,e.toElev));n.mesh.updateWorldMatrix(!0,!1);let i=n.mesh.worldToLocal(r.clone());n.aaYaw.rotation.y=Math.atan2(i.x,i.z),n.aaPitch.rotation.x=-Math.atan2(i.y-(n.pivotY??5.8),Math.hypot(i.x,i.z)),n.aaPitch.updateWorldMatrix(!0,!1);let o=n.aaPitch.localToWorld(new L(0,.1,n.muzzleZ??4.8));H[t.type].weapon?.kind===`shell`?this.effects.gunFlash(o,2.2):this.effects.tracer(o,r,16765562)}else if(e.kind===`proj-impact`){if(!this.canSee(e.dir))continue;this.effects.smallBlast(this.surface(...e.dir,.5),e.splash/5,e.water)}else if(e.kind===`horizon-launch`){let t=a.structById(e.struct);if(t){let e=this.structs.get(t.id),n=this.surface(t.x,t.y,t.z,30),r=n.clone().normalize();e?.barrel&&(e.barrel.updateWorldMatrix(!0,!1),n=e.barrel.localToWorld(new L(0,34,0)),r=e.barrel.localToWorld(new L(0,40,0)).sub(n).normalize(),e.recoil=1),this.effects.muzzle(n,r)}}else if(e.kind===`built`){let t=a.structById(e.struct);t&&(this.onBuilt(t),this.effects.ring(this.surface(t.x,t.y,t.z,.6),this.v.set(t.x,t.y,t.z).normalize().clone(),2,H[t.type].radius*2.2,.8,8257456,.7))}else e.kind===`message`&&e.team===q.me&&this.onMessage(e.text);a.events.length=0;let s=this.fog(),c=new Set;for(let t of a.structures){let n=t.team!==q.me&&s;if(n)this.canSee([t.x,t.y,t.z])&&(t.alive?this.seenStructs.set(t.id,{alive:!0,progress:t.progress,complete:t.complete}):this.seenStructs.delete(t.id));else if(!t.alive)continue;let r=this.known(t);if(!r)continue;let l=n&&!this.canSee([t.x,t.y,t.z]);c.add(t.id);let u=this.structs.get(t.id);if(!u){let e=new Io({color:16777215,roughness:.62,metalness:.06,transparent:!0}),n=a.teams[t.team]?.faction;Fh(e,{value:new R(t.type===V.PracticeTarget?14211288:$h[t.team])},{value:n===`agi`?1:n===`man`?-1:0});let r=new oi(t.type===V.Storage&&!a.planet.land[t.cell]?this.floatGeo??=ng():this.geometry(t.type),e);if(this.surface(t.x,t.y,t.z,0,r.position),Qh([t.x,t.y,t.z],r.quaternion),this.group.add(r),u={mesh:r,mat:e},rg(t.type,r,e,u),t.type===V.PracticeTarget){let e=new oi(new To(5.5,.5,8,32),new Io({color:16724e3,emissive:4198408}));e.rotateX(Math.PI/2),e.position.y=1.4,r.add(e)}this.structs.set(t.id,u)}let d=r.complete?1:r.progress;u.mesh.scale.set(1,.08+.92*d,1),u.mat.opacity=(r.complete?1:.35+.4*d)*(l?.55:1);let f=!t.complete&&t.idleTicks>0&&!n;if(u.mat.emissive.setHex(t.id===i?3364147:r.complete?0:f?Math.floor(o/10)%2?4198408:2099204:667680),!l){if(u.blades&&t.complete&&(u.blades.rotation.z+=e*(1+5*a.wind())),u.dish&&t.complete&&a.teams[t.team].radarPowered&&(u.dish.rotation.y+=e*1.2),u.turret){u.turret.rotation.y=Math.atan2(-t.aimE,t.aimN),u.recoil=Math.max(0,(u.recoil??0)-e*.8);let n=Math.sin(Math.min(1,u.recoil*4)*Math.PI/2)*u.recoil*5;u.barrel.position.set(0,3-Math.cos(.85)*n,-Math.sin(.85)*n)}if(t.complete&&t.prod.length&&Jd[t.type]&&Math.random()<e*14){let e=H[t.type].radius,n=t.type===V.DronePad||t.type===V.AdvDronePad?[t.x,t.y,t.z]:Qd([t.x,t.y,t.z],(Math.random()-.5)*e,t.type===V.Shipyard||t.type===V.AdvShipyard?(Math.random()-.5)*e:e*.55,a.planet.radius);this.effects.weld(this.surface(...n,2+Math.random()*4))}if(this.bars&&t.alive){let e=H[t.type].radius,n=this.surface(t.x,t.y,t.z),r=this.height(t.type)*(t.complete?1:.08+.92*t.progress)+5,i=Math.min(e*1.2,Math.max(5,this.bars.camHeight*.035));this.bars.add(n,r,i,t.hp/H[t.type].hp),t.complete||this.bars.add(n,r,i,t.progress,!0,1)}}}for(let[e,t]of this.structs)c.has(e)||(this.group.remove(t.mesh),t.mat.dispose(),this.structs.delete(e));let l=i>=0?a.structById(i):void 0,u=this.rallyLine.geometry.attributes.position;if(l&&l.alive&&l.team===q.me&&l.rally&&Jd[l.type]){let e=this.surface(l.x,l.y,l.z,3),t=this.surface(...l.rally,1.5);for(let n=0;n<=24;n++){let r=n/24,i=e.clone().lerp(t,r).normalize(),o=Math.max(0,a.planet.heightAt(i.x,i.y,i.z))*45;i.multiplyScalar(a.planet.radius+o+2+Math.sin(r*Math.PI)*6),u.setXYZ(n,i.x,i.y,i.z)}u.needsUpdate=!0,this.rallyLine.computeLineDistances(),this.rallyLine.visible=!0}else this.rallyLine.visible=!1;this.updateWrecks(e),this.updateSinking(e);for(let e of a.sites){if(this.siteMeshes.has(e.id)||e.richness<=0||!yf(a,q.me,e.team??-1,[e.x,e.y,e.z])||!this.seen([e.x,e.y,e.z]))continue;let t=new Pn,n=new oi(new Qi(11,32).rotateX(-Math.PI/2),new Io({color:2366486,roughness:1,transparent:!0,opacity:.85,depthWrite:!1,polygonOffset:!0,polygonOffsetFactor:-2}));n.position.y=.25;let r=new oi(new To(11,1.4,6,32).rotateX(Math.PI/2),new Io({color:5917242,roughness:1}));r.scale.y=.4,r.position.y=.3,t.add(n,r);let i=new Io({color:10475775,emissive:2788607,emissiveIntensity:.9,metalness:.8,roughness:.25}),o=5+Math.round(e.richness);for(let e=0;e<o;e++){let n=new oi(new ea(.9+Math.random()*.8,3+Math.random()*4,5),i),r=e/o*Math.PI*2+Math.random()*.5,a=Math.random()*5;n.position.set(Math.cos(r)*a,1.2,Math.sin(r)*a),n.rotation.set((Math.random()-.5)*.8,Math.random()*3,(Math.random()-.5)*.8),t.add(n)}this.orient(t,e.x,e.y,e.z,-.3),this.group.add(t),this.siteMeshes.set(e.id,t)}let d=new Set;for(let e of a.impacts){if(o<e.warnTick||!yf(a,q.me,e.team,[e.x,e.y,e.z]))continue;d.add(e.id);let t=this.warnings.get(e.id);t||(t=new oi(new Co(.8,1,48).rotateX(-Math.PI/2),new Jr({color:16726560,transparent:!0,depthWrite:!1,side:2})),this.orient(t,e.x,e.y,e.z,1),t.renderOrder=3,this.group.add(t),this.warnings.set(e.id,t));let n=(e.impactTick-o)/20,r=.5+.5*Math.sin(o*.6);if(t.scale.setScalar(Fd.damageRadius*(.85+.15*r)),t.material.opacity=.35+.5*r,n<3){let t=1-n/3,r=this.v.set(e.x,e.y,e.z).normalize().clone(),i=this.surface(e.x,e.y,e.z),a=new L(-r.z,.3,r.x).normalize().addScaledVector(r,-.3).normalize(),o=i.clone().addScaledVector(r,6e3).addScaledVector(a,3e3),s=o.clone().lerp(i,t*t*.3+t*.7),c=this.last.get(e.id)??o,l=s.clone().sub(c),u=Math.min(1,t/.45);l.lengthSq()>1e-6&&this.effects.meteorTrail(s,l.normalize(),e.shower?1:1.3,u*u),this.last.set(e.id,s)}}for(let[e,t]of this.warnings)d.has(e)||(this.group.remove(t),t.material.dispose(),this.warnings.delete(e),this.last.delete(e));let f=this.arcs.geometry.attributes.position,p=0;for(let e of a.shells)if(!(e.team!==q.me||e.rod||p+48>eg))for(let t=0;t<24;t++){let n=this.shellPos(e.from,e.to,t/24),r=this.shellPos(e.from,e.to,(t+1)/24);f.setXYZ(p++,n.x,n.y,n.z),f.setXYZ(p++,r.x,r.y,r.z)}this.arcs.geometry.setDrawRange(0,p),f.needsUpdate=!0;for(let t of a.shells){let n=Pt.clamp((o-t.launchTick)/(t.impactTick-t.launchTick),0,1),r=t.rod?new L(...t.to).normalize().multiplyScalar(a.planet.radius+900*(1-n)*(1-n)):this.shellPos(t.from,t.to,n),i=this.last.get(t.id)??r;this.effects.shellTrail(r,r.clone().sub(i).divideScalar(Math.max(e,.001))),this.last.set(t.id,r)}let m=this.beams.geometry.attributes.position,h=0,g=this.reclaimBeams.geometry.attributes.position,_=0;for(let e=0;e<a.count&&h<64;e++){let t=a.buildTask[e];if(t<0||!a.alive[e]||a.hasOrder[e]||!qd(a.type[e])||a.team[e]!==q.me&&!this.canSee([a.x[e],a.y[e],a.z[e]]))continue;let n=a.structById(t);if(!n){let n=a.wreckById(t);if(!n||!n.alive||_>=64)continue;let r=a.planet.radius;if(og(n,a.x[e],a.y[e],a.z[e])*r>n.radius+10.5)continue;let i=this.surface(a.x[e],a.y[e],a.z[e],a.type[e]===W.Commander?9:G[a.type[e]].layer===B.Air?a.elev[e]-1:5.6),o=this.surface(n.x,n.y,n.z,2);g.setXYZ(_*2,i.x,i.y,i.z),g.setXYZ(_*2+1,o.x+(Math.random()-.5)*2*n.radius,o.y+(Math.random()-.5)*2*n.radius,o.z+(Math.random()-.5)*2*n.radius),Math.random()<.5&&this.effects.reclaimGlint(o,i),_++;continue}if(n.complete&&(!n.alive||n.prod.length===0||n.prodProgress<=0||og(n,a.x[e],a.y[e],a.z[e])*a.planet.radius>Gp(n.type)))continue;let r=this.surface(a.x[e],a.y[e],a.z[e],a.type[e]===W.Commander?9:5.6),i=this.surface(n.x,n.y,n.z,n.complete?8:2+6*n.progress);m.setXYZ(h*2,r.x,r.y,r.z),m.setXYZ(h*2+1,i.x+(Math.random()-.5)*3,i.y+(Math.random()-.5)*3,i.z+(Math.random()-.5)*3),h++}this.beams.geometry.setDrawRange(0,h*2),m.needsUpdate=!0,this.reclaimBeams.geometry.setDrawRange(0,_*2),g.needsUpdate=!0;let v=new Set;for(let t of a.projectiles){if(!this.canSee(t.from)&&!this.canSee(t.to))continue;v.add(t.id);let n=Pt.clamp((o-t.launchTick)/(t.impactTick-t.launchTick),0,1),r=new L(...t.from),i=new L(...t.to),s=r.distanceTo(i)*a.planet.radius,c=(e,t)=>Math.max(t,Math.max(0,a.planet.heightAt(e.x,e.y,e.z))*45),l=r.clone().lerp(i,n).normalize(),u=c(r,t.fromElev)*(1-n)+c(i,t.toElev)*n+s*.12*4*n*(1-n),d=l.multiplyScalar(a.planet.radius+u+1.5),f=this.bulletLast.get(t.id)??d;this.effects.bullet(d,d.clone().sub(f).divideScalar(Math.max(e,.001))),this.bulletLast.set(t.id,d)}for(let e of this.bulletLast.keys())v.has(e)||this.bulletLast.delete(e);this.effects.update(e,n,r)}updateWrecks(e){let t=this.world,n=this.fog(),r=new Set;for(let i of t.wrecks){n&&this.canSee([i.x,i.y,i.z])&&(i.alive?this.seenWrecks.set(i.id,i.metal/i.metal0):this.seenWrecks.delete(i.id));let a=this.knownWreck(i);if(a<0)continue;r.add(i.id);let o=this.wreckVis.get(i.id);if(!o){let e=new oi(i.from===`unit`?zh(i.type):this.geometry(i.type),ig),t=new L(i.x,i.y,i.z).normalize(),n=new L(i.hx,i.hy,i.hz);n.addScaledVector(t,-n.dot(t)),n.lengthSq()<1e-6&&(n=new L(-t.z,0,t.x)),n.normalize();let r=new L().crossVectors(t,n);e.quaternion.setFromRotationMatrix(new on().makeBasis(r,t,n));let a=i.id*.6180339%1;e.rotateZ((a-.5)*.5),e.rotateX((i.id*.414%1-.5)*.3),e.rotateY(a*2),this.surface(i.x,i.y,i.z,i.from===`unit`?-.3:-.6,e.position),this.group.add(e),o={mesh:e,base:i.from===`unit`?G[i.type].layer===B.Air?1:.75:.4,smokeT:0},this.wreckVis.set(i.id,o)}let s=.45+.55*a;o.mesh.scale.set(s,o.base*s,s);let c=(t.tick-i.tick)/20;c<ag&&i.alive&&this.canSee([i.x,i.y,i.z])&&(o.smokeT-=e,o.smokeT<=0&&(o.smokeT=.12+Math.random()*.1,this.effects.wreckSmoke(this.surface(i.x,i.y,i.z,2),1-c/ag,Math.max(1,i.radius/3.5))))}for(let[e,t]of this.wreckVis)r.has(e)||(this.group.remove(t.mesh),this.wreckVis.delete(e))}startSinking(e,t,n,r){let i=new Io({color:$h[t],roughness:.8,metalness:.3,transparent:!0});i.color.multiplyScalar(.45);let a=new oi(zh(e),i),o=new L(...n).normalize(),s=new L(...r);s.addScaledVector(o,-s.dot(o)),s.lengthSq()<1e-6&&s.set(-o.z,0,o.x),s.normalize();let c=new L().crossVectors(o,s);a.quaternion.setFromRotationMatrix(new on().makeBasis(c,o,s)),a.position.copy(o).multiplyScalar(this.world.planet.radius),this.group.add(a),this.sinking.push({mesh:a,age:0,n:o,roll:s})}updateSinking(e){for(let t=this.sinking.length-1;t>=0;t--){let n=this.sinking[t];n.age+=e;let r=n.age/6;r>=1?(this.group.remove(n.mesh),n.mesh.material.dispose(),this.sinking.splice(t,1)):(n.mesh.rotateOnWorldAxis(n.roll,e*.35*(1-r)),n.mesh.position.copy(n.n).multiplyScalar(this.world.planet.radius-9*r*r),n.mesh.material.opacity=1-r*r,Math.random()<.4*(1-r)&&this.effects.wreckSmoke(n.mesh.position.clone().addScaledVector(n.n,2),1-r,1.3))}}shellPos(e,t,n){let r=new L(...e).normalize(),i=new L(...t).normalize(),a=Math.acos(Pt.clamp(r.dot(i),-1,1)),o;if(a<1e-4)o=r.clone();else{let e=Math.sin(a);o=r.clone().multiplyScalar(Math.sin((1-n)*a)/e).addScaledVector(i,Math.sin(n*a)/e)}let s=this.world.planet.radius,c=30+Math.min(Id.apex*s,a*s*.45+60)*Math.sin(Math.PI*n)**.85;return o.normalize().multiplyScalar(s+c)}},cg=2048,lg=new R(4895999),ug=new R(6160234),dg=new R(16765501),fg=new R(16728112),pg=class{group=new Pn;bg;fg;n=0;m=new on;p=new L;s=new L;c=new R;q=new Ft;right=new L;camUp=new L;camPos=new L;maxCamHeight=1100;camHeight=0;constructor(){let e=new So(1,1),t=(t,n)=>{let r=new vi(e,new Jr({color:t,transparent:!0,depthWrite:!1,opacity:.9}),cg);return r.count=0,r.frustumCulled=!1,r.renderOrder=n,r.instanceMatrix.setUsage(Ke),r};this.bg=t(1052688,5),this.fg=t(16777215,6),this.fg.setColorAt(0,new R),this.group.add(this.bg,this.fg)}begin(e,t){this.n=0,this.q.copy(e.quaternion),this.right.set(1,0,0).applyQuaternion(this.q),this.camUp.set(0,1,0).applyQuaternion(this.q),this.camPos.copy(e.position),this.camHeight=t}add(e,t,n,r,i=!1,a=0){if(this.n>=cg||this.camHeight>this.maxCamHeight)return;let o=this.p.copy(e).multiplyScalar(1+t/e.length());if(o.dot(this.s.copy(this.camPos).sub(o))<0)return;let s=n*.14;a&&o.addScaledVector(this.camUp,-a*s*2.1);let c=this.n++;this.m.compose(o,this.q,this.s.set(n+s*.5,s*1.5,1)),this.bg.setMatrixAt(c,this.m);let l=Math.max(0,Math.min(1,r));o.addScaledVector(this.right,-(n*(1-l))/2),this.m.compose(o,this.q,this.s.set(Math.max(.001,n*l),s,1)),this.fg.setMatrixAt(c,this.m),i?this.c.copy(lg):this.c.copy(l>.5?dg:fg).lerp(l>.5?ug:dg,l>.5?(l-.5)*2:l*2),this.fg.setColorAt(c,this.c)}flush(){this.bg.count=this.fg.count=this.n,this.bg.instanceMatrix.needsUpdate=this.fg.instanceMatrix.needsUpdate=!0,this.fg.instanceColor&&(this.fg.instanceColor.needsUpdate=!0)}},mg=[65,110];function hg(e){return Number.isFinite(e)?Math.round(Math.min(1,Math.max(0,e))*20)/20:0}function gg(e,t){let n=e/t;return 1/(1+n*n)}function _g(e){let[t,n]=mg,r=Math.min(1,Math.max(0,(e-t)/(n-t)));return r*r*(3-2*r)}function vg(e,t,n){let r=Math.sqrt(e[0]*e[0]+e[1]*e[1]+e[2]*e[2]);return r===0||(e[0]*t[0]+e[1]*t[1]+e[2]*t[2])/r>=n*.995}function yg(e,t,n,r,i){if(!vg(e,t,n))return 0;let a=t[0]-e[0],o=t[1]-e[1],s=t[2]-e[2],c=Math.sqrt(a*a+o*o+s*s),l=Math.sqrt(t[0]*t[0]+t[1]*t[1]+t[2]*t[2])-n,u=gg(c,r)*(i?1:1-_g(l));return u<.005?0:u}var bg=[`explosion-1`,`explosion-2`,`explosion-3`,`gun-1`,`gun-2`,`gun-3`,`gun-4`,`gun-5`,`impact-1`,`impact-2`,`woosh-1`,`burst`],xg={effects:.7,ambience:.7,music:.5},Sg=.4,Cg=20,wg=e=>e[Math.floor(Math.random()*e.length)],Tg=class{world;ctx=null;master;sfx;bus={};levels={...xg};music=null;buffers=new Map;noise;brown;engines=new Map;ocean=null;wind=null;hum=null;voices=new Map;lastDroneShot=new Map;lastFactoryClank=0;camera=null;tmp=new L;canHear=()=>!0;constructor(e){this.world=e;try{let e=localStorage.getItem(`blue.sound.levels`);if(e){let t=JSON.parse(e);for(let e of Object.keys(xg))typeof t[e]==`number`&&(this.levels[e]=hg(t[e]))}else if(localStorage.getItem(`blue.sound`)!==null){let e=hg(Number(localStorage.getItem(`blue.sound`)));this.levels.effects=this.levels.ambience=e}}catch{}let t=()=>{this.start(),window.removeEventListener(`pointerdown`,t),window.removeEventListener(`keydown`,t)};window.addEventListener(`pointerdown`,t),window.addEventListener(`keydown`,t)}get volume(){return this.levels.effects}get level(){return this.levels.effects}getLevel(e){return this.levels[e]}setLevel(e,t){this.levels[e]=hg(t);try{localStorage.setItem(`blue.sound.levels`,JSON.stringify(this.levels))}catch{}return this.ctx&&this.applyLevels(),this.levels[e]}applyLevels(){let e=this.ctx.currentTime;this.bus.effects.gain.setTargetAtTime(this.levels.effects,e,.05),this.bus.ambience.gain.setTargetAtTime(this.levels.ambience,e,.05),this.bus.music.gain.setTargetAtTime(this.levels.music*Sg,e,.05)}start(){if(this.ctx)return;let e=window.AudioContext??window.webkitAudioContext;if(!e)return;let t=this.ctx=new e;this.master=t.createGain(),this.master.gain.value=1,this.master.connect(t.destination);for(let e of[`effects`,`ambience`,`music`])this.bus[e]=t.createGain(),this.bus[e].connect(this.master);this.applyLevels(),this.sfx=t.createDynamicsCompressor(),this.sfx.threshold.value=-18,this.sfx.knee.value=12,this.sfx.ratio.value=4,this.sfx.attack.value=.004,this.sfx.release.value=.25,this.sfx.connect(this.bus.effects),this.noise=this.makeNoise(!1),this.brown=this.makeNoise(!0);for(let e of bg)fetch(`./sounds/${e}.mp3`).then(e=>e.arrayBuffer()).then(e=>t.decodeAudioData(e)).then(t=>this.buffers.set(e,t)).catch(()=>{});this.startAmbience()}makeNoise(e){let t=this.ctx,n=t.createBuffer(1,t.sampleRate*3,t.sampleRate),r=n.getChannelData(0),i=0;for(let t=0;t<r.length;t++){let n=Math.random()*2-1;e?(i=(i+.02*n)/1.02,r[t]=i*3.5):r[t]=n}return n}loopNoise(e){let t=this.ctx.createBufferSource();return t.buffer=e?this.brown:this.noise,t.loop=!0,t.start(0,Math.random()*2),t}startAmbience(){let e=this.ctx;{let t=this.loopNoise(!0),n=e.createBiquadFilter();n.type=`lowpass`,n.frequency.value=500,n.Q.value=.3;let r=e.createGain();r.gain.value=0;let i=e.createOscillator();i.frequency.value=.11;let a=e.createGain();a.gain.value=260,i.connect(a).connect(n.frequency),i.start(),t.connect(n).connect(r).connect(this.bus.ambience),this.ocean={gain:r,filter:n}}{let t=this.loopNoise(!1),n=e.createBiquadFilter();n.type=`bandpass`,n.frequency.value=700,n.Q.value=.8;let r=e.createOscillator();r.frequency.value=.07;let i=e.createGain();i.gain.value=350,r.connect(i).connect(n.frequency),r.start();let a=e.createGain();a.gain.value=0,t.connect(n).connect(a).connect(this.bus.ambience),this.wind={gain:a,filter:n}}{let t=e.createGain();t.gain.value=0;let n=e.createGain();n.gain.value=.5;let r=e.createOscillator();r.frequency.value=7;let i=e.createGain();i.gain.value=.35,r.connect(i).connect(n.gain),r.start();for(let t of[196,293.7,392.5]){let r=e.createOscillator();r.type=`sine`,r.frequency.value=t;let i=e.createGain();i.gain.value=t>300?.25:.5,r.connect(i).connect(n),r.start()}n.connect(t).connect(this.sfx),this.hum={gain:t}}}engine(e,t,n,r,i){let a=this.engines.get(e);if(a)return a;let o=this.ctx,s=o.createBiquadFilter();s.type=`lowpass`,s.frequency.value=n,s.Q.value=1.2;let c=o.createGain();c.gain.value=0;let l=o.createStereoPanner(),u=[];for(let[e,n,r]of[[1,`sawtooth`,.5],[1.007,`sawtooth`,.35],[.5,`square`,.3]]){let a=o.createOscillator();a.type=n,a.frequency.value=t*e;let c=o.createOscillator();c.frequency.value=i*(.8+Math.random()*.4);let l=o.createGain();l.gain.value=t*.04,c.connect(l).connect(a.frequency),c.start();let d=o.createGain();d.gain.value=r,a.connect(d).connect(s),a.start(),u.push(a)}if(r>0){let e=this.loopNoise(!1),t=o.createBiquadFilter();t.type=`bandpass`,t.frequency.value=n*1.5,t.Q.value=.7;let i=o.createGain();i.gain.value=r,e.connect(t).connect(i).connect(s)}return s.connect(c).connect(l).connect(this.sfx),a={gain:c,osc:u,filter:s,level:0,pan:l},this.engines.set(e,a),a}place(e,t,n=!1){let r=this.camera;if(!r)return{gain:0,pan:0};let i=r.position,a=yg([e.x,e.y,e.z],[i.x,i.y,i.z],this.world.planet.radius,t,n);if(a<=0)return{gain:0,pan:0};let o=this.tmp.copy(e).project(r);return{gain:a,pan:Pt.clamp(o.x*.8,-1,1)}}play(e,t,n={}){let r=this.ctx;if(!r||this.level===0)return;let i=this.buffers.get(e);if(!i)return;let a=n.gain??1,o=0;if(t){let e=this.place(t,n.ref??110,n.boom);a*=e.gain,o=e.pan}if(a<.005)return;let s=n.group??e,c=this.voices.get(s)??0;if(c>=(n.max??8))return;this.voices.set(s,c+1);let l=r.createBufferSource();l.buffer=i,l.playbackRate.value=(n.rate??1)*(.94+Math.random()*.12);let u=r.createGain();u.gain.value=a;let d=r.createStereoPanner();d.pan.value=o;let f=l;if(n.lowpass){let e=r.createBiquadFilter();e.type=`lowpass`,e.frequency.value=n.lowpass,f.connect(e),f=e}f.connect(u).connect(d).connect(this.sfx),l.onended=()=>this.voices.set(s,Math.max(0,(this.voices.get(s)??1)-1)),l.start(r.currentTime+(n.delay??0))}thump(e,t,n=400,r=!0){let i=this.ctx;if(!i||this.level===0)return;let a=t,o=0;if(e){let t=this.place(e,n,r);a*=t.gain,o=t.pan}if(a<.01)return;let s=i.createOscillator();s.type=`sine`;let c=i.currentTime;s.frequency.setValueAtTime(70,c),s.frequency.exponentialRampToValueAtTime(28,c+.9);let l=i.createGain();l.gain.setValueAtTime(0,c),l.gain.linearRampToValueAtTime(a,c+.02),l.gain.exponentialRampToValueAtTime(.001,c+1.4);let u=i.createStereoPanner();u.pan.value=o,s.connect(l).connect(u).connect(this.sfx),s.start(c),s.stop(c+1.5)}splash(e,t,n=100,r=!1){let i=this.ctx;if(!i||this.level===0)return;let a=this.place(e,n,r),o=t*a.gain;if(o<.01)return;let s=i.createBufferSource();s.buffer=this.noise;let c=i.createBiquadFilter();c.type=`bandpass`,c.Q.value=.9;let l=i.currentTime;c.frequency.setValueAtTime(1800,l),c.frequency.exponentialRampToValueAtTime(400,l+.7);let u=i.createGain();u.gain.setValueAtTime(o,l),u.gain.exponentialRampToValueAtTime(.001,l+.9);let d=i.createStereoPanner();d.pan.value=a.pan,s.connect(c).connect(u).connect(d).connect(this.sfx),s.start(l,Math.random()*2),s.stop(l+1)}ui(e){let t=this.ctx;if(!t||this.level===0)return;let n=t.currentTime,r=(e,r,i,a,o)=>{let s=t.createOscillator();s.type=a,s.frequency.value=e;let c=t.createGain();c.gain.setValueAtTime(0,n+r),c.gain.linearRampToValueAtTime(o,n+r+.008),c.gain.exponentialRampToValueAtTime(8e-4,n+r+i),s.connect(c).connect(this.bus.effects),s.start(n+r),s.stop(n+r+i+.02)};e===`click`?r(1400,0,.05,`sine`,.08):e===`ack`?(r(660,0,.07,`triangle`,.09),r(990,.06,.09,`triangle`,.08)):e===`place`?(r(180,0,.18,`triangle`,.18),r(360,.02,.12,`sine`,.06)):e===`error`?(r(200,0,.12,`square`,.05),r(150,.1,.16,`square`,.05)):e===`ready`&&(r(523,0,.12,`sine`,.09),r(784,.1,.18,`sine`,.09))}posOf(e,t=0){let n=this.world.planet.radius+Math.max(0,t);return new L(e[0],e[1],e[2]).normalize().multiplyScalar(n)}events(e){if(!this.ctx||this.level===0)return;let t=this.world;for(let n of e)switch(n.kind){case`shot`:{let e=n.unit,r=[t.x[e],t.y[e],t.z[e]];if(!this.canHear(r)&&!this.canHear(n.to))break;let i=this.posOf(r,t.elev[e]),a=t.type[e];if(a===W.Tank)this.play(wg([`gun-1`,`gun-2`,`gun-3`,`gun-4`]),i,{rate:.72,gain:.55,lowpass:3200,group:`cannon`,max:8});else if(a===W.Boat&&n.weapon===0)this.play(wg([`gun-1`,`gun-4`]),i,{rate:.5,gain:.85,lowpass:2200,group:`naval`,max:5,ref:150}),this.thump(i,.35,150,!1);else if(a===W.Boat&&n.weapon===2)this.thump(i,.45,150,!1);else if(a===W.Boat)this.play(`gun-5`,i,{rate:1.35,gain:.3,group:`flak`,max:4});else if(a===W.Sub)this.play(`gun-4`,i,{rate:.35,gain:.5,lowpass:900,group:`naval`,max:4}),this.thump(i,.3,120,!1);else if(a===W.HeavyTank)this.play(wg([`gun-1`,`gun-3`]),i,{rate:.58,gain:.7,lowpass:2600,group:`cannon`,max:8});else if(a===W.Artillery)this.play(wg([`gun-1`,`gun-4`]),i,{rate:.42,gain:.9,lowpass:1800,group:`arty`,max:4,ref:250}),this.thump(i,.4,250,!1);else if(a===W.Gunship)this.play(`woosh-1`,i,{rate:1.7,gain:.35,group:`rockets`,max:4});else if(a===W.Bomber)this.play(`woosh-1`,i,{rate:.55,gain:.55,group:`bombs`,max:2,ref:200});else if(a===W.Cruiser&&n.weapon===0)this.play(wg([`gun-1`,`gun-4`]),i,{rate:.4,gain:1,lowpass:1900,group:`naval`,max:5,ref:250}),this.thump(i,.5,250,!1);else if(a===W.Cruiser)this.play(`gun-5`,i,{rate:1.35,gain:.3,group:`flak`,max:4});else if(a===W.SubHunter&&n.weapon===0)this.thump(i,.55,150,!1);else if(a===W.SubHunter)this.play(`gun-4`,i,{rate:.35,gain:.5,lowpass:900,group:`naval`,max:4}),this.thump(i,.3,120,!1);else if(a===W.Drone){let n=this.lastDroneShot.get(e)??-1e9;t.tick-n>=10&&(this.lastDroneShot.set(e,t.tick),this.play(`burst`,i,{rate:1.25,gain:.32,group:`burst`,max:4}))}break}case`struct-shot`:{let e=t.structById(n.struct);if(!e||!this.canHear([e.x,e.y,e.z]))break;if(H[e.type].weapon?.kind===`shell`){let t=this.posOf([e.x,e.y,e.z],8);this.play(wg([`gun-1`,`gun-4`]),t,{rate:.45,gain:.9,lowpass:2e3,group:`naval`,max:5,ref:200}),this.thump(t,.45,200,!1);break}let r=this.lastDroneShot.get(-1-e.id)??-1e9;if(t.tick-r<6)break;this.lastDroneShot.set(-1-e.id,t.tick),this.play(`gun-5`,this.posOf([e.x,e.y,e.z],6),{rate:1.6,gain:.28,group:`flak`,max:4});break}case`proj-impact`:{if(!this.canHear(n.dir))break;let e=this.posOf(n.dir);n.water?this.splash(e,.25+n.splash*.04):this.play(wg([`impact-1`,`impact-2`]),e,{rate:.6,gain:.45,lowpass:2500,group:`impact`,max:6});break}case`destroyed`:{if(n.team!==q.me&&!this.canHear(n.dir))break;let e=this.posOf(n.dir,n.elev??0),t=n.big||n.what===`structure`,r=n.unitType===W.Drone||n.unitType===W.ConDrone||n.unitType===W.AdvConDrone;this.play(wg([`explosion-1`,`explosion-2`,`explosion-3`]),e,{rate:n.big?.55:t?.7:r?1.2:.9,gain:n.big?1:t?.85:r?.45:.7,group:`boom`,max:6,ref:n.big?800:400,boom:!0}),(t||n.unitType===W.Boat||n.unitType===W.ConShip||n.unitType===W.AdvConShip)&&this.thump(e,n.big?.9:.5,n.big?800:400),n.sink&&this.splash(e,.5,400,!0);break}case`meteor-impact`:{if(!yf(t,q.me,n.team,n.dir))break;let e=this.posOf(n.dir);this.play(wg([`explosion-1`,`explosion-2`,`explosion-3`]),e,{rate:.5,gain:1,lowpass:1800,group:`meteor`,max:3,ref:1200,boom:!0}),this.thump(e,1,1200),n.land||this.splash(e,.8,1200,!0);break}case`emp`:{let e=this.posOf(n.dir,6);this.thump(e,.8,500),this.play(`gun-5`,e,{rate:.5,gain:.5,lowpass:3e3,group:`emp`,max:2,ref:500,boom:!0});break}case`nuke-launch`:{let e=t.structById(n.struct);if(!e)break;let r=this.posOf([e.x,e.y,e.z],10);this.play(`explosion-3`,r,{rate:.32,gain:1,lowpass:1200,group:`horizon`,max:2,ref:1200,boom:!0}),this.play(`woosh-1`,r,{rate:.4,gain:.8,delay:.2,group:`horizon-w`,max:2,ref:600}),this.ui(`error`);break}case`nuke-stopped`:{let e=this.posOf(n.dir,180);this.play(`explosion-2`,e,{rate:.8,gain:.8,group:`hshell`,max:3,ref:1e3,boom:!0});break}case`shell-impact`:{let e=this.posOf(n.dir);n.nuke&&(this.play(`explosion-1`,e,{rate:.3,gain:1,lowpass:900,group:`nuke`,max:2,ref:3e3,boom:!0}),this.thump(e,1,3e3)),this.play(wg([`explosion-1`,`explosion-2`]),e,{rate:.6,gain:1,lowpass:2200,group:`hshell`,max:3,ref:1e3,boom:!0}),this.thump(e,1,1e3);break}case`horizon-launch`:{let e=t.structById(n.struct);if(!e)break;let r=this.posOf([e.x,e.y,e.z],10);this.play(`explosion-3`,r,{rate:.42,gain:1,lowpass:1500,group:`horizon`,max:2,ref:1e3,boom:!0}),this.thump(r,1,1e3),this.play(`woosh-1`,r,{rate:.6,gain:.6,delay:.15,group:`horizon-w`,max:2,ref:300});break}case`built`:{let e=t.structById(n.struct);e&&e.team===q.me&&this.ui(`ready`);break}case`unit-built`:t.team[n.unit]===q.me&&this.ui(`ready`)}}updateMusic(e){let t=this.ctx;if(!this.music){if(!e||this.levels.music===0)return;let n=new Audio(`./sounds/zarathustra.mp3`);n.preload=`auto`;let r=t.createGain();r.gain.value=0,t.createMediaElementSource(n).connect(r).connect(this.bus.music),this.music={el:n,gain:r,quietSince:-1,endedAt:-1},n.addEventListener(`ended`,()=>{this.music&&(this.music.endedAt=t.currentTime)})}let n=this.music,r=e&&this.levels.music>0;if(r&&n.el.paused){let e=n.endedAt>=0;(!e||t.currentTime-n.endedAt>Cg)&&((e||n.quietSince>=0&&t.currentTime-n.quietSince>Cg)&&(n.el.currentTime=0),n.endedAt=-1,n.el.play().catch(()=>{}))}n.gain.gain.setTargetAtTime(+!!r,t.currentTime,r?1.5:.8),r?n.quietSince=-1:n.quietSince<0&&(n.quietSince=t.currentTime),!r&&!n.el.paused&&t.currentTime-n.quietSince>4&&n.el.pause()}update(e,t,n,r=!1){this.camera=e;let i=this.ctx;if(!i)return;let a=this.world,o=i.currentTime,s=a.planet.radius;this.updateMusic(r);let c=Math.max(0,n),l=1-_g(c);this.ocean&&(this.ocean.gain.gain.setTargetAtTime(.3*gg(c,35)*l,o,.4),this.ocean.filter.Q.value=.3),this.wind&&this.wind.gain.gain.setTargetAtTime(.14*gg(c,50)*l*(.4+a.wind()),o,.6);let u=new Map,d=new L;for(let e=0;e<a.count;e++){if(!a.alive[e]||!a.hasOrder[e]||a.team[e]!==q.me&&!this.canHear([a.x[e],a.y[e],a.z[e]]))continue;let t=a.type[e],n=G[t].layer,r=n===B.Air?`drone`:n===B.Sea?`ship`:t===W.Commander?`commander`:`tracks`;d.set(a.x[e],a.y[e],a.z[e]).multiplyScalar(s+Math.max(0,a.elev[e]));let i=this.place(d,90);if(i.gain<=0)continue;let o=u.get(r)??{sum:0,pan:0};o.sum+=i.gain,o.pan+=i.pan*i.gain,u.set(r,o)}for(let[e,t]of Object.entries({tracks:[46,520,.25,6,.32],commander:[38,420,.3,4,.4],ship:[32,300,.4,2.2,.38],drone:[118,2400,.12,13,.16]})){let n=u.get(e);if(!n&&!this.engines.has(e))continue;let r=this.engine(e,t[0],t[1],t[2],t[3]),i=n?Math.min(1,Math.sqrt(n.sum))*t[4]:0;r.gain.gain.setTargetAtTime(i,o,.25),n&&n.sum>0&&r.pan.pan.setTargetAtTime(Pt.clamp(n.pan/n.sum,-.8,.8),o,.3);let a=1+Math.min(.25,(n?.sum??0)*.04);for(let e of r.osc)e.detune.setTargetAtTime((a-1)*1200,o,.5)}let f=0;for(let e=0;e<a.count;e++){if(!a.alive[e]||a.buildTask[e]<0||a.hasOrder[e]||a.team[e]!==q.me)continue;let t=a.structById(a.buildTask[e]);t&&t.complete&&t.prod.length===0||(d.set(a.x[e],a.y[e],a.z[e]).multiplyScalar(s),f+=this.place(d,70).gain)}if(this.hum&&this.hum.gain.gain.setTargetAtTime(Math.min(1,f)*.035,o,.3),this.lastFactoryClank-=t,this.lastFactoryClank<=0){this.lastFactoryClank=.35+Math.random()*.5;for(let e of a.structures)e.alive&&e.complete&&e.prod.length&&(e.team===q.me||this.canHear([e.x,e.y,e.z]))&&Jd[e.type]&&(Math.random()>.5||(d.set(e.x,e.y,e.z).multiplyScalar(s),this.play(wg([`impact-1`,`impact-2`]),d,{rate:.35+Math.random()*.25,gain:.25,lowpass:1400,group:`factory`,max:3,ref:80})))}}},Eg=[`conifer`,`broadleaf`,`palm`,`shrub`,`rock`];function Dg(e,t){let n=e.index?e.toNonIndexed():e,r=new R(t),i=n.attributes.position.count,a=new Float32Array(i*3);for(let e=0;e<i;e++)a[e*3]=r.r,a[e*3+1]=r.g,a[e*3+2]=r.b;return n.setAttribute(`color`,new xr(a,3)),n.deleteAttribute(`uv`),n}function Og(e,t,n,r=7){let i=new ea(e,t,r);return i.translate(0,n+t/2,0),i}function kg(e,t,n,r=5,i=e){let a=new $i(i,e,t,r);return a.translate(0,n+t/2,0),a}function Ag(e,t,n,r){let i=new bo(e,0);return i.translate(t,n,r),i}function jg(e){let t=5914672;switch(e){case`conifer`:return qm([Dg(kg(.05,.25,0),t),Dg(Og(.34,.45,.15),3894835),Dg(Og(.27,.38,.4),4422200),Dg(Og(.18,.32,.64),4949310)]);case`broadleaf`:return qm([Dg(kg(.05,.45,0,5,.035),t),Dg(Ag(.3,0,.62,0),6066232),Dg(Ag(.22,.17,.5,.08),5539382),Dg(Ag(.2,-.15,.55,-.1),6789439)]);case`palm`:{let e=[Dg(kg(.035,.5,0,5,.025),9071176),Dg(kg(.028,.45,.48,5,.022).translate(.05,0,0),9071176)];for(let t=0;t<6;t++){let n=new ea(.07,.5,3);n.rotateZ(-Math.PI/2-.35),n.translate(.25,.9,0),n.rotateY(t/6*Math.PI*2),e.push(Dg(n,t%2?5212724:5937722))}return qm(e)}case`shrub`:return qm([Dg(Ag(.5,0,.35,0),6261306),Dg(Ag(.35,.3,.25,.15),7246914)]);case`rock`:{let e=new bo(.5,1),t=e.attributes.position;for(let e=0;e<t.count;e++){let n=t.getX(e),r=t.getY(e),i=t.getZ(e),a=.75+.5*Math.abs(Math.sin(n*9.1+r*7.3)*Math.cos(i*8.7-n*3.1));t.setXYZ(e,n*a,Math.max(-.1,r*a*.7)+.12,i*a)}return e.computeVertexNormals(),Dg(e,9078140)}}}function Mg(e){let t=e>>>0;return()=>{t=t+1831565813>>>0;let e=t;return e=Math.imul(e^e>>>15,e|1),e^=e+Math.imul(e^e>>>7,e|61),((e^e>>>14)>>>0)/4294967296}}var Ng=class{world;group=new Pn;chunks=[];sig=``;count=0;constructor(e,t,n=1){this.world=e;let r=e.planet,i=r.radius,a=Mg(r.params.seed*7919+17),o=r.params.seed,s=r.N,c=s/32,l=new Map,u=(e,t,n)=>{let r=l.get(e);r||(r=new Map,l.set(e,r));let i=r.get(t);i||(i=[],r.set(t,i)),i.push(...n)},d=new L,f=new L,p=new L,m=new L,h=e=>r.heightAt(e.x,e.y,e.z);for(let e=0;e<r.cellCount;e++){if(!r.land[e])continue;let t=Math.floor(e/(s*s)),l=e%(s*s),g=Math.floor(l/s),_=l%s,v=t*c*c+Math.floor(g/32)*c+Math.floor(_/32);d.set(r.cx[e],r.cy[e],r.cz[e]),f.set(-d.z,0,d.x),f.lengthSq()<1e-8&&f.set(1,0,0),f.normalize(),p.crossVectors(d,f);let y=Math.round(9*n);for(let e=0;e<y;e++){let e=(a()-.5)*12,t=(a()-.5)*12;m.copy(d).addScaledVector(f,e/i).addScaledVector(p,t/i).normalize();let n=h(m);if(n<=.012)continue;let s=2/i;f.clone();let c=r.heightAt(m.x+f.x*s,m.y+f.y*s,m.z+f.z*s)-n,l=r.heightAt(m.x+p.x*s,m.y+p.y*s,m.z+p.z*s)-n,g=Math.hypot(c,l)*45/2,_=ud(m.x*9,m.y*9,m.z*9,o+501,3),y=a(),b=i+n*45,x=(e,t,n=.15)=>{let r=t*(.75+a()*.5);u(v,e,[m.x,m.y,m.z,b-n*r,r,a()*Math.PI*2,.85+a()*.3])};if(n<.045)y<.22?x(`palm`,9):y<.27&&x(`rock`,2.5,.3);else if(g>.55||n>.72)y<.05?x(`rock`,5+a()*4,.35):y<.13?x(`rock`,1.6+a()*2.2,.3):y<.16&&n<.8&&x(`conifer`,8);else{let e=_>.55,t=_>.5,r=n>.32||_>.68;e&&y<.3?x(r?`conifer`:`broadleaf`,r?11:9):t&&y<.1?x(r?`conifer`:`broadleaf`,9):!t&&y<.025?x(a()<.6?`broadleaf`:`conifer`,9):y<.1?x(`shrub`,2.2,.25):y<.115&&x(`rock`,1.6+a()*2,.3)}}}let g=new Map;for(let e of Eg){let n=new Io({vertexColors:!0,roughness:e===`rock`?.95:.85,metalness:0,flatShading:e!==`rock`,emissive:e===`rock`?0:858632});lh(n,t,e===`rock`?0:e===`shrub`?.25:1),g.set(e,n)}let _=new Map(Eg.map(e=>[e,jg(e)])),v=Mg(o*31+5),y=new on,b=new Ft,x=new Ft,S=new L,C=new L(0,1,0),w=new R;for(let[,e]of l)for(let[t,n]of e){let e=n.length/7,r=new vi(_.get(t),g.get(t),e),i=new Float32Array(e*3),a=new Float32Array(e),o=new Float32Array(e*16);for(let s=0;s<e;s++){let[e,c,l,u,f,p,h]=n.slice(s*7,s*7+7);d.set(e,c,l),b.setFromUnitVectors(C,d),x.setFromAxisAngle(C,p),b.multiply(x),m.copy(d).multiplyScalar(u),y.compose(m,b,S.set(f,f*(t===`rock`?.8+h*.3:1),f)),r.setMatrixAt(s,y),y.toArray(o,s*16),i[s*3]=e,i[s*3+1]=c,i[s*3+2]=l,a[s]=f;let g=v()-.5;t===`rock`?w.setRGB(h*(1+g*.12),h,h*(1-g*.12)):w.setRGB(h*(1+g*.35),h*(1+Math.abs(g)*.08),h*(1-g*.3)),r.setColorAt(s,w)}r.computeBoundingSphere(),r.castShadow=!1,this.group.add(r),this.chunks.push({mesh:r,pos:i,scale:a,mats:o,hidden:new Uint8Array(e)}),this.count+=e}}update(e){this.group.visible=e<2600;let t=this.world,n=0,r=0;for(let e of t.structures)e.alive&&n++;for(let e of t.wrecks)e.alive&&r++;let i=`${t.nextId}/${n}/${r}`;if(i===this.sig)return;this.sig=i;let a=t.planet.radius,o=[];for(let e of t.structures)e.alive&&o.push([e.x,e.y,e.z,(H[e.type].radius+2)/a]);for(let e of t.wrecks)e.alive&&o.push([e.x,e.y,e.z,(e.radius+1)/a]);let s=new on().makeScale(0,0,0),c=new on;for(let e of this.chunks){let t=e.mesh.boundingSphere,n=!1;for(let[e,r,i,s]of o){let o=e*a-t.center.x,c=r*a-t.center.y,l=i*a-t.center.z;if(Math.sqrt(o*o+c*c+l*l)<t.radius+s*a+5){n=!0;break}}let r=!1;for(let t=0;t<e.hidden.length;t++){let i=0;if(n){let n=e.pos[t*3],r=e.pos[t*3+1],a=e.pos[t*3+2];for(let[e,t,s,c]of o){let o=n-e,l=r-t,u=a-s;if(o*o+l*l+u*u<c*c){i=1;break}}}i!==e.hidden[t]&&(e.hidden[t]=i,e.mesh.setMatrixAt(t,i?s:c.fromArray(e.mats,t*16)),r=!0)}r&&(e.mesh.instanceMatrix.needsUpdate=!0)}}},Pg=[4033535,16734781,4063115,16765501];function Fg(e){return Lg(e,(e,t)=>{let n=new oi(tg(e),t);return rg(e,n,t,{}),n})}function Ig(e){return Lg(e,(e,t)=>new oi(zh(e),t))}function Lg(e,t){let n=new Map,r;try{r=new od({antialias:!0,alpha:!0,preserveDrawingBuffer:!0})}catch{return n}r.setPixelRatio(2),r.setSize(112,76,!1),r.outputColorSpace=Be;let i=new Hn;i.add(new ss(14675967,4210736,1.6));let a=new ws(16777215,2.2);a.position.set(-.6,1,.8),i.add(a);let o=new ys(30,112/76,.1,1e3);for(let a of e){let e=new Io({color:16777215,roughness:.62,metalness:.06});Fh(e,{value:new R(Pg[q.me])});let s=t(a,e);i.add(s);let c=new rr().setFromObject(s).getBoundingSphere(new Or),l=c.radius/Math.sin(Pt.degToRad(15))*.92,u=new L(-.55,.55,1).normalize();o.position.copy(c.center).addScaledVector(u,l),o.lookAt(c.center),r.render(i,o),n.set(a,r.domElement.toDataURL(`image/png`)),i.remove(s),s.geometry.dispose(),e.dispose()}return r.dispose(),r.forceContextLoss(),n}var Rg=[`#3d8bff`,`#ff5a3d`,`#3dff8b`,`#ffd23d`],zg=[{name:`Economy`,types:[V.Solar,V.Wind,V.Tidal,V.MetalMine,V.Converter,V.Storage]},{name:`Base & military`,types:[V.AaGun,V.Horizon,V.Anvil,V.VehiclePlant,V.Shipyard,V.DronePad]},{name:`Sensors`,types:[V.Radar,V.SonarBuoy]},{name:`Advanced (T2)`,types:[V.AdvVehiclePlant,V.AdvShipyard,V.AdvDronePad,V.Fission,V.AdvMine,V.HeavyTower]},{name:`Late T2`,types:[V.Fusion,V.LaunchComplex,V.PointDefence]}],Bg=3,Vg=e=>Math.abs(e)>=1e4?`${(e/1e3).toFixed(1)}k`:Math.round(e).toLocaleString(`en-US`),Hg=e=>e>=1e3?`${(e/1e3).toFixed(e<1e4&&e%1e3?1:0)}k`:String(Math.round(e)),Ug=e=>e>=100?e.toFixed(0):e.toFixed(1),Wg=class{world;res=document.getElementById(`resbar`);build=document.getElementById(`buildpanel`);info=document.getElementById(`info`);side=document.getElementById(`side`);toasts=document.getElementById(`toasts`);overlay=document.getElementById(`overlay`);buttons=new Map;factoryPanel=document.getElementById(`factorypanel`);factoryShown=``;activeBuild=null;page=0;iconsDone=!1;pageLabel;tabs=[];grid;onQueue=()=>{};onStop=()=>{};onStance=()=>{};onPatrol=()=>{};onReclaimStruct=()=>{};onDestroy=()=>{};cmdPanel=document.getElementById(`cmdpanel`);cmdStop=document.getElementById(`cmd-stop`);cmdStance=[`cmd-normal`,`cmd-passive`,`cmd-aggressive`].map(e=>document.getElementById(e));cmdPatrol=document.getElementById(`cmd-patrol`);cmdReclaim=document.getElementById(`cmd-reclaim`);cmdDestroy=document.getElementById(`cmd-destroy`);constructor(e,t){this.world=e,this.cmdStop.addEventListener(`click`,()=>this.onStop()),this.cmdStance.forEach((e,t)=>e.addEventListener(`click`,()=>this.onStance(t))),this.cmdPatrol.addEventListener(`click`,()=>this.onPatrol()),this.cmdReclaim.addEventListener(`click`,()=>this.onReclaimStruct()),this.cmdDestroy.addEventListener(`click`,()=>this.onDestroy());let n=document.createElement(`div`);n.className=`bphead`,zg.forEach((e,t)=>{let r=document.createElement(`button`);r.textContent=`${t+1} · ${e.name}`,r.title=`Tab: next page`,r.addEventListener(`click`,()=>this.showPage(t)),this.tabs.push(r),n.append(r)}),this.pageLabel=document.createElement(`span`),n.append(this.pageLabel),this.grid=document.createElement(`div`),this.grid.className=`bpgrid`,this.build.append(n,this.grid);for(let e of zg)e.types.forEach((e,n)=>{let r=H[e],i=document.createElement(`button`);i.className=`buildbtn`,i.title=`${r.name}: ${this.describe(e)}`,i.innerHTML=`<span class="pic"></span><span class="key">${n+1}</span><b>${r.name}</b><span class="cost">${Hg(r.metal)} M · ${Hg(r.energy)} E</span><span class="out">${this.describe(e)}</span>`,i.addEventListener(`click`,()=>{this.locked.has(e)?this.toast(this.lockedWhy(e)):t(e)}),i.addEventListener(`mouseenter`,()=>{this.hover={kind:`s`,t:e}}),i.addEventListener(`mouseleave`,()=>{this.hover=null}),this.buttons.set(e,i)});this.showPage(0)}factoryOpen=null;unitIcon(e){return this.portrait(e)}factoryKey(e,t){let n=this.factoryOpen,r=/^Digit([1-9])$/.exec(e);if(!n||!r)return!1;let i=n.units[Number(r[1])-1];if(i===void 0)return!1;for(let e=t?5:1;e>0;e--)this.onQueue(n.structId,i,1);return!0}buildKey(e){let t=/^Digit([1-9])$/.exec(e);if(!t)return null;let n=zg[this.page].types[Number(t[1])-1]??null;return n!==null&&this.locked.has(n)?(this.toast(this.lockedWhy(n)),null):n}get buildMenuOpen(){return this.build.style.display===`flex`}pageCount(){return this.showT2?zg.length:Bg}showT2=!1;locked=new Set;lockedWhy(e){let t=H[e];return Xd(this.world.teams[q.me],t)?this.world.techLimit<2&&t.tier===2?`${t.name}: T2 is off in this game`:t.t1Builds?`${t.name}: select a construction vehicle, ship or drone (not the Commander)`:`${t.name}: needs an advanced (T2) builder`:`${t.name}: ${zd[t.faction].name} only`}flipPage(e){let t=this.pageCount();this.showPage((this.page+e+t)%t)}showPage(e){this.page=e,this.grid.replaceChildren(...zg[e].types.map(e=>this.buttons.get(e))),this.pageLabel.textContent=`${e+1}/${this.pageCount()} · Tab`,this.tabs.forEach((t,n)=>{t.style.display=n<this.pageCount()?``:`none`,t.classList.toggle(`on`,n===e)})}ensureIcons(){if(this.iconsDone)return;this.iconsDone=!0;let e=Fg(zg.flatMap(e=>e.types));this.structIcons=e;for(let[t,n]of e){let e=this.buttons.get(t)?.querySelector(`.pic`);e&&(e.style.backgroundImage=`url(${n})`)}}structIcons=new Map;portraits=new Map;portrait(e){return this.portraits.has(e)||this.preparePortraits([e]),this.portraits.get(e)}preparePortraits(e){let t=e.filter(e=>!this.portraits.has(e));if(!t.length)return;let n=Ig(t);for(let e of t)this.portraits.set(e,n.get(e))}hover=null;details=document.getElementById(`details`);detailsKey=``;updateDetails(e){let t=this.hover??(this.activeBuild===null?null:{kind:`s`,t:this.activeBuild});if(!e||!t){this.details.style.display=`none`,this.detailsKey=``;return}this.details.style.display=`block`;let n=`${t.kind}${t.t}`;if(n===this.detailsKey)return;this.detailsKey=n;let r=(e,t)=>`<tr><td>${e}</td><td>${t}</td></tr>`,i=e=>e.map(e=>{let t=[e.land&&`land`,e.sea&&`ships`,e.sub&&`submarines`,e.air&&`air`].filter(Boolean).join(`, `),n=e.emp?` · single use: units within ${Cd.radius} stop for ${Cd.seconds} s (yours too), aircraft fall, Commanders only slowed · only on attack orders`:e.orderOnly?` · ${e.salvo} bombs per pass, only on attack orders`:``;return r(e.name,`range ${e.range} · ${e.damage} dmg every ${e.reload} s (${Math.round(e.damage/e.reload)}/s) · hits ${t}${n}`)}).join(``),a=``;if(t.kind===`s`){let e=H[t.t];a=`<b>${e.name}</b><table>`+r(`Cost`,`${Vg(e.metal)} metal · ${Vg(e.energy)} energy`)+r(`Build time`,e.tier===2&&!e.t1Builds?`${Math.round(e.buildTime/G[W.AdvBuilder].buildPower)} s by an advanced construction vehicle`:`${e.tier===2?``:`${Math.round(e.buildTime/Nd.buildPower)} s by the Commander · `}${Math.round(e.buildTime/Dd.buildPower)} s by a construction vehicle`)+r(`Health`,Vg(e.hp))+r(`Size`,`radius ${e.radius}`)+r(`Sight`,String(e.sight))+(e.radar?r(`Radar`,String(e.radar)):``)+(e.sonar?r(`Sonar`,String(e.sonar)):``)+(e.weapon?i([e.weapon]):``)+r(`Does`,this.describe(t.t))+`</table>`}else{let e=G[t.t],n=e.layer===B.Land?`land`:e.layer===B.Air?`air (altitude ${e.altitude})`:e.submerged?`submerged`:`sea`;a=`<b>${e.name}</b><table>`+r(`Cost`,`${Vg(e.metal)} metal · ${Vg(e.energy)} energy`)+r(`Build time`,`${Math.round(e.buildTime/Gg(t.t))} s by the factory alone`)+r(`Health`,Vg(e.hp))+r(`Moves`,`${n} · speed ${e.speed}`)+r(`Sight`,String(e.sight))+(e.radar?r(`Radar`,String(e.radar)):``)+(e.sonar?r(`Sonar`,String(e.sonar)):``)+(e.buildPower?r(`Builds`,`build power ${e.buildPower} · builds and reclaims`):``)+(e.capacity?r(`Carries`,`${e.capacity} land units (${e.carriesCommander?`including`:`not`} the Commander)`):``)+(e.weapons.some(t=>t.range>e.sight)?r(`Aims`,`fires at what your team sees or has on radar`):``)+i(e.weapons)+(e.weapons.length||e.buildPower||e.capacity?``:r(`Weapons`,`none`))+`</table>`}this.details.innerHTML=a}describe(e){let t=H[e];return e===V.Solar?`up to +${Math.round(t.energyOut*Hd.solarPeak)} energy/s by day, none at night`:e===V.Wind?`+0–${t.energyOut} energy/s (wind)`:e===V.MetalMine?`on a meteor site · metal/s`:e===V.Storage?`+${Vg(t.metalStore)} M / +${Vg(t.energyStore)} E storage · land or sea`:e===V.Horizon?`orbital artillery · AGI`:e===V.Anvil?`orbital strike: a rod anywhere in sight or on radar · ${bd.reload} s reload · MAN`:e===V.Fusion?`+${t.energyOut} energy/s · a huge blast when destroyed`:e===V.LaunchComplex?`makes satellites (orbital radar) and nuclear missiles; launches the missiles`:e===V.PointDefence?`may shoot down a nuclear missile landing within ${Sd.defenceReach} (${Math.round(Sd.stopChance*100)}% each)`:e===V.Radar?`radar ${t.radar} · −${t.energyUpkeep} energy/s`:e===V.VehiclePlant?`tanks · construction vehicles`:e===V.Shipyard?`destroyers · at the coast`:e===V.DronePad?`attack drones`:e===V.Converter?`${Td.energyIn} energy/s → ${Td.metalOut} metal/s (store above ${Td.minStore*100}%)`:e===V.SonarBuoy?`sonar ${t.sonar}: finds submarines · anywhere at sea`:e===V.Tidal?`+${t.energyOut} energy/s · anywhere in the ocean`:e===V.AaGun?`anti-air · range ${t.weapon.range}`:e===V.AdvVehiclePlant?`advanced construction vehicles`:e===V.AdvShipyard?`advanced construction ships · at the coast`:e===V.AdvDronePad?`advanced construction drones`:e===V.Fission?`+${t.energyOut} energy/s day and night · explodes when destroyed`:e===V.AdvMine?`${t.metalOut}× metal of a site · −${t.energyUpkeep} energy/s · upgrades a mine`:e===V.HeavyTower?`land & sea · range ${t.weapon.range}`:``}updateCmdPanel(e,t){let n=this.world,r=[...e].filter(e=>n.alive[e]&&n.team[e]===q.me),i=t>=0?n.structById(t):void 0,a=!!i&&i.alive&&i.team===q.me,o=a&&(i.type===V.Horizon||i.type===V.Anvil)&&i.complete;if(!r.length&&!a){this.cmdPanel.style.display=`none`;return}this.cmdPanel.style.display=`flex`,this.cmdStop.style.display=r.length||o?``:`none`,this.cmdStop.querySelector(`b`).textContent=r.length?`Stop`:`Cancel shot`,this.cmdStop.querySelector(`.cost`).textContent=r.length?`cancel orders`:`the shot waits`;let s=r.filter(e=>G[n.type[e]].weapons.length>0),c=e=>n.holdFire[e]?1:n.aggressive[e]?2:0;this.cmdStance.forEach((e,t)=>{e.style.display=s.length?``:`none`;let n=s.filter(e=>c(e)===t).length;e.classList.toggle(`on`,n===s.length&&n>0),e.querySelector(`.cost`).textContent=n&&n<s.length?`${n}/${s.length} units`:[`fire at will`,`hold fire`,`chase what it sees`][t]}),this.cmdPatrol.style.display=s.length?``:`none`,this.cmdReclaim.style.display=r.some(e=>qd(n.type[e]))?``:`none`,this.cmdDestroy.style.display=a&&!r.length?``:`none`}updateFactoryPanel(e){let t=this.world,n=e>=0?t.structById(e):void 0,r=n&&n.alive&&n.team===q.me?Jd[n.type]?.filter(e=>Xd(t.teams[q.me],G[e])):void 0;if(!n||!r){this.factoryPanel.style.display=`none`,this.factoryShown=``,this.factoryOpen=null;return}this.factoryPanel.style.display=`flex`,this.factoryOpen={structId:n.id,units:r};let i=`${n.id}`;if(i!==this.factoryShown){this.factoryShown=i,this.factoryPanel.innerHTML=`<div class="bphead"><span>Build · click +1, Shift +5, right-click −1</span></div>`;let e=document.createElement(`div`);e.className=`bpgrid`,this.factoryPanel.appendChild(e),this.preparePortraits(r),r.forEach((t,r)=>{let i=G[t],a=document.createElement(`button`);a.className=`buildbtn`,a.dataset.unit=String(t);let o=i.buildPower?`builds and reclaims`:i.weapons.map(e=>e.name.toLowerCase()).join(` + `);a.title=`${i.name}: ${o}`,a.innerHTML=`<span class="pic"></span><span class="count"></span><span class="key">${r+1}</span><b>${i.name}</b><span class="cost">${Hg(i.metal)} M · ${Hg(i.energy)} E · ${Math.round(i.buildTime/Dd.buildPower)} s</span><span class="prog"></span>`;let s=this.unitIcon(t);s&&(a.querySelector(`.pic`).style.backgroundImage=`url(${s})`),a.addEventListener(`click`,e=>{for(let r=e.shiftKey?5:1;r>0;r--)this.onQueue(n.id,t,1)}),a.addEventListener(`contextmenu`,e=>{e.preventDefault(),this.onQueue(n.id,t,-1)}),a.addEventListener(`mouseenter`,()=>{this.hover={kind:`u`,t}}),a.addEventListener(`mouseleave`,()=>{this.hover=null}),e.appendChild(a)})}for(let e of this.factoryPanel.querySelectorAll(`.buildbtn`)){let t=Number(e.dataset.unit),r=n.prod.filter(e=>e===t).length,i=e.querySelector(`.count`);i.style.display=r?`flex`:`none`,i.textContent=String(r),e.querySelector(`.prog`).style.width=n.prod[0]===t&&n.complete?`${Math.round(n.prodProgress*100)}%`:`0`,e.disabled=!n.complete}}setOverlay(e){this.overlay.style.display=e?`block`:`none`,e&&(this.overlay.innerHTML=e)}overlayShown(){return this.overlay.style.display!==`none`}toast(e,t=`info`){let n=document.createElement(`div`);n.className=`toast${t===`bad`?` bad`:``}`,n.textContent=e;for(let e of Array.from(this.toasts.children))e.classList.add(`old`);for(this.toasts.prepend(n),setTimeout(()=>n.classList.add(`fade`),6e3),setTimeout(()=>n.remove(),6700);this.toasts.children.length>5;)this.toasts.lastChild.remove()}topbar=document.getElementById(`topbar`);players=document.getElementById(`players`);deckHint=document.getElementById(`deckhint`);playersKey=``;resShown=``;cardShown=``;update(e,t,n=-1){let r=this.world,i=r.teams[q.me];if(document.body.classList.toggle(`ingame`,i.started),!i.started){this.topbar.style.display=`none`,this.build.style.display=`none`,this.side.style.display=`none`;return}this.topbar.style.display=`flex`,this.side.style.display=`flex`;let a=(e,t)=>`<svg viewBox="0 0 40 40" width="38" height="38" aria-hidden="true"><circle cx="20" cy="20" r="16" fill="none" stroke="#0f2c33" stroke-width="4"/><circle cx="20" cy="20" r="16" fill="none" stroke="${t}" stroke-width="4" stroke-dasharray="${(Math.max(0,Math.min(1,e))*100.5).toFixed(1)} 101" transform="rotate(-90 20 20)"/></svg>`,o=(e,t,n,r,i,o,s)=>`<div class="res ${t}">${a(r/Math.max(1,i),n)}<div class="col"><span class="lbl">${e}</span><span class="num">${Vg(r)} <small>/ ${Vg(i)}</small></span><span class="rates"><span class="inc">+${Ug(o)}</span><span class="exp">−${Ug(s)}</span></span></div></div>`,s=o(`METAL`,`metal`,`#dfe6ee`,i.metal,i.metalCap,i.metalIn,i.metalOut)+o(`ENERGY`,`energy`,`#3ff0d8`,i.energy,i.energyCap,i.energyIn,i.energyOut)+`<div class="res wind"><div class="col"><span class="lbl">WIND</span><span class="num">${Math.round(r.wind()*100)}%</span></div></div>`+(i.stall?`<div class="stall">Not enough ${i.short??`resources`} — building slowed, builders wait</div>`:``)+(i.lost?`<div class="stall">Commander lost</div>`:``);s!==this.resShown&&(this.resShown=s,this.res.innerHTML=s);let c=r.teams.map(e=>e.started?e.lost?`x`:`o`:`-`).join(``);c!==this.playersKey&&(this.playersKey=c,this.players.innerHTML=r.teams.map((e,t)=>e.started?`<span style="${e.lost?`opacity:0.4;text-decoration:line-through`:``}"><i style="color:${Rg[t]}">◆</i> ${t===q.me?`You${e.faction?` · ${zd[e.faction].name}`:``}`:Ld[t].split(` (`)[0]}</span>`:``).join(``));let l=[...e].some(e=>qd(r.type[e])&&r.alive[e]);if(this.build.style.display=l?`flex`:`none`,l){this.ensureIcons();let t=new Set;for(let n of e)r.alive[n]&&qd(r.type[n])&&t.add(r.type[n]);let n=[...t].some(e=>e!==W.Commander);n!==this.showT2&&(this.showT2=n,this.page>=this.pageCount()&&(this.page=0),this.showPage(this.page));for(let[e,n]of this.buttons){let i=!Xd(r.teams[q.me],H[e])||![...t].some(t=>Yd(t,e))||r.techLimit<2&&H[e].tier===2;i!==this.locked.has(e)&&(i?this.locked.add(e):this.locked.delete(e),n.classList.toggle(`locked`,i),n.title=i?this.lockedWhy(e):`${H[e].name}: ${this.describe(e)}`)}}this.updateFactoryPanel(t),this.updateCmdPanel(e,t),this.deckHint.style.display=l||this.factoryOpen?`none`:`flex`;for(let[e,t]of this.buttons)t.classList.toggle(`active`,this.activeBuild===e);this.updateDetails(l||this.factoryOpen!==null),this.info.style.display=`flex`;let u=this.cardHtml(e,t,n);u!==this.cardShown&&(this.cardShown=u,this.info.innerHTML=u)}cardHtml(e,t,n){let r=this.world,i=e=>{let t=e.max?Math.max(0,Math.min(1,(e.hp??0)/e.max)):-1;return`<div class="portrait${e.pic?``:` empty`}"${e.pic?` style="background-image:url(${e.pic})"`:``}></div><div class="txt"><span class="kick">${e.kick}</span><span class="name">${e.name}</span>`+(t>=0?`<div class="row"><span>Health</span><b>${Math.round(e.hp)} / ${Math.round(e.max)}</b></div><div class="bar"><i style="width:${(t*100).toFixed(1)}%;${t<.35?`background:#ff6a5a`:``}"></i></div>`:``)+(e.prog?`<div class="row"><span>${e.prog[0]}</span><b>${Math.round(e.prog[1]*100)}%</b></div><div class="bar prog"><i style="width:${(Math.max(0,Math.min(1,e.prog[1]))*100).toFixed(1)}%"></i></div>`:``)+(e.lines?`<div class="more">${e.lines}</div>`:``)+`</div>`},a=t>=0?r.structById(t):void 0;if(a&&a.alive){let e=H[a.type];this.ensureIcons();let t=this.structIcons.get(a.type),n=a.team===q.me,o=``,s;if(!a.complete){let e=Array.from({length:r.count},(e,t)=>t).some(e=>r.alive[e]&&r.buildTask[e]===a.id),t=!e&&Array.from({length:r.count},(e,t)=>t).some(e=>r.alive[e]&&(r.buildQueue[e]??[]).includes(a.id)),n=t?`Waiting in queue`:`Abandoned`;s=[`Built`,a.progress],!e&&t&&a.progress<=1e-9?o+=`Queued — waits for its turn`:o+=e?r.teams[a.team].stall?`Waiting for ${r.teams[a.team].short??`resources`}`:`Being built`:a.idleTicks>Md.grace*20?`<span class="warn">${n} — decaying, resources returned</span>`:`<span class="warn">${n} — decays soon</span>`,e||(o+=`<br>Select the Commander and right-click it to resume`)}else if(a.type===V.Horizon||a.type===V.Anvil){let e=a.type===V.Anvil,t=e?bd:Id;o+=`${a.target?a.reload>0?`Target set — fires after reloading (${Math.ceil(a.reload/20)} s)`:e?`Firing…`:`Turning to the target…`:a.reload>0?`Reloading ${Math.ceil(a.reload/20)} s`:`Ready — right-click a target`}`,o+=`<br><small>Right-click a target in sight or on radar: one ${e?`strike`:`shot`} per order · ${Vg(t.shotEnergy)} energy each · ${t.reload} s reload</small>`}else if((a.type===V.MetalMine||a.type===V.AdvMine)&&a.site>=0)o+=`${(H[a.type].metalOut??1)*r.sites[a.site].richness} metal/s (site richness ${r.sites[a.site].richness})`;else if(a.type===V.Wind)o+=`Output ${(e.energyOut*r.wind()).toFixed(1)} energy/s`;else if(a.type===V.Radar)o+=r.teams[a.team].radarPowered?`Radar range ${e.radar} — shows enemy units as blips`:`<span class="warn">No energy — radar off</span>`;else if(a.type===V.LaunchComplex)o+=`Nuclear missiles in stock: <b>${a.stock??0}</b>${a.stock?` — right-click a target in sight or on radar to launch one`:``}${a.target?` · launching…`:``}`,a.prod.length&&(s=[`Building ${G[a.prod[0]].name}`,a.prodProgress],a.prod.length>1&&(o+=`<br>${a.prod.length-1} more queued`));else if(Jd[a.type]){a.prod.length?(s=[`Building ${G[a.prod[0]].name}`,a.prodProgress],a.prod.length>1&&(o+=`${a.prod.length-1} more queued<br>`)):o+=`Idle — click a unit to build it<br>`;let e=0;for(let t=0;t<r.count;t++)r.alive[t]&&r.team[t]===q.me&&e++;o+=`<small>Right-click: remove one · right-click the ground: rally point${a.rally?` (set)`:``} · units ${e} / 300</small>`}return i({kick:n?`YOUR BUILDING`:`ENEMY BUILDING`,name:e.name,pic:t,hp:a.hp,max:e.hp,prog:s,lines:o})}if(n>=0&&r.wreckById(n)?.alive){let e=r.wreckById(n),t=e.from===`unit`?G[e.type].name:H[e.type].name,a=e.metal/(Nd.buildPower/Ad.workPerMetal);return i({kick:`WRECK`,name:t,lines:`${Math.round(e.metal)} metal to reclaim (about ${Math.ceil(a)} s)<br>Blocks land units · select the Commander and right-click it to reclaim`})}if(this.activeBuild!==null){let e=H[this.activeBuild];return this.ensureIcons(),i({kick:`PLACING`,name:e.name,pic:this.structIcons.get(this.activeBuild),lines:`Left-click to place${this.activeBuild===V.MetalMine?` on a glowing meteor site`:this.activeBuild===V.AdvMine?` on a meteor site or over one of your metal mines (upgrade: the old mine works until the new one is done)`:this.activeBuild===V.Fission?` · it explodes when destroyed: keep it away from your base`:this.activeBuild===V.Tidal?` anywhere in the ocean (a construction ship or drone reaches open water)`:` · snaps into a row next to the same kind (Ctrl: place freely)`}<br>Right-click or Esc cancels`})}let o=[...e].filter(e=>r.alive[e]);if(o.length===1){let e=o[0],t=G[r.type[e]],n=t.weapons.map(e=>`${e.name} (range ${e.range}, hits ${[e.land&&`land`,e.sea&&`sea`,e.air&&`air`].filter(Boolean).join(`/`)})`).join(` · `)||(r.type[e]===W.Commander?`Unarmed · builder · radar ${t.radar}`:qd(r.type[e])?`Unarmed · builder`:`Unarmed`),a,s=r.buildTask[e]>=0?r.wreckById(r.buildTask[e]):void 0,c=r.buildTask[e]>=0?r.structById(r.buildTask[e]):void 0;return r.holdFire[e]&&(n+=`<br>Holding fire (only shoots an attack target)`),s?n+=`<br>Reclaiming a wreck`:c&&!c.complete?a=[`Building ${H[c.type].name}`,c.progress]:c&&c.complete?n+=`<br>Assisting ${H[c.type].name}${c.prod.length?``:` (idle)`}`:r.attack[e]!==-1&&(n+=`<br>Attacking`),n+=t.weapons.length?`<br><small>${r.holdFire[e]?`Holding fire`:`Fires at will`} · right-click an enemy to attack it</small>`:qd(r.type[e])?`<br><small>Right-click a wreck: reclaim · a factory: assist</small>`:``,i({kick:r.team[e]===q.me?`SELECTED`:`ENEMY UNIT`,name:t.name,pic:this.portrait(r.type[e]),hp:r.hp[e],max:r.maxHp(e),prog:a,lines:n})}if(o.length>1){let e=0,t=0;for(let n of o)e+=r.hp[n],t+=r.maxHp(n);let n=new Map;for(let e of o)n.set(r.type[e],(n.get(r.type[e])??0)+1);let a=[...n].sort((e,t)=>t[1]-e[1]);return i({kick:`SELECTED`,name:`${o.length} units`,pic:this.portrait(a[0][0]),hp:e,max:t,lines:`${a.slice(0,3).map(([e,t])=>`${t} × ${G[e].name}`).join(` · `)}${a.length>3?` · …`:``}<br><small>Right-click an enemy to attack · drones are hit by destroyers, anti-air MGs and other drones</small>`})}return i({kick:`NOTHING SELECTED`,name:`—`,lines:`Left-click or drag to select<br><b>Space</b> jumps to the Commander`})}};function Gg(e){for(let[t,n]of Object.entries(Jd))if(n?.includes(e))return H[Number(t)].factoryPower??Dd.buildPower;return Dd.buildPower}var Kg=256,qg={dist:600,seconds:2.5},Jg=class{world;planet;stage;selected=new Set;selectedStruct=-1;selectedWreck=-1;fog;bars=new pg;audio;vegetation;hoverT=0;commander=-1;awaitCommander=!1;match=null;placing=null;gcam;unitsView=new Bh;worldView;ui;mouse={x:-1,y:-1,inside:!1,ctrl:!1};camPos=new L;tmp=new L;ghost;ghostMat=new Jr({color:8257405,transparent:!0,opacity:.4,depthWrite:!1});ghostSpot=null;marker;ringGroup=new Pn;rings=[];ringMat=new Ti({color:7330047,transparent:!0,opacity:.8,depthWrite:!1});ghostRingMat=new Ti({color:10485712,transparent:!0,opacity:.9,depthWrite:!1});markerAge=0;constructor(e,t,n){this.world=e,this.planet=t,this.stage=n,this.gcam=new jh(n.camera,t),this.worldView=new sg(e),this.fog=new ih(e),n.sky.uFogTex.value=this.fog.texture,n.sky.uFogN.value=t.N,this.worldView.fog=()=>this.fog.active,this.worldView.seen=e=>this.fog.seen(e),this.audio=new Tg(e),this.vegetation=new Ng(e,n.sky),n.scene.add(this.vegetation.group),this.audio.canHear=e=>this.worldView.canSee(e),this.worldView.bars=this.bars,this.ui=new Wg(e,e=>this.startPlacing(e)),this.ui.onQueue=(t,n,r)=>e.enqueue({kind:`factory-queue`,structId:t,unitType:n,delta:r}),this.ui.onStop=()=>this.stopSelected(),this.ui.onStance=e=>this.setStance(e),this.ui.onPatrol=()=>this.startPatrol(),this.ui.onReclaimStruct=()=>this.startReclaimStruct(),this.ui.onDestroy=()=>this.destroySelected(),n.scene.add(this.routeLine,this.routeDots),this.worldView.onMessage=e=>this.ui.toast(e,/^(an )?enemy|nuclear launch|commander destroyed|match lost/i.test(e)?`bad`:`info`),this.worldView.onBuilt=e=>{e.team===q.me&&this.ui.toast(`${H[e.type].name} complete`)},this.ghost=new oi(new Ir,this.ghostMat),this.ghost.visible=!1,this.marker=new oi(new Co(.7,1,32).rotateX(-Math.PI/2),new Jr({color:8257405,transparent:!0,depthWrite:!1})),this.marker.visible=!1,this.ringGroup.renderOrder=4,n.scene.add(this.ringGroup),n.scene.add(this.unitsView.group,this.worldView.group,this.ghost,this.marker,this.bars.group)}get camera(){return this.stage.camera}toNdc(e,t){return[e/window.innerWidth*2-1,-(t/window.innerHeight)*2+1]}pick(e,t){return this.gcam.pick(...this.toNdc(e,t))}placeStart(e){let{planet:t,world:n}=this;if(!t.land[t.cellOf(e.x,e.y,e.z)])return this.ui.toast(`Choose a spot on land`),!1;n.enqueue({kind:`place-start`,team:q.me,target:[e.x,e.y,e.z],difficulty:this.match?.difficulty,faction:this.match?.faction,opponents:this.match?.opponents()}),n.step();for(let e=0;e<n.count;e++)n.type[e]===W.Commander&&n.team[e]===q.me&&(this.commander=e);return this.commander<0&&(this.awaitCommander=!0),this.selected.clear(),this.commander>=0&&this.selected.add(this.commander),this.gcam.glideTo(e.clone(),qg.dist,qg.seconds),this.ui.setOverlay(null),this.ui.toast(`Meteor shower incoming — watch the red markers`),!0}selectableIds(){let e=[];for(let t=0;t<this.world.count;t++)this.world.team[t]===q.me&&this.world.alive[t]&&this.world.carriedBy[t]<0&&e.push(t);return e}unitScreen(e){let t=this.tmp.set(this.unitsView.wx[e],this.unitsView.wy[e],this.unitsView.wz[e]),n=this.camPos;return t.x*(n.x-t.x)+t.y*(n.y-t.y)+t.z*(n.z-t.z)<0||(t.project(this.camera),t.z>1||t.z<-1)?null:[(t.x+1)/2*window.innerWidth,(1-t.y)/2*window.innerHeight]}structureAt(e,t,n=!1){let r=-1,i=1/0;for(let a of this.world.structures){if(n?a.team===q.me||!this.worldView.known(a)||!a.alive:!a.alive||a.team!==q.me)continue;let o=this.footprintHit(a.x,a.y,a.z,H[a.type].radius,e,t);o>=0&&o<i&&(i=o,r=a.id)}return r}wreckAt(e,t){let n=-1,r=1/0;for(let i of this.world.wrecks){if(!i.alive||this.worldView.knownWreck(i)<0)continue;let a=this.footprintHit(i.x,i.y,i.z,Math.max(4,i.radius),e,t);a>=0&&a<r&&(r=a,n=i.id)}return n}unitPickDist(e,t,n,r=16){let i=this.unitScreen(e);if(!i)return 1/0;let a=this.unitsView,o=this.world.type[e],s=a.modelScale,c=this.tmp.set(a.wx[e],a.wy[e],a.wz[e]),l=c.clone().normalize(),u=Math.max(1,c.distanceTo(this.camPos)),d=c.clone().addScaledVector(l,(a.modelHeight[o]??0)*s).project(this.camera),f=(d.x+1)/2*window.innerWidth,p=(1-d.y)/2*window.innerHeight,m=f-i[0],h=p-i[1],g=m*m+h*h,_=g>0?Math.max(0,Math.min(1,((t-i[0])*m+(n-i[1])*h)/g)):0,v=Math.hypot(t-(i[0]+m*_),n-(i[1]+h*_)),y=window.innerHeight/(2*Math.tan(Pt.degToRad(this.camera.fov)/2)*u);return v-Math.max(r,(a.modelHalfWidth[o]??0)*s*y)}ownTransportAt(e,t){let n=-1,r=0;for(let i=0;i<this.world.count;i++){if(!this.world.alive[i]||this.world.team[i]!==q.me||!G[this.world.type[i]].capacity)continue;let a=this.unitPickDist(i,e,t);a<=r&&(r=a,n=i)}return n}enemyAt(e,t){let n=-1,r=0;for(let i=0;i<this.world.count;i++){if(!this.world.alive[i]||this.world.team[i]===q.me||this.unitsView.seen[i]===0)continue;let a=this.unitPickDist(i,e,t,18);a<=r&&(r=a,n=i)}return n}footprintHit(e,t,n,r,i,a){{let o=this.worldView.surface(e,t,n,4);if(this.camPos.clone().sub(o).dot(o)<0)return-1;let s=o.clone().add(this.camera.up.clone().multiplyScalar(r)).project(this.camera);o.project(this.camera);let c=(o.x+1)/2*window.innerWidth,l=(1-o.y)/2*window.innerHeight,u=(s.x+1)/2*window.innerWidth,d=(1-s.y)/2*window.innerHeight,f=Math.max(14,Math.hypot(u-c,d-l)),p=Math.hypot(c-i,l-a);return p<f?p:-1}}clickSelect(e,t,n){let r=-1,i=0;for(let n of this.selectableIds()){let a=this.unitPickDist(n,e,t);a<=i&&(i=a,r=n)}n||this.selected.clear(),this.selectedStruct=-1,this.selectedWreck=-1,r>=0?n&&this.selected.has(r)?this.selected.delete(r):this.selected.add(r):n||(this.selectedStruct=this.structureAt(e,t),this.selectedStruct<0&&(this.selectedWreck=this.wreckAt(e,t)))}boxSelect(e,t,n,r,i){let a=Math.min(e,n),o=Math.max(e,n),s=Math.min(t,r),c=Math.max(t,r);i||this.selected.clear(),this.selectedStruct=-1;for(let e of this.selectableIds()){let t=this.unitScreen(e);t&&t[0]>=a&&t[0]<=o&&t[1]>=s&&t[1]<=c&&this.selected.add(e)}}stopSelected(){let e=[...this.selected].filter(e=>this.world.alive[e]&&this.world.team[e]===q.me),t=this.selectedStruct>=0?this.world.structById(this.selectedStruct):void 0,n=t&&t.team===q.me&&(t.type===V.Horizon||t.type===V.Anvil)?[t.id]:[];(e.length||n.length)&&(this.world.enqueue({kind:`stop`,ids:e,structIds:n}),this.audio.ui(`ack`),this.ui.toast(e.length?`Stopped ${e.length} unit${e.length>1?`s`:``}`:`Shot cancelled`))}armedSelected(){let e=this.world;return[...this.selected].filter(t=>e.alive[t]&&e.team[t]===q.me&&G[e.type[t]].weapons.length>0)}setStance(e){let t=this.armedSelected();t.length&&(this.world.enqueue({kind:`stance`,ids:t,stance:e}),this.audio.ui(`ack`),this.ui.toast(`${t.length} unit${t.length>1?`s`:``}: ${[`normal — fire at will`,`passive — hold fire`,`aggressive — chase enemies they see`][e]}`))}cycleStance(){let e=this.world,t=this.armedSelected();if(!t.length)return;let n=e.holdFire[t[0]]?1:e.aggressive[t[0]]?2:0;this.setStance((n+1)%3)}mode=null;waypoints=[];routeLine=new Ni(new Ir,new zo({color:8377599,dashSize:10,gapSize:5,depthTest:!1,transparent:!0}));routeDots=new Wi(new Ir,new zi({color:8377599,size:9,sizeAttenuation:!1,depthTest:!1}));startPatrol(){this.armedSelected().length&&(this.stopPlacing(),this.mode=`patrol`,this.waypoints=[],this.ui.toast(`Patrol: left-click waypoints · click the first one again to close a loop · right-click or Enter to finish · Esc cancels`))}startReclaimStruct(){[...this.selected].some(e=>qd(this.world.type[e]))&&(this.stopPlacing(),this.mode=`reclaim`,this.ui.toast(`Reclaim: left-click one of your buildings (full metal back) · Esc cancels`))}cancelMode(){this.mode=null,this.waypoints=[]}modeClick(e,t){let n=this.world;if(this.mode===`reclaim`){let r=this.structureAt(e,t),i=r>=0?n.structById(r):void 0;if(!i||i.team!==q.me){this.ui.toast(`Pick one of your own buildings (Esc cancels)`);return}let a=[...this.selected].filter(e=>n.alive[e]&&qd(n.type[e]));n.enqueue({kind:`reclaim-struct`,ids:a,structId:i.id}),this.ui.toast(`Reclaiming ${H[i.type].name}`),this.audio.ui(`ack`),this.cancelMode();return}if(this.mode!==`patrol`)return;let r=this.pick(e,t);if(r){if(this.waypoints.length>=2){let n=this.screenOf(this.waypoints[0]);if(n&&Math.hypot(n[0]-e,n[1]-t)<18){this.finishPatrol(!0);return}}this.waypoints.push(r.clone()),this.audio.ui(`ack`)}}finishPatrol(e=!1){if(this.mode!==`patrol`)return;let t=this.armedSelected();t.length&&this.waypoints.length&&(this.world.enqueue({kind:`patrol`,ids:t,points:this.waypoints.map(e=>[e.x,e.y,e.z]),loop:e}),this.ui.toast(`${t.length} unit${t.length>1?`s`:``} patrolling ${e?`a loop`:`there and back`} (${this.waypoints.length} waypoint${this.waypoints.length>1?`s`:``})`)),this.cancelMode()}destroySelected(){let e=this.selectedStruct>=0?this.world.structById(this.selectedStruct):void 0;e&&e.alive&&e.team===q.me&&(this.world.enqueue({kind:`self-destruct`,structIds:[e.id]}),this.ui.toast(`${H[e.type].name} destroyed`),this.selectedStruct=-1)}screenOf(e){let t=this.surfacePoint(e).project(this.camera);return t.z>1?null:[(t.x+1)/2*window.innerWidth,(1-t.y)/2*window.innerHeight]}surfacePoint(e){let t=Math.max(0,this.planet.heightAt(e.x,e.y,e.z))*45;return e.clone().normalize().multiplyScalar(this.planet.radius+t+2)}updateRoute(){let e=this.world,t=[],n=!1;if(this.mode===`patrol`){let n=this.armedSelected()[0];if(n!==void 0&&t.push(new L(e.x[n],e.y[n],e.z[n])),t.push(...this.waypoints),this.mouse.inside){let e=this.pick(this.mouse.x,this.mouse.y);e&&t.push(e)}}else for(let r of this.selected){let i=e.patrol[r];if(i){t=i.map(e=>new L(e[0],e[1],e[2])),n=!!e.patrolLoop[r];break}}let r=t.length>=2;if(this.routeLine.visible=this.routeDots.visible=r,!r)return;let i=[],a=n?[...t,t[0]]:t;for(let e=0;e+1<a.length;e++){let t=a[e].clone().normalize(),n=a[e+1].clone().normalize(),r=Math.max(2,Math.ceil(t.angleTo(n)*this.planet.radius/20));for(let e=0;e<r;e++)i.push(this.surfacePoint(t.clone().lerp(n,e/r)))}i.push(this.surfacePoint(a[a.length-1])),this.routeLine.geometry.dispose(),this.routeLine.geometry=new Ir().setFromPoints(i),this.routeLine.computeLineDistances(),this.routeDots.geometry.dispose(),this.routeDots.geometry=new Ir().setFromPoints(t.map(e=>this.surfacePoint(e)))}clearSelection(){this.selected.clear(),this.selectedStruct=-1,this.selectedWreck=-1}issueOrder(e,t){let n=this.pick(e,t);if(!n)return;let{world:r}=this,i=this.selectedStruct>=0?r.structById(this.selectedStruct):void 0;if(i&&i.alive&&i.team===q.me&&(i.type===V.Horizon||i.type===V.Anvil)&&this.selected.size===0){r.enqueue({kind:`fire`,structIds:[i.id],target:[n.x,n.y,n.z]}),this.audio.ui(`ack`),r.detected(q.me,[n.x,n.y,n.z])||this.ui.toast(`Target not in sight or on radar — the ${i.type===V.Anvil?`Anvil`:`Horizon`} fires once a unit, drone or radar covers it`);return}if(i&&i.alive&&i.team===q.me&&i.type===V.LaunchComplex&&(i.stock??0)>0&&this.selected.size===0){r.enqueue({kind:`fire`,structIds:[i.id],target:[n.x,n.y,n.z]}),this.audio.ui(`ack`),this.ui.toast(r.detected(q.me,[n.x,n.y,n.z])?`Nuclear missile launching`:`Target not in sight or on radar — the missile launches once a satellite or radar covers it`);return}if(i&&i.alive&&i.team===q.me&&Jd[i.type]&&this.selected.size===0){r.enqueue({kind:`rally`,structIds:[i.id],target:[n.x,n.y,n.z]}),this.flashMarker(n,4895999);return}if(this.selected.size===0)return;let a=[...this.selected],o=this.enemyAt(e,t),s=o<0?this.structureAt(e,t,!0):-1;if(o>=0||s>=0){let e=a.filter(e=>G[r.type[e]].weapons.some(e=>{if(s>=0)return e.land;let t=G[r.type[o]];return t.submerged?!!e.sub:t.layer===0?e.land:t.layer===1?e.sea:e.air}));if(e.length){r.enqueue(o>=0?{kind:`attack`,ids:e,unit:o}:{kind:`attack`,ids:e,structId:s}),this.flashMarker(n,16730682);return}this.ui.toast(o>=0&&G[r.type[o]].layer===2?`Drones are hit by destroyers, anti-air MGs and attack drones`:o>=0&&G[r.type[o]].submerged?`Submarines are hit by torpedoes and depth charges (destroyers, submarines)`:`The selected units can't attack that`);return}let c=this.ownTransportAt(e,t),l=c>=0?a.filter(e=>sf(r.type[e],r.type[c])):[];if(c>=0&&l.length&&!a.includes(c)){r.enqueue({kind:`load`,ids:l,transport:c}),this.ui.toast(`Boarding the transport (${Math.min(l.length,(G[r.type[c]].capacity??0)-(r.cargo[c]?.length??0))} fit)`),this.flashMarker(n,4895999);return}let u=a.filter(e=>(r.cargo[e]?.length??0)>0);if(u.length&&u.length===a.length){let e=[n.x,n.y,n.z];if(!r.planet.land[r.planet.cellOf(...e)]){this.ui.toast(`Transports set their cargo down on land — pick a spot on an island`);return}for(let t of u)r.enqueue({kind:`unload`,id:t,target:e});this.flashMarker(n,4895999);return}let d=this.wreckAt(e,t),f=a.filter(e=>qd(r.type[e]));if(d>=0&&f.length){r.enqueue({kind:`reclaim`,ids:f,wreckId:d}),this.ui.toast(`Reclaiming wreck`),this.flashMarker(n,16757575);return}let p=this.structureAt(e,t),m=p>=0?r.structById(p):void 0,h=[...this.selected].filter(e=>qd(r.type[e]));m&&!m.complete&&h.length?(r.enqueue({kind:`assist`,ids:h,structId:m.id}),this.ui.toast(`Resuming ${H[m.type].name}`)):m&&m.complete&&m.team===q.me&&Jd[m.type]&&h.length?(r.enqueue({kind:`assist`,ids:h,structId:m.id}),this.ui.toast(`Assisting ${H[m.type].name}`),this.audio.ui(`ack`)):(r.enqueue({kind:`move`,ids:[...this.selected],target:[n.x,n.y,n.z]}),this.flashMarker(n,8257405))}flashMarker(e,t){this.audio.ui(`ack`),this.marker.visible=!0,this.markerAge=0,this.marker.material.color.setHex(t);let n=Math.max(0,this.planet.heightAt(e.x,e.y,e.z))*45;this.marker.position.copy(e).multiplyScalar(this.planet.radius+n+.6),this.marker.quaternion.setFromUnitVectors(new L(0,1,0),e)}updateCursor(e){if(this.hoverT-=e,this.hoverT>0||!this.mouse.inside)return;this.hoverT=.1;let t=``;if(this.selected.size&&this.placing===null){let{x:e,y:n}=this.mouse;this.enemyAt(e,n)>=0||this.structureAt(e,n,!0)>=0?t=`crosshair`:[...this.selected].some(e=>qd(this.world.type[e]))&&this.wreckAt(e,n)>=0&&(t=`cell`)}this.stage.renderer.domElement.style.cursor=t}startPlacing(e){[...this.selected].some(e=>qd(this.world.type[e]))&&(this.placing=e,this.ui.activeBuild=e,this.ghost.geometry=this.worldView.geometry(e))}stopPlacing(){this.placing=null,this.ui.activeBuild=null,this.ghost.visible=!1}confirmPlacing(){if(this.updateGhost(),this.placing===null)return;if(!this.ghostSpot){this.ui.toast(this.placing===V.MetalMine?`Metal mines must go on a meteor site`:this.placing===V.AdvMine?`Advanced mines go on a meteor site or over one of your metal mines`:`Can't build there`),this.audio.ui(`error`);return}let e=[...this.selected].filter(e=>qd(this.world.type[e]));this.world.enqueue({kind:`build`,ids:e,structType:this.placing,target:this.ghostSpot}),this.audio.ui(`place`),this.stopPlacing()}updateGhost(){let{ghost:e}=this;if(this.placing===null||!this.mouse.inside){e.visible=!1;return}let t=this.pick(this.mouse.x,this.mouse.y);if(!t){e.visible=!1;return}let n=this.mouse.ctrl?null:Zh(this.world,0,this.placing,[t.x,t.y,t.z]),r=this.world.canPlace(this.placing,n??[t.x,t.y,t.z],q.me),i=r?new L(...r.dir):t;this.worldView.surface(i.x,i.y,i.z,.3,e.position),Qh([i.x,i.y,i.z],e.quaternion),this.ghostMat.color.setHex(r?8257405:16730682),e.visible=!0,this.ghostSpot=r?r.dir:null}radarPicked(){if(this.placing===V.Radar)return!0;if(this.placing===null&&this.selectedStruct>=0){let e=this.world.structById(this.selectedStruct);if(e&&e.alive&&e.team===q.me&&e.type===V.Radar)return!0}for(let e of this.selected)if(this.world.alive[e]&&(this.world.type[e]===W.RadarDrone||this.world.type[e]===W.Satellite))return!0;return!1}updateRangeRing(){let e=this.radarPicked()?hf(this.world,q.me):[];if(this.placing===V.Radar&&this.ghost.visible){let t=this.ghost.position;e.push({dir:[t.x,t.y,t.z],radius:H[V.Radar].radar,ghost:!0})}for(;this.rings.length<e.length;){let e=new Ir;e.setAttribute(`position`,new xr(new Float32Array(Kg*3),3));let t=new Ri(e,this.ringMat);t.frustumCulled=!1,t.renderOrder=4,this.rings.push(t),this.ringGroup.add(t)}this.rings.forEach((t,n)=>{let r=e[n];if(t.visible=!!r,!r)return;t.material=r.ghost?this.ghostRingMat:this.ringMat;let i=`${r.dir.map(e=>e.toFixed(4)).join()}|${r.radius}`;t.userData.key!==i&&(t.userData.key=i,this.circleOnPlanet(r.dir,r.radius,t.geometry.attributes.position))})}circleOnPlanet(e,t,n){let r=this.planet.radius,i=new L(...e).normalize(),a=new L(-i.z,0,i.x);a.lengthSq()<1e-6&&a.set(1,0,0),a.normalize();let o=new L().crossVectors(i,a),s=2*Math.asin(Math.min(1,t/(2*r))),c=new L;for(let e=0;e<Kg;e++){let t=e/Kg*Math.PI*2;c.copy(i).multiplyScalar(Math.cos(s)).addScaledVector(a,Math.sin(s)*Math.cos(t)).addScaledVector(o,Math.sin(s)*Math.sin(t)).normalize();let l=Math.max(0,this.planet.heightAt(c.x,c.y,c.z))*45;c.multiplyScalar(r+l+2),n.setXYZ(e,c.x,c.y,c.z)}n.needsUpdate=!0}update(e,t){this.updateRoute();let{world:n}=this;if(this.awaitCommander&&n.teams[q.me].started)for(let e=0;e<n.count;e++)n.alive[e]&&n.type[e]===W.Commander&&n.team[e]===q.me&&(this.commander=e,this.selected.clear(),this.selected.add(e),this.awaitCommander=!1,this.ui.overlayShown()&&(this.ui.setOverlay(null),this.gcam.focusOn(new L(n.x[e],n.y[e],n.z[e])),this.gcam.zoom(330/this.gcam.dist)));this.camPos.copy(this.camera.position);for(let e of this.selected)(!n.alive[e]||n.carriedBy[e]>=0)&&this.selected.delete(e);this.selectedStruct>=0&&!n.structById(this.selectedStruct)?.alive&&(this.selectedStruct=-1),this.selectedWreck>=0&&!n.wreckById(this.selectedWreck)?.alive&&(this.selectedWreck=-1),this.fog.update(e),this.stage.sky.uFogOn.value=+!!this.fog.active,this.bars.begin(this.camera,this.gcam.heightAboveSurface()),this.audio.events(n.events),this.vegetation.update(this.gcam.heightAboveSurface()),this.stage.sky.uWind.value=n.wind(),this.audio.update(this.camera,e,this.gcam.heightAboveSurface(),this.gcam.dist>=this.gcam.maxDist*.95),this.unitsView.update(n,t,this.selected,this.gcam.heightAboveSurface(),this.fog.active,this.bars,performance.now()/1e3),this.worldView.update(e,t,this.camera,this.stage.renderer.domElement.height,this.selectedStruct),this.bars.flush(),this.updateGhost(),this.updateRangeRing(),this.updateCursor(e),this.ui.update(this.selected,this.selectedStruct,this.selectedWreck),this.marker.visible&&(this.markerAge+=e,this.marker.scale.setScalar((4+this.markerAge*30)*Math.max(1,this.gcam.dist/300)),this.marker.material.opacity=Math.max(0,1-this.markerAge*1.5),this.markerAge>.7&&(this.marker.visible=!1))}},Yg=class{game;keys=new Set;edgeScroll=!1;fp=null;dragStart=null;dragging=!1;rotating=null;grab=null;box=document.getElementById(`selbox`);constructor(e,t){this.game=e,t.addEventListener(`contextmenu`,e=>e.preventDefault()),t.addEventListener(`pointerdown`,e=>{try{t.setPointerCapture(e.pointerId)}catch{}this.down(e)}),t.addEventListener(`pointermove`,e=>this.move(e)),t.addEventListener(`pointerup`,e=>this.up(e)),t.addEventListener(`wheel`,t=>{t.preventDefault();let n=this.fp;if(n?.active){t.deltaY>0&&n.exit();return}if(t.deltaY<0&&n?.tryEnter())return;let r=e.pick(t.clientX,t.clientY)??void 0;e.gcam.zoom(Math.exp(Math.sign(t.deltaY)*Math.min(Math.abs(t.deltaY),200)*.0025),r)},{passive:!1}),document.addEventListener(`pointerleave`,()=>e.mouse.inside=!1),window.addEventListener(`blur`,()=>{e.mouse.inside=!1,this.keys.clear(),this.grab=null,this.rotating=null,e.gcam.held=!1}),window.addEventListener(`keydown`,t=>{e.mouse.ctrl=t.ctrlKey,this.keyDown(t)}),window.addEventListener(`keyup`,t=>{e.mouse.ctrl=t.ctrlKey,this.keys.delete(t.code)})}down(e){let t=this.game;if(this.fp?.active)this.fpClick(e.button);else{if(t.mode!==null&&!(e.button===2&&e.ctrlKey)){if(e.button===0){t.modeClick(e.clientX,e.clientY);return}if(e.button===2){t.mode===`patrol`?t.finishPatrol(!1):t.cancelMode();return}}if(e.button===0&&!t.world.teams[q.me].started){let n=t.pick(e.clientX,e.clientY);n&&t.placeStart(n)}else e.button===2&&e.ctrlKey?(t.gcam.spin.set(0,0,0),this.rotating={x:e.clientX,y:e.clientY,sx:e.clientX,sy:e.clientY,right:!0,moved:!1}):e.button===0&&t.placing!==null?t.confirmPlacing():e.button===2&&t.placing!==null?t.stopPlacing():e.button===0&&!e.altKey?(this.dragStart={x:e.clientX,y:e.clientY},this.dragging=!1):e.button===2?(t.gcam.spin.set(0,0,0),t.gcam.held=!0,this.grab={x:e.clientX,y:e.clientY,hit:this.seaPick(e.clientX,e.clientY),lastT:performance.now(),moved:!1,vel:new L}):(e.button===1||e.button===0&&e.altKey)&&(this.rotating={x:e.clientX,y:e.clientY,sx:e.clientX,sy:e.clientY,right:!1,moved:!1},e.preventDefault())}}move(e){let t=this.game,n=t.gcam;if(this.fp?.active)return;t.mouse.x=e.clientX,t.mouse.y=e.clientY,t.mouse.inside=!0,t.mouse.ctrl=e.ctrlKey;let r=this.dragStart;if(r){let t=e.clientX-r.x,n=e.clientY-r.y;!this.dragging&&t*t+n*n>36&&(this.dragging=!0),this.dragging&&Object.assign(this.box.style,{display:`block`,left:Math.min(r.x,e.clientX)+`px`,top:Math.min(r.y,e.clientY)+`px`,width:Math.abs(t)+`px`,height:Math.abs(n)+`px`})}let i=this.grab;if(i){let r=e.clientX-i.x,a=e.clientY-i.y;if(!i.moved&&r*r+a*a>16&&(i.moved=!0),i.moved){let o=performance.now(),s=Math.max(1,o-i.lastT)/1e3,c=this.seaPick(e.clientX,e.clientY),l;if(i.hit&&c)l=new Ft().setFromUnitVectors(c,i.hit);else{let e=1.2/Math.max(200,Math.min(window.innerWidth,window.innerHeight)),i=new L().setFromMatrixColumn(t.camera.matrixWorld,0),o=new L().setFromMatrixColumn(t.camera.matrixWorld,1).multiplyScalar(-r).addScaledVector(i,-a),s=o.length()*e*Math.min(1,n.dist/2500+.15);l=s>0?new Ft().setFromAxisAngle(o.normalize(),s):new Ft}n.rotateBy(l),n.update(0);let u=new L(l.x,l.y,l.z),d=u.length();d>1e-6&&i.vel.lerp(u.divideScalar(d).multiplyScalar(2*Math.atan2(d,l.w)/Math.max(s,.008)),.5),i.x=e.clientX,i.y=e.clientY,i.lastT=o,i.hit&&c||(i.hit=this.seaPick(e.clientX,e.clientY))}}let a=this.rotating;if(a){!a.moved&&(e.clientX-a.sx)**2+(e.clientY-a.sy)**2>16&&(a.moved=!0),n.rotate((e.clientX-a.x)*-.005);let t=(e.clientY-a.y)*(a.right?-1:1);n.tiltOffset=Pt.clamp(n.tiltOffset+t*.004,-1.3,.5),a.x=e.clientX,a.y=e.clientY}}up(e){let t=this.game;this.fp?.active||(e.button===0&&this.dragStart&&(this.dragging?t.boxSelect(this.dragStart.x,this.dragStart.y,e.clientX,e.clientY,e.shiftKey):t.clickSelect(e.clientX,e.clientY,e.shiftKey),this.box.style.display=`none`,this.dragStart=null,this.dragging=!1),e.button===2&&this.rotating?.right&&(this.rotating.moved||t.issueOrder(e.clientX,e.clientY),this.rotating=null),e.button===2&&this.grab&&(this.grab.moved?performance.now()-this.grab.lastT<80&&t.gcam.spin.copy(this.grab.vel):t.issueOrder(e.clientX,e.clientY),t.gcam.held=!1,this.grab=null),e.button!==1&&e.button!==0||this.rotating?.right||(this.rotating=null))}fpClick(e){let t=this.game,n=this.fp;if(n.captureOnClick())return;let[r,i]=n.cursor;e===0?t.placing===null?(t.clickSelect(r,i,!1),t.selected.size===0&&t.selectedStruct<0&&t.commander>=0&&t.selected.add(t.commander)):t.confirmPlacing():e===2&&(t.placing===null?t.issueOrder(r,i):t.stopPlacing())}seaPick(e,t){return this.game.gcam.pick(...this.game.toNdc(e,t),!0)}keyDown(e){let t=this.game,n=t.world;if(this.keys.add(e.code),this.fp?.active&&e.code===`Escape`&&t.placing===null){this.fp.exit();return}if((e.code===`Space`||e.code===`Home`)&&t.commander>=0&&!this.fp?.active&&(t.gcam.focusOn(new L(n.x[t.commander],n.y[t.commander],n.z[t.commander])),e.preventDefault()),e.code===`Escape`&&(t.mode===null?t.placing===null?t.clearSelection():t.stopPlacing():t.cancelMode()),e.code===`KeyX`&&!e.ctrlKey&&!e.metaKey&&t.stopSelected(),e.code===`KeyH`&&!e.ctrlKey&&!e.metaKey&&t.cycleStance(),e.code===`KeyP`&&!e.ctrlKey&&!e.metaKey&&t.startPatrol(),(e.code===`Delete`||e.code===`Backspace`)&&t.selectedStruct>=0&&t.selected.size===0&&t.destroySelected(),(e.code===`Enter`||e.code===`NumpadEnter`)&&t.mode===`patrol`&&t.finishPatrol(!1),e.code===`Tab`&&t.ui.buildMenuOpen&&(t.ui.flipPage(e.shiftKey?-1:1),e.preventDefault()),!t.ui.buildMenuOpen&&t.ui.factoryKey(e.code,e.shiftKey))return;let r=t.ui.buildKey(e.code);if(r!==null&&t.startPlacing(r),e.code===`KeyA`&&(e.ctrlKey||e.metaKey)){e.preventDefault();for(let e of t.selectableIds())t.selected.add(e)}}updateCamera(e){let{keys:t}=this,n=this.game.gcam,r=this.game.mouse;if(this.fp?.active){[r.x,r.y]=this.fp.cursor,r.inside=!0,this.fp.updateWalk(e,t);return}let i=900*e,a=0,o=0;(t.has(`KeyW`)||t.has(`ArrowUp`))&&(o+=i),(t.has(`KeyS`)||t.has(`ArrowDown`))&&(o-=i),(t.has(`KeyD`)||t.has(`ArrowRight`))&&(a+=i),(t.has(`KeyA`)||t.has(`ArrowLeft`))&&(a-=i),this.edgeScroll&&r.inside&&!this.dragStart&&!this.rotating&&!this.grab&&(r.x<=10&&(a-=i),r.x>=window.innerWidth-10&&(a+=i),r.y<=10&&(o+=i),r.y>=window.innerHeight-10&&(o-=i)),(a||o)&&n.pan(a,o),t.has(`KeyQ`)&&n.rotate(1.6*e),t.has(`KeyE`)&&n.rotate(-1.6*e),(t.has(`KeyR`)||t.has(`PageUp`))&&n.zoom(Math.exp(-2*e)),(t.has(`KeyF`)||t.has(`PageDown`))&&n.zoom(Math.exp(2*e))}},Xg=8.3,Zg=40,Qg=.1,$g=.035,e_=class{game;active=!1;locked=!1;yaw=0;pitch=-.25;sent=null;sentAt=0;hud=document.getElementById(`fps`);canvas;t=0;constructor(e){this.game=e,this.canvas=e.stage.renderer.domElement,document.addEventListener(`pointerlockchange`,()=>{let e=this.locked;this.locked=document.pointerLockElement===this.canvas,this.hud.classList.toggle(`locked`,this.locked),e&&!this.locked&&this.active&&this.exit()}),document.addEventListener(`mousemove`,e=>{this.active&&this.locked&&(this.yaw+=e.movementX*.0025,this.pitch=Pt.clamp(this.pitch-e.movementY*.0025,-1.35,1.35))})}tryEnter(){let e=this.game,t=e.world,n=e.commander;if(this.active||n<0||!t.alive[n]||e.gcam.dist>e.gcam.minDist+.5)return!1;let r=e.planet.radius,i=e.gcam.f;if(Math.hypot(i.x-t.x[n],i.y-t.y[n],i.z-t.z[n])*r>Zg)return!1;this.active=!0;let{north:a,east:o}=Zd([t.x[n],t.y[n],t.z[n]]);return this.yaw=Math.atan2(t.hx[n]*o[0]+t.hy[n]*o[1]+t.hz[n]*o[2],t.hx[n]*a[0]+t.hy[n]*a[1]+t.hz[n]*a[2]),this.pitch=-.25,e.selected.clear(),e.selected.add(n),e.selectedStruct=-1,e.unitsView.hidden=n,this.hud.style.display=`block`,document.body.classList.add(`fp`),!0}captureOnClick(){return!this.active||this.locked?!1:(this.canvas.requestPointerLock?.(),!0)}exit(){if(!this.active)return;let e=this.game,t=e.world,n=e.commander;if(this.active=!1,this.send(null),e.unitsView.hidden=-1,this.hud.style.display=`none`,document.body.classList.remove(`fp`),document.pointerLockElement===this.canvas&&document.exitPointerLock(),n>=0){e.gcam.focusOn(new L(t.x[n],t.y[n],t.z[n]),e.gcam.minDist*1.6);let{fwd:r}=this.frame(n);e.gcam.fwd.copy(r)}}get cursor(){return[window.innerWidth/2,window.innerHeight/2]}updateWalk(e,t){if(!this.active)return;let n=this.game,r=n.world,i=n.commander;if(i<0||!r.alive[i]){this.exit();return}this.t+=e;let a=0,o=0;if((t.has(`KeyW`)||t.has(`ArrowUp`))&&(a+=1),(t.has(`KeyS`)||t.has(`ArrowDown`))&&--a,(t.has(`KeyD`)||t.has(`ArrowRight`))&&(o+=1),(t.has(`KeyA`)||t.has(`ArrowLeft`))&&--o,!a&&!o){this.send(null);return}let{fwd:s,right:c}=this.frame(i),l=s.multiplyScalar(a).addScaledVector(c,o).normalize(),u=[l.x,l.y,l.z],d=this.sent;(!d||Math.acos(Math.min(1,d[0]*u[0]+d[1]*u[1]+d[2]*u[2]))>$g)&&(!d||this.t-this.sentAt>=Qg)&&this.send(u)}send(e){if(e===null&&this.sent===null)return;let t=this.game.commander;t>=0&&this.game.world.enqueue({kind:`drive`,id:t,dir:e}),this.sent=e,this.sentAt=this.t}frame(e){let t=this.game.world,{north:n,east:r}=Zd([t.x[e],t.y[e],t.z[e]]),i=Math.cos(this.yaw),a=Math.sin(this.yaw);return{fwd:new L(n[0]*i+r[0]*a,n[1]*i+r[1]*a,n[2]*i+r[2]*a).normalize(),right:new L(r[0]*i-n[0]*a,r[1]*i-n[1]*a,r[2]*i-n[2]*a).normalize()}}updateCamera(e,t){if(!this.active)return;let n=this.game,r=n.world,i=n.commander;if(i<0||!r.alive[i])return;let a=n.planet.radius,o=r.px[i]+(r.x[i]-r.px[i])*t,s=r.py[i]+(r.y[i]-r.py[i])*t,c=r.pz[i]+(r.z[i]-r.pz[i])*t,l=Math.hypot(o,s,c);o/=l,s/=l,c/=l;let u=Math.max(0,n.planet.heightAt(o,s,c))*45,d=new L(o,s,c);e.position.copy(d).multiplyScalar(a+u+Xg);let{fwd:f}=this.frame(i),p=f.multiplyScalar(Math.cos(this.pitch)).addScaledVector(d,Math.sin(this.pitch));e.up.copy(d),e.lookAt(e.position.clone().add(p)),e.updateMatrixWorld()}},t_=[`Auto`,`High`,`Medium`,`Low`],n_={Auto:1,High:1,Medium:.75,Low:.5},r_=class{renderer;button;level=`Auto`;onApply=()=>{};scale=1;window=0;frames=0;constructor(e,t){this.renderer=e,this.button=t;try{let e=localStorage.getItem(`blue.quality`);e&&t_.includes(e)&&(this.level=e)}catch{}t.addEventListener(`click`,()=>this.set(t_[(t_.indexOf(this.level)+1)%t_.length])),this.set(this.level)}set(e){this.level=e,this.scale=n_[e],this.button.textContent=`Quality: ${e}`;try{localStorage.setItem(`blue.quality`,e)}catch{}this.apply()}apply(){let e=Math.min(window.devicePixelRatio||1,3);this.renderer.setPixelRatio(Math.max(.35,e*this.scale)),this.renderer.setSize(window.innerWidth,window.innerHeight),this.onApply(this.level===`Low`?`low`:this.level===`Medium`?`medium`:`high`)}frame(e){if(this.window+=e,this.frames++,this.window<2)return;let t=this.frames/this.window;this.level===`Auto`&&(t<45&&this.scale>.5?(this.scale=Math.max(.5,this.scale*.85),this.apply()):t>57&&this.scale<1&&(this.scale=Math.min(1,this.scale*1.1),this.apply())),this.window=0,this.frames=0}};function i_(e,t=()=>{}){return[[`effects`,`Effects`],[`ambience`,`Waves & wind`],[`music`,`Music (fully zoomed out)`]].map(([n,r])=>{let i=document.createElement(`label`);i.className=`srow`;let a=document.createElement(`span`);a.className=`val`;let o=document.createElement(`input`);o.type=`range`,o.min=`0`,o.max=`100`,o.step=`5`,o.dataset.channel=n;let s=()=>{let t=Math.round(e.getLevel(n)*100);o.value=String(t),a.textContent=t?`${t}%`:`off`};return o.addEventListener(`input`,()=>{e.setLevel(n,Number(o.value)/100),s(),t()}),o.addEventListener(`keydown`,e=>e.stopPropagation()),s(),i.append(document.createTextNode(r),o,a),i})}var a_=`Music: <i>Also sprach Zarathustra</i> (R. Strauss), recording conducted by Philip Milman (PM Music), <a href="https://creativecommons.org/licenses/by/3.0/" target="_blank" rel="noopener">CC BY 3.0</a>, re-encoded.`;function o_(e,t){let n=document.createElement(`div`);n.id=`sound-panel`,n.style.cssText=`position:fixed;display:none;z-index:20;padding:12px 14px;font-size:13px;width:300px;pointer-events:auto;`;let r=()=>{e.textContent=[`effects`,`ambience`,`music`].map(e=>t.getLevel(e)).every(e=>e===0)?`Sound: off`:`Sound: ${Math.round(t.getLevel(`effects`)*100)}%`};for(let e of i_(t,r)){e.style.cssText=`display:grid;grid-template-columns:1fr;gap:2px;margin-bottom:8px;`;let[t,r,i]=Array.from(e.childNodes),a=document.createElement(`div`);a.style.cssText=`display:flex;justify-content:space-between;`,a.append(t,i),e.replaceChildren(a,r),r.style.width=`100%`,n.append(e)}let i=document.createElement(`div`);i.style.cssText=`color:#8fb5ba;font-size:11px;line-height:1.4;`,i.innerHTML=a_,n.append(i),document.body.append(n),r();let a=()=>{let t=e.getBoundingClientRect();n.style.left=`${Math.min(t.left,window.innerWidth-320)}px`,n.style.top=`${t.bottom+6}px`};return e.addEventListener(`click`,e=>{e.stopPropagation();let t=n.style.display===`none`;t&&a(),n.style.display=t?`block`:`none`}),n.addEventListener(`pointerdown`,e=>e.stopPropagation()),window.addEventListener(`pointerdown`,t=>{t.target!==e&&!n.contains(t.target)&&(n.style.display=`none`)}),{refresh:r}}var s_=`blue.help`;function c_(){let e=document.getElementById(`help`),t={open:!1,flip:()=>{},onChange:()=>{}};if(!e)return t;let n=document.createElement(`div`);for(n.className=`help-body`;e.firstChild;)n.append(e.firstChild);let r=document.createElement(`button`);r.id=`help-toggle`,e.append(r,n);let i=window.innerHeight>=860;try{let e=localStorage.getItem(s_);e!==null&&(i=e===`open`)}catch{}let a=()=>{e.classList.toggle(`folded`,!i),n.style.display=i?``:`none`,r.textContent=i?`Hide controls (F1)`:`? Controls (F1)`,t.onChange()},o=()=>{i=!i;try{localStorage.setItem(s_,i?`open`:`closed`)}catch{}a()};return Object.defineProperty(t,"open",{get:()=>i}),t.flip=o,r.addEventListener(`click`,e=>{e.stopPropagation(),o(),r.blur()}),r.addEventListener(`pointerdown`,e=>e.stopPropagation()),window.addEventListener(`keydown`,e=>{e.code===`F1`&&(e.preventDefault(),o())}),a(),t}var l_=3e4,u_=3e6,d_=1e3,f_=1/20,p_=class extends mm{viewFiltered=!0;seenLevel=new Uint8Array(U);bx=new Float64Array(U);by=new Float64Array(U);bz=new Float64Array(U);bvx=new Float64Array(U);bvy=new Float64Array(U);bvz=new Float64Array(U);bt=new Float64Array(U);ex=new Float64Array(U);ey=new Float64Array(U);ez=new Float64Array(U);serverTick=0;recvAt=0;send=()=>{};stats=null;constructor(e){super(e),this.autoLandAi=!1}enqueue(e){this.send(e)}step(){}unitSeenBy(e,t){return this.team[t]===e?2:this.alive[t]?this.seenLevel[t]:0}apply(e,t){let n=q.me;e.full&&this.reset(),this.serverTick=e.tick,this.recvAt=t,(this.tick<e.tick-8||this.tick>e.tick+8)&&(this.tick=e.tick);for(let t of e.units??[])this.unit(t);for(let t of e.ugone??[])t<this.count&&(this.alive[t]=0,this.seenLevel[t]=0);for(let t of e.structs??[])this.struct(t,n);for(let t of e.sgone??[])this.remove(this.structures,t);for(let t of e.wrecks??[])this.wreck(t);for(let t of e.wgone??[])this.remove(this.wrecks,t);for(let t of e.sites??[]){for(;this.sites.length<=t.id;)this.sites.push({id:this.sites.length,x:0,y:0,z:0,richness:0,mine:-2,tick:0});this.sites[t.id]={...t}}for(let t of e.shells??[])this.shells.some(e=>e.id===t.h)||this.shells.push({id:t.h,team:t.team,from:t.from,to:t.to,launchTick:t.launchTick,impactTick:t.impactTick,rod:t.rod,nuke:t.nuke});for(let t of e.projs??[])this.projectiles.push({id:this.nextProjectile++,team:t.team,from:t.from,fromElev:t.fromElev,to:t.to,toElev:t.toElev,launchTick:t.launchTick,impactTick:t.impactTick,damage:0,splash:0,land:!0,sea:!0});for(let t of e.meteors??[])this.impacts.push({id:this.nextId++,x:t.x,y:t.y,z:t.z,land:t.land,impactTick:t.impactTick,warnTick:t.warnTick,shower:t.shower,team:-1});for(let t of e.events??[])this.events.push(t);e.econ&&Object.assign(this.teams[n],e.econ),e.teams&&e.teams.forEach((e,t)=>{let n=this.teams[t];n.started=e.started,n.lost=e.lost,n.faction=e.faction,e.home&&(n.home=e.home)}),e.sun&&(this.sunX=e.sun[0],this.sunY=e.sun[1],this.sunZ=e.sun[2]),e.stats&&(this.stats=e.stats,e.stats.forEach((e,t)=>Object.assign(this.teams[t].stats,e)))}reset(){for(let e=0;e<this.count;e++)this.alive[e]=0,this.seenLevel[e]=0;this.structures.length=0,this.wrecks.length=0,this.shells.length=0,this.projectiles.length=0,this.impacts.length=0}unit(e){let[t,n,r,i,a,o,s,c,l,u,d,f,p,m,h]=e;if(t<0||t>=4096)return;for(;this.count<=t;)this.alive[this.count]=0,this.cargo[this.count]=[],this.buildQueue[this.count]=[],this.patrol[this.count]=null,this.count++;let g=!this.alive[t],_=i/l_,v=a/l_,y=o/l_;this.alive[t]=1,n<0?(this.seenLevel[t]=1,this.team[t]=255):(this.seenLevel[t]=2,this.type[t]=n,this.team[t]=r,this.hp[t]=m,this.elev[t]=this.prevElev[t]=u/10,this.hx[t]=d/d_,this.hy[t]=f/d_,this.hz[t]=p/d_),g?(this.ex[t]=this.ey[t]=this.ez[t]=0,this.x[t]=this.px[t]=_,this.y[t]=this.py[t]=v,this.z[t]=this.pz[t]=y):(this.ex[t]=this.x[t]-_,this.ey[t]=this.y[t]-v,this.ez[t]=this.z[t]-y),this.bx[t]=_,this.by[t]=v,this.bz[t]=y,this.bvx[t]=s/u_,this.bvy[t]=c/u_,this.bvz[t]=l/u_,this.bt[t]=this.serverTick,this.cell[t]=this.planet.cellOf(_,v,y),h?(this.buildTask[t]=h.bt,this.hasOrder[t]=h.ho,this.holdFire[t]=h.hf,this.aggressive[t]=h.ag,this.carriedBy[t]=h.cb,this.cargo[t]=h.cg,this.patrol[t]=h.pt,this.patrolLoop[t]=h.pl,this.buildQueue[t]=h.bq,this.attack[t]=h.at):r!==q.me&&(this.buildTask[t]=-1,this.carriedBy[t]=-1,this.hasOrder[t]=0)}struct(e,t){let n=this.structById(e.h),r=e.x/l_,i=e.y/l_,a=e.z/l_;n||(n={id:e.h,type:e.type,team:e.team,x:r,y:i,z:a,cell:this.planet.cellOf(r,i,a),progress:e.progress,hp:e.hp,alive:!0,complete:!!e.complete,site:e.site??-1,reload:0,aimTarget:-1,target:null,aimE:e.aimE,aimN:e.aimN,warned:!1,idleTicks:0,prod:[],prodProgress:0,rally:null,capWarned:!1},m_(this.structures,n)),n.type=e.type,n.team=e.team,n.x=r,n.y=i,n.z=a,n.hp=e.hp,n.progress=e.progress,n.complete=!!e.complete,n.aimE=e.aimE,n.aimN=e.aimN,n.alive=!0,e.site!==void 0&&(n.site=e.site),e.team===t&&(n.prod=e.prod??[],n.prodProgress=e.prodProgress??0,n.rally=e.rally??null,n.reload=e.reload??0,n.target=e.target??null,e.stock!==void 0&&(n.stock=e.stock))}wreck(e){let t=this.wreckById(e.h),n=e.x/l_,r=e.y/l_,i=e.z/l_;t||(t={id:e.h,x:n,y:r,z:i,cell:this.planet.cellOf(n,r,i),radius:e.radius,metal:e.metal,metal0:e.metal0,alive:!0,from:e.from,type:e.type,hx:e.hx/d_,hy:e.hy/d_,hz:e.hz/d_,tick:e.tick},m_(this.wrecks,t)),t.metal=e.metal,t.alive=!0}remove(e,t){let n=e.findIndex(e=>e.id===t);n>=0&&e.splice(n,1)}advance(e,t){let n=this.serverTick+Math.min(10,(e-this.recvAt)/1e3/f_);this.tick=Math.floor(n);let r=Math.exp(-t*10);for(let e=0;e<this.count;e++){if(!this.alive[e])continue;let t=this.seenLevel[e]===1?0:n-this.bt[e];this.ex[e]*=r,this.ey[e]*=r,this.ez[e]*=r;let i=this.bx[e]+this.bvx[e]*t+this.ex[e],a=this.by[e]+this.bvy[e]*t+this.ey[e],o=this.bz[e]+this.bvz[e]*t+this.ez[e],s=Math.sqrt(i*i+a*a+o*o);i/=s,a/=s,o/=s,this.x[e]=this.px[e]=i,this.y[e]=this.py[e]=a,this.z[e]=this.pz[e]=o}let i=this.tick;h_(this.shells,e=>e.impactTick<i-2),h_(this.projectiles,e=>e.impactTick<i-2),h_(this.impacts,e=>e.impactTick<i-2)}};function m_(e,t){let n=e.length;for(;n>0&&e[n-1].id>t.id;)n--;e.splice(n,0,t)}function h_(e,t){for(let n=e.length-1;n>=0;n--)t(e[n])&&e.splice(n,1)}var g_=[`#3d8bff`,`#ff5a3d`,`#3dff8b`,`#ffd23d`],__={easy:`Easy`,normal:`Normal`,hard:`Hard`},v_={commander:`Commander`,everything:`Everything destroyed`},y_={commander:`A side is out when its Commander is destroyed.`,everything:`A side is out only when all its units and buildings are destroyed.`},b_=e=>e.replace(/[&<>"']/g,e=>`&#${e.charCodeAt(0)};`),x_=e=>Ld[e].split(` (`)[0],S_=class{el=document.getElementById(`mpscreen`);box;lobby;view=`list`;games=[];room=null;status={text:``,ok:!1};error=``;session=null;askPassword=null;form={name:`My game`,win:`commander`,seats:[`open`,`off`,`off`],factions:[`man`,`agi`,`man`],planet:``,resources:`normal`,tech:2,password:``};constructor(){this.box=this.el.querySelector(`.box`),this.lobby=new Cm({status:(e,t)=>{this.status={text:e,ok:t},this.render()},games:e=>{this.games=e,this.view===`list`&&this.render()},room:e=>{this.room=e,this.view=e?`room`:`list`,this.error=``,this.askPassword=null,this.render()},error:e=>{this.error=e,(e===`Password needed`||e===`Wrong password`)&&(this.askPassword??=this.pendingJoin),/host closed/.test(e)&&(this.room=null,this.view=`list`),this.render()},started:e=>this.enterGame(e),session:e=>{this.session=e,e?.phase===`room`&&this.lobby.join(e.match),this.render()}}),this.el.addEventListener(`click`,e=>this.click(e)),this.el.addEventListener(`input`,e=>this.input(e))}pendingJoin=null;show(){this.el.style.display=`flex`,this.lobby.open(),this.render()}hide(){this.room&&this.lobby.leave(),this.lobby.close(),this.el.style.display=`none`}enterGame(e){let t=new URLSearchParams(location.search);t.set(`mp`,e),t.delete(`autostart`),location.href=`${location.pathname}?${t.toString()}`}render(){let e=`<h1>MULTIPLAYER</h1><div class="mp-status ${this.status.ok?`ok`:``}">${b_(this.status.text)}${location.hostname.endsWith(`atollrising.eu`)?` · server ${b_(location.host)}`:``}</div>`+(this.error?`<div class="mp-error">${b_(this.error)}</div>`:``),t=this.view===`create`?this.createHtml():this.view===`room`&&this.room?this.roomHtml(this.room):this.listHtml();this.box.innerHTML=e+t}listHtml(){let e=this.session&&this.session.phase===`playing`?`<div class="mp-rejoin">You are in game ${b_(this.session.match)}. <button data-act="rejoin" class="primary">Rejoin your game</button></div>`:``,t=this.games.map(e=>{let t=e.seats.filter(e=>e===`human`).length,n=e.seats.filter(e=>e===`open`).length,r=e.seats.filter(e=>e===`computer`).length,i=`${t} player${t===1?``:`s`}${r?` + ${r} computer${r===1?``:`s`}`:``}${n?` · ${n} free`:``}`,a=e.phase===`room`?n?``:`full`:e.phase===`playing`?`in progress`:`finished`,o=e.phase===`room`&&n?this.askPassword===e.code?`<input type="password" data-field="pw-${e.code}" placeholder="Password" maxlength="64" class="mp-pw"> <button data-act="join" data-code="${e.code}" class="primary">Join</button>`:`<button data-act="join" data-code="${e.code}">Join</button>`:`<span class="mp-dim">${a}</span>`,s=`<span class="pips">${e.seats.map((e,t)=>`<i style="${e===`open`?`border:1px solid ${g_[t]}`:`background:${g_[t]}`}"></i>`).join(``)}</span>`;return`<tr><td>${e.lock?_m:``}${b_(e.name)}</td><td>${s}${i}</td><td>${v_[e.win]}</td><td>${e.tech===1?`T1 only`:`T1 + T2`}${e.resources===`high`?` · rich start`:``}</td><td>Planet ${e.planet}</td><td>${o}</td></tr>`}).join(``);return e+(this.games.length?`<table class="mp-list"><tr><th>Game</th><th>Players</th><th>Win</th><th>Rules</th><th></th><th></th></tr>${t}</table>`:`<p class="mp-dim">${this.status.ok?`No games yet. Create one!`:``}</p>`)+`<div class="btns"><button data-act="create" class="primary"${this.status.ok?``:` disabled`}>Create game</button><button data-act="close">Back to single player</button><button data-act="servers">All servers</button></div>`}createHtml(){let e=this.form,t=(e,t,n,r)=>`<button data-act="set" data-field="${e}" data-value="${t}" class="${r?`on`:``}">${n}</button>`;return`<table class="mp-form">
      <tr><td>Game name</td><td><input data-field="name" maxlength="30" value="${b_(e.name)}"></td></tr>
      <tr><td>Win condition</td><td>${t(`win`,`commander`,v_.commander,e.win===`commander`)}${t(`win`,`everything`,v_.everything,e.win===`everything`)}<br><small>${y_[e.win]}</small></td></tr>
      <tr><td style="color:${g_[0]}">${x_(0)}</td><td>You (host)</td></tr>
      ${[0,1,2].map(n=>{let r=e.seats[n],i=[[`open`,`Open for a player`],[`easy`,`Easy`],[`normal`,`Normal`],[`hard`,`Hard`],[`off`,`Not in the game`]],a=r===`open`||r===`off`?``:` · ${[`agi`,`man`].map(r=>t(`fac${n}`,r,zd[r].name,e.factions[n]===r)).join(``)}`;return`<tr><td style="color:${g_[n+1]}">${x_(n+1)}</td><td>${i.map(([e,i])=>t(`seat${n}`,e,i,r===e)).join(``)}${a}</td></tr>`}).join(``)}
      <tr><td>Planet</td><td>${t(`planet`,``,`Random`,e.planet===``)} or number <input data-field="planet" inputmode="numeric" maxlength="10" value="${b_(e.planet)}" placeholder="e.g. 1337" class="mp-num"></td></tr>
      <tr><td>Start resources</td><td>${t(`resources`,`normal`,`Normal`,e.resources===`normal`)}${t(`resources`,`high`,`High`,e.resources===`high`)}</td></tr>
      <tr><td>Tech</td><td>${t(`tech`,`1`,`T1 only`,e.tech===1)}${t(`tech`,`2`,`T1 + T2`,e.tech===2)}</td></tr>
      <tr><td>Password</td><td><input data-field="password" type="password" maxlength="64" value="${b_(e.password)}" placeholder="optional: shown with a lock in the list"></td></tr>
    </table>
    <div class="btns"><button data-act="do-create" class="primary"${e.seats.every(e=>e===`off`)?` disabled`:``}>Create game</button><button data-act="back">Back</button></div>`}roomHtml(e){let t=e.detail.map((t,n)=>{let r=t.kind===`open`?`<span class="mp-open">Waiting for a player to join…</span>`:t.kind===`computer`?`Computer · ${__[t.level]} · ${zd[t.faction].name}`:`${n===e.you?`<b>You</b>`:`Player`}${n===0?` (host)`:``} · ${zd[t.faction].name}`;return`<tr><td style="color:${g_[n]}">${x_(n)}</td><td>${r}</td></tr>`}).join(``),n=e.detail[e.you].faction,r=e.detail.filter(e=>e.kind===`open`).length;return`<h2>${e.lock?_m:``}${b_(e.name)}</h2>
      <div class="mp-dim">${v_[e.win]} · ${e.tech===1?`T1 only`:`T1 + T2`} · ${e.resources===`high`?`high`:`normal`} start resources · planet ${e.planet}</div>
      <table class="mp-room">${t}</table>
      <div>Your side: ${[`agi`,`man`].map(e=>`<button data-act="faction" data-value="${e}" class="${n===e?`on`:``}">${zd[e].name}</button>`).join(``)}</div>
      ${r&&e.host?`<div class="mp-wait">Waiting for ${r===1?`a player`:`${r} players`} to join. Other players find this game in their Multiplayer list${e.lock?` (they need the password)`:``}. Start when everyone is here.</div>`:``}
      <div class="btns">${e.host?`<button data-act="start" class="${r?``:`primary`}">${r?`Start now: ${r===1?`the free seat is`:`${r} free seats are`} played by a computer`:`Start`}</button>`:`<span class="mp-dim">Waiting for the host to start…</span>`}<button data-act="leave">${e.host?`Close the game`:`Leave`}</button></div>`}input(e){let t=e.target,n=t.dataset.field;n===`name`?this.form.name=t.value:n===`planet`?(this.form.planet=t.value.replace(/\D/g,``).slice(0,10),this.box.querySelector(`button[data-field="planet"]`)?.classList.toggle(`on`,this.form.planet===``)):n===`password`&&(this.form.password=t.value)}click(e){let t=e.target.closest(`button`);if(!t||t.disabled)return;let n=t.dataset.act,r=this.form;switch(n){case`close`:this.hide();return;case`servers`:location.href=`${vm}#mp`;return;case`create`:this.view=`create`,this.error=``;break;case`back`:this.view=`list`,this.error=``;break;case`rejoin`:this.session&&this.enterGame(this.session.match);return;case`set`:{let e=t.dataset.field,n=t.dataset.value;e===`win`?r.win=n:e===`resources`?r.resources=n:e===`tech`?r.tech=Number(n):e===`planet`?r.planet=``:e.startsWith(`seat`)?r.seats[Number(e.slice(4))]=n:e.startsWith(`fac`)&&(r.factions[Number(e.slice(3))]=n);break}case`do-create`:{let e=[];r.seats.forEach((t,n)=>{t===`open`?e.push({kind:`open`}):t!==`off`&&e.push({kind:`computer`,level:t,faction:r.factions[n]})}),this.lobby.create({name:r.name,win:r.win,seats:e,planet:r.planet?Number(r.planet)>>>0:null,resources:r.resources,tech:r.tech,password:r.password||void 0});return}case`join`:{let e=t.dataset.code;this.pendingJoin=e;let n=this.box.querySelector(`input[data-field="pw-${e}"]`)?.value;if(this.games.find(t=>t.code===e)?.lock&&!n){this.askPassword=e,this.error=`Password needed`;break}this.lobby.join(e,n||void 0);return}case`faction`:this.lobby.faction(t.dataset.value);return;case`start`:this.lobby.start();return;case`leave`:this.lobby.leave();return;default:return}this.render()}};function C_(e=location.hostname){return e===`test.atollrising.eu`?`https://test.atollrising.eu/download/`:`https://atollrising.eu/download/`}function w_(e,t){let n=e=>typeof e==`string`&&/^\d+(\.\d+)*$/.test(e)?e.split(`.`).map(Number):null,r=n(e),i=n(t);if(!r||!i)return r?1:i?-1:0;for(let e=0;e<Math.max(r.length,i.length);e++){let t=(r[e]??0)-(i[e]??0);if(t)return t<0?-1:1}return 0}function T_(e,t=Lm){return w_(e,t)>=0}var E_=e=>e.replace(/[&<>"']/g,e=>`&#${e.charCodeAt(0)};`),D_=class{el=document.getElementById(`mpscreen`);box=this.el.querySelector(`.box`);servers=[];state=`loading`;timer=0;constructor(){this.el.addEventListener(`click`,e=>{let t=e.target.closest(`button`);if(t&&!t.disabled&&this.el.style.display!==`none`){if(t.dataset.act===`close`)this.hide();else if(t.dataset.act===`refresh`)this.load();else if(t.dataset.act===`join`){let e=this.servers.find(e=>e.name===t.dataset.name);e&&e.reachable&&T_(e.version)&&(location.href=`https://${e.host}:${e.port}/#mp`)}}})}show(){this.el.style.display=`flex`,this.load(),clearInterval(this.timer),this.timer=window.setInterval(()=>void this.load(),3e4)}hide(){clearInterval(this.timer),this.el.style.display=`none`}async load(){this.servers.length||(this.state=`loading`,this.render());try{let e=await(await fetch(Sm(),{cache:`no-store`})).json();this.servers=Array.isArray(e.servers)?e.servers.filter(e=>typeof e?.name==`string`&&typeof e.host==`string`):[],this.state=`ok`}catch{this.state=`error`}this.render()}render(){let e=this.servers.length,t=this.state===`loading`?`Looking for servers…`:this.state===`error`?`The server list cannot be reached right now.`:`${e} server${e===1?``:`s`} online`,n=this.servers.map(e=>{let t=T_(e.version),n=e.reachable&&t,r=t?e.reachable?`<span class="ok">Online</span>`:`<span class="mp-dim">Not reachable from the internet</span>`:`<span class="old">Outdated: version ${E_(e.version||`unknown`)}, needs ${Lm}</span>`;return`<tr class="${t?``:`outdated`}">
      <td>${e.official?`<span class="badge">OFFICIAL</span>`:``}${E_(e.title)}<div class="mp-dim">${E_(e.host)}${e.version?` · version ${E_(e.version)}`:``}</div></td>
      <td>${e.players} player${e.players===1?``:`s`} · ${e.games} game${e.games===1?``:`s`}</td>
      <td>${r}</td>
      <td>${t?`<button data-act="join" data-name="${E_(e.name)}" class="${n?`primary`:``}"${n?``:` disabled`}>Join</button>`:``}</td></tr>`}).join(``);this.box.innerHTML=`<h1>MULTIPLAYER</h1>
      <div class="mp-status ${this.state===`ok`?`ok`:``}">${t}</div>
      ${e?`<table class="mp-list"><tr><th>Server</th><th>Now</th><th>Status</th><th></th></tr>${n}</table>`:this.state===`ok`?`<p class="mp-dim">No servers are running right now. Host one yourself:</p>`:``}
      <div class="sect">HOST YOUR OWN SERVER</div>
      <div class="mp-dim">Download the server for Windows or Linux, unpack it and run it. Forward one TCP port on your router (25564 unless you change it). It gets its own address and certificate and shows up in this list by itself. The server runs the games, so whoever runs it can see everything in them.</div>
      <div class="btns"><a class="btnlink" href="${C_()}" target="_blank" rel="noopener">Download the server</a><button data-act="refresh">Refresh</button><button data-act="close">Back to single player</button></div>`}};function O_(e){let t=document.getElementById(`settings`),n=document.getElementById(`set-sound`),r=document.getElementById(`set-quality`),i=document.getElementById(`set-help`);e.multiplayer?t.querySelectorAll(`.sp-only`).forEach(e=>e.remove()):t.querySelectorAll(`.mp-only`).forEach(e=>e.remove());let a=(e,t,n)=>{let r=document.getElementById(e);if(!r)return;if(!n){r.remove();return}let i=r.textContent??``,a=!1;r.addEventListener(`click`,()=>{a?n():(a=!0,r.textContent=t,r.classList.add(`on`),setTimeout(()=>{a=!1,r.textContent=i,r.classList.remove(`on`)},4e3))})};a(`btn-quit`,`Click again to leave`,e.quit),a(`btn-end`,`Click again: close for all`,e.host?e.end:void 0);let o=[`Auto`,`High`,`Medium`,`Low`],s=o.map(t=>{let n=document.createElement(`button`);return n.textContent=t,n.addEventListener(`click`,()=>{e.quality.set(t),c()}),r.append(n),n}),c=()=>s.forEach((t,n)=>t.classList.toggle(`on`,e.quality.level===o[n])),l=()=>{i.textContent=e.help.open?`Shown`:`Folded`,i.classList.toggle(`on`,e.help.open)};e.help.onChange=l,i.addEventListener(`click`,()=>e.help.flip());let u=()=>{let r=document.createElement(`div`);r.className=`note`,r.innerHTML=a_,n.replaceChildren(...i_(e.audio,e.soundChanged),r),c(),l(),t.style.display=`flex`},d=()=>{t.style.display=`none`};return document.getElementById(`btn-menu`)?.addEventListener(`click`,e=>{e.stopPropagation(),u()}),document.getElementById(`set-done`)?.addEventListener(`click`,d),t.addEventListener(`keydown`,e=>{e.stopPropagation(),e.key===`Escape`&&d()}),window.addEventListener(`keydown`,e=>{e.key===`Escape`&&t.style.display===`flex`&&(d(),e.stopImmediatePropagation())},!0),t.addEventListener(`pointerdown`,e=>e.stopPropagation()),{show:u,hide:d}}var k_=new URLSearchParams(location.search);document.body.classList.toggle(`dev`,k_.has(`dev`));{let e=document.getElementById(`brand-emblem`);e&&(e.outerHTML=gm(34))}var A_=``,j_=k_.get(`mp`)?await wm().catch(e=>(A_=e.message,null)):null,M_=j_?j_.joined.seed:Number(k_.get(`seed`)??1337)>>>0;q.me=j_?j_.joined.seat:Math.min(3,Math.max(0,(Number(k_.get(`side`)??1)|0)-1));var N_=performance.now(),P_=new gd({seed:M_}),F_=j_?new p_(P_):null,I_=F_??new mm(P_);F_?j_.attach(F_):(I_.setupPracticeTargets(3),I_.enableAi());var L_=performance.now()-N_,R_=Ah(P_,M_),{renderer:z_,camera:B_,sky:V_,clouds:H_,cloudBake:U_}=R_,W_=new Jg(I_,P_,R_),G_=new Yg(W_,z_.domElement),K_=R_.daylight;K_.addCasters(W_.unitsView.group,W_.worldView.group,W_.vegetation.group),W_.worldView.effects.group.userData.noShadow=!0;var q_=new r_(z_,document.getElementById(`btn-quality`));q_.onApply=e=>{K_.effects=e,K_.setSize(window.innerWidth,window.innerHeight)},q_.apply();var J_=P_.blobs.find(e=>e.kind===`large`)??P_.blobs[0];W_.gcam.focusOn(new L(...J_.c),5200),W_.gcam.zoom(2600/5200);var Y_=new Im(I_,M_);Y_.multiplayer=!!j_;var X_=new e_(W_);if(G_.fp=X_,W_.match=Y_,j_&&(W_.awaitCommander=!0),j_)for(let e of[`btn-stress`,`btn-chaos`,`btn-dev`,`btn-enemy`,`btn-seed`])document.getElementById(e)?.remove();var Z_=`<div class="kicker">${gm(40)}<span>SIGNAL ACQUIRED</span></div><div class="title">ATOLL<br>RISING</div><div class="ver">VERSION ${Lm}</div>`,Q_=(e,t,n,r=``,i=!1)=>`<button id="${t}" class="mitem${i?` primary`:``}"><span class="n">${e}</span><span class="t"><span class="disp">${n}</span>${r?`<small id="${t}-sub">${r}</small>`:``}</span>${i?`<span class="go">›</span>`:``}</button>`,$_=(e,t)=>`<div class="land"><b>${e}</b><br>${t}</div>`;W_.ui.setOverlay(j_?`${Z_}<nav class="mainmenu">${Q_(`01`,`btn-settings-start`,`SETTINGS`)}</nav><div class="setup" id="setup">${Y_.startHtml(!0)}</div>`+$_(`MULTIPLAYER GAME ${j_.joined.match}: CHOOSE WHERE TO LAND`,`You are ${[`Player 1 (blue)`,`Player 2 (red)`,`Player 3 (green)`,`Player 4 (yellow)`][q.me]}. Spin the globe with right-drag, zoom with the wheel, then left-click a spot on an island.<br><small>Computer players land once every human has.</small>`):`${Z_}<div class="lead">Land on an ocean world, mine the meteor craters and take the islands, one atoll at a time.</div><nav class="mainmenu">${Q_(`01`,`btn-sp`,`SINGLE PLAYER`,Y_.summary(),!0)}${Q_(`02`,`btn-mp`,`MULTIPLAYER`)}${Q_(`03`,`btn-setup`,`GAME SETUP`)}${Q_(`04`,`btn-settings-start`,`SETTINGS`)}</nav><div class="setup" id="setup">${Y_.startHtml()}<div class="btns"><button id="btn-setup-done" class="primary">DONE</button></div></div><div class="landing">${$_(`CHOOSE WHERE TO LAND`,`Spin the globe with right-drag, zoom with the wheel, then left-click a spot on an island.<br><small>Meteors will rain down around your landing site — their craters hold the metal you need.</small>`)}<button id="btn-sp-back">‹ BACK</button></div><div class="zone"><b class="disp">LANDING ZONE · NOT SET</b><br>Pick an island on the globe to land</div>`);{let e=document.getElementById(`overlay`);e.classList.add(`start`);let t=document.createElement(`div`);t.id=`start-rings`,t.innerHTML=`<svg viewBox="-100 -100 200 200" preserveAspectRatio="xMidYMid meet" aria-hidden="true"><circle r="72" class="r1"/><circle r="82" class="r2"/><circle r="94" class="r3"/><path d="M0 -99V-91M0 91V99M-99 0H-91M91 0H99" class="tick"/></svg>`,document.body.append(t);let n=t=>{e.dataset.mode=t};j_||n(`menu`);let r=(e,t)=>document.getElementById(e)?.addEventListener(`click`,e=>{e.stopPropagation(),t()});r(`btn-sp`,()=>n(`landing`)),r(`btn-sp-back`,()=>n(`menu`)),r(`btn-setup`,()=>n(e.dataset.mode===`setup`?`menu`:`setup`)),r(`btn-setup-done`,()=>n(`menu`)),Y_.onChange=()=>{let e=document.getElementById(`btn-sp-sub`);e&&(e.textContent=Y_.summary())}}Y_.bindStart(document.getElementById(`overlay`));var ev=bm()?new S_:new D_;document.getElementById(`btn-mp`)?.addEventListener(`click`,e=>{e.stopPropagation(),ev.show()}),(location.hash===`#mp`||A_)&&(ev.show(),history.replaceState(null,``,location.pathname+location.search.replace(/[?&]mp=[^&]*/,``))),A_&&W_.ui.toast(A_),Number(k_.get(`units`)??0)>0&&I_.spawnStress(Number(k_.get(`units`)),0,M_+2),window.addEventListener(`resize`,()=>{B_.aspect=window.innerWidth/window.innerHeight,B_.updateProjectionMatrix(),q_.apply()});var tv=!1,nv=0,rv=new sd(M_+9),iv=(e,t)=>{let n=document.getElementById(e);n?.addEventListener(`click`,()=>t(n))};iv(`btn-stress`,()=>I_.spawnStress(1200,0,M_+I_.count)),iv(`btn-chaos`,e=>{tv=!tv,e.textContent=`Random orders: ${tv?`on`:`off`}`}),iv(`btn-edge`,e=>{G_.edgeScroll=!G_.edgeScroll,e.textContent=`Edge scroll: ${G_.edgeScroll?`on`:`off`}`}),iv(`btn-clouds`,e=>{H_.visible=!H_.visible,V_.uCloudShadows.value=+!!H_.visible,e.textContent=`Clouds: ${H_.visible?`on`:`off`}`}),iv(`btn-seed`,()=>{sv.allow();let e=new URLSearchParams(location.search);e.set(`seed`,String(Math.random()*1e9>>>0)),location.search=e.toString()}),iv(`btn-dev`,()=>{I_.teams[q.me].started&&(I_.enqueue({kind:`dev-resources`,team:q.me}),W_.ui.toast(`Dev: storage and resources maxed (for testing Horizon)`))});var av=o_(document.getElementById(`btn-sound`),W_.audio),ov=!1,sv=new Rm(()=>I_.teams[q.me].started&&!Y_.over&&!ov),cv=()=>{sv.allow(),location.href=`${vm}#mp`},lv=O_({audio:W_.audio,quality:q_,help:c_(),multiplayer:!!j_,soundChanged:av.refresh,host:j_?.joined.seat===0,quit:j_?()=>{j_.send({t:`quit`}),setTimeout(cv,300)}:void 0,end:j_?()=>{j_.send({t:`end`}),setTimeout(cv,300)}:void 0});j_&&(j_.onEnded=e=>{ov=!0;let t=document.getElementById(`endscreen`);t.querySelector(`.box`).innerHTML=`<h1>GAME CLOSED</h1><div>${e}.</div><div class="btns"><button id="ended-home" class="primary">Back to Atoll Rising</button></div>`,t.style.display=`flex`,document.getElementById(`ended-home`).onclick=cv}),document.getElementById(`btn-settings-start`)?.addEventListener(`click`,e=>{e.stopPropagation(),lv.show()}),document.addEventListener(`click`,e=>{e.target.closest(`button`)&&W_.audio.ui(`click`)}),iv(`btn-fog`,e=>{W_.fog.enabled=!W_.fog.enabled,e.textContent=`Fog of war: ${W_.fog.enabled?`on`:`off`}`}),iv(`btn-enemy`,()=>{if(!I_.teams[q.me].started)return;let e=W_.pick(window.innerWidth/2,window.innerHeight/2);e?(I_.enqueue({kind:`dev-spawn-enemy`,team:q.me===1?0:1,target:[e.x,e.y,e.z]}),W_.ui.toast(I_.planet.land[I_.planet.cellOf(e.x,e.y,e.z)]?`Dev: enemy tanks and drones placed at screen centre`:`Dev: enemy destroyers and drones placed at screen centre`)):W_.ui.toast(`Point the camera at the planet first`)});var uv=document.getElementById(`stats`),dv=z_.getContext()instanceof WebGL2RenderingContext?`WebGL2`:`WebGL1`,fv=performance.now(),pv=0,mv=0,hv=0,gv=0,_v=0,vv=0,yv=0,bv=``;function xv(e){let t=Math.min(.1,(e-fv)/1e3);fv=e,mv+=t,G_.updateCamera(t);{let e=W_.ui.overlayShown()?`${window.innerWidth}x${window.innerHeight}`:``;if(e!==bv){bv=e,e?B_.setViewOffset(window.innerWidth,window.innerHeight,-.18*window.innerWidth,0,window.innerWidth,window.innerHeight):B_.clearViewOffset();let t=document.getElementById(`start-rings`);t&&(t.style.display=e?`block`:`none`)}}if(tv&&(nv-=t)<=0){nv=2.5;let e=[];for(let t=0;t<Math.min(300,I_.count);t++)e.push(rv.int(I_.count));I_.enqueue({kind:`move`,ids:e,target:rv.dir()})}F_&&F_.advance(e,t),pv+=t;let n=0;for((Y_.paused||F_)&&(pv=0);pv>=.05&&n<5&&!F_;)I_.step(),vv=vv*.95+I_.lastStepMs*.05,yv=Math.max(yv*.995,I_.lastStepMs),pv-=Ud,n++;n===5&&(pv=0),Y_.update();let r=pv/Ud,i=W_.gcam;i.update(t),X_.updateCamera(B_,r);let a=W_.worldView.effects.shake;if(a>.02){let e=a*Math.min(3,400/Math.max(50,i.dist));B_.position.add(new L((Math.random()-.5)*e,(Math.random()-.5)*e,(Math.random()-.5)*e))}if(V_.uTime.value=mv,H_.visible&&U_.step(z_,mv),V_.uPixelAngle.value=2*Math.tan(Pt.degToRad(B_.fov)/2)/window.innerHeight,V_.uCamHeight.value=i.heightAboveSurface(),W_.update(t,r),K_.update(t,[I_.sunX,I_.sunY,I_.sunZ],i.f,i.dist,P_.radius),K_.render(),q_.frame(t),hv++,gv+=t,gv>=.5){_v=hv/gv,hv=0,gv=0;let e=[...W_.selected],t=e.length===1?G[I_.type[e[0]]].name:`${e.length} units`;uv.textContent=`FPS ${_v.toFixed(0)}  ·  ${z_.domElement.width}×${z_.domElement.height} px (${dv}) · render scale ${Math.round(q_.scale*100)}%\nSim tick ${vv.toFixed(2)} ms avg · ${yv.toFixed(1)} ms worst · last path field ${I_.lastFieldMs.toFixed(0)} ms\nUnits ${I_.count} · selected: ${e.length?t:`none`} · metal sites ${I_.sites.length} · meteors incoming ${I_.impacts.length} · wrecks ${I_.wrecks.filter(e=>e.alive).length} · shells ${I_.projectiles.length}\nPlanet seed ${M_} · ${P_.blobs.length} islands · generated in ${L_.toFixed(0)} ms · height bake ${R_.bakeMs.toFixed(0)} ms`}requestAnimationFrame(xv)}requestAnimationFrame(xv),k_.get(`autostart`)&&W_.placeStart(new L(...J_.c).normalize()),window.__blue={world:I_,planet:P_,game:W_,sky:V_,camera:B_,gcam:W_.gcam,selected:W_.selected,unitsView:W_.unitsView,worldView:W_.worldView,unitScreen:e=>W_.unitScreen(e),issueMove:(e,t)=>W_.issueOrder(e,t),placeStart:e=>W_.placeStart(e),startPlacing:e=>W_.startPlacing(e),get selectedStruct(){return W_.selectedStruct},set selectedStruct(e){W_.selectedStruct=e},issueOrderAt:(e,t)=>W_.issueOrder(e,t),fog:W_.fog,match:Y_,fp:X_,net:j_,verifyHeight:()=>Km(z_,P_,R_.heightBake.rt,R_.heightBake.offset),heightFloat:R_.heightBake.offset===0,get fps(){return _v}};